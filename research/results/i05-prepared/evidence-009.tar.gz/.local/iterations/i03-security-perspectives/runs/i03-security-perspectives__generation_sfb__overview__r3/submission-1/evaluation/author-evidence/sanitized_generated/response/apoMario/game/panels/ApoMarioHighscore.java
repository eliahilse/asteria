package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Persistent, score-ordered snapshots of completed runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;
        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0 || playerName == null) {
            return false;
        }
        String name = playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        if (name.length() > 64) {
            name = name.substring(0, 64);
        }
        entries.add(new Entry(name, score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.survivalTime);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                writer.write("APOMARIO_HIGHSCORE_1");
                writer.newLine();
                for (Entry entry : entries) {
                    writer.write(Base64.getEncoder().encodeToString(entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A failed write must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APOMARIO_HIGHSCORE_1".equals(reader.readLine())) return;
                String line;
                while ((line = reader.readLine()) != null && entries.size() < MAX_ENTRIES) {
                    String[] parts = line.split("\\t", -1);
                    if (parts.length != 3) continue;
                    try {
                        String name = new String(Base64.getDecoder().decode(parts[0]), StandardCharsets.UTF_8);
                        int score = Integer.parseInt(parts[1]);
                        int time = Integer.parseInt(parts[2]);
                        if (name.length() > 0 && name.length() <= 64 && time >= 0) {
                            entries.add(new Entry(name, score, time));
                        }
                    } catch (IllegalArgumentException ex) {
                        // Ignore one malformed record and continue loading the board.
                    }
                }
            } finally {
                reader.close();
            }
            sortAndLimit();
        } catch (IOException ex) {
            entries.clear();
        }
    }

    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
}