package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private final Set<ApoMarioLevel> recordedLevels = Collections.newSetFromMap(new IdentityHashMap<ApoMarioLevel, Boolean>());

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 80) name = name.substring(0, 80);
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
                writer.write("APO_MARIO_HIGHSCORE_1");
                writer.newLine();
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.time));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }
        } catch (IOException ignored) {
            // A failed save must not stop the game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level)) return;
        recordedLevels.add(level);
        try {
            ApoMarioPlayer selected = null;
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && player.isBVisible() && player.getAi() == null) {
                    selected = player;
                    break;
                }
            }
            if (selected == null && level.getPlayers() != null && !level.getPlayers().isEmpty()) {
                selected = level.getPlayers().get(0);
            }
            if (selected != null) {
                String name = selected.getTeamName();
                if (name == null || name.trim().length() == 0) name = "Player";
                storeRun(selected.getPoints(), level.getPassedTime(), name);
            }
        } catch (RuntimeException ignored) {
            // Terminal processing must remain safe even for partially built levels.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            if (!"APO_MARIO_HIGHSCORE_1".equals(reader.readLine())) return;
            String line;
            while ((line = reader.readLine()) != null && runs.size() < MAX_ENTRIES) {
                String[] parts = line.split("\\t", 3);
                if (parts.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8);
                    if (name.length() > 80) name = name.substring(0, 80);
                    runs.add(new Run(Integer.parseInt(parts[0]), Math.max(0, Integer.parseInt(parts[1])), name));
                } catch (IllegalArgumentException ignored) { }
            }
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
}