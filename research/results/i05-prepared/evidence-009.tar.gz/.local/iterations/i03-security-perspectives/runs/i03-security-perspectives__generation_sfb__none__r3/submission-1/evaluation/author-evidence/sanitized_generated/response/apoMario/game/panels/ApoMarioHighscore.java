package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, points-ordered results for completed runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 20;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    /** Records the best real player result in the finished level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (best == null || player.getPoints() > best.getPoints())) {
                best = player;
            }
        }
        if (best == null) {
            best = level.getPlayers().get(0);
        }
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = best.getAuthor();
        }
        storeRun(best.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    /** Survival times are milliseconds; formatting belongs to the view. */
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.survivalTime);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.write('\t');
                    writer.write(entry.name.replace("\t", " ").replace("\n", " "));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
        } catch (IOException ignored) {
            // A highscore must never stop the game if its store is unavailable.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", 3);
                    if (parts.length == 3) {
                        try {
                            entries.add(new Entry(parts[2], Integer.parseInt(parts[0]), Integer.parseInt(parts[1])));
                        } catch (NumberFormatException ignored) { }
                    }
                }
            } finally {
                reader.close();
            }
            sortAndLimit();
        } catch (IOException ignored) { }
    }

    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry left, Entry right) {
                return right.score < left.score ? -1 : (right.score == left.score ? 0 : 1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;
        private Entry(String name, int score, int survivalTime) {
            this.name = name == null || name.length() == 0 ? "Player" : name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}