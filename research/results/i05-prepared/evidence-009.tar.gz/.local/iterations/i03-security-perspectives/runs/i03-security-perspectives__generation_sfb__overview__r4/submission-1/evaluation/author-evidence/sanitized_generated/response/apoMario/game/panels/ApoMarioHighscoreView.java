package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores, int width) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, 20, width * 3 / 4, 200, 15, 15);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, 20, width * 3 / 4, 200, 15, 15);
        g.drawString("HIGHSCORES  (H or ESC to return)", width / 8 + 15, 45);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 8; i++) {
            int ms = times.get(i);
            int seconds = ms / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), width / 8 + 18, 68 + i * 18);
            g.drawString(Integer.toString(points.get(i)), width / 2, 68 + i * 18);
            g.drawString(time, width * 3 / 4 - 55, 68 + i * 18);
        }
    }
}