package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 64) name = name.substring(0, 64);
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                writer.write("APOMARIO_HIGHSCORE_1");
                writer.newLine();
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score)); writer.write('\t');
                    writer.write(Integer.toString(run.time)); writer.write('\t');
                    writer.write(java.util.Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A failed save must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APOMARIO_HIGHSCORE_1".equals(reader.readLine())) return;
                String line;
                while ((line = reader.readLine()) != null && runs.size() < MAX_ENTRIES) {
                    String[] parts = line.split("\\t", -1);
                    if (parts.length != 3) continue;
                    try {
                        int score = Integer.parseInt(parts[0]);
                        int time = Integer.parseInt(parts[1]);
                        String name = new String(java.util.Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8);
                        if (name.length() > 0 && name.length() <= 64) runs.add(new Run(score, Math.max(0, time), name));
                    } catch (RuntimeException ex) { /* ignore malformed records */ }
                }
            } finally { reader.close(); }
            sortAndLimit();
        } catch (IOException ex) { runs.clear(); }
    }

    private void sortAndLimit() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    /** Records the first human player in the completed level. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && player.getAi() == null) { chosen = player; break; }
        }
        if (chosen == null && !level.getPlayers().isEmpty()) chosen = level.getPlayers().get(0);
        if (chosen == null) return;
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = chosen.getAuthor();
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }
}