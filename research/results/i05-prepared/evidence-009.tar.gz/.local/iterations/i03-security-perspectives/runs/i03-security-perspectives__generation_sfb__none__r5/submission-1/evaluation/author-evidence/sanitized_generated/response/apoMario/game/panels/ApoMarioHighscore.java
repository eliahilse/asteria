package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, score-descending highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name;
        final int score;
        final int time;
        Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }
        playerName = playerName.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
        entries.add(new Entry(playerName, score, Math.max(0, survivalTime)));
        sort();
        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Records the best real player in the finished level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (best == null || player.getPoints() > best.getPoints())) best = player;
        }
        if (best == null) best = level.getPlayers().get(0);
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(best.getPoints(), level.getPassedTime(), name);
    }

    public static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.drawString("HIGHSCORES", x, y);
        List<String> names = getPlayersNames();
        List<Integer> scores = getPlayersScores();
        List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            g.drawString((i + 1) + ". " + names.get(i), x, y + 22 * (i + 1));
            g.drawString(String.valueOf(scores.get(i)), x + width - 105, y + 22 * (i + 1));
            g.drawString(formatTime(times.get(i)), x + width - 50, y + 22 * (i + 1));
        }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length == 3) {
                    try { entries.add(new Entry(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]))); }
                    catch (NumberFormatException ignored) { }
                }
            }
            reader.close();
            sort();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            for (Entry e : entries) writer.write(e.name + "\t" + e.score + "\t" + e.time + "\n");
            writer.close();
            return true;
        } catch (IOException ignored) {
            return false;
        }
    }
}