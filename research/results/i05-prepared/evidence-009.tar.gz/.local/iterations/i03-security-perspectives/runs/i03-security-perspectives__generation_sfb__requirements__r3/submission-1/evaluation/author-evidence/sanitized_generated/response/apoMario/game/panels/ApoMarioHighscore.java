package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private static final int MAX_LINE_LENGTH = 512;

    private static final class Run {
        String name;
        int score;
        int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first active player's finalized result at a level terminal. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.time));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A full/read-only store must never stop the game; the entry remains in memory.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                int count = 0;
                while (count < MAX_ENTRIES && (line = reader.readLine()) != null) {
                    if (line.length() > MAX_LINE_LENGTH) continue;
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3) continue;
                    try {
                        String name = cleanName(new String(Base64.getDecoder().decode(fields[0]), StandardCharsets.UTF_8));
                        int score = Integer.parseInt(fields[1]);
                        int time = Integer.parseInt(fields[2]);
                        if (name != null && score >= 0 && time >= 0) { runs.add(new Run(name, score, time)); count++; }
                    } catch (IllegalArgumentException ex) { /* ignore corrupt record */ }
                }
            } finally { reader.close(); }
            sortAndTrim();
        } catch (IOException ex) { /* missing/corrupt stores are treated as empty */ }
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                int result = Integer.compare(b.score, a.score);
                if (result != 0) return result;
                return a.name.compareTo(b.name);
            }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private static String cleanName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return null;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return null;
        return name;
    }

    public static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    public void render(Graphics2D g, int x, int y, int width) {
        g.drawString("HIGHSCORES", x, y);
        List<String> names = getPlayersNames();
        List<Integer> scores = getPlayersScores();
        List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            g.drawString((i + 1) + ". " + names.get(i), x, y + 22 + i * 18);
            g.drawString(Integer.toString(scores.get(i)), x + width / 2, y + 22 + i * 18);
            g.drawString(formatTime(times.get(i)), x + width - 55, y + 22 + i * 18);
        }
    }
}