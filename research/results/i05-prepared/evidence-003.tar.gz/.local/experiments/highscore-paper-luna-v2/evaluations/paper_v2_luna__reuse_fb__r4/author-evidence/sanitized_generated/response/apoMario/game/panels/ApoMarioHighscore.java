package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int FILE_VERSION = 1;
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store must not be null");
		}
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 40) {
			name = name.substring(0, 40);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		if (this.playersNames.size() > MAX_ENTRIES) {
			this.playersNames.subList(MAX_ENTRIES, this.playersNames.size()).clear();
			this.playersScores.subList(MAX_ENTRIES, this.playersScores.size()).clear();
			this.survivalTimes.subList(MAX_ENTRIES, this.survivalTimes.size()).clear();
		}
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		Path parent = this.store.getParent();
		try {
			if (parent != null) {
				Files.createDirectories(parent);
			}
			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			DataOutputStream output = new DataOutputStream(
					new BufferedOutputStream(Files.newOutputStream(temporary)));
			try {
				output.writeInt(FILE_VERSION);
				output.writeInt(this.playersNames.size());
				for (int i = 0; i < this.playersNames.size(); i++) {
					output.writeUTF(this.playersNames.get(i));
					output.writeInt(this.playersScores.get(i).intValue());
					output.writeInt(this.survivalTimes.get(i).intValue());
				}
			} finally {
				output.close();
			}
			try {
				Files.move(temporary, this.store, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
						java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player != null && player.isBVisible()) {
				if (selected == null || player.getPoints() > selected.getPoints()) {
					selected = player;
				}
			}
		}
		if (selected == null) {
			selected = level.getPlayers().get(0);
		}
		if (selected == null) {
			return;
		}

		String name = selected.getTeamName();
		if (name == null || name.trim().length() == 0) {
			if (selected.getAi() != null) {
				name = selected.getAi().getAuthor();
			}
		}
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		int survivalTime;
		try {
			survivalTime = level.getPassedTime();
		} catch (RuntimeException ex) {
			survivalTime = Math.max(0, level.getStartTime() - level.getTime());
		}
		this.storeRun(selected.getPoints(), survivalTime, name);
	}

	public static String formatSurvivalTime(int milliseconds) {
		long seconds = Math.max(0L, milliseconds) / 1000L;
		long minutes = seconds / 60L;
		long remainingSeconds = seconds % 60L;
		return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(remainingSeconds));
	}

	private void load() {
		if (!Files.isRegularFile(this.store)) {
			return;
		}
		try {
			DataInputStream input = new DataInputStream(
					new BufferedInputStream(Files.newInputStream(this.store)));
			try {
				if (input.readInt() != FILE_VERSION) {
					return;
				}
				int count = input.readInt();
				if (count < 0 || count > MAX_ENTRIES * 10) {
					return;
				}
				for (int i = 0; i < count; i++) {
					this.playersNames.add(input.readUTF());
					this.playersScores.add(Integer.valueOf(input.readInt()));
					this.survivalTimes.add(Integer.valueOf(Math.max(0, input.readInt())));
				}
			} finally {
				input.close();
			}
			this.sort();
			while (this.playersNames.size() > MAX_ENTRIES) {
				int last = this.playersNames.size() - 1;
				this.playersNames.remove(last);
				this.playersScores.remove(last);
				this.survivalTimes.remove(last);
			}
		} catch (IOException | RuntimeException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			order.add(Integer.valueOf(i));
		}
		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						playersScores.get(second.intValue()).intValue(),
						playersScores.get(first.intValue()).intValue());
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return Integer.compare(first.intValue(), second.intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();
		for (Integer index : order) {
			names.add(this.playersNames.get(index.intValue()));
			scores.add(this.playersScores.get(index.intValue()));
			times.add(this.survivalTimes.get(index.intValue()));
		}
		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}
}