package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

public class ApoMarioHighscore {

    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final List<Run> runs;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.runs.add(new Run(score, time, name));
        sortRuns();

        try {
            this.persistAcrossRuns();
            return true;
        } catch (RuntimeException ex) {
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (Run run : this.runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encode(run.name));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
            throw new IllegalStateException("Unable to persist highscores", ex);
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int elapsedMilliseconds = Math.max(0, level.getStartTime() - level.getTime());
        int survivalTime = elapsedMilliseconds / 1000;
        String playerName = findPlayerName(player);

        this.storeRun(score, survivalTime, playerName);
    }

    public synchronized String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        List<Run> loaded = new ArrayList<Run>();

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                if (survivalTime < 0) {
                    throw new IOException("Invalid survival time");
                }

                String name = normalizeName(decode(values[2]));
                loaded.add(new Run(score, survivalTime, name));
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            sortRuns();
        } catch (Exception ex) {
            this.runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private String findPlayerName(ApoMarioPlayer player) {
        String name = invokeString(player, "getName");
        if (name == null) {
            name = invokeString(player, "getPlayerName");
        }
        if (name == null) {
            name = invokeString(player, "getTeamName");
        }

        if (name == null && player.getAi() != null) {
            name = invokeString(player.getAi(), "getAuthor");
            if (name == null) {
                name = invokeString(player.getAi(), "getTeamName");
            }
        }

        return normalizeName(name);
    }

    private String invokeString(Object object, String methodName) {
        try {
            Object value = object.getClass().getMethod(methodName).invoke(object);
            if (value instanceof String && ((String) value).trim().length() > 0) {
                return ((String) value).trim();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private String normalizeName(String name) {
        if (name == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String normalized = name.replace('\t', ' ')
                .replace('\r', ' ')
                .replace('\n', ' ')
                .trim();

        if (normalized.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }

        return normalized;
    }

    private String encode(String value) {
        return value.replace("\\", "\\\\")
                .replace("\t", "\\t")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }

    private String decode(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);

            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == 'r') {
                    result.append('\r');
                } else if (character == 'n') {
                    result.append('\n');
                } else {
                    result.append(character);
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }

        return result.toString();
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}