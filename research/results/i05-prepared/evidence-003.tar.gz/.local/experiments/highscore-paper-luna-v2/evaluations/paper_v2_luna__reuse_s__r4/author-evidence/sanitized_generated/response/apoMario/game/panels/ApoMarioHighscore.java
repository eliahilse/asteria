package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String SEPARATOR = "\t";

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sort();
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return new ArrayList<String>(this.playersNames);
	}

	public synchronized List<Integer> getPlayersScores() {
		return new ArrayList<Integer>(this.playersScores);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return new ArrayList<Integer>(this.survivalTimes);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			BufferedWriter writer = Files.newBufferedWriter(
					temporary,
					StandardCharsets.UTF_8);

			try {
				for (int i = 0; i < this.playersNames.size(); i++) {
					String encodedName = Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(encodedName);
					writer.write(SEPARATOR);
					writer.write(String.valueOf(this.playersScores.get(i).intValue()));
					writer.write(SEPARATOR);
					writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
					writer.newLine();
				}
			} finally {
				writer.close();
			}

			try {
				Files.move(
						temporary,
						this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING,
						java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(
						temporary,
						this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(
						this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = player.getAuthor();
		}
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		int survivalTime;
		try {
			survivalTime = level.getPassedTime();
		} catch (RuntimeException ex) {
			survivalTime = level.getStartTime() - level.getTime();
		}

		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.storeRun(player.getPoints(), survivalTime, name);
	}

	public synchronized String getSurvivalTimeText(int index) {
		if (index < 0 || index >= this.survivalTimes.size()) {
			return "00:00";
		}
		return formatSurvivalTime(this.survivalTimes.get(index).intValue());
	}

	public static String formatSurvivalTime(int milliseconds) {
		if (milliseconds < 0) {
			milliseconds = 0;
		}

		int seconds = milliseconds / 1000;
		int minutes = seconds / 60;
		seconds %= 60;

		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			BufferedReader reader = Files.newBufferedReader(
					this.store,
					StandardCharsets.UTF_8);

			try {
				String line;
				while ((line = reader.readLine()) != null) {
					String[] values = line.split(SEPARATOR, -1);
					if (values.length != 3) {
						continue;
					}

					String name = new String(
							Base64.getDecoder().decode(values[0]),
							StandardCharsets.UTF_8);
					int score = Integer.parseInt(values[1]);
					int survivalTime = Integer.parseInt(values[2]);

					if (survivalTime < 0) {
						survivalTime = 0;
					}

					this.playersNames.add(name);
					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(survivalTime));
				}
			} finally {
				reader.close();
			}

			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		} catch (RuntimeException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return Integer.compare(first.intValue(), second.intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			names.add(this.playersNames.get(index.intValue()));
			scores.add(this.playersScores.get(index.intValue()));
			times.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics;
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());

		g.setColor(Color.BLACK);
		g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
		g.drawString("Highscore", 20, 30);

		g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
		int y = 60;

		for (int i = 0; i < this.playersNames.size(); i++) {
			String line = (i + 1) + ". "
					+ this.playersNames.get(i)
					+ "  "
					+ this.playersScores.get(i)
					+ "  "
					+ formatSurvivalTime(this.survivalTimes.get(i).intValue());

			g.drawString(line, 20, y);
			y += 22;

			if (y > this.getHeight() - 10) {
				break;
			}
		}
	}
}