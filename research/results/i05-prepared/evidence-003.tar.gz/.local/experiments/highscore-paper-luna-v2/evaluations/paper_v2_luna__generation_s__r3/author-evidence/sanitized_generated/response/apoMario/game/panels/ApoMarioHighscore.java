package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_PLAYER_NAME = "Player";
	private static final int DEFAULT_WIDTH = 320;
	private static final int DEFAULT_HEIGHT = 240;

	private final Path store;
	private final ArrayList<Entry> entries;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.entries = new ArrayList<Entry>();
		this.load();
		setOpaque(true);
		setBackground(Color.WHITE);
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.entries.add(new Entry(name, score, survivalTime));
		this.sortEntries();
		this.persistAcrossRuns();
		repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		ArrayList<String> result = new ArrayList<String>();
		for (Entry entry : this.entries) {
			result.add(entry.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			StringBuilder data = new StringBuilder();
			for (Entry entry : this.entries) {
				String encodedName = Base64.getEncoder().encodeToString(
						entry.name.getBytes(StandardCharsets.UTF_8));
				data.append(encodedName)
					.append('\t')
					.append(entry.score)
					.append('\t')
					.append(entry.survivalTime)
					.append('\n');
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			Files.write(temporary, data.toString().getBytes(StandardCharsets.UTF_8));

			try {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException atomicMoveFailure) {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			// A failed save must not interrupt the game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null) {
				continue;
			}
			if (selected == null || player.getPoints() > selected.getPoints()) {
				selected = player;
			}
		}

		if (selected == null) {
			return;
		}

		int elapsed = level.getPassedTime();
		if (elapsed < 0) {
			elapsed = 0;
		}
		if (elapsed > 0) {
			elapsed /= 1000;
		}

		String playerName = selected.getTeamName();
		if (playerName == null || playerName.trim().length() == 0) {
			playerName = DEFAULT_PLAYER_NAME;
		}

		this.storeRun(selected.getPoints(), elapsed, playerName);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);

			int width = getWidth() > 0 ? getWidth() : DEFAULT_WIDTH;
			int rowHeight = 26;
			int y = 32;

			g.setColor(Color.BLACK);
			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			g.drawString("Highscore", 20, y);

			y += 30;
			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
			g.drawString("#", 20, y);
			g.drawString("Player", 55, y);
			g.drawString("Points", Math.max(170, width - 130), y);
			g.drawString("Time", Math.max(235, width - 70), y);

			g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
			for (int i = 0; i < this.entries.size(); i++) {
				Entry entry = this.entries.get(i);
				y += rowHeight;

				if ((i & 1) == 1) {
					g.setColor(new Color(238, 238, 238));
					g.fillRect(10, y - 19, Math.max(0, width - 20), rowHeight);
				}

				g.setColor(Color.BLACK);
				g.drawString(String.valueOf(i + 1), 20, y);
				g.drawString(entry.name, 55, y);
				g.drawString(String.valueOf(entry.score),
						Math.max(170, width - 130), y);
				g.drawString(formatTime(entry.survivalTime),
						Math.max(235, width - 70), y);
			}
		} finally {
			g.dispose();
		}
	}

	private synchronized void load() {
		this.entries.clear();
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			for (String line : lines) {
				if (line.trim().length() == 0) {
					continue;
				}

				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					this.entries.clear();
					return;
				}

				String name = new String(
						Base64.getDecoder().decode(values[0]),
						StandardCharsets.UTF_8);
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);

				if (name.trim().length() == 0 || score < 0 || survivalTime < 0) {
					this.entries.clear();
					return;
				}

				this.entries.add(new Entry(name, score, survivalTime));
			}
			this.sortEntries();
		} catch (Exception ex) {
			this.entries.clear();
		}
	}

	private void sortEntries() {
		Collections.sort(this.entries, new Comparator<Entry>() {
			@Override
			public int compare(Entry first, Entry second) {
				int scoreOrder = Integer.compare(second.score, first.score);
				if (scoreOrder != 0) {
					return scoreOrder;
				}
				return first.name.compareToIgnoreCase(second.name);
			}
		});
	}

	private String normalizeName(String playerName) {
		if (playerName == null) {
			return DEFAULT_PLAYER_NAME;
		}

		String name = playerName.trim();
		if (name.length() == 0) {
			return DEFAULT_PLAYER_NAME;
		}
		if (name.length() > 40) {
			return name.substring(0, 40);
		}
		return name;
	}

	private String formatTime(int seconds) {
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	private static final class Entry {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Entry(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}