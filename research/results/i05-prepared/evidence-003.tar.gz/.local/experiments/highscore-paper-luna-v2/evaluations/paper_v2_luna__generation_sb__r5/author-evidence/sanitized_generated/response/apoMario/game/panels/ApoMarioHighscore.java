package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<Run> runs;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.runs = new ArrayList<Run>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		String name = sanitizeName(playerName);
		runs.add(new Run(name, score, survivalTime));
		sortRuns();

		while (runs.size() > MAX_ENTRIES) {
			runs.remove(runs.size() - 1);
		}

		boolean stored = writeStore();
		repaint();
		return stored;
	}

	public synchronized List<String> getPlayersNames() {
		ArrayList<String> result = new ArrayList<String>();
		for (Run run : runs) {
			result.add(run.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Run run : runs) {
			result.add(run.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Run run : runs) {
			result.add(run.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		writeStore();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null || !player.isBVisible()) {
				continue;
			}
			if (selected == null || player.getPoints() > selected.getPoints()) {
				selected = player;
			}
		}

		if (selected == null) {
			for (ApoMarioPlayer player : level.getPlayers()) {
				if (player != null) {
					if (selected == null || player.getPoints() > selected.getPoints()) {
						selected = player;
					}
				}
			}
		}

		if (selected == null) {
			return;
		}

		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}

		String name = selected.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		storeRun(selected.getPoints(), elapsed, name);
	}

	public synchronized String getFormattedSurvivalTime(int index) {
		if (index < 0 || index >= runs.size()) {
			return "00:00";
		}
		return formatTime(runs.get(index).survivalTime);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setColor(Color.BLACK);
			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
			g.drawString("Highscores", 20, 30);

			g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
			g.drawString("#", 20, 58);
			g.drawString("Player", 55, 58);
			g.drawString("Points", 210, 58);
			g.drawString("Time", 285, 58);

			int y = 82;
			for (int i = 0; i < runs.size(); i++) {
				Run run = runs.get(i);
				g.drawString(String.valueOf(i + 1), 20, y);
				g.drawString(run.name, 55, y);
				g.drawString(String.valueOf(run.score), 210, y);
				g.drawString(formatTime(run.survivalTime), 285, y);
				y += 22;
			}
		} finally {
			g.dispose();
		}
	}

	private synchronized void load() {
		runs.clear();

		if (store == null || !Files.isRegularFile(store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				if (line.trim().length() == 0) {
					continue;
				}

				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					throw new IOException("Invalid highscore record");
				}

				String name = sanitizeName(unescape(values[0]));
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);

				if (score < 0 || survivalTime < 0) {
					throw new IOException("Invalid highscore value");
				}

				runs.add(new Run(name, score, survivalTime));
			}

			sortRuns();
			while (runs.size() > MAX_ENTRIES) {
				runs.remove(runs.size() - 1);
			}
		} catch (Exception exception) {
			runs.clear();
		}
	}

	private synchronized boolean writeStore() {
		if (store == null) {
			return false;
		}

		try {
			Path parent = store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(
					temporary, StandardCharsets.UTF_8)) {
				for (Run run : runs) {
					writer.write(escape(run.name));
					writer.write('\t');
					writer.write(String.valueOf(run.score));
					writer.write('\t');
					writer.write(String.valueOf(run.survivalTime));
					writer.newLine();
				}
			}

			try {
				Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException exception) {
				Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			return false;
		}
	}

	private void sortRuns() {
		Collections.sort(runs, new Comparator<Run>() {
			@Override
			public int compare(Run first, Run second) {
				int scoreComparison = Integer.compare(second.score, first.score);
				if (scoreComparison != 0) {
					return scoreComparison;
				}
				return Integer.compare(first.survivalTime, second.survivalTime);
			}
		});
	}

	private static String sanitizeName(String value) {
		if (value == null) {
			return "Player";
		}

		String result = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
		if (result.length() == 0) {
			return "Player";
		}
		if (result.length() > 32) {
			result = result.substring(0, 32);
		}
		return result;
	}

	private static String escape(String value) {
		return value.replace("\\", "\\\\").replace("\t", "\\t");
	}

	private static String unescape(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;

		for (int i = 0; i < value.length(); i++) {
			char character = value.charAt(i);
			if (escaped) {
				if (character == 't') {
					result.append('\t');
				} else {
					result.append(character);
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else {
				result.append(character);
			}
		}

		if (escaped) {
			result.append('\\');
		}
		return result.toString();
	}

	private static String formatTime(int milliseconds) {
		int totalSeconds = milliseconds / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", minutes, seconds);
	}

	private static final class Run {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Run(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}