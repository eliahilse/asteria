package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;
import apoMario.ai.ApoMarioAI;

public class ApoMarioHighscore {

    private static final String DEFAULT_PLAYER_NAME = "Player";
    private static final Comparator<Run> SCORE_ORDER = new Comparator<Run>() {
        @Override
        public int compare(Run first, Run second) {
            int result = Integer.compare(second.score, first.score);
            if (result != 0) {
                return result;
            }
            return Integer.compare(first.order, second.order);
        }
    };

    private final Path store;
    private final List<Run> runs;
    private int nextOrder;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.nextOrder = 0;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        runs.add(new Run(score, survivalTime < 0 ? 0 : survivalTime, name, nextOrder++));
        Collections.sort(runs, SCORE_ORDER);
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return result;
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = 0;
        try {
            survivalTime = Math.max(0, level.getPassedTime());
        } catch (RuntimeException ex) {
            survivalTime = 0;
        }

        String playerName = DEFAULT_PLAYER_NAME;
        ApoMarioAI ai = player.getAi();
        if (ai != null && ai.getTeamName() != null) {
            String teamName = ai.getTeamName().trim();
            if (!teamName.isEmpty()) {
                playerName = teamName;
            }
        }

        storeRun(score, survivalTime, playerName);
    }

    public synchronized Path getStore() {
        return store;
    }

    public static String formatSurvivalTime(int milliseconds) {
        long totalSeconds = Math.max(0, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        List<Run> loaded = new ArrayList<Run>();
        int order = 0;

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                if (survivalTime < 0) {
                    throw new IOException("Invalid survival time");
                }

                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);
                name = normalizeName(name);
                loaded.add(new Run(score, survivalTime, name, order++));
            }

            runs.clear();
            runs.addAll(loaded);
            nextOrder = order;
            Collections.sort(runs, SCORE_ORDER);
        } catch (Exception ex) {
            runs.clear();
            nextOrder = 0;
        }
    }

    private boolean persist() {
        if (store == null) {
            return false;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                for (Run run : runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String name = playerName.trim();
        if (name.isEmpty()) {
            return DEFAULT_PLAYER_NAME;
        }

        return name.length() > 64 ? name.substring(0, 64) : name;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;
        private final int order;

        private Run(int score, int survivalTime, String name, int order) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
            this.order = order;
        }
    }
}