package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String HEADER = "APOMARIO_HIGHSCORE_1";
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
		this.setBackground(Color.WHITE);
		this.setOpaque(true);
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 32) {
			name = name.substring(0, 32);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}
		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}
			try (BufferedWriter writer = Files.newBufferedWriter(this.store,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE)) {
				writer.write(HEADER);
				writer.newLine();
				for (int i = 0; i < this.playersNames.size(); i++) {
					String encodedName = Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(encodedName);
					writer.write('\t');
					writer.write(String.valueOf(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
					writer.newLine();
				}
			}
		} catch (IOException ex) {
		}
	}

	public void recordRunEnd(ApoMarioLevel level) {
		if (level == null) {
			return;
		}

		int score = 0;
		int survivalTime = 0;
		String playerName = "Player";

		try {
			Object playerList = level.getClass().getMethod("getPlayers").invoke(level);
			if (playerList instanceof List<?>) {
				List<?> players = (List<?>) playerList;
				if (!players.isEmpty() && players.get(0) != null) {
					Object player = players.get(0);
					Object value = player.getClass().getMethod("getPoints").invoke(player);
					if (value instanceof Number) {
						score = ((Number) value).intValue();
					}

					try {
						value = player.getClass().getMethod("getTeamName").invoke(player);
						if (value != null && value.toString().trim().length() > 0) {
							playerName = value.toString().trim();
						}
					} catch (ReflectiveOperationException ex) {
					}
				}
			}
		} catch (ReflectiveOperationException ex) {
		}

		try {
			Object value = level.getClass().getMethod("getPassedTime").invoke(level);
			if (value instanceof Number) {
				survivalTime = ((Number) value).intValue();
			}
		} catch (ReflectiveOperationException ex) {
			try {
				Object value = level.getClass().getMethod("getStartTime").invoke(level);
				if (value instanceof Number) {
					survivalTime = ((Number) value).intValue();
				}
			} catch (ReflectiveOperationException ignored) {
			}
		}

		this.storeRun(score, survivalTime, playerName);
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line = reader.readLine();
			if (!HEADER.equals(line)) {
				return;
			}

			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}
				try {
					String name = new String(Base64.getDecoder().decode(values[0]), StandardCharsets.UTF_8);
					int score = Integer.parseInt(values[1]);
					int time = Integer.parseInt(values[2]);
					names.add(name);
					scores.add(Integer.valueOf(score));
					times.add(Integer.valueOf(Math.max(0, time)));
				} catch (IllegalArgumentException ex) {
				}
			}
		} catch (IOException ex) {
			return;
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(names);
		this.playersScores.addAll(scores);
		this.survivalTimes.addAll(times);
		this.sort();
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			names.add(this.playersNames.get(index.intValue()));
			scores.add(this.playersScores.get(index.intValue()));
			times.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(names);
		this.playersScores.addAll(scores);
		this.survivalTimes.addAll(times);
	}

	public static String formatSurvivalTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		g.setColor(Color.BLACK);
		g.setFont(new Font("Dialog", Font.BOLD, 24));
		g.drawString("Highscore", 30, 40);

		g.setFont(new Font("Dialog", Font.BOLD, 15));
		g.drawString("#", 30, 75);
		g.drawString("Points", 80, 75);
		g.drawString("Player", 180, 75);
		g.drawString("Time", 390, 75);

		g.setFont(new Font("Dialog", Font.PLAIN, 15));
		for (int i = 0; i < this.playersNames.size(); i++) {
			int y = 105 + i * 25;
			if (y > this.getHeight() - 10) {
				break;
			}
			g.drawString(String.valueOf(i + 1), 30, y);
			g.drawString(String.valueOf(this.playersScores.get(i)), 80, y);
			g.drawString(this.playersNames.get(i), 180, y);
			g.drawString(formatSurvivalTime(this.survivalTimes.get(i).intValue()), 390, y);
		}

		g.dispose();
	}
}