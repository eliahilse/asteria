package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_NAME_LENGTH = 32;

    private final Path store;
    private final List<Run> runs;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }
        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        runs.add(new Run(score, survivalTime, name));
        sortRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) {
            result.add(run.name);
        }
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(run.score);
        }
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encode(run.name));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(store.resolveSibling(
                        store.getFileName().toString() + ".tmp"));
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null ||
                level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer bestPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (bestPlayer == null || player.getPoints() > bestPlayer.getPoints()) {
                bestPlayer = player;
            }
        }

        if (bestPlayer == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (bestPlayer == null || player.getPoints() > bestPlayer.getPoints()) {
                        bestPlayer = player;
                    }
                }
            }
        }

        if (bestPlayer == null) {
            return;
        }

        int elapsed;
        try {
            elapsed = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsed = level.getStartTime() - level.getTime();
        }

        if (elapsed < 0) {
            elapsed = 0;
        }

        storeRun(bestPlayer.getPoints(), elapsed, bestPlayer.getTeamName());
        persistAcrossRuns();
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(254, 254, 254, 235));
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int lineY = y + 55;
        int row = 1;

        for (Run run : runs) {
            if (lineY > y + height - 12) {
                break;
            }

            String time = formatTime(run.survivalTime);
            String line = row + ". " + run.name + "  " + run.score + "  " + time;
            graphics.drawString(line, x + 20, lineY);
            lineY += 20;
            row++;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        return formatTime(survivalTime);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        List<Run> loaded = new ArrayList<Run>();

        try {
            BufferedReader reader = Files.newBufferedReader(
                    store,
                    StandardCharsets.UTF_8);

            try {
                String header = reader.readLine();
                if (!HEADER.equals(header)) {
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null) {
                    String[] values = line.split("\t", -1);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore record");
                    }

                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String name = normalizeName(decode(values[2]));

                    if (score < 0 || survivalTime < 0 || name.length() == 0) {
                        throw new IOException("Invalid highscore values");
                    }

                    loaded.add(new Run(score, survivalTime, name));
                }
            } finally {
                reader.close();
            }

            runs.clear();
            runs.addAll(loaded);
            sortRuns();
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = value.charAt(i);
            if (character == '\t' || character == '\r' || character == '\n') {
                result.append(' ');
            } else {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private static String encode(String value) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            if (character == '\\') {
                result.append("\\\\");
            } else {
                result.append(character);
            }
        }
        return result.toString();
    }

    private static String decode(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            if (escaped) {
                result.append(character);
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }

        return result.toString();
    }

    private static String formatTime(int milliseconds) {
        int totalSeconds = milliseconds / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}