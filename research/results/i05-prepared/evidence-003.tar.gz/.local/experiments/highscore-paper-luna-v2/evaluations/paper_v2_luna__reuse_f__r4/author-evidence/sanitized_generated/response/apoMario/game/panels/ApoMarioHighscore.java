package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 40) {
			name = name.substring(0, 40);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(Math.max(0, score)));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int index = this.playersNames.size() - 1;
			this.playersNames.remove(index);
			this.playersScores.remove(index);
			this.survivalTimes.remove(index);
		}
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			try (BufferedWriter writer = Files.newBufferedWriter(
					this.store,
					StandardCharsets.UTF_8)) {
				for (int i = 0; i < this.playersNames.size(); i++) {
					writer.write(encode(this.playersNames.get(i)));
					writer.write('\t');
					writer.write(String.valueOf(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
					writer.newLine();
				}
			}
		} catch (IOException ex) {
			// A failed save must not interrupt the running game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player != null && player.isBVisible()) {
				if (selected == null || player.getPoints() > selected.getPoints()) {
					selected = player;
				}
			}
		}
		if (selected == null) {
			selected = level.getPlayers().get(0);
		}
		if (selected == null) {
			return;
		}

		String name = selected.getTeamName();
		if (name == null || name.trim().length() == 0) {
			if (selected.getAi() != null) {
				name = selected.getAi().getAuthor();
			}
		}
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		this.storeRun(selected.getPoints(), level.getPassedTime(), name);
	}

	public synchronized void render(Graphics2D graphics, int x, int y, int width) {
		if (graphics == null) {
			return;
		}

		Font originalFont = graphics.getFont();
		Color originalColor = graphics.getColor();

		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font(originalFont.getName(), Font.BOLD, originalFont.getSize()));
		graphics.drawString("Highscore", x, y);

		graphics.setFont(originalFont);
		for (int i = 0; i < this.playersNames.size(); i++) {
			int rowY = y + originalFont.getSize() + 8 + i * (originalFont.getSize() + 6);
			String score = String.valueOf(this.playersScores.get(i));
			String time = formatTime(this.survivalTimes.get(i).intValue());
			String line = (i + 1) + ". " + this.playersNames.get(i);
			graphics.drawString(line, x, rowY);
			graphics.drawString(score, x + Math.max(0, width - 120), rowY);
			graphics.drawString(time, x + Math.max(0, width - 55), rowY);
		}

		graphics.setFont(originalFont);
		graphics.setColor(originalColor);
	}

	public static String formatTime(int milliseconds) {
		long totalSeconds = Math.max(0L, milliseconds) / 1000L;
		long minutes = totalSeconds / 60L;
		long seconds = totalSeconds % 60L;
		return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
	}

	private void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(
				this.store,
				StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}
				try {
					String name = decode(values[0]);
					int score = Integer.parseInt(values[1]);
					int time = Integer.parseInt(values[2]);
					if (name.length() > 0 && score >= 0 && time >= 0) {
						this.playersNames.add(name);
						this.playersScores.add(Integer.valueOf(score));
						this.survivalTimes.add(Integer.valueOf(time));
					}
				} catch (NumberFormatException ex) {
					// Ignore malformed records and keep valid entries.
				}
			}
			this.sort();
			while (this.playersNames.size() > MAX_ENTRIES) {
				int index = this.playersNames.size() - 1;
				this.playersNames.remove(index);
				this.playersScores.remove(index);
				this.survivalTimes.remove(index);
			}
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			indexes.add(Integer.valueOf(i));
		}

		Collections.sort(indexes, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						playersScores.get(second.intValue()).intValue(),
						playersScores.get(first.intValue()).intValue());
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return Integer.compare(
						survivalTimes.get(second.intValue()).intValue(),
						survivalTimes.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : indexes) {
			names.add(this.playersNames.get(index.intValue()));
			scores.add(this.playersScores.get(index.intValue()));
			times.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private static String encode(String value) {
		return value.replace("\\", "\\\\")
				.replace("\t", "\\t")
				.replace("\r", "\\r")
				.replace("\n", "\\n");
	}

	private static String decode(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;
		for (int i = 0; i < value.length(); i++) {
			char character = value.charAt(i);
			if (escaped) {
				if (character == 't') {
					result.append('\t');
				} else if (character == 'r') {
					result.append('\r');
				} else if (character == 'n') {
					result.append('\n');
				} else {
					result.append(character);
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else {
				result.append(character);
			}
		}
		if (escaped) {
			result.append('\\');
		}
		return result.toString();
	}
}