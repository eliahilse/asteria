package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(time));
        this.sortEntries();

        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                for (int i = 0; i < this.playersNames.size(); i++) {
                    writer.write(Integer.toString(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(encode(this.playersNames.get(i)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        String playerName = player.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = player.getAuthor();
        }

        int elapsed = level.getStartTime() - level.getTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        int survivalSeconds = elapsed / 1000;
        this.storeRun(player.getPoints(), survivalSeconds, playerName);
        this.persistAcrossRuns();
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        int width = ApoMarioConstants.GAME_WIDTH;
        int height = ApoMarioConstants.GAME_HEIGHT;

        graphics.setColor(new Color(254, 254, 254, 235));
        graphics.fillRoundRect(15, 15, width - 30, height - 30, 20, 20);

        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(15, 15, width - 30, height - 30, 20, 20);

        graphics.setFont(ApoMarioConstants.FONT_CREDITS);
        String title = "HIGHSCORES";
        int titleWidth = graphics.getFontMetrics().stringWidth(title);
        graphics.drawString(title, (width - titleWidth) / 2, 45);

        graphics.setFont(ApoMarioConstants.FONT_MENU);
        int y = 75;
        int rowHeight = graphics.getFontMetrics().getHeight() + 4;

        graphics.drawString("#", 30, y);
        graphics.drawString("PLAYER", 60, y);
        graphics.drawString("POINTS", width - 125, y);
        graphics.drawString("TIME", width - 65, y);

        for (int i = 0; i < this.playersNames.size(); i++) {
            if (y + rowHeight > height - 15) {
                break;
            }

            y += rowHeight;
            graphics.drawString(Integer.toString(i + 1), 30, y);
            graphics.drawString(this.playersNames.get(i), 60, y);
            graphics.drawString(
                    Integer.toString(this.playersScores.get(i).intValue()),
                    width - 125,
                    y);
            graphics.drawString(
                    formatTime(this.survivalTimes.get(i).intValue()),
                    width - 65,
                    y);
        }
    }

    public static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        try {
            BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().length() == 0) {
                        continue;
                    }

                    String[] values = line.split("\t", 3);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore record");
                    }

                    int score = Integer.parseInt(values[0]);
                    int time = Integer.parseInt(values[1]);
                    String name = normalizeName(decode(values[2]));

                    scores.add(Integer.valueOf(score));
                    times.add(Integer.valueOf(Math.max(0, time)));
                    names.add(name);
                }
            } finally {
                reader.close();
            }

            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();

            this.playersNames.addAll(names);
            this.playersScores.addAll(scores);
            this.survivalTimes.addAll(times);
            this.sortEntries();

            while (this.playersNames.size() > MAX_ENTRIES) {
                int last = this.playersNames.size() - 1;
                this.playersNames.remove(last);
                this.playersScores.remove(last);
                this.survivalTimes.remove(last);
            }
        } catch (Exception ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sortEntries() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersNames.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreCompare = Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());

                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                return Integer.compare(
                        survivalTimes.get(first.intValue()).intValue(),
                        survivalTimes.get(second.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            sortedNames.add(this.playersNames.get(i));
            sortedScores.add(this.playersScores.get(i));
            sortedTimes.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        this.playersNames.addAll(sortedNames);
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.addAll(sortedTimes);
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String result = name.trim();
        if (result.length() == 0) {
            return "Player";
        }

        if (result.length() > 32) {
            result = result.substring(0, 32);
        }

        return result;
    }

    private static String encode(String value) {
        return value
                .replace("\\", "\\\\")
                .replace("\t", "\\t")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }

    private static String decode(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);

            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == 'r') {
                    result.append('\r');
                } else if (character == 'n') {
                    result.append('\n');
                } else {
                    result.append(character);
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }

        return result.toString();
    }
}