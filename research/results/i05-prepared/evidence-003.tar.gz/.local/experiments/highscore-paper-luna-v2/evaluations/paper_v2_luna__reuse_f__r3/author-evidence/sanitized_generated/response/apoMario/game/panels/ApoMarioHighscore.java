package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();

        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8)) {
                for (int i = 0; i < this.playersNames.size(); i++) {
                    writer.write(Integer.toString(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(this.playersNames.get(i)
                            .replace('\t', ' ')
                            .replace('\r', ' ')
                            .replace('\n', ' '));
                    writer.newLine();
                }
            }
        } catch (IOException ex) {
            this.load();
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        String name = "Human";
        if (player.getAi() != null) {
            if (player.getAi().getTeamName() != null
                    && player.getAi().getTeamName().trim().length() > 0) {
                name = player.getAi().getTeamName().trim();
            } else if (player.getAi().getAuthor() != null
                    && player.getAi().getAuthor().trim().length() > 0) {
                name = player.getAi().getAuthor().trim();
            }
        }

        int elapsed;
        try {
            elapsed = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsed = level.getStartTime() - level.getTime();
        }

        this.storeRun(player.getPoints(), Math.max(0, elapsed), name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        int rowY = y + 35;
        int rowHeight = 24;

        for (int i = 0; i < this.playersNames.size(); i++) {
            String rank = Integer.toString(i + 1) + ".";
            String name = this.playersNames.get(i);
            String score = Integer.toString(this.playersScores.get(i));
            String time = formatTime(this.survivalTimes.get(i).intValue());

            graphics.drawString(rank, x, rowY);
            graphics.drawString(name, x + 35, rowY);
            graphics.drawString(score, x + Math.max(120, width / 2), rowY);
            graphics.drawString(time, x + Math.max(210, width * 3 / 4), rowY);

            rowY += rowHeight;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        int minutes = seconds / 60;
        seconds %= 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", 3);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0].trim());
                    int time = Integer.parseInt(values[1].trim());
                    String name = values[2].trim();

                    if (name.length() == 0) {
                        name = "Player";
                    }

                    this.playersScores.add(Integer.valueOf(score));
                    this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
                    this.playersNames.add(name);
                } catch (NumberFormatException ex) {
                    this.playersNames.clear();
                    this.playersScores.clear();
                    this.survivalTimes.clear();
                    return;
                }
            }

            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersNames.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            names.add(this.playersNames.get(i));
            scores.add(this.playersScores.get(i));
            times.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(names);
        this.playersScores.clear();
        this.playersScores.addAll(scores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(times);
    }
}