package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int DEFAULT_MAX_ENTRIES = 100;

    private final Path store;
    private final List<String> playersNames;
    private final List<Integer> playersScores;
    private final List<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(survivalTime));

        this.sort();
        while (this.playersScores.size() > DEFAULT_MAX_ENTRIES) {
            int last = this.playersScores.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                for (int i = 0; i < this.playersScores.size(); i++) {
                    writer.write(encode(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(encode(this.survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(encode(this.playersNames.get(i)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.isBVisible()) {
                player = candidate;
                break;
            }
        }
        if (player == null) {
            player = level.getPlayers().get(0);
        }
        if (player == null) {
            return;
        }

        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsed = level.getPassedTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        this.storeRun(player.getPoints(), elapsed, name);
        this.persistAcrossRuns();
    }

    public static String formatSurvivalTime(int milliseconds) {
        long totalSeconds = Math.max(0, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            BufferedReader reader = Files.newBufferedReader(
                    this.store,
                    StandardCharsets.UTF_8);

            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().length() == 0) {
                        continue;
                    }

                    String[] values = line.split("\t", 3);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore entry");
                    }

                    int score = Integer.parseInt(decode(values[0]));
                    int survivalTime = Integer.parseInt(decode(values[1]));
                    String name = decode(values[2]);

                    if (score < 0 || survivalTime < 0 || name.length() == 0) {
                        throw new IOException("Invalid highscore value");
                    }

                    this.playersScores.add(Integer.valueOf(score));
                    this.survivalTimes.add(Integer.valueOf(survivalTime));
                    this.playersNames.add(name);
                }
            } finally {
                reader.close();
            }

            this.sort();
        } catch (Exception ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        List<Entry> entries = new ArrayList<Entry>();

        for (int i = 0; i < this.playersScores.size(); i++) {
            entries.add(new Entry(
                    this.playersNames.get(i),
                    this.playersScores.get(i).intValue(),
                    this.survivalTimes.get(i).intValue()));
        }

        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                return Integer.compare(second.score, first.score);
            }
        });

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        for (Entry entry : entries) {
            this.playersNames.add(entry.name);
            this.playersScores.add(Integer.valueOf(entry.score));
            this.survivalTimes.add(Integer.valueOf(entry.survivalTime));
        }
    }

    private static String encode(String value) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            if (character == '\\') {
                result.append("\\\\");
            } else if (character == '\t') {
                result.append("\\t");
            } else if (character == '\n') {
                result.append("\\n");
            } else if (character == '\r') {
                result.append("\\r");
            } else {
                result.append(character);
            }
        }
        return result.toString();
    }

    private static String encode(int value) {
        return String.valueOf(value);
    }

    private static String decode(String value) throws IOException {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);

            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == 'n') {
                    result.append('\n');
                } else if (character == 'r') {
                    result.append('\r');
                } else if (character == '\\') {
                    result.append('\\');
                } else {
                    throw new IOException("Invalid escape sequence");
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            throw new IOException("Incomplete escape sequence");
        }

        return result.toString();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}