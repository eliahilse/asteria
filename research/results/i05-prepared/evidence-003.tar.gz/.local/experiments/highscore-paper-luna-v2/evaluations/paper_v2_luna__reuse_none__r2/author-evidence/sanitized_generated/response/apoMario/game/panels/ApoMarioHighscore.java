package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final String DEFAULT_PLAYER_NAME = "Player";

	private final Path store;
	private final List<Entry> entries;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.entries = new ArrayList<Entry>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = DEFAULT_PLAYER_NAME;
		}
		this.entries.add(new Entry(score, survivalTime, name));
		Collections.sort(this.entries, new Comparator<Entry>() {
			@Override
			public int compare(Entry first, Entry second) {
				return Integer.compare(second.score, first.score);
			}
		});
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		List<String> result = new ArrayList<String>();
		for (Entry entry : this.entries) {
			result.add(entry.name);
		}
		return result;
	}

	public synchronized List<Integer> getPlayersScores() {
		List<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.score);
		}
		return result;
	}

	public synchronized List<Integer> getSurvivalTimes() {
		List<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.survivalTime);
		}
		return result;
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
				for (Entry entry : this.entries) {
					String encodedName = Base64.getEncoder()
							.encodeToString(entry.name.getBytes(StandardCharsets.UTF_8));
					writer.write(Integer.toString(entry.score));
					writer.write('\t');
					writer.write(Integer.toString(entry.survivalTime));
					writer.write('\t');
					writer.write(encodedName);
					writer.newLine();
				}
			}

			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	public void recordRunEnd(ApoMarioLevel level) {
		if (level == null) {
			return;
		}

		Object player = this.findPrimaryPlayer(level);
		int score = this.findInt(player, "getPoints", this.findInt(level, "getScore", 0));
		int survivalTime = this.findSurvivalTime(level);
		String name = this.findPlayerName(level, player);

		this.storeRun(score, survivalTime, name);
	}

	public static String formatSurvivalTime(int milliseconds) {
		long seconds = Math.max(0L, milliseconds) / 1000L;
		long minutes = seconds / 60L;
		long remainingSeconds = seconds % 60L;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					int score = Integer.parseInt(values[0]);
					int survivalTime = Integer.parseInt(values[1]);
					String name = new String(Base64.getDecoder().decode(values[2]), StandardCharsets.UTF_8);
					if (name.trim().length() > 0) {
						this.entries.add(new Entry(score, survivalTime, name));
					}
				} catch (IllegalArgumentException ex) {
				}
			}
		} catch (IOException ex) {
			this.entries.clear();
		}

		Collections.sort(this.entries, new Comparator<Entry>() {
			@Override
			public int compare(Entry first, Entry second) {
				return Integer.compare(second.score, first.score);
			}
		});
	}

	private int findSurvivalTime(ApoMarioLevel level) {
		Integer passedTime = this.invokeInt(level, "getPassedTime");
		if (passedTime != null && passedTime.intValue() >= 0) {
			return passedTime.intValue();
		}

		Integer startTime = this.invokeInt(level, "getStartTime");
		Integer remainingTime = this.invokeInt(level, "getTime");
		if (startTime != null && remainingTime != null) {
			return Math.max(0, startTime.intValue() - remainingTime.intValue());
		}
		return 0;
	}

	private String findPlayerName(ApoMarioLevel level, Object player) {
		String name = this.findString(level, "getPlayerName");
		if (name == null || name.trim().length() == 0) {
			name = this.findString(player, "getPlayerName");
		}
		if (name == null || name.trim().length() == 0) {
			name = this.findString(player, "getName");
		}
		if (name == null || name.trim().length() == 0) {
			Object ai = this.invoke(player, "getAi");
			name = this.findString(ai, "getTeamName");
		}
		if (name == null || name.trim().length() == 0) {
			name = DEFAULT_PLAYER_NAME;
		}
		return name.trim();
	}

	private Object findPrimaryPlayer(ApoMarioLevel level) {
		Object players = this.invoke(level, "getPlayers");
		if (players == null) {
			return null;
		}
		if (players instanceof List<?>) {
			List<?> list = (List<?>) players;
			return list.isEmpty() ? null : list.get(0);
		}
		if (players.getClass().isArray() && Array.getLength(players) > 0) {
			return Array.get(players, 0);
		}
		return null;
	}

	private int findInt(Object target, String methodName, int fallback) {
		Integer value = this.invokeInt(target, methodName);
		return value == null ? fallback : value.intValue();
	}

	private Integer invokeInt(Object target, String methodName) {
		Object value = this.invoke(target, methodName);
		if (value instanceof Number) {
			return Integer.valueOf(((Number) value).intValue());
		}
		return null;
	}

	private String findString(Object target, String methodName) {
		Object value = this.invoke(target, methodName);
		return value == null ? null : String.valueOf(value);
	}

	private Object invoke(Object target, String methodName) {
		if (target == null) {
			return null;
		}
		try {
			Method method = target.getClass().getMethod(methodName);
			return method.invoke(target);
		} catch (Exception ex) {
			return null;
		}
	}

	private static final class Entry {
		private final int score;
		private final int survivalTime;
		private final String name;

		private Entry(int score, int survivalTime, String name) {
			this.score = score;
			this.survivalTime = survivalTime;
			this.name = name;
		}
	}
}