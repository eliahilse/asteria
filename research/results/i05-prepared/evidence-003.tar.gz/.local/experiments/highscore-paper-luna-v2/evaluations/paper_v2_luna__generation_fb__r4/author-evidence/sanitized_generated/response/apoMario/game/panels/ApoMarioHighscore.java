package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String SEPARATOR = "\t";
	private static final int DEFAULT_WIDTH = 520;
	private static final int DEFAULT_HEIGHT = 420;

	private final Path store;
	private final List<Entry> entries;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.entries = new ArrayList<Entry>();
		this.setBackground(Color.WHITE);
		this.setPreferredSize(new java.awt.Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		int safeScore = Math.max(0, score);
		int safeTime = Math.max(0, survivalTime);

		this.entries.add(new Entry(name, safeScore, safeTime));
		this.sortEntries();

		try {
			this.write();
			return true;
		} catch (IOException ex) {
			return false;
		}
	}

	public synchronized List<String> getPlayersNames() {
		List<String> result = new ArrayList<String>();
		for (Entry entry : this.entries) {
			result.add(entry.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		List<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		List<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		try {
			this.write();
		} catch (IOException ex) {
			// Persistence failures do not interrupt the game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = player.getAuthor();
		}
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		int elapsedMilliseconds = level.getStartTime() - level.getTime();
		if (elapsedMilliseconds < 0) {
			elapsedMilliseconds = 0;
		}

		int survivalSeconds = elapsedMilliseconds / 1000;
		this.storeRun(player.getPoints(), survivalSeconds, name);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 24));
			g.drawString("Highscore", 24, 36);

			g.setFont(new Font("Dialog", Font.BOLD, 15));
			g.drawString("#", 28, 68);
			g.drawString("Player", 70, 68);
			g.drawString("Points", 310, 68);
			g.drawString("Time", 405, 68);

			g.setFont(new Font("Dialog", Font.PLAIN, 15));
			int y = 94;
			for (int i = 0; i < this.entries.size(); i++) {
				Entry entry = this.entries.get(i);
				g.drawString(String.valueOf(i + 1), 28, y);
				g.drawString(entry.name, 70, y);
				g.drawString(String.valueOf(entry.score), 310, y);
				g.drawString(formatTime(entry.survivalTime), 405, y);
				y += 26;
			}
		} finally {
			g.dispose();
		}
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			List<Entry> loaded = new ArrayList<Entry>();

			for (String line : lines) {
				if (line == null || line.trim().length() == 0) {
					continue;
				}

				String[] values = line.split(SEPARATOR, -1);
				if (values.length != 3) {
					throw new IOException("Invalid highscore entry");
				}

				String name = normalizeName(unescape(values[0]));
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);

				if (score < 0 || survivalTime < 0) {
					throw new IOException("Invalid highscore values");
				}

				loaded.add(new Entry(name, score, survivalTime));
			}

			this.entries.clear();
			this.entries.addAll(loaded);
			this.sortEntries();
		} catch (Exception ex) {
			this.entries.clear();
		}
	}

	private void write() throws IOException {
		if (this.store == null) {
			throw new IOException("No highscore store configured");
		}

		Path parent = this.store.getParent();
		if (parent != null) {
			Files.createDirectories(parent);
		}

		Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
		List<String> lines = new ArrayList<String>();

		for (Entry entry : this.entries) {
			lines.add(escape(entry.name) + SEPARATOR + entry.score + SEPARATOR + entry.survivalTime);
		}

		Files.write(temporary, lines, StandardCharsets.UTF_8);

		try {
			Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
					StandardCopyOption.ATOMIC_MOVE);
		} catch (IOException ex) {
			Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
		}
	}

	private void sortEntries() {
		Collections.sort(this.entries, new Comparator<Entry>() {
			@Override
			public int compare(Entry first, Entry second) {
				int scoreComparison = Integer.compare(second.score, first.score);
				if (scoreComparison != 0) {
					return scoreComparison;
				}
				return Integer.compare(first.survivalTime, second.survivalTime);
			}
		});
	}

	private static String normalizeName(String name) {
		if (name == null) {
			return "Player";
		}

		String normalized = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
		if (normalized.length() == 0) {
			return "Player";
		}
		return normalized;
	}

	private static String escape(String value) {
		return value.replace("\\", "\\\\").replace("\t", "\\t")
				.replace("\r", "\\r").replace("\n", "\\n");
	}

	private static String unescape(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;

		for (int i = 0; i < value.length(); i++) {
			char character = value.charAt(i);
			if (escaped) {
				if (character == 't') {
					result.append('\t');
				} else if (character == 'r') {
					result.append('\r');
				} else if (character == 'n') {
					result.append('\n');
				} else {
					result.append(character);
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else {
				result.append(character);
			}
		}

		if (escaped) {
			result.append('\\');
		}
		return result.toString();
	}

	private static String formatTime(int seconds) {
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	private static final class Entry {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Entry(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}