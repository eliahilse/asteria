package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String SEPARATOR = "\t";

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        int normalizedTime = Math.max(0, survivalTime);
        entries.add(new Entry(name, score, normalizedTime));
        sortEntries();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                for (Entry entry : entries) {
                    writer.write(encode(entry.name));
                    writer.write(SEPARATOR);
                    writer.write(Integer.toString(entry.score));
                    writer.write(SEPARATOR);
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            try {
                Files.deleteIfExists(store.resolveSibling(
                        store.getFileName().toString() + ".tmp"));
            } catch (IOException ignored) {
            }
        }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null) {
            return;
        }

        try {
            List<ApoMarioPlayer> players = level.getPlayers();
            if (players == null || players.isEmpty() || players.get(0) == null) {
                return;
            }

            ApoMarioPlayer player = players.get(0);
            String name = player.getTeamName();

            if (name == null || name.trim().length() == 0) {
                if (player.getAi() != null) {
                    name = player.getAi().getTeamName();
                }
            }

            int elapsedMilliseconds = level.getPassedTime();
            int elapsedSeconds = elapsedMilliseconds / 1000;

            storeRun(player.getPoints(), elapsedSeconds, name);
        } catch (RuntimeException exception) {
            // A failed highscore write must not interrupt the game-end flow.
        }
    }

    public synchronized String getFormattedSurvivalTime(int index) {
        if (index < 0 || index >= entries.size()) {
            throw new IndexOutOfBoundsException("index: " + index);
        }

        int seconds = Math.max(0, entries.get(index).survivalTime);
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;

        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        if (!Files.isRegularFile(store)) {
            return;
        }

        ArrayList<Entry> loaded = new ArrayList<Entry>();

        try {
            BufferedReader reader = Files.newBufferedReader(
                    store,
                    StandardCharsets.UTF_8);

            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().length() == 0) {
                        continue;
                    }

                    String[] values = line.split(SEPARATOR, -1);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore entry");
                    }

                    String name = normalizeName(decode(values[0]));
                    int score = Integer.parseInt(values[1]);
                    int survivalTime = Integer.parseInt(values[2]);

                    if (name.length() == 0 || survivalTime < 0) {
                        throw new IOException("Invalid highscore entry");
                    }

                    loaded.add(new Entry(name, score, survivalTime));
                }
            } finally {
                reader.close();
            }

            entries.clear();
            entries.addAll(loaded);
            sortEntries();
        } catch (IOException exception) {
            entries.clear();
        } catch (RuntimeException exception) {
            entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                if (first.score < second.score) {
                    return 1;
                }
                if (first.score > second.score) {
                    return -1;
                }
                return 0;
            }
        });
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "";
        }

        String normalized = name.replace('\t', ' ')
                .replace('\r', ' ')
                .replace('\n', ' ')
                .trim();

        if (normalized.length() > 80) {
            normalized = normalized.substring(0, 80);
        }

        return normalized;
    }

    private static String encode(String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        StringBuilder result = new StringBuilder(bytes.length * 2);

        for (byte valueByte : bytes) {
            int valueInt = valueByte & 0xff;
            result.append(Character.forDigit((valueInt >>> 4) & 0x0f, 16));
            result.append(Character.forDigit(valueInt & 0x0f, 16));
        }

        return result.toString();
    }

    private static String decode(String value) throws IOException {
        if ((value.length() & 1) != 0) {
            throw new IOException("Invalid encoded player name");
        }

        byte[] bytes = new byte[value.length() / 2];

        for (int i = 0; i < bytes.length; i++) {
            int high = Character.digit(value.charAt(i * 2), 16);
            int low = Character.digit(value.charAt(i * 2 + 1), 16);

            if (high < 0 || low < 0) {
                throw new IOException("Invalid encoded player name");
            }

            bytes[i] = (byte) ((high << 4) | low);
        }

        return new String(bytes, StandardCharsets.UTF_8);
    }
}