package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;
	private static final String HEADER = "APOMARIO_HIGHSCORE_1";
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final List<Entry> entries;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.entries = new ArrayList<Entry>();
		this.load();
		this.setBackground(Color.BLACK);
		this.setForeground(Color.WHITE);
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 64) {
			name = name.substring(0, 64);
		}

		Entry entry = new Entry(name, Math.max(0, score), Math.max(0, survivalTime));
		this.entries.add(entry);
		this.sortEntries();

		if (this.entries.size() > MAX_ENTRIES) {
			this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
		}

		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		List<String> result = new ArrayList<String>();
		for (Entry entry : this.entries) {
			result.add(entry.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		List<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		List<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
				writer.write(HEADER);
				writer.newLine();

				for (Entry entry : this.entries) {
					writer.write(Base64.getEncoder().encodeToString(entry.name.getBytes(StandardCharsets.UTF_8)));
					writer.write('\t');
					writer.write(Integer.toString(entry.score));
					writer.write('\t');
					writer.write(Integer.toString(entry.survivalTime));
					writer.newLine();
				}
			}

			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
				Files.deleteIfExists(temporary);
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null || !player.isBVisible()) {
				continue;
			}
			if (selected == null || player.getPoints() > selected.getPoints()) {
				selected = player;
			}
		}

		if (selected == null) {
			selected = level.getPlayers().get(0);
		}

		String name = selected.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		int elapsed = level.getStartTime() - level.getTime();
		this.storeRun(selected.getPoints(), elapsed, name);
	}

	private synchronized void load() {
		this.entries.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
				return;
			}

			for (int i = 1; i < lines.size(); i++) {
				String line = lines.get(i);
				if (line.trim().length() == 0) {
					continue;
				}

				String[] values = line.split("\\t", -1);
				if (values.length != 3) {
					throw new IOException("Invalid highscore entry");
				}

				String name = new String(Base64.getDecoder().decode(values[0]), StandardCharsets.UTF_8);
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);

				if (name.length() == 0 || name.length() > 64 || score < 0 || survivalTime < 0) {
					throw new IOException("Invalid highscore values");
				}

				this.entries.add(new Entry(name, score, survivalTime));
			}

			this.sortEntries();
			if (this.entries.size() > MAX_ENTRIES) {
				this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
			}
		} catch (Exception ex) {
			this.entries.clear();
		}
	}

	private void sortEntries() {
		Collections.sort(this.entries, new Comparator<Entry>() {
			@Override
			public int compare(Entry first, Entry second) {
				return Integer.compare(second.score, first.score);
			}
		});
	}

	private static String formatTime(int seconds) {
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setColor(Color.WHITE);
			g.setFont(new Font("Dialog", Font.BOLD, 24));
			g.drawString("Highscores", 20, 35);

			g.setFont(new Font("Dialog", Font.PLAIN, 16));
			g.drawString("Name", 20, 65);
			g.drawString("Points", 220, 65);
			g.drawString("Time", 320, 65);

			int y = 90;
			for (int i = 0; i < this.entries.size(); i++) {
				Entry entry = this.entries.get(i);
				g.drawString((i + 1) + ". " + entry.name, 20, y);
				g.drawString(Integer.toString(entry.score), 220, y);
				g.drawString(formatTime(entry.survivalTime), 320, y);
				y += 24;
			}
		} finally {
			g.dispose();
		}
	}

	private static final class Entry {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Entry(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}