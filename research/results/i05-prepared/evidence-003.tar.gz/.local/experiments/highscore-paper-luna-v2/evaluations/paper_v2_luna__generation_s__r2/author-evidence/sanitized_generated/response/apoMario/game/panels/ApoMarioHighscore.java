package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String VERSION = "APOMARIO_HIGHSCORE_1";
    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final ArrayList<Run> runs;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.runs.add(new Run(score, time, name));
        this.sortRuns();
        return this.persist();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        this.persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }

        this.storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    public static String formatSurvivalTime(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Run> loaded = new ArrayList<Run>();
        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!VERSION.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);

                loaded.add(new Run(score, Math.max(0, survivalTime), normalizeName(name)));
            }
        } catch (Exception exception) {
            this.runs.clear();
            return;
        }

        this.runs.clear();
        this.runs.addAll(loaded);
        this.sortRuns();
    }

    private synchronized boolean persist() {
        if (this.store == null) {
            return false;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                writer.write(VERSION);
                writer.newLine();

                for (Run run : this.runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException exception) {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }

        if (name.length() > 32) {
            return name.substring(0, 32);
        }
        return name;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}