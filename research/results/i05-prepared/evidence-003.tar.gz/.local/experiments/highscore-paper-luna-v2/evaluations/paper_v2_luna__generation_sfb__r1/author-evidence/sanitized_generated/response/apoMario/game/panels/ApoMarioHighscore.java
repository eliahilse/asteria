package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        int time = Math.max(0, survivalTime);
        runs.add(new Run(name, score, time));
        sortRuns();
        return write();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = 0;
        try {
            survivalTime = Math.max(0, level.getPassedTime());
        } catch (RuntimeException ignored) {
            survivalTime = Math.max(0, level.getStartTime() - level.getTime());
        }

        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        storeRun(score, survivalTime, name);
    }

    public static String formatSurvivalTime(int milliseconds) {
        long totalSeconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private synchronized void load() {
        runs.clear();
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        List<Run> loaded = new ArrayList<Run>();
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    runs.clear();
                    return;
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);
                loaded.add(new Run(cleanName(name), score, Math.max(0, survivalTime)));
            }

            runs.addAll(loaded);
            sortRuns();
        } catch (Exception exception) {
            runs.clear();
        }
    }

    private synchronized boolean write() {
        if (store == null) {
            return false;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String cleanName(String name) {
        if (name == null) {
            return "Player";
        }

        String cleaned = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return cleaned.length() == 0 ? "Player" : cleaned;
    }
}