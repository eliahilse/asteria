package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final String DEFAULT_PLAYER_NAME = "Player";

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;
        private final long order;

        private Run(String name, int score, int survivalTime, long order) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
            this.order = order;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private long nextOrder;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int safeTime = Math.max(0, survivalTime);
        runs.add(new Run(name, score, safeTime, nextOrder++));
        sortRuns();
        return writeStore();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        writeStore();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }
        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        int survivalSeconds = Math.max(0, elapsedMilliseconds / 1000);
        storeRun(selected.getPoints(), survivalSeconds, name);
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, 640, 480);
        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        graphics.drawString("Highscores", 24, 40);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        graphics.drawString("Name", 30, 75);
        graphics.drawString("Score", 300, 75);
        graphics.drawString("Time", 450, 75);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
        int y = 105;
        for (Run run : runs) {
            graphics.drawString(run.name, 30, y);
            graphics.drawString(String.valueOf(run.score), 300, y);
            graphics.drawString(formatTime(run.survivalTime), 450, y);
            y += 25;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        return formatTime(survivalTime);
    }

    private String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private String normalizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }

        return name.length() > 40 ? name.substring(0, 40) : name;
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Long.compare(first.order, second.order);
            }
        });
    }

    private void load() {
        runs.clear();
        nextOrder = 0;

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                runs.clear();
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore entry");
                }

                String name = new String(
                    Base64.getDecoder().decode(values[0]),
                    StandardCharsets.UTF_8
                );
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                runs.add(new Run(normalizeName(name), score, Math.max(0, survivalTime), nextOrder++));
            }

            sortRuns();
        } catch (Exception exception) {
            runs.clear();
            nextOrder = 0;
        }
    }

    private boolean writeStore() {
        if (store == null) {
            return false;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                        run.name.getBytes(StandardCharsets.UTF_8)
                    );
                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                    temporary,
                    store,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
                );
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException exception) {
            return false;
        }
    }
}