package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = DEFAULT_PLAYER_NAME;
        }

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(survivalTime));
        this.sort();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(this.playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(this.playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(this.survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            ArrayList<String> lines = new ArrayList<String>();
            for (int i = 0; i < this.playersNames.size(); i++) {
                String encodedName = Base64.getEncoder().encodeToString(
                        this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
                lines.add(this.playersScores.get(i) + "\t"
                        + this.survivalTimes.get(i) + "\t"
                        + encodedName);
            }

            Files.write(this.store, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
        } catch (Exception ex) {
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selectedPlayer == null || player.getPoints() > selectedPlayer.getPoints()) {
                selectedPlayer = player;
            }
        }

        if (selectedPlayer == null) {
            selectedPlayer = level.getPlayers().get(0);
        }
        if (selectedPlayer == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = level.getStartTime() - level.getTime();
        }

        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalTime = elapsedMilliseconds / 1000;
        if (elapsedMilliseconds > 0 && survivalTime == 0) {
            survivalTime = 1;
        }

        String playerName = selectedPlayer.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = selectedPlayer.getAuthor();
        }

        this.storeRun(selectedPlayer.getPoints(), survivalTime, playerName);
    }

    public synchronized String getFormattedSurvivalTime(int index) {
        if (index < 0 || index >= this.survivalTimes.size()) {
            return "00:00";
        }

        int totalSeconds = Math.max(0, this.survivalTimes.get(index).intValue());
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(Color.WHITE);
        graphics.fillRect(x, y, width, height);
        graphics.setColor(Color.BLACK);
        graphics.drawRect(x, y, width, height);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int rowY = y + 60;
        int rowHeight = 24;

        for (int i = 0; i < this.playersNames.size(); i++) {
            if (rowY + rowHeight > y + height) {
                break;
            }

            graphics.drawString(String.valueOf(i + 1), x + 20, rowY);
            graphics.drawString(this.playersNames.get(i), x + 60, rowY);
            graphics.drawString(String.valueOf(this.playersScores.get(i)), x + width - 150, rowY);
            graphics.drawString(this.getFormattedSurvivalTime(i), x + width - 75, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    private synchronized void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            for (String line : lines) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore entry");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);

                if (name.trim().length() == 0) {
                    name = DEFAULT_PLAYER_NAME;
                }

                this.playersScores.add(Integer.valueOf(score));
                this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
                this.playersNames.add(name);
            }
            this.sort();
        } catch (Exception ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indices = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            indices.add(Integer.valueOf(i));
        }

        indices.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : indices) {
            int position = index.intValue();
            sortedNames.add(this.playersNames.get(position));
            sortedScores.add(this.playersScores.get(position));
            sortedTimes.add(this.survivalTimes.get(position));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }
}