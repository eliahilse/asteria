package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		int points = Math.max(0, score);
		int time = Math.max(0, survivalTime);

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(points));
		this.survivalTimes.add(Integer.valueOf(time));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}
		return this.persist();
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		this.persist();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		String playerName = player.getTeamName();
		if (playerName == null || playerName.trim().length() == 0) {
			playerName = player.getAuthor();
		}
		this.storeRun(player.getPoints(), survivalTime, playerName);
	}

	public synchronized void render(Graphics2D graphics, int x, int y, int width, int rowHeight, int rows) {
		if (graphics == null) {
			return;
		}

		Font oldFont = graphics.getFont();
		Color oldColor = graphics.getColor();

		graphics.setColor(Color.BLACK);
		graphics.setFont(oldFont.deriveFont(Font.BOLD));
		graphics.drawString("HIGHSCORES", x, y);

		graphics.setFont(oldFont);
		int count = Math.min(Math.max(0, rows), this.playersNames.size());
		for (int i = 0; i < count; i++) {
			int rowY = y + rowHeight * (i + 1);
			String rank = String.valueOf(i + 1);
			String name = this.playersNames.get(i);
			String score = String.valueOf(this.playersScores.get(i));
			String time = formatTime(this.survivalTimes.get(i).intValue());

			graphics.drawString(rank, x, rowY);
			graphics.drawString(name, x + width / 5, rowY);
			graphics.drawString(score, x + width * 3 / 5, rowY);
			graphics.drawString(time, x + width * 4 / 5, rowY);
		}

		graphics.setFont(oldFont);
		graphics.setColor(oldColor);
	}

	public static String formatTime(int milliseconds) {
		int seconds = Math.max(0, milliseconds) / 1000;
		int minutes = seconds / 60;
		seconds %= 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					String name = unescape(values[2]);
					this.playersScores.add(Integer.valueOf(Math.max(0, score)));
					this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
					this.playersNames.add(normalizeName(name));
				} catch (NumberFormatException ex) {
					this.playersNames.clear();
					this.playersScores.clear();
					this.survivalTimes.clear();
					return;
				}
			}
			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private synchronized boolean persist() {
		if (this.store == null) {
			return false;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			try (BufferedWriter writer = Files.newBufferedWriter(
					this.store,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE)) {
				for (int i = 0; i < this.playersNames.size(); i++) {
					writer.write(String.valueOf(this.playersScores.get(i)));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i)));
					writer.write('\t');
					writer.write(escape(this.playersNames.get(i)));
					writer.newLine();
				}
			}
			return true;
		} catch (IOException ex) {
			return false;
		}
	}

	private void sort() {
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			indexes.add(Integer.valueOf(i));
		}

		Collections.sort(indexes, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : indexes) {
			names.add(this.playersNames.get(index.intValue()));
			scores.add(this.playersScores.get(index.intValue()));
			times.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private static String normalizeName(String name) {
		if (name == null) {
			return "Player";
		}
		String result = name.trim();
		if (result.length() == 0) {
			return "Player";
		}
		return result.length() > 32 ? result.substring(0, 32) : result;
	}

	private static String escape(String value) {
		return value.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n");
	}

	private static String unescape(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;
		for (int i = 0; i < value.length(); i++) {
			char character = value.charAt(i);
			if (escaped) {
				if (character == 't') {
					result.append('\t');
				} else if (character == 'n') {
					result.append('\n');
				} else {
					result.append(character);
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else {
				result.append(character);
			}
		}
		if (escaped) {
			result.append('\\');
		}
		return result.toString();
	}
}