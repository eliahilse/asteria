package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_PLAYER_NAME = "Player";
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.setBackground(Color.WHITE);
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? DEFAULT_PLAYER_NAME : playerName.trim();
		if (name.length() == 0) {
			name = DEFAULT_PLAYER_NAME;
		}
		if (name.length() > 64) {
			name = name.substring(0, 64);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		if (this.playersNames.size() > MAX_ENTRIES) {
			this.playersNames.remove(this.playersNames.size() - 1);
			this.playersScores.remove(this.playersScores.size() - 1);
			this.survivalTimes.remove(this.survivalTimes.size() - 1);
		}

		try {
			this.write();
			return true;
		} catch (IOException ex) {
			return false;
		}
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		try {
			this.write();
		} catch (IOException ex) {
			// Persistence failures do not interrupt the game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selectedPlayer = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player != null && player.isBVisible()) {
				if (selectedPlayer == null || player.getPoints() > selectedPlayer.getPoints()) {
					selectedPlayer = player;
				}
			}
		}
		if (selectedPlayer == null) {
			selectedPlayer = level.getPlayers().get(0);
		}
		if (selectedPlayer == null) {
			return;
		}

		String name = selectedPlayer.getTeamName();
		int survivalTime;
		try {
			survivalTime = level.getPassedTime();
		} catch (RuntimeException ex) {
			survivalTime = level.getStartTime() - level.getTime();
		}
		this.storeRun(selectedPlayer.getPoints(), Math.max(0, survivalTime), name);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		int width = this.getWidth();
		int rowHeight = 26;
		int y = 35;

		g.setColor(Color.BLACK);
		g.setFont(new Font("Dialog", Font.BOLD, 20));
		g.drawString("Highscore", 20, y);

		y += 32;
		g.setFont(new Font("Dialog", Font.BOLD, 14));
		g.drawString("#", 20, y);
		g.drawString("Name", 60, y);
		g.drawString("Points", Math.max(180, width - 190), y);
		g.drawString("Time", Math.max(270, width - 90), y);

		g.setFont(new Font("Dialog", Font.PLAIN, 14));
		for (int i = 0; i < this.playersNames.size(); i++) {
			y += rowHeight;
			g.drawString(String.valueOf(i + 1), 20, y);
			g.drawString(this.playersNames.get(i), 60, y);
			g.drawString(String.valueOf(this.playersScores.get(i)), Math.max(180, width - 190), y);
			g.drawString(formatTime(this.survivalTimes.get(i)), Math.max(270, width - 90), y);
		}
		g.dispose();
	}

	private static String formatTime(int seconds) {
		int safeSeconds = Math.max(0, seconds);
		return String.format("%02d:%02d", safeSeconds / 60, safeSeconds % 60);
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					String name = new String(Base64.getDecoder().decode(values[0]), StandardCharsets.UTF_8);
					int score = Integer.parseInt(values[1]);
					int time = Integer.parseInt(values[2]);
					if (name.length() > 0) {
						this.playersNames.add(name);
						this.playersScores.add(Integer.valueOf(score));
						this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
					}
				} catch (IllegalArgumentException ex) {
					this.playersNames.clear();
					this.playersScores.clear();
					this.survivalTimes.clear();
					return;
				}
			}
			this.sort();
			while (this.playersNames.size() > MAX_ENTRIES) {
				int last = this.playersNames.size() - 1;
				this.playersNames.remove(last);
				this.playersScores.remove(last);
				this.survivalTimes.remove(last);
			}
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private synchronized void write() throws IOException {
		if (this.store == null) {
			return;
		}

		Path parent = this.store.toAbsolutePath().getParent();
		if (parent != null) {
			Files.createDirectories(parent);
		}

		try (BufferedWriter writer = Files.newBufferedWriter(
				this.store,
				StandardCharsets.UTF_8,
				StandardOpenOption.CREATE,
				StandardOpenOption.TRUNCATE_EXISTING,
				StandardOpenOption.WRITE)) {
			for (int i = 0; i < this.playersNames.size(); i++) {
				String encodedName = Base64.getEncoder().encodeToString(
						this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
				writer.write(encodedName);
				writer.write('\t');
				writer.write(String.valueOf(this.playersScores.get(i)));
				writer.write('\t');
				writer.write(String.valueOf(this.survivalTimes.get(i)));
				writer.newLine();
			}
		}
	}

	private synchronized void sort() {
		ArrayList<Integer> indices = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			indices.add(Integer.valueOf(i));
		}

		Collections.sort(indices, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()),
						ApoMarioHighscore.this.playersScores.get(first.intValue()));
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : indices) {
			sortedNames.add(this.playersNames.get(index.intValue()));
			sortedScores.add(this.playersScores.get(index.intValue()));
			sortedTimes.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.addAll(sortedTimes);
	}
}