package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int FILE_VERSION = 1;
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(survivalTime));
        this.sort();
        this.trim();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            DataOutputStream output = new DataOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(temporary)));

            output.writeInt(FILE_VERSION);
            output.writeInt(this.playersNames.size());

            for (int i = 0; i < this.playersNames.size(); i++) {
                output.writeUTF(this.playersNames.get(i));
                output.writeInt(this.playersScores.get(i).intValue());
                output.writeInt(this.survivalTimes.get(i).intValue());
            }

            output.flush();
            output.close();

            try {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }

        int elapsed;
        try {
            elapsed = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsed = level.getStartTime() - level.getTime();
        }

        if (elapsed < 0) {
            elapsed = 0;
        }

        this.storeRun(player.getPoints(), elapsed, name);
    }

    public static String formatSurvivalTime(int milliseconds) {
        if (milliseconds < 0) {
            milliseconds = 0;
        }

        int totalSeconds = milliseconds / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            DataInputStream input = new DataInputStream(
                    new BufferedInputStream(Files.newInputStream(this.store)));

            int version = input.readInt();
            if (version != FILE_VERSION) {
                input.close();
                return;
            }

            int size = input.readInt();
            if (size < 0 || size > MAX_ENTRIES * 10) {
                input.close();
                return;
            }

            for (int i = 0; i < size; i++) {
                String name = input.readUTF();
                int score = input.readInt();
                int survivalTime = input.readInt();

                if (name.length() == 0) {
                    name = "Player";
                }
                if (score < 0) {
                    score = 0;
                }
                if (survivalTime < 0) {
                    survivalTime = 0;
                }

                this.playersNames.add(name);
                this.playersScores.add(Integer.valueOf(score));
                this.survivalTimes.add(Integer.valueOf(survivalTime));
            }

            input.close();
            this.sort();
            this.trim();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indices = new ArrayList<Integer>();
        for (int i = 0; i < this.playersNames.size(); i++) {
            indices.add(Integer.valueOf(i));
        }

        Collections.sort(indices, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int firstScore = playersScores.get(first.intValue()).intValue();
                int secondScore = playersScores.get(second.intValue()).intValue();
                return Integer.compare(secondScore, firstScore);
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : indices) {
            int i = index.intValue();
            names.add(this.playersNames.get(i));
            scores.add(this.playersScores.get(i));
            times.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(names);
        this.playersScores.clear();
        this.playersScores.addAll(scores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(times);
    }

    private void trim() {
        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }
    }
}