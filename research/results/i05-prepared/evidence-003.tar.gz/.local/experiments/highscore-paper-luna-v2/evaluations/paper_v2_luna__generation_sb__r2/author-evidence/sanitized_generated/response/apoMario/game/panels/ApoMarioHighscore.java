package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int FILE_VERSION = 1;
    private static final int MAX_NAME_LENGTH = 64;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.playersNames.add(name);
        this.playersScores.add(score);
        this.survivalTimes.add(time);
        sortScores();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(this.playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(this.playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(this.survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            DataOutputStream output = new DataOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(temporary)));

            output.writeInt(FILE_VERSION);
            output.writeInt(this.playersNames.size());

            for (int i = 0; i < this.playersNames.size(); i++) {
                output.writeUTF(this.playersNames.get(i));
                output.writeInt(this.playersScores.get(i));
                output.writeInt(this.survivalTimes.get(i));
            }

            output.flush();
            output.close();

            try {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int elapsedSeconds = elapsedMilliseconds / 1000;
        storeRun(player.getPoints(), elapsedSeconds, player.getTeamName());
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        graphics.setColor(Color.BLACK);
        graphics.drawString("Highscore", 20, 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int y = 58;

        for (int i = 0; i < this.playersNames.size(); i++) {
            String line = (i + 1) + ". " + this.playersNames.get(i)
                    + "  " + this.playersScores.get(i)
                    + "  " + formatTime(this.survivalTimes.get(i));
            graphics.drawString(line, 20, y);
            y += 22;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            DataInputStream input = new DataInputStream(
                    new BufferedInputStream(Files.newInputStream(this.store)));

            int version = input.readInt();
            int count = input.readInt();

            if (version != FILE_VERSION || count < 0 || count > 100000) {
                input.close();
                clearScores();
                return;
            }

            ArrayList<String> names = new ArrayList<String>();
            ArrayList<Integer> scores = new ArrayList<Integer>();
            ArrayList<Integer> times = new ArrayList<Integer>();

            for (int i = 0; i < count; i++) {
                String name = input.readUTF();
                if (name.length() > MAX_NAME_LENGTH) {
                    throw new IOException("Invalid player name");
                }

                names.add(normalizeName(name));
                scores.add(input.readInt());
                times.add(Math.max(0, input.readInt()));
            }

            input.close();

            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();

            this.playersNames.addAll(names);
            this.playersScores.addAll(scores);
            this.survivalTimes.addAll(times);
            sortScores();
        } catch (IOException | RuntimeException ex) {
            clearScores();
        }
    }

    private void clearScores() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();
    }

    private void sortScores() {
        ArrayList<ScoreEntry> entries = new ArrayList<ScoreEntry>();

        for (int i = 0; i < this.playersNames.size(); i++) {
            entries.add(new ScoreEntry(
                    this.playersNames.get(i),
                    this.playersScores.get(i),
                    this.survivalTimes.get(i),
                    i));
        }

        Collections.sort(entries, new Comparator<ScoreEntry>() {
            @Override
            public int compare(ScoreEntry first, ScoreEntry second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Integer.compare(first.order, second.order);
            }
        });

        for (int i = 0; i < entries.size(); i++) {
            ScoreEntry entry = entries.get(i);
            this.playersNames.set(i, entry.name);
            this.playersScores.set(i, entry.score);
            this.survivalTimes.set(i, entry.time);
        }
    }

    private String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String normalized = name.trim();
        if (normalized.length() == 0) {
            return "Player";
        }

        if (normalized.length() > MAX_NAME_LENGTH) {
            return normalized.substring(0, MAX_NAME_LENGTH);
        }

        return normalized;
    }

    private static final class ScoreEntry {
        private final String name;
        private final int score;
        private final int time;
        private final int order;

        private ScoreEntry(String name, int score, int time, int order) {
            this.name = name;
            this.score = score;
            this.time = time;
            this.order = order;
        }
    }
}