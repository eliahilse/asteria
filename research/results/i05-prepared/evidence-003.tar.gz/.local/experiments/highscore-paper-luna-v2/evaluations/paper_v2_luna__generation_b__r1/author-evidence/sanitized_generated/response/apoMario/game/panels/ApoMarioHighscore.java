package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final List<Run> runs;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int points = Math.max(0, score);
        int time = Math.max(0, survivalTime);

        this.runs.add(new Run(points, time, name));
        this.sortRuns();

        if (this.runs.size() > MAX_ENTRIES) {
            this.runs.subList(MAX_ENTRIES, this.runs.size()).clear();
        }

        return this.write();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        this.write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = level.getStartTime() - level.getTime();
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        String playerName = player.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        this.storeRun(score, survivalTime / 1000, playerName);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 230));
        graphics.fillRoundRect(x, y, width, height, 20, 20);

        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);
        graphics.setFont(new Font("Dialog", Font.BOLD, 24));
        graphics.drawString("Highscore", x + 20, y + 35);

        graphics.setFont(new Font("Dialog", Font.BOLD, 16));
        int lineY = y + 65;
        int rowHeight = 25;

        for (int i = 0; i < this.runs.size(); i++) {
            if (lineY + rowHeight > y + height) {
                break;
            }

            Run run = this.runs.get(i);
            String line = (i + 1) + ". " + run.name + "   "
                    + run.score + "   " + formatTime(run.survivalTime);

            graphics.drawString(line, x + 20, lineY);
            lineY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        List<Run> loaded = new ArrayList<Run>();

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8
                );

                if (score < 0 || survivalTime < 0) {
                    throw new IOException("Invalid highscore value");
                }

                loaded.add(new Run(score, survivalTime, normalizeName(name)));
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            this.sortRuns();

            if (this.runs.size() > MAX_ENTRIES) {
                this.runs.subList(MAX_ENTRIES, this.runs.size()).clear();
            }
        } catch (Exception ex) {
            this.runs.clear();
        }
    }

    private boolean write() {
        if (this.store == null) {
            return false;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {

                for (Run run : this.runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)
                    );

                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            }

            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return "Player";
        }

        if (name.length() > 32) {
            return name.substring(0, 32);
        }

        return name;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}