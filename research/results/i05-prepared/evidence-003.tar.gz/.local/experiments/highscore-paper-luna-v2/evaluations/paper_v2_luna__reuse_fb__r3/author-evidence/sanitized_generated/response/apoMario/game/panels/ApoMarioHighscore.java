package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String SEPARATOR = "\t";

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName;
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name.trim());
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {

                for (int i = 0; i < this.playersNames.size(); i++) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
                    writer.write(encodedName);
                    writer.write(SEPARATOR);
                    writer.write(String.valueOf(this.playersScores.get(i).intValue()));
                    writer.write(SEPARATOR);
                    writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
                    writer.newLine();
                }
            }
        } catch (IOException ex) {
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.isBVisible()) {
                player = candidate;
                break;
            }
        }

        if (player == null) {
            player = level.getPlayers().get(0);
        }
        if (player == null) {
            return;
        }

        String playerName = player.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = player.getAuthor();
        }
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        int survivalTime = level.getStartTime() - level.getTime();
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.storeRun(player.getPoints(), survivalTime, playerName);
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        int totalSeconds = Math.max(0, survivalTime) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(SEPARATOR, -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    String name = new String(
                            Base64.getDecoder().decode(values[0]),
                            StandardCharsets.UTF_8);
                    int score = Integer.parseInt(values[1]);
                    int survivalTime = Integer.parseInt(values[2]);

                    if (name.trim().length() > 0) {
                        this.playersNames.add(name);
                        this.playersScores.add(Integer.valueOf(score));
                        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
                    }
                } catch (IllegalArgumentException ex) {
                }
            }
            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indices = new ArrayList<Integer>();
        for (int i = 0; i < this.playersNames.size(); i++) {
            indices.add(Integer.valueOf(i));
        }

        Collections.sort(indices, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
                        ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : indices) {
            int value = index.intValue();
            sortedNames.add(this.playersNames.get(value));
            sortedScores.add(this.playersScores.get(value));
            sortedTimes.add(this.survivalTimes.get(value));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }
}