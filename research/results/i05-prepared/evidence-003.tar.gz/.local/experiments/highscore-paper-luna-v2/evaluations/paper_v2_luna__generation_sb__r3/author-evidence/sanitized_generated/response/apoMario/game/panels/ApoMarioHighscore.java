package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final String FORMAT_VERSION = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        if (name.length() > 64) {
            name = name.substring(0, 64);
        }

        Entry entry = new Entry(name, score, Math.max(0, survivalTime));
        this.entries.add(entry);
        this.sortEntries();

        while (this.entries.size() > MAX_ENTRIES) {
            this.entries.remove(this.entries.size() - 1);
        }

        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add(FORMAT_VERSION);

            for (Entry entry : this.entries) {
                String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);

            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            survivalTime = level.getStartTime() - level.getTime();
        }

        String playerName = selected.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        this.storeRun(selected.getPoints(), Math.max(0, survivalTime), playerName);
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        int width = getWidth() > 0 ? getWidth() : 640;
        int height = getHeight() > 0 ? getHeight() : 480;

        graphics.setColor(new Color(245, 245, 245));
        graphics.fillRect(0, 0, width, height);

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        graphics.drawString("Highscores", 24, 36);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        graphics.drawString("#", 28, 68);
        graphics.drawString("Player", 70, 68);
        graphics.drawString("Points", 340, 68);
        graphics.drawString("Time", 450, 68);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int y = 92;
        for (int i = 0; i < this.entries.size(); i++) {
            Entry entry = this.entries.get(i);
            graphics.drawString(String.valueOf(i + 1), 28, y);
            graphics.drawString(entry.name, 70, y);
            graphics.drawString(String.valueOf(entry.score), 340, y);
            graphics.drawString(formatTime(entry.survivalTime), 450, y);
            y += 24;
            if (y > height - 10) {
                break;
            }
        }
    }

    public synchronized int size() {
        return this.entries.size();
    }

    private synchronized void load() {
        this.entries.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !FORMAT_VERSION.equals(lines.get(0))) {
                return;
            }

            ArrayList<Entry> loaded = new ArrayList<Entry>();
            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore entry");
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);

                if (name.length() == 0 || name.length() > 64) {
                    throw new IllegalArgumentException("Invalid player name");
                }

                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);
                if (survivalTime < 0) {
                    throw new IllegalArgumentException("Invalid survival time");
                }

                loaded.add(new Entry(name, score, survivalTime));
            }

            this.entries.addAll(loaded);
            this.sortEntries();

            while (this.entries.size() > MAX_ENTRIES) {
                this.entries.remove(this.entries.size() - 1);
            }
        } catch (Exception ex) {
            this.entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });
    }

    private static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainder = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}