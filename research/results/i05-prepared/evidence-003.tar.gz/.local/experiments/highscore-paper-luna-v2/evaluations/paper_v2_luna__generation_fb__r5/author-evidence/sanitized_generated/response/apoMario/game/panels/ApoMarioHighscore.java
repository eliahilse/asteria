package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int DEFAULT_SCORE = 0;
    private static final int DEFAULT_SURVIVAL_TIME = 0;

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);
        runs.add(new Run(score, time, name));
        sortRuns();
        return write();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        String playerName = player.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            if (player.getAi() != null) {
                playerName = player.getAi().getAuthor();
            }
        }
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        int elapsedMilliseconds = level.getPassedTime();
        int survivalSeconds = Math.max(0, elapsedMilliseconds / 1000);
        storeRun(player.getPoints(), survivalSeconds, playerName);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setFont(new Font("Dialog", Font.BOLD, 24));
        graphics.setColor(Color.BLACK);
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font("Dialog", Font.BOLD, 16));
        int lineY = y + 32;
        int row = 1;
        for (Run run : runs) {
            String line = row + ". " + run.name + "  " + run.score
                    + "  " + formatSurvivalTime(run.survivalTime);
            graphics.drawString(line, x, lineY);
            lineY += 24;
            row++;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatSurvivalTime(int survivalTime) {
        int seconds = Math.max(0, survivalTime);
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        synchronized (this) {
            runs.clear();
            if (!Files.isRegularFile(store)) {
                return;
            }

            try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
                String header = reader.readLine();
                if (!HEADER.equals(header)) {
                    runs.clear();
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().length() == 0) {
                        continue;
                    }

                    String[] values = line.split("\t", -1);
                    if (values.length != 3) {
                        runs.clear();
                        return;
                    }

                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);

                    runs.add(new Run(score, Math.max(0, survivalTime), normalizeName(name)));
                }
                sortRuns();
            } catch (Exception exception) {
                runs.clear();
            }
        }
    }

    private boolean write() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveException) {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            return true;
        } catch (IOException exception) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(
                        second.survivalTime, first.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String normalized = name.trim();
        if (normalized.length() == 0) {
            return "Player";
        }

        return normalized;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}