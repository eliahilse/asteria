package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final int MAX_ENTRIES = 100;
	private static final String DEFAULT_NAME = "Player";

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		int time = Math.max(0, survivalTime);

		this.playersNames.add(name);
		this.playersScores.add(score);
		this.survivalTimes.add(time);
		this.sortEntries();

		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}

		boolean persisted = this.write();
		this.repaint();
		return persisted;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		this.write();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer bestPlayer = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null) {
				continue;
			}
			if (bestPlayer == null || player.getPoints() > bestPlayer.getPoints()) {
				bestPlayer = player;
			}
		}

		if (bestPlayer == null) {
			return;
		}

		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.storeRun(bestPlayer.getPoints(), survivalTime, bestPlayer.getTeamName());
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
		graphics.drawString("Highscore", 20, 28);

		graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
		graphics.drawString("Name", 20, 55);
		graphics.drawString("Score", 180, 55);
		graphics.drawString("Time", 270, 55);

		int y = 78;
		for (int i = 0; i < this.playersNames.size(); i++) {
			graphics.drawString((i + 1) + ". " + this.playersNames.get(i), 20, y);
			graphics.drawString(String.valueOf(this.playersScores.get(i)), 180, y);
			graphics.drawString(formatTime(this.survivalTimes.get(i)), 270, y);
			y += 22;
		}
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					String name = new String(
							Base64.getDecoder().decode(values[0]),
							StandardCharsets.UTF_8);
					int score = Integer.parseInt(values[1]);
					int time = Integer.parseInt(values[2]);

					this.playersNames.add(normalizeName(name));
					this.playersScores.add(score);
					this.survivalTimes.add(Math.max(0, time));
				} catch (IllegalArgumentException ex) {
					this.playersNames.clear();
					this.playersScores.clear();
					this.survivalTimes.clear();
					return;
				}
			}
			this.sortEntries();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private synchronized boolean write() {
		if (this.store == null) {
			return false;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(
					temporary, StandardCharsets.UTF_8)) {
				for (int i = 0; i < this.playersNames.size(); i++) {
					String encodedName = Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(encodedName);
					writer.write('\t');
					writer.write(String.valueOf(this.playersScores.get(i)));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i)));
					writer.newLine();
				}
			}

			try {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException ex) {
			return false;
		}
	}

	private void sortEntries() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(i);
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						playersScores.get(second),
						playersScores.get(first));
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : order) {
			sortedNames.add(this.playersNames.get(index));
			sortedScores.add(this.playersScores.get(index));
			sortedTimes.add(this.survivalTimes.get(index));
		}

		this.playersNames.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.clear();
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(sortedTimes);
	}

	private static String normalizeName(String name) {
		if (name == null) {
			return DEFAULT_NAME;
		}

		String normalized = name.trim();
		if (normalized.length() == 0) {
			return DEFAULT_NAME;
		}
		return normalized;
	}

	private static String formatTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", minutes, seconds);
	}
}