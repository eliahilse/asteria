package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final String HEADER = "APO_MARIO_HIGHSCORE_1";

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return new ArrayList<String>(this.playersNames);
	}

	public synchronized List<Integer> getPlayersScores() {
		return new ArrayList<Integer>(this.playersScores);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return new ArrayList<Integer>(this.survivalTimes);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			try (BufferedWriter writer = Files.newBufferedWriter(this.store, StandardCharsets.UTF_8)) {
				writer.write(HEADER);
				writer.newLine();

				for (int i = 0; i < this.playersNames.size(); i++) {
					String encodedName = Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(encodedName);
					writer.write('\t');
					writer.write(String.valueOf(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
					writer.newLine();
				}
			}
		} catch (IOException ex) {
			// A failed write must not interrupt the running game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}

		String playerName = player.getTeamName();
		if (playerName == null || playerName.trim().length() == 0) {
			playerName = "Player";
		}

		this.storeRun(player.getPoints(), elapsed, playerName);
	}

	public static String formatSurvivalTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String header = reader.readLine();
			if (!HEADER.equals(header)) {
				return;
			}

			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					String name = new String(
							Base64.getDecoder().decode(values[0]), StandardCharsets.UTF_8);
					int score = Integer.parseInt(values[1]);
					int time = Integer.parseInt(values[2]);

					this.playersNames.add(name);
					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
				} catch (IllegalArgumentException ex) {
					// Ignore malformed records and retain valid scores.
				}
			}
			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		order.sort(new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}
}