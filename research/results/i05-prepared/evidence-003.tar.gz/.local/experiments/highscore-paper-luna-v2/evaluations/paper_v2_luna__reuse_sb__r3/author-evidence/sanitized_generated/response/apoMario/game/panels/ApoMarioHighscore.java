package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final Comparator<Run> SCORE_ORDER = new Comparator<Run>() {
        @Override
        public int compare(Run first, Run second) {
            return Integer.compare(second.score, first.score);
        }
    };

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }

        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(score);
        this.survivalTimes.add(survivalTime);
        this.sort();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        Path parent = this.store.getParent();

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {

                for (int i = 0; i < this.playersNames.size(); i++) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));

                    writer.write(Integer.toString(this.playersScores.get(i)));
                    writer.write('\t');
                    writer.write(Integer.toString(this.survivalTimes.get(i)));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            }
        } catch (IOException ex) {
            // A failed save must not interrupt the game loop.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }

            if (selectedPlayer == null
                    || player.getPoints() > selectedPlayer.getPoints()) {
                selectedPlayer = player;
            }
        }

        if (selectedPlayer == null) {
            return;
        }

        int elapsedTime = 0;
        try {
            elapsedTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedTime = level.getStartTime() - level.getTime();
        }

        if (elapsedTime < 0) {
            elapsedTime = 0;
        }

        String playerName = selectedPlayer.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = selectedPlayer.getAuthor();
        }
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        this.storeRun(selectedPlayer.getPoints(), elapsedTime, playerName);
        this.persistAcrossRuns();
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Run> runs = new ArrayList<Run>();

        try (BufferedReader reader = Files.newBufferedReader(
                this.store, StandardCharsets.UTF_8)) {

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore entry");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);

                if (name.trim().length() == 0) {
                    name = "Player";
                }
                runs.add(new Run(score, survivalTime, name));
            }

            Collections.sort(runs, SCORE_ORDER);
            for (Run run : runs) {
                this.playersScores.add(run.score);
                this.survivalTimes.add(run.survivalTime);
                this.playersNames.add(run.name);
            }
        } catch (IOException | RuntimeException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Run> runs = new ArrayList<Run>();

        for (int i = 0; i < this.playersNames.size(); i++) {
            runs.add(new Run(
                    this.playersScores.get(i),
                    this.survivalTimes.get(i),
                    this.playersNames.get(i)));
        }

        Collections.sort(runs, SCORE_ORDER);

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        for (Run run : runs) {
            this.playersNames.add(run.name);
            this.playersScores.add(run.score);
            this.survivalTimes.add(run.survivalTime);
        }
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}