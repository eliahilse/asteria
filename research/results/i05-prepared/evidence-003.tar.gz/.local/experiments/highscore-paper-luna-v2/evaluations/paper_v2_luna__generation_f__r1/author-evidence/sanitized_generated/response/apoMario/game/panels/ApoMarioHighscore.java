package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final ArrayList<Run> runs;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.runs.add(new Run(score, survivalTime, name));
        this.sortRuns();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (Run run : this.runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A failed write must not interrupt the running game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.isBVisible()) {
                player = candidate;
                break;
            }
        }
        if (player == null) {
            player = level.getPlayers().get(0);
        }
        if (player == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = level.getStartTime() - level.getTime();
        }

        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalSeconds = elapsedMilliseconds / 1000;
        String playerName = DEFAULT_PLAYER_NAME;

        if (player.getAi() != null) {
            String teamName = player.getAi().getTeamName();
            if (teamName != null && teamName.trim().length() > 0) {
                playerName = teamName.trim();
            } else {
                String author = player.getAi().getAuthor();
                if (author != null && author.trim().length() > 0) {
                    playerName = author.trim();
                }
            }
        }

        this.storeRun(player.getPoints(), survivalSeconds, playerName);
    }

    public synchronized String getFormattedSurvivalTime(int index) {
        if (index < 0 || index >= this.runs.size()) {
            return "00:00";
        }
        return formatSurvivalTime(this.runs.get(index).survivalTime);
    }

    public static String formatSurvivalTime(int seconds) {
        if (seconds < 0) {
            seconds = 0;
        }

        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);
                    if (survivalTime >= 0) {
                        this.runs.add(new Run(score, survivalTime, normalizeName(name)));
                    }
                } catch (RuntimeException ex) {
                    this.runs.clear();
                    return;
                }
            }
            this.sortRuns();
        } catch (IOException | RuntimeException ex) {
            this.runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String name = playerName.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (name.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }
        return name;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}