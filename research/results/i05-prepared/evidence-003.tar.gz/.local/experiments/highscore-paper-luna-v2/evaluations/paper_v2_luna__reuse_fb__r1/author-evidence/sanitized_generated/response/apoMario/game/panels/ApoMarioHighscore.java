package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(Math.max(0, score)));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        while (this.playersNames.size() > MAX_ENTRIES) {
            int index = this.playersNames.size() - 1;
            this.playersNames.remove(index);
            this.playersScores.remove(index);
            this.survivalTimes.remove(index);
        }
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {
                for (int i = 0; i < this.playersNames.size(); i++) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(String.valueOf(this.playersScores.get(i)));
                    writer.write('\t');
                    writer.write(String.valueOf(this.survivalTimes.get(i)));
                    writer.newLine();
                }
            }
        } catch (IOException ignored) {
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsed = level.getPassedTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        this.storeRun(player.getPoints(), elapsed, name);
        this.persistAcrossRuns();
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font("Dialog", Font.BOLD, 24));
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font("Dialog", Font.PLAIN, 16));
        int line = y + 32;
        int limit = Math.min(this.playersNames.size(), 10);

        for (int i = 0; i < limit; i++) {
            String time = formatSurvivalTime(this.survivalTimes.get(i).intValue());
            String text = (i + 1) + ". " + this.playersNames.get(i)
                    + "  " + this.playersScores.get(i) + "  " + time;
            graphics.drawString(text, x, line);
            line += 24;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatSurvivalTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        int minutes = seconds / 60;
        seconds %= 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    String name = new String(
                            Base64.getDecoder().decode(values[0]),
                            StandardCharsets.UTF_8);
                    int score = Integer.parseInt(values[1]);
                    int time = Integer.parseInt(values[2]);

                    if (name.length() > 0 && score >= 0 && time >= 0) {
                        this.playersNames.add(name);
                        this.playersScores.add(Integer.valueOf(score));
                        this.survivalTimes.add(Integer.valueOf(time));
                    }
                } catch (IllegalArgumentException ignored) {
                }
            }
            this.sort();
            while (this.playersNames.size() > MAX_ENTRIES) {
                int index = this.playersNames.size() - 1;
                this.playersNames.remove(index);
                this.playersScores.remove(index);
                this.survivalTimes.remove(index);
            }
        } catch (IOException ignored) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indices = new ArrayList<Integer>();
        for (int i = 0; i < this.playersNames.size(); i++) {
            indices.add(Integer.valueOf(i));
        }

        Collections.sort(indices, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreCompare = Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());
                if (scoreCompare != 0) {
                    return scoreCompare;
                }
                return Integer.compare(
                        survivalTimes.get(first.intValue()).intValue(),
                        survivalTimes.get(second.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : indices) {
            sortedNames.add(this.playersNames.get(index.intValue()));
            sortedScores.add(this.playersScores.get(index.intValue()));
            sortedTimes.add(this.survivalTimes.get(index.intValue()));
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        this.playersNames.addAll(sortedNames);
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.addAll(sortedTimes);
    }
}