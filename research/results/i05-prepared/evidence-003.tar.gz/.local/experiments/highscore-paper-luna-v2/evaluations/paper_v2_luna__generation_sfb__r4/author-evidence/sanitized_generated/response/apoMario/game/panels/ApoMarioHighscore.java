package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final String DEFAULT_PLAYER_NAME = "Player";
    private static final int DEFAULT_X = 20;
    private static final int DEFAULT_Y = 30;
    private static final int DEFAULT_WIDTH = 280;

    private final Path store;
    private final List<Run> runs;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);
        this.runs.add(new Run(name, score, time));
        sortRuns();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                selectedPlayer = player;
                break;
            }
        }

        if (selectedPlayer == null) {
            selectedPlayer = level.getPlayers().get(0);
        }
        if (selectedPlayer == null) {
            return;
        }

        int elapsedMilliseconds = level.getPassedTime();
        int elapsedSeconds = Math.max(0, elapsedMilliseconds / 1000);
        String playerName = selectedPlayer.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            if (selectedPlayer.getAi() != null) {
                playerName = selectedPlayer.getAi().getTeamName();
            }
        }

        storeRun(selectedPlayer.getPoints(), elapsedSeconds, playerName);
    }

    public synchronized String getFormattedSurvivalTime(int index) {
        if (index < 0 || index >= this.runs.size()) {
            return "00:00";
        }
        return formatSurvivalTime(this.runs.get(index).survivalTime);
    }

    public static String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainder = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    public synchronized void render(Graphics2D graphics) {
        render(graphics, DEFAULT_X, DEFAULT_Y, DEFAULT_WIDTH);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.setColor(Color.BLACK);
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int rowY = y + 28;
        int rowHeight = 20;

        for (int i = 0; i < this.runs.size(); i++) {
            Run run = this.runs.get(i);
            String row = (i + 1) + ". " + run.name + "  " + run.score
                    + "  " + formatSurvivalTime(run.survivalTime);
            graphics.drawString(row, x, rowY + i * rowHeight);
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        List<Run> loaded = new ArrayList<Run>();

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line = reader.readLine();
            if (!HEADER.equals(line)) {
                return;
            }

            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    return;
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (name.trim().length() == 0 || survivalTime < 0) {
                    return;
                }

                loaded.add(new Run(name, score, survivalTime));
            }
        } catch (Exception exception) {
            return;
        }

        this.runs.clear();
        this.runs.addAll(loaded);
        sortRuns();
    }

    private boolean persist() {
        if (this.store == null) {
            return false;
        }

        Path parent = this.store.getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : this.runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            return true;
        } catch (IOException exception) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String normalized = playerName.trim();
        if (normalized.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }

        return normalized;
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}