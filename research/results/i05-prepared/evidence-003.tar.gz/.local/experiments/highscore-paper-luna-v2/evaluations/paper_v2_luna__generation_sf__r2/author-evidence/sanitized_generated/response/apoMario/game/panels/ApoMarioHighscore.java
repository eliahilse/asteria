package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;
	private static final int FILE_VERSION = 1;
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<Entry> entries;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.entries = new ArrayList<Entry>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = cleanName(playerName);
		Entry entry = new Entry(name, score, Math.max(0, survivalTime));
		this.entries.add(entry);
		Collections.sort(this.entries, ENTRY_ORDER);
		if (this.entries.size() > MAX_ENTRIES) {
			this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
		}
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		ArrayList<String> result = new ArrayList<String>();
		for (Entry entry : this.entries) {
			result.add(entry.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (DataOutputStream output = new DataOutputStream(
					new BufferedOutputStream(Files.newOutputStream(temporary)))) {
				output.writeInt(FILE_VERSION);
				output.writeInt(this.entries.size());
				for (Entry entry : this.entries) {
					output.writeUTF(entry.name);
					output.writeInt(entry.score);
					output.writeInt(entry.survivalTime);
				}
			}

			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException atomicMoveFailure) {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null || !player.isBVisible()) {
				continue;
			}
			if (selected == null || player.getPoints() > selected.getPoints()) {
				selected = player;
			}
		}

		if (selected == null) {
			for (ApoMarioPlayer player : level.getPlayers()) {
				if (player != null) {
					if (selected == null || player.getPoints() > selected.getPoints()) {
						selected = player;
					}
				}
			}
		}

		if (selected == null) {
			return;
		}

		int elapsed;
		try {
			elapsed = level.getPassedTime();
		} catch (RuntimeException ex) {
			elapsed = 0;
		}

		String name = selected.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = selected.getAuthor();
		}
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		this.storeRun(selected.getPoints(), elapsed, name);
	}

	public static String formatSurvivalTime(int milliseconds) {
		long seconds = Math.max(0, milliseconds) / 1000L;
		long minutes = seconds / 60L;
		long remainingSeconds = seconds % 60L;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			int width = getWidth();
			int rowHeight = 25;
			int y = 30;

			g.setColor(Color.BLACK);
			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			g.drawString("Highscore", 15, y);

			y += 30;
			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
			g.drawString("#", 15, y);
			g.drawString("Player", 50, y);
			g.drawString("Points", Math.max(150, width - 180), y);
			g.drawString("Time", Math.max(230, width - 90), y);

			g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
			for (int i = 0; i < this.entries.size(); i++) {
				Entry entry = this.entries.get(i);
				y += rowHeight;
				g.drawString(String.valueOf(i + 1), 15, y);
				g.drawString(entry.name, 50, y);
				g.drawString(String.valueOf(entry.score), Math.max(150, width - 180), y);
				g.drawString(formatSurvivalTime(entry.survivalTime), Math.max(230, width - 90), y);
			}
		} finally {
			g.dispose();
		}
	}

	private void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (DataInputStream input = new DataInputStream(
				new BufferedInputStream(Files.newInputStream(this.store)))) {
			if (input.readInt() != FILE_VERSION) {
				this.entries.clear();
				return;
			}

			int count = input.readInt();
			if (count < 0 || count > MAX_ENTRIES) {
				this.entries.clear();
				return;
			}

			for (int i = 0; i < count; i++) {
				String name = cleanName(input.readUTF());
				int score = input.readInt();
				int survivalTime = input.readInt();
				if (survivalTime < 0) {
					throw new IOException("Invalid survival time");
				}
				this.entries.add(new Entry(name, score, survivalTime));
			}
			Collections.sort(this.entries, ENTRY_ORDER);
		} catch (IOException | RuntimeException ex) {
			this.entries.clear();
		}
	}

	private static String cleanName(String name) {
		if (name == null) {
			return "Player";
		}

		String cleaned = name.replace('\r', ' ').replace('\n', ' ').trim();
		if (cleaned.length() == 0) {
			return "Player";
		}
		if (cleaned.length() >  forty()) {
			return cleaned.substring(0, forty());
		}
		return cleaned;
	}

	private static int forty() {
		return 40;
	}

	private static final Comparator<Entry> ENTRY_ORDER = new Comparator<Entry>() {
		@Override
		public int compare(Entry first, Entry second) {
			int score = Integer.compare(second.score, first.score);
			if (score != 0) {
				return score;
			}
			return Integer.compare(first.survivalTime, second.survivalTime);
		}
	};

	private static final class Entry {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Entry(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}