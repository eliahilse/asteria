package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String HEADER = "APOMARIO_HIGHSCORE_1";
	private static final int DEFAULT_WIDTH = 640;
	private static final int DEFAULT_HEIGHT = 480;

	private final Path store;
	private final List<Run> runs;

	private static final class Run {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Run(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.runs = new ArrayList<Run>();
		this.setBackground(Color.WHITE);
		this.setOpaque(true);
		this.setFocusable(false);
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		runs.add(new Run(name, score, survivalTime));
		sortRuns();
		persistAcrossRuns();
		repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		List<String> result = new ArrayList<String>();
		for (Run run : runs) {
			result.add(run.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		List<Integer> result = new ArrayList<Integer>();
		for (Run run : runs) {
			result.add(Integer.valueOf(run.score));
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		List<Integer> result = new ArrayList<Integer>();
		for (Run run : runs) {
			result.add(Integer.valueOf(run.survivalTime));
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		if (store == null) {
			return;
		}

		try {
			Path parent = store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
			BufferedWriter writer = Files.newBufferedWriter(
					temporary,
					StandardCharsets.UTF_8);

			try {
				writer.write(HEADER);
				writer.newLine();

				for (Run run : runs) {
					String encodedName = Base64.getEncoder().encodeToString(
							run.name.getBytes(StandardCharsets.UTF_8));
					writer.write(encodedName);
					writer.write('\t');
					writer.write(Integer.toString(run.score));
					writer.write('\t');
					writer.write(Integer.toString(run.survivalTime));
					writer.newLine();
				}
			} finally {
				writer.close();
			}

			try {
				Files.move(temporary, store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException atomicMoveFailure) {
				Files.move(temporary, store,
						StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
				Files.deleteIfExists(temporary);
			} catch (IOException ignored) {
			}
		}
	}

	public void recordRunEnd(ApoMarioLevel level) {
		if (level == null) {
			return;
		}

		try {
			Object playersObject = level.getPlayers();
			if (!(playersObject instanceof List<?>)) {
				return;
			}

			List<?> players = (List<?>) playersObject;
			if (players.isEmpty() || players.get(0) == null) {
				return;
			}

			Object player = players.get(0);
			int score = invokeInt(player, "getPoints", 0);
			String name = invokeString(player, "getTeamName", null);

			if (name == null || name.trim().length() == 0) {
				Object ai = invokeObject(player, "getAi");
				name = invokeString(ai, "getTeamName", null);
			}
			if (name == null || name.trim().length() == 0) {
				name = "Player";
			}

			int elapsedMilliseconds;
			try {
				elapsedMilliseconds = level.getPassedTime();
			} catch (RuntimeException ex) {
				elapsedMilliseconds = level.getStartTime() - level.getTime();
			}

			if (elapsedMilliseconds < 0) {
				elapsedMilliseconds = 0;
			}

			storeRun(score, elapsedMilliseconds / 1000, name);
		} catch (RuntimeException ex) {
			// A run that has not been fully initialized cannot be recorded.
		}
	}

	private synchronized void load() {
		runs.clear();

		if (store == null || !Files.isRegularFile(store)) {
			return;
		}

		try {
			BufferedReader reader = Files.newBufferedReader(
					store,
					StandardCharsets.UTF_8);

			try {
				String header = reader.readLine();
				if (!HEADER.equals(header)) {
					runs.clear();
					return;
				}

				String line;
				while ((line = reader.readLine()) != null) {
					if (line.trim().length() == 0) {
						continue;
					}

					String[] values = line.split("\\t", -1);
					if (values.length != 3) {
						throw new IOException("Invalid highscore record");
					}

					String name = new String(
							Base64.getDecoder().decode(values[0]),
							StandardCharsets.UTF_8);
					int score = Integer.parseInt(values[1]);
					int survivalTime = Integer.parseInt(values[2]);

					if (name.trim().length() == 0 || score < 0 || survivalTime < 0) {
						throw new IOException("Invalid highscore values");
					}

					runs.add(new Run(name, score, survivalTime));
				}
			} finally {
				reader.close();
			}

			sortRuns();
		} catch (Exception ex) {
			runs.clear();
		}
	}

	private void sortRuns() {
		Collections.sort(runs, new Comparator<Run>() {
			@Override
			public int compare(Run first, Run second) {
				return Integer.compare(second.score, first.score);
			}
		});
	}

	private static Object invokeObject(Object target, String methodName) {
		if (target == null) {
			return null;
		}

		try {
			return target.getClass().getMethod(methodName).invoke(target);
		} catch (Exception ex) {
			return null;
		}
	}

	private static int invokeInt(Object target, String methodName, int fallback) {
		Object value = invokeObject(target, methodName);
		if (value instanceof Number) {
			return ((Number) value).intValue();
		}
		return fallback;
	}

	private static String invokeString(Object target, String methodName, String fallback) {
		Object value = invokeObject(target, methodName);
		return value instanceof String ? (String) value : fallback;
	}

	public static String formatSurvivalTime(int seconds) {
		if (seconds < 0) {
			seconds = 0;
		}

		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes),
				Integer.valueOf(remainingSeconds));
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);

			int width = getWidth() > 0 ? getWidth() : DEFAULT_WIDTH;
			int rowHeight = 30;
			int y = 42;

			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 24));
			g.drawString("Highscores", 24, 30);

			g.setFont(new Font("Dialog", Font.BOLD, 15));
			g.drawString("#", 28, y);
			g.drawString("Player", 70, y);
			g.drawString("Score", Math.max(260, width - 250), y);
			g.drawString("Time", Math.max(410, width - 130), y);

			g.setFont(new Font("Dialog", Font.PLAIN, 15));
			for (int i = 0; i < runs.size(); i++) {
				Run run = runs.get(i);
				y += rowHeight;

				g.drawString(Integer.toString(i + 1), 28, y);
				g.drawString(run.name, 70, y);
				g.drawString(Integer.toString(run.score),
						Math.max(260, width - 250), y);
				g.drawString(formatSurvivalTime(run.survivalTime),
						Math.max(410, width - 130), y);
			}
		} finally {
			g.dispose();
		}
	}
}