package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<Run> runs;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.runs.add(new Run(name, score, survivalTime));
        this.sort();
        while (this.runs.size() > MAX_ENTRIES) {
            this.runs.remove(this.runs.size() - 1);
        }

        try {
            this.write();
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        try {
            this.write();
        } catch (IOException ex) {
            // The in-memory board remains available when the store cannot be written.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalTime = elapsedMilliseconds / 1000;
        this.storeRun(score, survivalTime, getPlayerName(player));
    }

    public static String formatSurvivalTime(int survivalTime) {
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        int minutes = survivalTime / 60;
        int seconds = survivalTime % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private String getPlayerName(ApoMarioPlayer player) {
        String name = null;

        if (player.getAi() != null) {
            name = player.getAi().getTeamName();
            if (name == null || name.trim().length() == 0) {
                name = player.getAi().getAuthor();
            }
        }

        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        return normalizeName(name);
    }

    private String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String result = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) {
            return "Player";
        }
        return result;
    }

    private void sort() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Run> loaded = new ArrayList<Run>();
        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);
                if (score < 0 || survivalTime < 0) {
                    throw new IOException("Invalid highscore values");
                }

                loaded.add(new Run(normalizeName(values[0]), score, survivalTime));
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            this.sort();
            while (this.runs.size() > MAX_ENTRIES) {
                this.runs.remove(this.runs.size() - 1);
            }
        } catch (Exception ex) {
            this.runs.clear();
        }
    }

    private void write() throws IOException {
        Path parent = this.store.toAbsolutePath().getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }

        Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
        try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
            for (Run run : this.runs) {
                writer.write(run.name);
                writer.write('\t');
                writer.write(Integer.toString(run.score));
                writer.write('\t');
                writer.write(Integer.toString(run.survivalTime));
                writer.newLine();
            }
        }

        try {
            Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}