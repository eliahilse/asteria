package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int FIELD_COUNT = 3;

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        Run run = new Run(name, Math.max(0, score), Math.max(0, survivalTime));
        runs.add(run);
        sortRuns();
        return writeStore();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        writeStore();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsedMilliseconds = level.getPassedTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = Math.max(0, level.getStartTime() - level.getTime());
        }

        int survivalSeconds = elapsedMilliseconds / 1000;
        String playerName = player.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            playerName = player.getAuthor();
        }
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        storeRun(player.getPoints(), survivalSeconds, playerName);
    }

    public synchronized String getSurvivalTimeText(int index) {
        if (index < 0 || index >= runs.size()) {
            return "00:00";
        }
        return formatTime(runs.get(index).survivalTime);
    }

    public synchronized List<String> getFormattedSurvivalTimes() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) {
            result.add(formatTime(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 230));
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font("Dialog", Font.BOLD, 22));
        graphics.drawString("Highscore", x + 20, y + 32);

        graphics.setFont(new Font("Dialog", Font.BOLD, 14));
        int rowY = y + 60;
        graphics.drawString("#", x + 20, rowY);
        graphics.drawString("Player", x + 55, rowY);
        graphics.drawString("Points", x + width - 145, rowY);
        graphics.drawString("Time", x + width - 75, rowY);

        graphics.setFont(new Font("Dialog", Font.PLAIN, 14));
        for (int i = 0; i < runs.size(); i++) {
            Run run = runs.get(i);
            rowY += 22;
            if (rowY > y + height - 10) {
                break;
            }
            graphics.drawString(String.valueOf(i + 1), x + 20, rowY);
            graphics.drawString(run.name, x + 55, rowY);
            graphics.drawString(String.valueOf(run.score), x + width - 145, rowY);
            graphics.drawString(formatTime(run.survivalTime), x + width - 75, rowY);
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    private synchronized void load() {
        runs.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("\t", -1);
                if (fields.length != FIELD_COUNT) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(fields[1]);
                int survivalTime = Integer.parseInt(fields[2]);
                String name = cleanName(fields[0]);

                if (name.length() == 0 || score < 0 || survivalTime < 0) {
                    throw new IOException("Invalid highscore value");
                }

                runs.add(new Run(name, score, survivalTime));
            }
            sortRuns();
        } catch (Exception exception) {
            runs.clear();
        }
    }

    private synchronized boolean writeStore() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                for (Run run : runs) {
                    writer.write(encode(run.name));
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException exception) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String cleanName(String value) {
        if (value == null) {
            return "";
        }
        return value.replace('\t', ' ')
                .replace('\r', ' ')
                .replace('\n', ' ')
                .trim();
    }

    private static String encode(String value) {
        return cleanName(value);
    }

    private static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}