package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final String DEFAULT_PLAYER_NAME = "Player";

	private final Path store;
	private final List<Entry> entries;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store must not be null");
		}
		this.store = store;
		this.entries = new ArrayList<Entry>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		int normalizedScore = Math.max(0, score);
		int normalizedTime = Math.max(0, survivalTime);

		this.entries.add(new Entry(name, normalizedScore, normalizedTime));
		Collections.sort(this.entries, Entry.SCORE_ORDER);
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		List<String> result = new ArrayList<String>(this.entries.size());
		for (Entry entry : this.entries) {
			result.add(entry.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		List<Integer> result = new ArrayList<Integer>(this.entries.size());
		for (Entry entry : this.entries) {
			result.add(entry.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		List<Integer> result = new ArrayList<Integer>(this.entries.size());
		for (Entry entry : this.entries) {
			result.add(entry.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		Path parent = this.store.getParent();
		Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

		try {
			if (parent != null) {
				Files.createDirectories(parent);
			}

			try (BufferedWriter writer = Files.newBufferedWriter(
					temporary,
					StandardCharsets.UTF_8)) {
				for (Entry entry : this.entries) {
					String encodedName = Base64.getEncoder().encodeToString(
							entry.name.getBytes(StandardCharsets.UTF_8));
					writer.write(encodedName);
					writer.write('\t');
					writer.write(Integer.toString(entry.score));
					writer.write('\t');
					writer.write(Integer.toString(entry.survivalTime));
					writer.newLine();
				}
			}

			try {
				Files.move(
						temporary,
						this.store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(
						temporary,
						this.store,
						StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(temporary);
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int elapsedMilliseconds = level.getStartTime() - level.getTime();
		if (elapsedMilliseconds < 0) {
			elapsedMilliseconds = 0;
		}

		int survivalTime = elapsedMilliseconds / 1000;
		String playerName = player.getTeamName();
		this.storeRun(player.getPoints(), survivalTime, playerName);
	}

	public static String formatSurvivalTime(int survivalTime) {
		int seconds = Math.max(0, survivalTime);
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	private void load() {
		if (!Files.isRegularFile(this.store)) {
			return;
		}

		List<Entry> loaded = new ArrayList<Entry>();

		try (BufferedReader reader = Files.newBufferedReader(
				this.store,
				StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				if (line.trim().isEmpty()) {
					continue;
				}

				String[] values = line.split("\\t", -1);
				if (values.length != 3) {
					throw new IOException("Invalid highscore entry");
				}

				String name = new String(
						Base64.getDecoder().decode(values[0]),
						StandardCharsets.UTF_8);
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);

				if (score < 0 || survivalTime < 0) {
					throw new IOException("Invalid highscore values");
				}

				loaded.add(new Entry(normalizeName(name), score, survivalTime));
			}

			Collections.sort(loaded, Entry.SCORE_ORDER);
			this.entries.clear();
			this.entries.addAll(loaded);
		} catch (Exception ex) {
			this.entries.clear();
		}
	}

	private static String normalizeName(String playerName) {
		if (playerName == null) {
			return DEFAULT_PLAYER_NAME;
		}

		String name = playerName.trim();
		if (name.length() == 0) {
			return DEFAULT_PLAYER_NAME;
		}

		return name;
	}

	private static final class Entry {

		private static final Comparator<Entry> SCORE_ORDER =
				new Comparator<Entry>() {
					@Override
					public int compare(Entry first, Entry second) {
						int scoreComparison = Integer.compare(
								second.score,
								first.score);
						if (scoreComparison != 0) {
							return scoreComparison;
						}
						return Integer.compare(
								first.survivalTime,
								second.survivalTime);
					}
				};

		private final String name;
		private final int score;
		private final int survivalTime;

		private Entry(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}