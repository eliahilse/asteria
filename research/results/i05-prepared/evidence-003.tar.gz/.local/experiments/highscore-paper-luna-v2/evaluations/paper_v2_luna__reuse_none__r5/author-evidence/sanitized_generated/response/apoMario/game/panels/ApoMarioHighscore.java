package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName;
		if (name == null) {
			name = "";
		}
		name = name.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}

		return this.write();
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		this.write();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		String name = "Player";
		if (player.getAi() != null) {
			if (player.getAi().getTeamName() != null
					&& player.getAi().getTeamName().trim().length() > 0) {
				name = player.getAi().getTeamName().trim();
			} else if (player.getAi().getAuthor() != null
					&& player.getAi().getAuthor().trim().length() > 0) {
				name = player.getAi().getAuthor().trim();
			}
		}

		int elapsed = 0;
		try {
			elapsed = level.getPassedTime();
		} catch (RuntimeException ex) {
			elapsed = 0;
		}
		if (elapsed > 1000) {
			elapsed /= 1000;
		}

		this.storeRun(player.getPoints(), elapsed, name);
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}
				try {
					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					String name = unescape(values[2]);
					if (name.length() == 0) {
						name = "Player";
					}
					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(time));
					this.playersNames.add(name);
				} catch (NumberFormatException ex) {
					this.playersNames.clear();
					this.playersScores.clear();
					this.survivalTimes.clear();
					return;
				}
			}
			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private synchronized boolean write() {
		if (this.store == null) {
			return false;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
				for (int i = 0; i < this.playersNames.size(); i++) {
					writer.write(Integer.toString(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
					writer.write('\t');
					writer.write(escape(this.playersNames.get(i)));
					writer.newLine();
				}
			}

			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException ex) {
			return false;
		}
	}

	private void sort() {
		ArrayList<Integer> indices = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			indices.add(Integer.valueOf(i));
		}

		Collections.sort(indices, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : indices) {
			names.add(this.playersNames.get(index.intValue()));
			scores.add(this.playersScores.get(index.intValue()));
			times.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private static String escape(String value) {
		return value.replace("\\", "\\\\")
				.replace("\t", "\\t")
				.replace("\r", "\\r")
				.replace("\n", "\\n");
	}

	private static String unescape(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;

		for (int i = 0; i < value.length(); i++) {
			char character = value.charAt(i);
			if (escaped) {
				if (character == 't') {
					result.append('\t');
				} else if (character == 'r') {
					result.append('\r');
				} else if (character == 'n') {
					result.append('\n');
				} else {
					result.append(character);
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else {
				result.append(character);
			}
		}

		if (escaped) {
			result.append('\\');
		}
		return result.toString();
	}
}