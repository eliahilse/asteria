package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final List<Entry> entries;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int safeScore = Math.max(0, score);
        int safeTime = Math.max(0, survivalTime);

        this.entries.add(new Entry(name, safeScore, safeTime));
        this.sort();
        return this.save();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        this.save();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = getSurvivalTime(level);
        String playerName = player.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            if (player.getAi() != null && player.getAi().getTeamName() != null) {
                playerName = player.getAi().getTeamName();
            } else {
                playerName = DEFAULT_PLAYER_NAME;
            }
        }

        this.storeRun(score, survivalTime, playerName);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 230));
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font("Dialog", Font.BOLD, 20));
        graphics.drawString("Highscore", x + 20, y + 32);

        graphics.setFont(new Font("Dialog", Font.BOLD, 14));
        int rowY = y + 60;
        int rowHeight = 24;

        for (int i = 0; i < this.entries.size(); i++) {
            if (rowY + rowHeight > y + height - 8) {
                break;
            }

            Entry entry = this.entries.get(i);
            graphics.drawString(String.valueOf(i + 1), x + 20, rowY);
            graphics.drawString(entry.name, x + 55, rowY);
            graphics.drawString(String.valueOf(entry.score), x + width - 145, rowY);
            graphics.drawString(formatSurvivalTime(entry.survivalTime), x + width - 75, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
    }

    private int getSurvivalTime(ApoMarioLevel level) {
        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }
        return elapsedMilliseconds / 1000;
    }

    private String normalizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }
        if (name.length() > 32) {
            return name.substring(0, 32);
        }
        return name;
    }

    private void sort() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        List<Entry> loaded = new ArrayList<Entry>();

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                String name = new String(
                    Base64.getDecoder().decode(values[0]),
                    StandardCharsets.UTF_8
                );
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (score < 0 || survivalTime < 0) {
                    throw new IOException("Invalid highscore values");
                }

                loaded.add(new Entry(normalizeName(name), score, survivalTime));
            }

            this.entries.clear();
            this.entries.addAll(loaded);
            this.sort();
        } catch (Exception ex) {
            this.entries.clear();
        }
    }

    private boolean save() {
        Path parent = this.store.toAbsolutePath().getParent();

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Entry entry : this.entries) {
                    String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8)
                    );
                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(String.valueOf(entry.score));
                    writer.write('\t');
                    writer.write(String.valueOf(entry.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                    temporary,
                    this.store,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
                );
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                    temporary,
                    this.store,
                    StandardCopyOption.REPLACE_EXISTING
                );
            }

            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}