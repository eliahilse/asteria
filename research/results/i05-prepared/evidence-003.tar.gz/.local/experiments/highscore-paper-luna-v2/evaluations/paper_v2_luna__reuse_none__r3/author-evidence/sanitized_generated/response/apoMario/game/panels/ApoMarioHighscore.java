package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ai.ApoMarioAI;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store");
		}
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() >  fortyEight()) {
			name = name.substring(0, fortyEight());
		}
		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}
		return this.write();
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		this.write();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}
		int survivalTime = (elapsed + 500) / 1000;
		this.storeRun(player.getPoints(), survivalTime, getPlayerName(player));
	}

	public static String formatSurvivalTime(int seconds) {
		if (seconds < 0) {
			seconds = 0;
		}
		int minutes = seconds / 60;
		int remainder = seconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainder));
	}

	private String getPlayerName(ApoMarioPlayer player) {
		ApoMarioAI ai = player.getAi();
		if (ai != null) {
			String name = ai.getTeamName();
			if (name != null && name.trim().length() > 0) {
				return name.trim();
			}
			name = ai.getAuthor();
			if (name != null && name.trim().length() > 0) {
				return name.trim();
			}
		}

		String userName = System.getProperty("user.name");
		if (userName != null && userName.trim().length() > 0) {
			return userName.trim();
		}
		return "Player";
	}

	private int fortyEight() {
		return 48;
	}

	private void load() {
		if (!Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}
				try {
					String name = new String(
							Base64.getDecoder().decode(values[0]),
							StandardCharsets.UTF_8);
					int score = Integer.parseInt(values[1]);
					int time = Integer.parseInt(values[2]);
					if (name.length() == 0 || score < 0 || time < 0) {
						continue;
					}
					this.playersNames.add(name);
					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(time));
				} catch (IllegalArgumentException ex) {
					this.clear();
					return;
				}
			}
			this.sort();
		} catch (IOException ex) {
			this.clear();
		}
	}

	private boolean write() {
		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			try (BufferedWriter writer = Files.newBufferedWriter(
					this.store,
					StandardCharsets.UTF_8)) {
				for (int i = 0; i < this.playersNames.size(); i++) {
					String encoded = Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(encoded);
					writer.write('\t');
					writer.write(String.valueOf(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
					writer.newLine();
				}
			}
			return true;
		} catch (IOException ex) {
			return false;
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						playersScores.get(second.intValue()).intValue(),
						playersScores.get(first.intValue()).intValue());
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return Integer.compare(
						survivalTimes.get(first.intValue()).intValue(),
						survivalTimes.get(second.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(names);
		this.playersScores.addAll(scores);
		this.survivalTimes.addAll(times);
	}

	private void clear() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
	}
}