package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final List<Entry> entries;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.entries = new ArrayList<Entry>();
		this.load();
		setBackground(new Color(245, 245, 245));
		setForeground(Color.BLACK);
		setFocusable(true);
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = sanitizeName(playerName);
		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.entries.add(new Entry(name, score, survivalTime));
		this.sortEntries();

		if (this.entries.size() > MAX_ENTRIES) {
			this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
		}

		return true;
	}

	public synchronized List<String> getPlayersNames() {
		List<String> result = new ArrayList<String>();
		for (Entry entry : this.entries) {
			result.add(entry.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		List<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		List<Integer> result = new ArrayList<Integer>();
		for (Entry entry : this.entries) {
			result.add(entry.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			List<String> lines = new ArrayList<String>();
			for (Entry entry : this.entries) {
				String encodedName = java.util.Base64.getEncoder().encodeToString(
						entry.name.getBytes(StandardCharsets.UTF_8));
				lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
			}

			Files.write(this.store, lines, StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE);
		} catch (Exception ex) {
			// Persistence failures do not interrupt the running game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int score = Math.max(0, player.getPoints());
		int survivalTime = getElapsedTime(level);
		String playerName = player.getTeamName();

		if (playerName == null || playerName.trim().length() == 0) {
			playerName = "Player";
		}

		if (this.storeRun(score, survivalTime, playerName)) {
			this.persistAcrossRuns();
		}
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			int width = getWidth();
			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 28));
			g.drawString("Highscore", 30, 42);

			g.setFont(new Font("Dialog", Font.BOLD, 16));
			g.drawString("#", 35, 78);
			g.drawString("Player", 80, 78);
			g.drawString("Points", Math.max(230, width - 220), 78);
			g.drawString("Time", Math.max(330, width - 105), 78);

			g.setFont(new Font("Dialog", Font.PLAIN, 15));
			int y = 108;
			for (int i = 0; i < this.entries.size(); i++) {
				Entry entry = this.entries.get(i);
				g.setColor(i % 2 == 0 ? new Color(235, 235, 235) : Color.WHITE);
				g.fillRect(25, y - 20, Math.max(380, width - 50), 25);

				g.setColor(Color.BLACK);
				g.drawString(String.valueOf(i + 1), 35, y);
				g.drawString(entry.name, 80, y);
				g.drawString(String.valueOf(entry.score), Math.max(230, width - 220), y);
				g.drawString(formatTime(entry.survivalTime), Math.max(330, width - 105), y);
				y += 27;

				if (y > getHeight() - 10) {
					break;
				}
			}
		} finally {
			g.dispose();
		}
	}

	private int getElapsedTime(ApoMarioLevel level) {
		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}
		return elapsed / 1000;
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			List<Entry> loaded = new ArrayList<Entry>();

			for (String line : lines) {
				if (line == null || line.trim().length() == 0) {
					continue;
				}

				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					throw new IllegalArgumentException("Invalid highscore entry");
				}

				String name = new String(
						java.util.Base64.getDecoder().decode(values[0]),
						StandardCharsets.UTF_8);
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);

				if (score < 0 || survivalTime < 0) {
					throw new IllegalArgumentException("Invalid highscore value");
				}

				loaded.add(new Entry(sanitizeName(name), score, survivalTime));
			}

			this.entries.clear();
			this.entries.addAll(loaded);
			this.sortEntries();

			if (this.entries.size() > MAX_ENTRIES) {
				this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
			}
		} catch (Exception ex) {
			this.entries.clear();
		}
	}

	private void sortEntries() {
		Collections.sort(this.entries, new Comparator<Entry>() {
			@Override
			public int compare(Entry first, Entry second) {
				int scoreCompare = Integer.compare(second.score, first.score);
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return Integer.compare(second.survivalTime, first.survivalTime);
			}
		});
	}

	private static String sanitizeName(String name) {
		if (name == null) {
			return "Player";
		}

		String result = name.trim();
		if (result.length() == 0) {
			return "Player";
		}
		if (result.length() > 32) {
			result = result.substring(0, 32);
		}
		return result;
	}

	private static String formatTime(int seconds) {
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	private static final class Entry {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Entry(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}