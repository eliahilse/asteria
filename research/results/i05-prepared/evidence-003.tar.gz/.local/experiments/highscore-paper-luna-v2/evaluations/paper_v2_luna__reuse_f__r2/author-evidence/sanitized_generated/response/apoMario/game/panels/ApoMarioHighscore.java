package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int DEFAULT_SURVIVAL_TIME = 0;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(time));
        this.sort();

        return this.persist();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        this.persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        int survivalTime = DEFAULT_SURVIVAL_TIME;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            survivalTime = level.getStartTime() - level.getTime();
        }

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        this.storeRun(selected.getPoints(), survivalTime, name);
    }

    public static String formatSurvivalTime(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<String> loadedNames = new ArrayList<String>();
        ArrayList<Integer> loadedScores = new ArrayList<Integer>();
        ArrayList<Integer> loadedTimes = new ArrayList<Integer>();

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                String name = new String(Base64.getDecoder().decode(values[0]), StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int time = Integer.parseInt(values[2]);

                loadedNames.add(normalizeName(name));
                loadedScores.add(Integer.valueOf(score));
                loadedTimes.add(Integer.valueOf(Math.max(0, time)));
            }

            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();

            this.playersNames.addAll(loadedNames);
            this.playersScores.addAll(loadedScores);
            this.survivalTimes.addAll(loadedTimes);
            this.sort();
        } catch (Exception ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private boolean persist() {
        if (this.store == null) {
            return false;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {

                for (int i = 0; i < this.playersNames.size(); i++) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(String.valueOf(this.playersScores.get(i)));
                    writer.write('\t');
                    writer.write(String.valueOf(this.survivalTimes.get(i)));
                    writer.newLine();
                }
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        ApoMarioHighscore.this.playersScores.get(second.intValue()),
                        ApoMarioHighscore.this.playersScores.get(first.intValue()));
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int value = index.intValue();
            sortedNames.add(this.playersNames.get(value));
            sortedScores.add(this.playersScores.get(value));
            sortedTimes.add(this.survivalTimes.get(value));
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        this.playersNames.addAll(sortedNames);
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.addAll(sortedTimes);
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String normalized = name.trim();
        if (normalized.length() == 0) {
            return "Player";
        }

        return normalized;
    }
}