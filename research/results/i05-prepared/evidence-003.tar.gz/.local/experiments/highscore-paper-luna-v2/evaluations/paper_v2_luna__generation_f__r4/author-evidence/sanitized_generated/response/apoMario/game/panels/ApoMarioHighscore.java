package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;
	private static final String HEADER = "APOMARIO_HIGHSCORE_1";
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.setBackground(Color.BLACK);
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		int time = Math.max(0, survivalTime);

		this.playersNames.add(name);
		this.playersScores.add(score);
		this.survivalTimes.add(time);
		this.sortEntries();

		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}

		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			ArrayList<String> lines = new ArrayList<String>();
			lines.add(HEADER);

			for (int i = 0; i < this.playersNames.size(); i++) {
				String encodedName = Base64.getEncoder().encodeToString(
						this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
				lines.add(encodedName + "\t" + this.playersScores.get(i) + "\t"
						+ this.survivalTimes.get(i));
			}

			Files.write(temporary, lines, StandardCharsets.UTF_8);
			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (Exception ex) {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (Exception ex) {
			try {
				Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
				Files.deleteIfExists(temporary);
			} catch (Exception ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		String playerName = getPlayerName(player);
		int score = player.getPoints();
		int survivalTime = 0;

		try {
			survivalTime = level.getStartTime() - level.getTime();
		} catch (Exception ex) {
			try {
				survivalTime = level.getPassedTime();
			} catch (Exception ignored) {
				survivalTime = 0;
			}
		}

		this.storeRun(score, survivalTime, playerName);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			int width = this.getWidth();
			int rowHeight = 28;

			g.setColor(Color.WHITE);
			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
			g.drawString("Highscore", 20, 34);

			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
			g.drawString("Player", 20, 62);
			g.drawString("Points", Math.max(180, width / 2), 62);
			g.drawString("Time", Math.max(280, width * 3 / 4), 62);

			g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
			for (int i = 0; i < this.playersNames.size(); i++) {
				int y = 88 + i * rowHeight;
				if (y > this.getHeight() - 8) {
					break;
				}

				g.drawString((i + 1) + ". " + this.playersNames.get(i), 20, y);
				g.drawString(String.valueOf(this.playersScores.get(i)),
						Math.max(180, width / 2), y);
				g.drawString(formatTime(this.survivalTimes.get(i)),
						Math.max(280, width * 3 / 4), y);
			}
		} finally {
			g.dispose();
		}
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
				return;
			}

			for (int i = 1; i < lines.size(); i++) {
				String line = lines.get(i);
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					throw new IllegalArgumentException("Invalid highscore record");
				}

				String name = new String(Base64.getDecoder().decode(values[0]),
						StandardCharsets.UTF_8);
				int score = Integer.parseInt(values[1]);
				int time = Integer.parseInt(values[2]);

				if (name.trim().length() == 0 || time < 0) {
					throw new IllegalArgumentException("Invalid highscore value");
				}

				this.playersNames.add(normalizeName(name));
				this.playersScores.add(score);
				this.survivalTimes.add(time);
			}

			this.sortEntries();
			while (this.playersNames.size() > MAX_ENTRIES) {
				int last = this.playersNames.size() - 1;
				this.playersNames.remove(last);
				this.playersScores.remove(last);
				this.survivalTimes.remove(last);
			}
		} catch (Exception ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sortEntries() {
		ArrayList<Integer> indices = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			indices.add(i);
		}

		Collections.sort(indices, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						playersScores.get(second), playersScores.get(first));
				if (scoreCompare != 0) {
					return scoreCompare;
				}

				return Integer.compare(
						survivalTimes.get(first), survivalTimes.get(second));
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : indices) {
			names.add(this.playersNames.get(index));
			scores.add(this.playersScores.get(index));
			times.add(this.survivalTimes.get(index));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private String getPlayerName(ApoMarioPlayer player) {
		try {
			if (player.getAi() != null) {
				String teamName = player.getAi().getTeamName();
				if (teamName != null && teamName.trim().length() > 0) {
					return teamName;
				}

				String author = player.getAi().getAuthor();
				if (author != null && author.trim().length() > 0) {
					return author;
				}
			}
		} catch (Exception ignored) {
		}

		return "Player";
	}

	private String normalizeName(String playerName) {
		if (playerName == null) {
			return "Player";
		}

		String name = playerName.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
		if (name.length() == 0) {
			return "Player";
		}
		if (name.length() > 40) {
			return name.substring(0, 40);
		}
		return name;
	}

	private String formatTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", minutes, seconds);
	}
}