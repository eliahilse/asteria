package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String HEADER = "APOMARIO_HIGHSCORE_1";
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 32) {
			name = name.substring(0, 32);
		}

		this.playersNames.add(name);
		this.playersScores.add(Math.max(0, score));
		this.survivalTimes.add(Math.max(0, survivalTime));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}
		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			ArrayList<String> lines = new ArrayList<String>();
			lines.add(HEADER);
			for (int i = 0; i < this.playersNames.size(); i++) {
				String encodedName = Base64.getEncoder().encodeToString(
						this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
				lines.add(this.playersScores.get(i) + "\t"
						+ this.survivalTimes.get(i) + "\t" + encodedName);
			}

			Files.write(this.store, lines, StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE);
		} catch (Exception ex) {
			// A failed write must not interrupt the game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int score = player.getPoints();
		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		String playerName = player.getTeamName();
		if (playerName == null || playerName.trim().length() == 0) {
			playerName = "Player";
		}

		this.storeRun(score, survivalTime, playerName);
	}

	public synchronized String formatSurvivalTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", minutes, seconds);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics;
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, getWidth(), getHeight());

		g.setColor(Color.BLACK);
		g.setFont(new Font("Dialog", Font.BOLD, 22));
		g.drawString("Highscore", 20, 32);

		g.setFont(new Font("Dialog", Font.BOLD, 14));
		g.drawString("#", 20, 60);
		g.drawString("Points", 60, 60);
		g.drawString("Player", 150, 60);
		g.drawString("Time", 350, 60);

		g.setFont(new Font("Dialog", Font.PLAIN, 14));
		for (int i = 0; i < this.playersNames.size(); i++) {
			int y = 84 + i * 22;
			g.drawString(String.valueOf(i + 1), 20, y);
			g.drawString(String.valueOf(this.playersScores.get(i)), 60, y);
			g.drawString(this.playersNames.get(i), 150, y);
			g.drawString(formatSurvivalTime(this.survivalTimes.get(i)), 350, y);
		}
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
				return;
			}

			for (int i = 1; i < lines.size(); i++) {
				String line = lines.get(i);
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}

				int score = Integer.parseInt(values[0]);
				int time = Integer.parseInt(values[1]);
				String name = new String(
						Base64.getDecoder().decode(values[2]),
						StandardCharsets.UTF_8);

				if (name.length() == 0) {
					name = "Player";
				}
				this.playersScores.add(Math.max(0, score));
				this.survivalTimes.add(Math.max(0, time));
				this.playersNames.add(name);
			}
			this.sort();
		} catch (Exception ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(i);
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int score = Integer.compare(
						playersScores.get(second),
						playersScores.get(first));
				if (score != 0) {
					return score;
				}
				return Integer.compare(
						survivalTimes.get(first),
						survivalTimes.get(second));
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			names.add(this.playersNames.get(index));
			scores.add(this.playersScores.get(index));
			times.add(this.survivalTimes.get(index));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}
}