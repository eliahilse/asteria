package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;

    private static final String DEFAULT_PLAYER_NAME = "Player";

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final List<Run> runs;

    public ApoMarioHighscore(Path store) {
        this.store = store == null
                ? Path.of(System.getProperty("user.home"), "apoMario-highscore.dat")
                : store;
        this.runs = new ArrayList<Run>();
        this.load();
        this.setOpaque(true);
        this.setBackground(Color.WHITE);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int safeScore = Math.max(0, score);
        int safeTime = Math.max(0, survivalTime);

        this.runs.add(new Run(name, safeScore, safeTime));
        this.sortRuns();
        this.persistAcrossRuns();
        this.repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            List<String> lines = new ArrayList<String>();
            for (Run run : this.runs) {
                String encodedName = Base64.getEncoder().encodeToString(
                        run.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + run.score + "\t" + run.survivalTime);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName() + ".tmp");
            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception ex) {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            try {
                Files.deleteIfExists(this.store.resolveSibling(
                        this.store.getFileName() + ".tmp"));
            } catch (Exception ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null
                || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = Math.max(0, level.getPassedTime());
        } catch (Exception ex) {
            elapsedMilliseconds = Math.max(0,
                    level.getStartTime() - level.getTime());
        }

        int elapsedSeconds = (elapsedMilliseconds + 500) / 1000;
        String name = getPlayerName(player);
        this.storeRun(player.getPoints(), elapsedSeconds, name);
    }

    public synchronized String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
            g.drawString("Highscores", 20, 35);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
            int y = 70;
            int rank = 1;
            for (Run run : this.runs) {
                g.drawString(rank + ".", 20, y);
                g.drawString(run.name, 55, y);
                g.drawString(String.valueOf(run.score), 220, y);
                g.drawString(formatSurvivalTime(run.survivalTime), 300, y);
                y += 25;
                rank++;
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store,
                    StandardCharsets.UTF_8);
            List<Run> loaded = new ArrayList<Run>();

            for (String line : lines) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IllegalArgumentException();
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (score < 0 || survivalTime < 0) {
                    throw new IllegalArgumentException();
                }

                loaded.add(new Run(normalizeName(name), score, survivalTime));
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            this.sortRuns();
        } catch (Exception ex) {
            this.runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private String getPlayerName(ApoMarioPlayer player) {
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }
        return normalizeName(name);
    }

    private String normalizeName(String name) {
        if (name == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String result = name.replace('\t', ' ').replace('\r', ' ')
                .replace('\n', ' ').trim();
        if (result.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }
        return result;
    }
}