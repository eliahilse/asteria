package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final String DEFAULT_PLAYER_NAME = "Player";

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final List<Run> runs;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        int time = Math.max(0, survivalTime);
        this.runs.add(new Run(name, score, time));
        sortRuns();
        return persistInternal();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persistInternal();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.isBVisible()) {
                player = candidate;
                break;
            }
        }
        if (player == null) {
            player = level.getPlayers().get(0);
        }
        if (player == null) {
            return;
        }

        String playerName = player.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = player.getAuthor();
        }

        int elapsed = level.getPassedTime();
        storeRun(player.getPoints(), Math.max(0, elapsed), playerName);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 235));
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        int rowY = y + 58;
        int rowHeight = 22;

        graphics.drawString("#", x + 20, rowY);
        graphics.drawString("Name", x + 55, rowY);
        graphics.drawString("Points", x + width - 125, rowY);
        graphics.drawString("Time", x + width - 65, rowY);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        for (int i = 0; i < this.runs.size(); i++) {
            if (rowY + rowHeight > y + height - 8) {
                break;
            }

            Run run = this.runs.get(i);
            rowY += rowHeight;

            graphics.drawString(String.valueOf(i + 1), x + 20, rowY);
            graphics.drawString(run.name, x + 55, rowY);
            graphics.drawString(String.valueOf(run.score), x + width - 125, rowY);
            graphics.drawString(formatSurvivalTime(run.survivalTime), x + width - 65, rowY);
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public synchronized String getFormattedSurvivalTime(int index) {
        if (index < 0 || index >= this.runs.size()) {
            return "00:00";
        }
        return formatSurvivalTime(this.runs.get(index).survivalTime);
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                this.runs.clear();
                return;
            }

            List<Run> loaded = new ArrayList<Run>();
            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                String name = new String(Base64.getDecoder().decode(values[0]), StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (name.trim().length() == 0 || survivalTime < 0) {
                    throw new IOException("Invalid highscore values");
                }

                loaded.add(new Run(sanitizeName(name), score, survivalTime));
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            sortRuns();
        } catch (Exception ex) {
            this.runs.clear();
        }
    }

    private boolean persistInternal() {
        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            for (Run run : this.runs) {
                String encodedName = Base64.getEncoder().encodeToString(
                        run.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + run.score + "\t" + run.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String sanitizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String name = playerName.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (name.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }
        return name;
    }

    private static String formatSurvivalTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = seconds / 60L;
        long remainingSeconds = seconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(remainingSeconds));
    }
}