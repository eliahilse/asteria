package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.level.ApoMarioLevel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final int MAX_ENTRIES = 100;

	private final Path store;

	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 64) {
			name = name.substring(0, 64);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}
		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}
			try (BufferedWriter writer = Files.newBufferedWriter(
					this.store,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE)) {
				for (int i = 0; i < this.playersNames.size(); i++) {
					writer.write(Integer.toString(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
					writer.write('\t');
					writer.write(escape(this.playersNames.get(i)));
					writer.newLine();
				}
			}
		} catch (IOException ex) {
			// A failed write must not interrupt the game loop.
		}
	}

	public void recordRunEnd(apoMario.level.ApoMarioLevel level) {
		if (level == null) {
			return;
		}

		Object player = null;
		try {
			Method getPlayers = level.getClass().getMethod("getPlayers");
			Object players = getPlayers.invoke(level);
			if (players != null) {
				if (players instanceof List<?>) {
					List<?> list = (List<?>) players;
					if (!list.isEmpty()) {
						player = list.get(0);
					}
				} else if (players.getClass().isArray() && Array.getLength(players) > 0) {
					player = Array.get(players, 0);
				}
			}

			if (player == null) {
				return;
			}

			int score = invokeInt(player, "getPoints", 0);
			String name = invokeString(player, "getTeamName", "Player");
			int survivalTime = invokeInt(level, "getPassedTime", 0);
			this.storeRun(score, survivalTime, name);
		} catch (Exception ex) {
			// Invalid or incomplete game state cannot produce a run entry.
		}
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, getWidth(), getHeight());

			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 24));
			g.drawString("Highscore", 20, 35);

			g.setFont(new Font("Dialog", Font.PLAIN, 14));
			g.drawString("Rank", 20, 65);
			g.drawString("Name", 80, 65);
			g.drawString("Score", 280, 65);
			g.drawString("Time", 370, 65);

			for (int i = 0; i < this.playersNames.size(); i++) {
				int y = 90 + i * 22;
				g.drawString(Integer.toString(i + 1), 20, y);
				g.drawString(this.playersNames.get(i), 80, y);
				g.drawString(Integer.toString(this.playersScores.get(i)), 280, y);
				g.drawString(formatTime(this.survivalTimes.get(i).intValue()), 370, y);
			}
		} finally {
			g.dispose();
		}
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}
				try {
					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					String name = unescape(values[2]);
					if (name.length() == 0) {
						name = "Player";
					}
					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
					this.playersNames.add(name);
				} catch (NumberFormatException ex) {
					this.playersNames.clear();
					this.playersScores.clear();
					this.survivalTimes.clear();
					break;
				}
			}
			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			indexes.add(Integer.valueOf(i));
		}

		Collections.sort(indexes, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						playersScores.get(second.intValue()).intValue(),
						playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : indexes) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private static int invokeInt(Object target, String methodName, int defaultValue) {
		try {
			Object value = target.getClass().getMethod(methodName).invoke(target);
			if (value instanceof Number) {
				return ((Number) value).intValue();
			}
		} catch (Exception ex) {
			// Use the supplied default when the game object does not expose the value.
		}
		return defaultValue;
	}

	private static String invokeString(Object target, String methodName, String defaultValue) {
		try {
			Object value = target.getClass().getMethod(methodName).invoke(target);
			if (value != null) {
				String result = value.toString().trim();
				if (result.length() > 0) {
					return result;
				}
			}
		} catch (Exception ex) {
			// Use the supplied default when the game object does not expose the value.
		}
		return defaultValue;
	}

	private static String formatTime(int seconds) {
		int safeSeconds = Math.max(0, seconds);
		return String.format("%02d:%02d", Integer.valueOf(safeSeconds / 60),
				Integer.valueOf(safeSeconds % 60));
	}

	private static String escape(String value) {
		return value.replace("\\", "\\\\")
				.replace("\t", "\\t")
				.replace("\r", "\\r")
				.replace("\n", "\\n");
	}

	private static String unescape(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;

		for (int i = 0; i < value.length(); i++) {
			char character = value.charAt(i);
			if (escaped) {
				if (character == 't') {
					result.append('\t');
				} else if (character == 'r') {
					result.append('\r');
				} else if (character == 'n') {
					result.append('\n');
				} else {
					result.append(character);
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else {
				result.append(character);
			}
		}

		if (escaped) {
			result.append('\\');
		}
		return result.toString();
	}
}