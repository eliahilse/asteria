package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String FORMAT_VERSION = "APOMARIO_HIGHSCORE_1";
    private static final int DEFAULT_X = 20;
    private static final int DEFAULT_Y = 40;
    private static final int ROW_HEIGHT = 22;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(this.playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(this.playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(this.survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(FORMAT_VERSION);
                writer.newLine();

                for (int i = 0; i < this.playersNames.size(); i++) {
                    writer.write(Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(String.valueOf(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = null;

        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.isBVisible()) {
                player = candidate;
                break;
            }
        }

        if (player == null) {
            player = level.getPlayers().get(0);
        }

        if (player == null) {
            return;
        }

        String name = player.getTeamName();

        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }

        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsedMilliseconds = 0;

        try {
            elapsedMilliseconds = Math.max(0, level.getPassedTime());
        } catch (RuntimeException ignored) {
            elapsedMilliseconds = Math.max(0, level.getStartTime() - level.getTime());
        }

        int survivalTime = elapsedMilliseconds / 1000;
        this.storeRun(player.getPoints(), survivalTime, name);
    }

    public synchronized void render(Graphics2D graphics) {
        this.render(graphics, DEFAULT_X, DEFAULT_Y);
    }

    public synchronized void render(Graphics2D graphics, int x, int y) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.setColor(Color.BLACK);
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));

        int rowY = y + ROW_HEIGHT;
        for (int i = 0; i < this.playersNames.size(); i++) {
            String entry = (i + 1)
                    + ". "
                    + this.playersNames.get(i)
                    + "  "
                    + this.playersScores.get(i)
                    + "  "
                    + formatSurvivalTime(this.survivalTimes.get(i).intValue());

            graphics.drawString(entry, x, rowY);
            rowY += ROW_HEIGHT;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;

        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
    }

    private synchronized void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String version = reader.readLine();

            if (!FORMAT_VERSION.equals(version)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);

                if (values.length != 3) {
                    continue;
                }

                try {
                    String name = new String(
                            Base64.getDecoder().decode(values[0]),
                            StandardCharsets.UTF_8);

                    int score = Integer.parseInt(values[1]);
                    int survivalTime = Integer.parseInt(values[2]);

                    if (name.trim().length() == 0 || survivalTime < 0) {
                        continue;
                    }

                    this.playersNames.add(name);
                    this.playersScores.add(Integer.valueOf(score));
                    this.survivalTimes.add(Integer.valueOf(survivalTime));
                } catch (IllegalArgumentException ex) {
                    this.playersNames.clear();
                    this.playersScores.clear();
                    this.survivalTimes.clear();
                    return;
                }
            }

            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();

        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        order.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
                        ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int position = index.intValue();
            sortedNames.add(this.playersNames.get(position));
            sortedScores.add(this.playersScores.get(position));
            sortedTimes.add(this.survivalTimes.get(position));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);

        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);

        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }
}