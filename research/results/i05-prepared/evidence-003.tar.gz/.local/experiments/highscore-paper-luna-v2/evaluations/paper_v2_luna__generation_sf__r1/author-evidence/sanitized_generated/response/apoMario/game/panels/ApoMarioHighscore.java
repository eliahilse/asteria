package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int DEFAULT_WIDTH = 480;
    private static final int DEFAULT_HEIGHT = 360;

    private final Path store;
    private final List<Run> runs;
    private final Set<ApoMarioLevel> recordedLevels;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.recordedLevels = Collections.newSetFromMap(
                new IdentityHashMap<ApoMarioLevel, Boolean>());
        this.setBackground(Color.BLACK);
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            return false;
        }

        int time = Math.max(0, survivalTime);
        this.runs.add(new Run(name, score, time));
        this.sortRuns();
        this.persistAcrossRuns();
        this.repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(
                    this.store.getFileName().toString() + ".tmp");

            List<String> lines = new ArrayList<String>();
            for (Run run : this.runs) {
                String encodedName = Base64.getEncoder().encodeToString(
                        run.name.getBytes(StandardCharsets.UTF_8));
                lines.add(run.score + "\t" + run.survivalTime + "\t" + encodedName);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);

            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception exception) {
            try {
                Path temporary = this.store.resolveSibling(
                        this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || this.recordedLevels.contains(level)) {
            return;
        }

        List<ApoMarioPlayer> players;
        try {
            players = level.getPlayers();
        } catch (RuntimeException exception) {
            return;
        }

        if (players == null || players.isEmpty()) {
            return;
        }

        int survivalTime;
        try {
            survivalTime = Math.max(0, level.getPassedTime());
        } catch (RuntimeException exception) {
            survivalTime = 0;
        }

        boolean recorded = false;
        for (ApoMarioPlayer player : players) {
            if (player == null) {
                continue;
            }

            try {
                if (!player.isBVisible()) {
                    continue;
                }
            } catch (RuntimeException exception) {
                continue;
            }

            String name = null;
            try {
                name = player.getTeamName();
            } catch (RuntimeException exception) {
            }

            if (normalizeName(name).length() == 0) {
                try {
                    name = player.getAuthor();
                } catch (RuntimeException exception) {
                    name = null;
                }
            }

            if (storeRun(player.getPoints(), survivalTime, name)) {
                recorded = true;
            }
        }

        if (recorded) {
            this.recordedLevels.add(level);
        }
    }

    public synchronized void clearScores() {
        this.runs.clear();
        this.persistAcrossRuns();
        this.repaint();
    }

    public synchronized void render(Graphics2D graphics) {
        this.paintComponent(graphics);
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            int width = this.getWidth() > 0 ? this.getWidth() : DEFAULT_WIDTH;
            int height = this.getHeight() > 0 ? this.getHeight() : DEFAULT_HEIGHT;

            g.setColor(new Color(35, 80, 150));
            g.fillRect(0, 0, width, height);

            g.setColor(Color.WHITE);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 26));
            g.drawString("HIGHSCORES", 20, 38);

            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
            g.drawString("#", 25, 68);
            g.drawString("PLAYER", 65, 68);
            g.drawString("POINTS", Math.max(220, width - 210), 68);
            g.drawString("TIME", Math.max(340, width - 110), 68);

            int y = 96;
            int row = 1;
            for (Run run : this.runs) {
                if (y > height - 15) {
                    break;
                }

                g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
                g.setColor(Color.WHITE);
                g.drawString(Integer.toString(row), 25, y);
                g.drawString(run.name, 65, y);
                g.drawString(Integer.toString(run.score),
                        Math.max(220, width - 210), y);
                g.drawString(formatTime(run.survivalTime),
                        Math.max(340, width - 110), y);

                y += 25;
                row++;
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            List<Run> loaded = new ArrayList<Run>();

            for (String line : lines) {
                if (line == null || line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);

                name = normalizeName(name);
                if (name.length() == 0 || survivalTime < 0) {
                    throw new IllegalArgumentException("Invalid highscore value");
                }

                loaded.add(new Run(name, score, survivalTime));
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            this.sortRuns();
        } catch (Exception exception) {
            this.runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int score = Integer.compare(second.score, first.score);
                if (score != 0) {
                    return score;
                }

                int time = Integer.compare(second.survivalTime, first.survivalTime);
                if (time != 0) {
                    return time;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "";
        }

        String normalized = name.trim();
        if (normalized.length() > 40) {
            normalized = normalized.substring(0, 40);
        }
        return normalized;
    }

    private static String formatTime(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}