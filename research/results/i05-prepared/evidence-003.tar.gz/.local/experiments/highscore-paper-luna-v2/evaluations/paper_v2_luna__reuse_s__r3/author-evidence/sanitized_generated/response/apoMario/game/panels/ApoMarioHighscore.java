package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int FILE_VERSION = 1;
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(survivalTime));
        this.sort();

        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(this.playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(this.playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(this.survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            DataOutputStream output = new DataOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(temporary)));

            output.writeInt(FILE_VERSION);
            output.writeInt(this.playersNames.size());

            for (int i = 0; i < this.playersNames.size(); i++) {
                output.writeUTF(this.playersNames.get(i));
                output.writeInt(this.playersScores.get(i).intValue());
                output.writeInt(this.survivalTimes.get(i).intValue());
            }

            output.flush();
            output.close();

            try {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                if (selectedPlayer == null || player.getPoints() > selectedPlayer.getPoints()) {
                    selectedPlayer = player;
                }
            }
        }

        if (selectedPlayer == null) {
            selectedPlayer = level.getPlayers().get(0);
        }

        if (selectedPlayer == null) {
            return;
        }

        int survivalTime = 0;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            survivalTime = level.getStartTime() - level.getTime();
        }

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        String playerName = selectedPlayer.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            playerName = selectedPlayer.getAuthor();
        }

        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        this.storeRun(selectedPlayer.getPoints(), survivalTime, playerName);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int rowHeight) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));

        int rowY = y + rowHeight;
        for (int i = 0; i < this.playersNames.size(); i++) {
            String name = this.playersNames.get(i);
            String score = String.valueOf(this.playersScores.get(i));
            String time = formatSurvivalTime(this.survivalTimes.get(i).intValue());

            graphics.drawString(String.valueOf(i + 1), x, rowY);
            graphics.drawString(name, x + width / 5, rowY);
            graphics.drawString(score, x + width * 3 / 5, rowY);
            graphics.drawString(time, x + width * 4 / 5, rowY);

            rowY += rowHeight;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatSurvivalTime(int milliseconds) {
        if (milliseconds < 0) {
            milliseconds = 0;
        }

        int seconds = milliseconds / 1000;
        int minutes = seconds / 60;
        seconds %= 60;

        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private synchronized void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            DataInputStream input = new DataInputStream(
                    new BufferedInputStream(Files.newInputStream(this.store)));

            int version = input.readInt();
            int count = input.readInt();

            if (version != FILE_VERSION || count < 0 || count > MAX_ENTRIES * 100) {
                input.close();
                return;
            }

            for (int i = 0; i < count; i++) {
                String name = input.readUTF();
                int score = input.readInt();
                int time = input.readInt();

                this.playersNames.add(name);
                this.playersScores.add(Integer.valueOf(score));
                this.survivalTimes.add(Integer.valueOf(time));
            }

            input.close();
            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();

        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
                        ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : order) {
            int value = index.intValue();
            names.add(this.playersNames.get(value));
            scores.add(this.playersScores.get(value));
            times.add(this.survivalTimes.get(value));
        }

        this.playersNames.clear();
        this.playersNames.addAll(names);
        this.playersScores.clear();
        this.playersScores.addAll(scores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(times);
    }
}