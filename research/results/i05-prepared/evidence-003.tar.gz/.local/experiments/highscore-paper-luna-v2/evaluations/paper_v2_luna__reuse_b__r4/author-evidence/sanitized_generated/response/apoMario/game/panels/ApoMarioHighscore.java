package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();

        if (this.playersNames.size() > MAX_ENTRIES) {
            this.playersNames.subList(MAX_ENTRIES, this.playersNames.size()).clear();
            this.playersScores.subList(MAX_ENTRIES, this.playersScores.size()).clear();
            this.survivalTimes.subList(MAX_ENTRIES, this.survivalTimes.size()).clear();
        }

        return this.write();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        this.write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = 0;
        try {
            survivalTime = Math.max(0, level.getPassedTime());
        } catch (RuntimeException ex) {
            survivalTime = 0;
        }

        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        this.storeRun(score, survivalTime, name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(Color.WHITE);
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font("Dialog", Font.BOLD, 20));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font("Dialog", Font.BOLD, 14));
        int rowY = y + 58;
        graphics.drawString("#", x + 20, rowY);
        graphics.drawString("Name", x + 55, rowY);
        graphics.drawString("Points", x + width - 150, rowY);
        graphics.drawString("Time", x + width - 75, rowY);

        graphics.setFont(new Font("Dialog", Font.PLAIN, 14));
        int rows = Math.min(this.playersNames.size(), Math.max(0, (height - 75) / 22));
        for (int i = 0; i < rows; i++) {
            rowY += 22;
            graphics.drawString(String.valueOf(i + 1), x + 20, rowY);
            graphics.drawString(this.playersNames.get(i), x + 55, rowY);
            graphics.drawString(String.valueOf(this.playersScores.get(i)), x + width - 150, rowY);
            graphics.drawString(formatTime(this.survivalTimes.get(i).intValue()), x + width - 75, rowY);
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatTime(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private synchronized void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    String name = values[0].replace("\\t", "\t").replace("\\\\", "\\");
                    int score = Integer.parseInt(values[1]);
                    int survivalTime = Integer.parseInt(values[2]);
                    this.playersNames.add(name);
                    this.playersScores.add(Integer.valueOf(score));
                    this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
                } catch (NumberFormatException ex) {
                    this.playersNames.clear();
                    this.playersScores.clear();
                    this.survivalTimes.clear();
                    return;
                }
            }
            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private synchronized boolean write() {
        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {

                for (int i = 0; i < this.playersNames.size(); i++) {
                    String name = this.playersNames.get(i)
                            .replace("\\", "\\\\")
                            .replace("\t", "\\t");
                    writer.write(name);
                    writer.write('\t');
                    writer.write(String.valueOf(this.playersScores.get(i)));
                    writer.write('\t');
                    writer.write(String.valueOf(this.survivalTimes.get(i)));
                    writer.newLine();
                }
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private synchronized void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersNames.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreCompare = Integer.compare(
                        ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
                        ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
                if (scoreCompare != 0) {
                    return scoreCompare;
                }
                return Integer.compare(first.intValue(), second.intValue());
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : order) {
            names.add(this.playersNames.get(index.intValue()));
            scores.add(this.playersScores.get(index.intValue()));
            times.add(this.survivalTimes.get(index.intValue()));
        }

        this.playersNames.clear();
        this.playersNames.addAll(names);
        this.playersScores.clear();
        this.playersScores.addAll(scores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(times);
    }
}