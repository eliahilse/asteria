package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final List<Run> runs;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int points = Math.max(0, score);
        int time = Math.max(0, survivalTime);

        this.runs.add(new Run(points, time, name));
        sortAndTrim();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.playerName);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }
        if (selected == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = level.getStartTime() - level.getTime();
        }

        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int elapsedSeconds = elapsedMilliseconds / 1000;
        String playerName = selected.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        storeRun(selected.getPoints(), elapsedSeconds, playerName);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int rowHeight) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font("Dialog", Font.BOLD, 24));
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font("Dialog", Font.BOLD, 16));
        graphics.drawString("Player", x, y + rowHeight);
        graphics.drawString("Score", x + width / 2, y + rowHeight);
        graphics.drawString("Time", x + width - 90, y + rowHeight);

        graphics.setFont(new Font("Dialog", Font.PLAIN, 15));
        int rowY = y + rowHeight * 2;
        for (Run run : this.runs) {
            graphics.drawString(run.playerName, x, rowY);
            graphics.drawString(String.valueOf(run.score), x + width / 2, rowY);
            graphics.drawString(formatTime(run.survivalTime), x + width - 90, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public synchronized String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainder = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String playerName = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);
                    this.runs.add(new Run(
                            Math.max(0, score),
                            Math.max(0, survivalTime),
                            normalizeName(playerName)));
                } catch (IllegalArgumentException ex) {
                    this.runs.clear();
                    return;
                }
            }
            sortAndTrim();
        } catch (IOException | RuntimeException ex) {
            this.runs.clear();
        }
    }

    private boolean persist() {
        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = this.store.resolveSibling(this.store.getFileName() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                for (Run run : this.runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            run.playerName.getBytes(StandardCharsets.UTF_8));
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
            return false;
        }
    }

    private void sortAndTrim() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });

        while (this.runs.size() > MAX_ENTRIES) {
            this.runs.remove(this.runs.size() - 1);
        }
    }

    private String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String normalized = playerName.trim();
        if (normalized.length() == 0) {
            return "Player";
        }

        if (normalized.length() > 32) {
            normalized = normalized.substring(0, 32);
        }
        return normalized;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String playerName;

        private Run(int score, int survivalTime, String playerName) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.playerName = playerName;
        }
    }
}