package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String VERSION = "APOMARIO_HIGHSCORE_1";
    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        playersNames.add(name);
        playersScores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(time));
        sortEntries();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                writer.write(VERSION);
                writer.newLine();

                for (int i = 0; i < playersNames.size(); i++) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            playersNames.get(i).getBytes(StandardCharsets.UTF_8));

                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(String.valueOf(playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(String.valueOf(survivalTimes.get(i).intValue()));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }

            if (selectedPlayer == null
                    || player.getPoints() > selectedPlayer.getPoints()) {
                selectedPlayer = player;
            }
        }

        if (selectedPlayer == null) {
            selectedPlayer = level.getPlayers().get(0);
        }

        if (selectedPlayer == null) {
            return;
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            survivalTime = level.getStartTime() - level.getTime();
        }

        storeRun(
                selectedPlayer.getPoints(),
                Math.max(0, survivalTime),
                getPlayerName(selectedPlayer));
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        int seconds = Math.max(0, survivalTime) / 1000;
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;

        return String.format("%02d:%02d", Integer.valueOf(minutes),
                Integer.valueOf(remainingSeconds));
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int rowY = y + 25;

        for (int i = 0; i < playersNames.size(); i++) {
            String line = (i + 1) + ". " + playersNames.get(i)
                    + "  " + playersScores.get(i)
                    + "  " + formatSurvivalTime(survivalTimes.get(i).intValue());

            graphics.drawString(line, x, rowY);
            rowY += 19;

            if (rowY > y + 25 + width) {
                break;
            }
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    private void load() {
        playersNames.clear();
        playersScores.clear();
        survivalTimes.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            BufferedReader reader = Files.newBufferedReader(
                    store,
                    StandardCharsets.UTF_8);

            try {
                String header = reader.readLine();
                if (!VERSION.equals(header)) {
                    clearEntries();
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null) {
                    String[] values = line.split("\t", -1);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore entry");
                    }

                    String name = new String(
                            Base64.getDecoder().decode(values[0]),
                            StandardCharsets.UTF_8);

                    int score = Integer.parseInt(values[1]);
                    int survivalTime = Integer.parseInt(values[2]);

                    playersNames.add(normalizeName(name));
                    playersScores.add(Integer.valueOf(score));
                    survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
                }
            } finally {
                reader.close();
            }

            sortEntries();
        } catch (Exception ex) {
            clearEntries();
        }
    }

    private void clearEntries() {
        playersNames.clear();
        playersScores.clear();
        survivalTimes.clear();
    }

    private void sortEntries() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < playersNames.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int firstScore = playersScores.get(first.intValue()).intValue();
                int secondScore = playersScores.get(second.intValue()).intValue();
                return Integer.compare(secondScore, firstScore);
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            sortedNames.add(playersNames.get(i));
            sortedScores.add(playersScores.get(i));
            sortedTimes.add(survivalTimes.get(i));
        }

        playersNames.clear();
        playersScores.clear();
        survivalTimes.clear();

        playersNames.addAll(sortedNames);
        playersScores.addAll(sortedScores);
        survivalTimes.addAll(sortedTimes);
    }

    private String getPlayerName(ApoMarioPlayer player) {
        String name = player.getTeamName();

        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }

        return normalizeName(name);
    }

    private String normalizeName(String name) {
        if (name == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String normalized = name.trim();
        if (normalized.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }

        if (normalized.length() > 32) {
            return normalized.substring(0, 32);
        }

        return normalized;
    }
}