package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String VERSION = "APOMARIO_HIGHSCORE_1";
    private static final String DEFAULT_NAME = "Player";

    private final Path store;
    private final List<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.entries.add(new Entry(score, time, name));
        sortEntries();

        try {
            persistAcrossRuns();
            return true;
        } catch (RuntimeException ex) {
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add(VERSION);

            for (Entry entry : this.entries) {
                String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(entry.score + "\t" + entry.survivalTime + "\t" + encodedName);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to persist highscores", ex);
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsed;
        try {
            elapsed = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsed = level.getStartTime() - level.getTime();
        }

        if (elapsed < 0) {
            elapsed = 0;
        }

        String name = player.getTeamName();
        if ((name == null || name.trim().length() == 0) && player.getAi() != null) {
            name = player.getAi().getTeamName();
        }

        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        graphics.drawString("Highscores", x, y);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int lineY = y + 25;
        int rank = 1;

        for (Entry entry : this.entries) {
            String line = rank + ". " + entry.name + "  " + entry.score
                    + "  " + formatSurvivalTime(entry.survivalTime);
            graphics.drawString(line, x, lineY);
            lineY += 20;
            rank++;

            if (lineY > y + 25 + Math.max(0, width)) {
                break;
            }
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatSurvivalTime(int survivalTime) {
        int seconds = Math.max(0, survivalTime) / 1000;
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !VERSION.equals(lines.get(0))) {
                this.entries.clear();
                return;
            }

            List<Entry> loaded = new ArrayList<Entry>();
            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);

                loaded.add(new Entry(score, Math.max(0, survivalTime),
                        normalizeName(name)));
            }

            this.entries.clear();
            this.entries.addAll(loaded);
            sortEntries();
        } catch (Exception ex) {
            this.entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return DEFAULT_NAME;
        }

        String normalized = name.trim();
        if (normalized.length() == 0) {
            return DEFAULT_NAME;
        }

        if (normalized.length() > 32) {
            return normalized.substring(0, 32);
        }

        return normalized;
    }

    private static final class Entry {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Entry(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}