package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final List<Entry> entries;
    private String defaultPlayerName = "Player";

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.setOpaque(true);
        this.setBackground(Color.WHITE);
        this.setForeground(Color.BLACK);
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int validScore = Math.max(0, score);
        int validTime = Math.max(0, survivalTime);

        this.entries.add(new Entry(name, validScore, validTime));
        this.sortEntries();

        if (this.entries.size() > MAX_ENTRIES) {
            this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
        }

        this.persistAcrossRuns();
        this.repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            List<String> lines = new ArrayList<String>(this.entries.size());
            for (Entry entry : this.entries) {
                lines.add(escape(entry.name) + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(
                this.store,
                lines,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING,
                StandardOpenOption.WRITE
            );
        } catch (Exception ex) {
            // Persistence failures do not interrupt gameplay.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = level.getPassedTime();
        String playerName = player.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            playerName = this.defaultPlayerName;
        }

        this.storeRun(score, survivalTime, playerName);
    }

    public synchronized void setPlayerName(String playerName) {
        this.defaultPlayerName = normalizeName(playerName);
    }

    public synchronized String getPlayerName() {
        return this.defaultPlayerName;
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setRenderingHint(
                RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON
            );

            int width = this.getWidth();
            int y = 35;

            g.setColor(Color.BLACK);
            g.setFont(new Font("Dialog", Font.BOLD, 24));
            g.drawString("Highscore", 20, y);

            g.setFont(new Font("Dialog", Font.BOLD, 14));
            y += 35;
            g.drawString("Player", 20, y);
            g.drawString("Points", Math.max(180, width / 2), y);
            g.drawString("Time", Math.max(290, width * 3 / 4), y);

            g.setFont(new Font("Dialog", Font.PLAIN, 14));
            y += 25;

            for (int i = 0; i < this.entries.size(); i++) {
                Entry entry = this.entries.get(i);
                g.drawString((i + 1) + ". " + entry.name, 20, y);
                g.drawString(String.valueOf(entry.score), Math.max(180, width / 2), y);
                g.drawString(formatTime(entry.survivalTime), Math.max(290, width * 3 / 4), y);
                y += 22;

                if (y > this.getHeight() - 10) {
                    break;
                }
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            for (String line : lines) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore entry");
                }

                String name = unescape(values[0]);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (name.length() == 0 || score < 0 || survivalTime < 0) {
                    throw new IllegalArgumentException("Invalid highscore value");
                }

                this.entries.add(new Entry(name, score, survivalTime));
            }

            this.sortEntries();
            if (this.entries.size() > MAX_ENTRIES) {
                this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
            }
        } catch (Exception ex) {
            this.entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(second.survivalTime, first.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return "Player";
        }

        if (name.length() > 32) {
            name = name.substring(0, 32);
        }

        return name;
    }

    private String escape(String value) {
        return value.replace("\\", "\\\\")
                    .replace("\t", "\\t")
                    .replace("\r", "\\r")
                    .replace("\n", "\\n");
    }

    private String unescape(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);

            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == 'r') {
                    result.append('\r');
                } else if (character == 'n') {
                    result.append('\n');
                } else {
                    result.append(character);
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }

        return normalizeName(result.toString());
    }

    private String formatTime(int milliseconds) {
        long totalSeconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
    }
}