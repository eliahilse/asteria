package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;
    private static final String SEPARATOR = "\t";

    private final Path store;
    private final ArrayList<Run> runs;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int points = Math.max(0, score);
        int time = Math.max(0, survivalTime);

        runs.add(new Run(name, points, time));
        sortRuns();

        if (runs.size() > MAX_ENTRIES) {
            runs.subList(MAX_ENTRIES, runs.size()).clear();
        }

        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();

            for (Run run : runs) {
                lines.add(encode(run.name) + SEPARATOR
                        + run.score + SEPARATOR
                        + run.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveUnavailable) {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ignored) {
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null
                || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }

            if (selectedPlayer == null
                    || player.getPoints() > selectedPlayer.getPoints()) {
                selectedPlayer = player;
            }
        }

        if (selectedPlayer == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selectedPlayer == null
                            || player.getPoints() > selectedPlayer.getPoints()) {
                        selectedPlayer = player;
                    }
                }
            }
        }

        if (selectedPlayer == null) {
            return;
        }

        int elapsedMilliseconds = level.getPassedTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalTime = elapsedMilliseconds / 1000;
        storeRun(selectedPlayer.getPoints(), survivalTime,
                getPlayerName(selectedPlayer));
    }

    public synchronized void clear() {
        runs.clear();
        persistAcrossRuns();
    }

    public synchronized int size() {
        return runs.size();
    }

    public synchronized void render(Graphics2D graphics) {
        int width = getWidth();
        int height = getHeight();

        if (width <= 0) {
            width = 640;
        }
        if (height <= 0) {
            height = 480;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, width, height);

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        graphics.drawString("Highscores", 24, 38);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        graphics.drawString("#", 28, 72);
        graphics.drawString("Player", 70, 72);
        graphics.drawString("Points", Math.max(250, width - 220), 72);
        graphics.drawString("Time", Math.max(390, width - 100), 72);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));

        int y = 100;
        int row = 1;
        for (Run run : runs) {
            if (y > height - 12) {
                break;
            }

            graphics.drawString(String.valueOf(row), 30, y);
            graphics.drawString(run.name, 70, y);
            graphics.drawString(String.valueOf(run.score),
                    Math.max(250, width - 220), y);
            graphics.drawString(formatTime(run.survivalTime),
                    Math.max(390, width - 100), y);

            y += 28;
            row++;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        render((Graphics2D) graphics);
    }

    public static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private String getPlayerName(ApoMarioPlayer player) {
        String name = player.getTeamName();

        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }

        return normalizeName(name);
    }

    private String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String normalized = name.replace('\t', ' ')
                .replace('\r', ' ')
                .replace('\n', ' ')
                .trim();

        if (normalized.length() == 0) {
            return "Player";
        }

        return normalized;
    }

    private String encode(String value) {
        return value.replace("\\", "\\\\")
                .replace("\t", "\\t")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }

    private String decode(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);

            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == 'r') {
                    result.append('\r');
                } else if (character == 'n') {
                    result.append('\n');
                } else {
                    result.append(character);
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }

        return normalizeName(result.toString());
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            ArrayList<Run> loaded = new ArrayList<Run>();

            for (String line : lines) {
                String[] values = line.split(SEPARATOR, -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (score < 0 || survivalTime < 0) {
                    throw new IOException("Invalid highscore value");
                }

                loaded.add(new Run(decode(values[0]), score, survivalTime));
            }

            runs.clear();
            runs.addAll(loaded);
            sortRuns();

            if (runs.size() > MAX_ENTRIES) {
                runs.subList(MAX_ENTRIES, runs.size()).clear();
            }
        } catch (Exception corruptStore) {
            runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(
                        first.survivalTime, second.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}