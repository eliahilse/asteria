package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final List<Entry> entries;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store must not be null");
		}
		this.store = store;
		this.entries = new ArrayList<Entry>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		if (name.length() == 0) {
			name = "Player";
		}
		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.entries.add(new Entry(name, score, survivalTime));
		this.sortEntries();
		while (this.entries.size() > MAX_ENTRIES) {
			this.entries.remove(this.entries.size() - 1);
		}
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		List<String> result = new ArrayList<String>(this.entries.size());
		for (Entry entry : this.entries) {
			result.add(entry.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		List<Integer> result = new ArrayList<Integer>(this.entries.size());
		for (Entry entry : this.entries) {
			result.add(Integer.valueOf(entry.score));
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		List<Integer> result = new ArrayList<Integer>(this.entries.size());
		for (Entry entry : this.entries) {
			result.add(Integer.valueOf(entry.survivalTime));
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		Path absolute = this.store.toAbsolutePath();
		Path parent = absolute.getParent();
		Path temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");

		try {
			if (parent != null) {
				Files.createDirectories(parent);
			}
			try (BufferedWriter writer = Files.newBufferedWriter(
					temporary, StandardCharsets.UTF_8)) {
				writer.write("APOMARIO_HIGHSCORE_1");
				writer.newLine();
				for (Entry entry : this.entries) {
					writer.write(Base64.getEncoder().encodeToString(
							entry.name.getBytes(StandardCharsets.UTF_8)));
					writer.write('\t');
					writer.write(Integer.toString(entry.score));
					writer.write('\t');
					writer.write(Integer.toString(entry.survivalTime));
					writer.newLine();
				}
			}
			try {
				Files.move(temporary, absolute,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, absolute,
						StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(temporary);
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null
				|| level.getPlayers().isEmpty()
				|| level.getPlayers().get(0) == null) {
			return;
		}

		Object player = level.getPlayers().get(0);
		int score = invokeInt(player, "getPoints", 0);
		String name = invokeString(player, "getTeamName", null);

		if (name == null || name.trim().length() == 0) {
			name = invokeString(player, "getName", null);
		}
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		int elapsedMilliseconds;
		try {
			elapsedMilliseconds = level.getStartTime() - level.getTime();
		} catch (RuntimeException ex) {
			elapsedMilliseconds = 0;
		}
		if (elapsedMilliseconds < 0) {
			elapsedMilliseconds = 0;
		}

		int survivalSeconds = elapsedMilliseconds / 1000;
		this.storeRun(score, survivalSeconds, name);
		this.persistAcrossRuns();
	}

	public synchronized String formatSurvivalTime(int survivalTime) {
		int seconds = survivalTime;
		if (seconds < 0) {
			seconds = 0;
		}
		int minutes = seconds / 60;
		int remainder = seconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes),
				Integer.valueOf(remainder));
	}

	private void load() {
		this.entries.clear();
		if (!Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(
				this.store, StandardCharsets.UTF_8)) {
			String header = reader.readLine();
			if (!"APOMARIO_HIGHSCORE_1".equals(header)) {
				this.entries.clear();
				return;
			}

			String line;
			while ((line = reader.readLine()) != null) {
				if (line.trim().length() == 0) {
					continue;
				}
				String[] values = line.split("\\t", -1);
				if (values.length != 3) {
					throw new IOException("Invalid highscore entry");
				}

				String name = new String(Base64.getDecoder().decode(values[0]),
						StandardCharsets.UTF_8);
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);
				if (score < 0 || survivalTime < 0) {
					throw new IOException("Invalid highscore value");
				}
				this.entries.add(new Entry(normalizeName(name), score,
						survivalTime));
			}
			this.sortEntries();
			while (this.entries.size() > MAX_ENTRIES) {
				this.entries.remove(this.entries.size() - 1);
			}
		} catch (Exception ex) {
			this.entries.clear();
		}
	}

	private void sortEntries() {
		Collections.sort(this.entries, new Comparator<Entry>() {
			@Override
			public int compare(Entry first, Entry second) {
				return Integer.compare(second.score, first.score);
			}
		});
	}

	private static String normalizeName(String name) {
		if (name == null) {
			return "";
		}
		String result = name.trim();
		if (result.length() > 40) {
			result = result.substring(0, 40);
		}
		return result;
	}

	private static int invokeInt(Object target, String methodName,
			int fallback) {
		try {
			Method method = target.getClass().getMethod(methodName);
			Object value = method.invoke(target);
			if (value instanceof Number) {
				return ((Number) value).intValue();
			}
		} catch (Exception ex) {
		}
		return fallback;
	}

	private static String invokeString(Object target, String methodName,
			String fallback) {
		try {
			Method method = target.getClass().getMethod(methodName);
			Object value = method.invoke(target);
			if (value != null) {
				return String.valueOf(value);
			}
		} catch (Exception ex) {
		}
		return fallback;
	}

	private static final class Entry {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Entry(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}