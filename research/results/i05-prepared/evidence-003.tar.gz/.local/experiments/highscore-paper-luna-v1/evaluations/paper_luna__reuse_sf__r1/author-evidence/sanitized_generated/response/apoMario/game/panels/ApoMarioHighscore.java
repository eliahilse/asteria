package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int DEFAULT_SURVIVAL_TIME = 0;

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final ArrayList<Run> runs;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);
        this.runs.add(new Run(name, score, time));
        this.sort();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
                temporary = Files.createTempFile(parent, this.store.getFileName().toString(), ".tmp");
            } else {
                temporary = Files.createTempFile("apomario-highscore", ".tmp");
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : this.runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encode(run.name));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ignored) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignoredCleanup) {
                }
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer bestPlayer = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (bestPlayer == null || player.getPoints() > bestPlayer.getPoints()) {
                bestPlayer = player;
            }
        }

        if (bestPlayer == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (bestPlayer == null || player.getPoints() > bestPlayer.getPoints()) {
                        bestPlayer = player;
                    }
                }
            }
        }

        if (bestPlayer == null) {
            return;
        }

        String playerName = bestPlayer.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = bestPlayer.getAuthor();
        }

        int survivalTime;
        try {
            survivalTime = Math.max(0, level.getPassedTime());
        } catch (RuntimeException exception) {
            survivalTime = Math.max(0, level.getStartTime() - level.getTime());
        }

        this.storeRun(bestPlayer.getPoints(), survivalTime, playerName);
    }

    public static String formatSurvivalTime(int milliseconds) {
        long totalSeconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String name = normalizeName(decode(values[2]));
                    this.runs.add(new Run(name, score, survivalTime));
                } catch (RuntimeException ignored) {
                }
            }

            this.sort();
        } catch (IOException ignored) {
            this.runs.clear();
        }
    }

    private void sort() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int score = Integer.compare(second.score, first.score);
                if (score != 0) {
                    return score;
                }
                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String normalized = name.trim();
        if (normalized.length() == 0) {
            return "Player";
        }

        return normalized;
    }

    private static String encode(String value) {
        return Base64.getEncoder().encodeToString(
                value.getBytes(StandardCharsets.UTF_8));
    }

    private static String decode(String value) {
        return new String(
                Base64.getDecoder().decode(value),
                StandardCharsets.UTF_8);
    }
}