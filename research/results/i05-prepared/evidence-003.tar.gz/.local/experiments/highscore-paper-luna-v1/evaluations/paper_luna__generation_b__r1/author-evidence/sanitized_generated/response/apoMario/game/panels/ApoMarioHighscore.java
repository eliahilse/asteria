package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;

    private static final String VERSION = "APOMARIO_HIGHSCORE_1";
    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final List<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store == null
                ? Path.of(System.getProperty("user.home"), ".apomario-highscores")
                : store;
        this.entries = new ArrayList<Entry>();
        this.setOpaque(true);
        this.setBackground(Color.WHITE);
        this.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        this.setLayout(new GridLayout(0, 1, 0, 4));
        load();
        rebuildView();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        int validScore = Math.max(0, score);
        int validSurvivalTime = Math.max(0, survivalTime);

        entries.add(new Entry(name, validScore, validSurvivalTime));
        sortEntries();
        persistAcrossRuns();
        rebuildView();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(VERSION);
                writer.newLine();

                for (Entry entry : entries) {
                    writer.write(Base64.getEncoder().encodeToString(
                            entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null
                || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }

            if (selectedPlayer == null
                    || player.getPoints() > selectedPlayer.getPoints()) {
                selectedPlayer = player;
            }
        }

        if (selectedPlayer == null) {
            return;
        }

        int elapsed = level.getStartTime() - level.getTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        String playerName = selectedPlayer.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = DEFAULT_PLAYER_NAME;
        }

        storeRun(selectedPlayer.getPoints(), elapsed, playerName);
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        int seconds = Math.max(0, survivalTime) / 1000;
        int minutes = seconds / 60;
        int remainder = seconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font("Dialog", Font.BOLD, 18));
        graphics.drawString("Highscores", 12, 24);

        graphics.setFont(new Font("Dialog", Font.PLAIN, 14));
        int y = 52;

        for (int i = 0; i < entries.size(); i++) {
            Entry entry = entries.get(i);
            String line = (i + 1) + ". " + entry.name
                    + "  " + entry.score
                    + "  " + formatSurvivalTime(entry.survivalTime);
            graphics.drawString(line, 12, y);
            y += 20;
        }
    }

    private synchronized void load() {
        entries.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                store,
                StandardCharsets.UTF_8)) {

            String header = reader.readLine();
            if (!VERSION.equals(header)) {
                entries.clear();
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore entry");
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);

                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (name.trim().length() == 0 || score < 0 || survivalTime < 0) {
                    throw new IOException("Invalid highscore values");
                }

                entries.add(new Entry(name, score, survivalTime));
            }

            sortEntries();
        } catch (Exception ex) {
            entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private String sanitizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }

        if (name.length() > 32) {
            return name.substring(0, 32);
        }

        return name;
    }

    private void rebuildView() {
        removeAll();

        JLabel title = new JLabel("Highscores");
        title.setFont(new Font("Dialog", Font.BOLD, 18));
        add(title);

        for (int i = 0; i < entries.size(); i++) {
            Entry entry = entries.get(i);
            add(new JLabel(
                    (i + 1) + ". " + entry.name
                            + "    " + entry.score
                            + "    " + formatSurvivalTime(entry.survivalTime)));
        }

        revalidate();
        repaint();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}