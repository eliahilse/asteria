package apoMario.game.panels;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Small dedicated renderer used by the menu for the persistent highscore board. */
public class ApoMarioHighscoreView {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 20, 20);
        g.setFont(new Font("SansSerif", Font.BOLD, 24));
        g.drawString("HIGHSCORES", width / 2 - 75, height / 10 + 38);
        g.setFont(new Font("SansSerif", Font.PLAIN, 16));
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 15; i++) {
            int y = height / 10 + 70 + i * 23;
            g.drawString((i + 1) + ". " + names.get(i), width / 5, y);
            g.drawString(Integer.toString(scores.get(i)), width / 2, y);
            int seconds = Math.max(0, times.get(i)) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width * 3 / 5, y);
        }
        g.drawString("Press H or Escape to return", width / 2 - 100, height * 9 / 10);
    }
}
