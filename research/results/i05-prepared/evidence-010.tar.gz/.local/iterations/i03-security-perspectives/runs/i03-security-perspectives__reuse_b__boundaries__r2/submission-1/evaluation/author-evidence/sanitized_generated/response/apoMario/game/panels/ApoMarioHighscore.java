package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, bounded high-score table. Times are retained as milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the finalized human player's score at the level end boundary. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) { selected = player; break; }
        }
        if (selected == null) return;
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(selected.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try { for (Entry e : entries) out.write(e.score + "\t" + e.time + "\t" + e.name + "\n"); }
            finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed save must not stop the game. */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = in.readLine()) != null && count++ < MAX_RECORDS) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                        String name = cleanName(p[2]);
                        if (score >= 0 && time >= 0 && name != null) entries.add(new Entry(name, score, time));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ex) { entries.clear(); }
    }

    private String cleanName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME) return null;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return null;
        return name;
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score - a.score; } });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }

    /** Menu rendering; conversion to mm:ss happens only here. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(30, 25, width - 60, height - 50, 20, 20);
        g.setColor(Color.BLACK); g.drawRoundRect(30, 25, width - 60, height - 50, 20, 20);
        g.setFont(new Font("Dialog", Font.BOLD, 24)); g.drawString("HIGHSCORES", 55, 65);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        if (entries.isEmpty()) { g.drawString("No runs recorded yet", 55, 105); return; }
        int y = 100;
        for (int i = 0; i < entries.size() && i < 15; i++, y += 25) {
            Entry e = entries.get(i); int seconds = e.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ".", 55, y); g.drawString(e.name, 90, y);
            g.drawString(String.valueOf(e.score), width - 180, y); g.drawString(time, width - 95, y);
        }
        g.drawString("ESC: back", 55, height - 35);
    }
}