package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAGIC = 0x41504F48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        int safeScore = score;
        int safeTime = Math.max(0, survivalTime);

        runs.add(new Run(safeScore, safeTime, name));
        Collections.sort(runs, RUN_COMPARATOR);

        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }

        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return result;
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        int survivalTime = Math.max(0, elapsedMilliseconds / 1000);
        String playerName = selected.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            playerName = selected.getAuthor();
        }
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        storeRun(selected.getPoints(), survivalTime, playerName);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 230));
        graphics.fillRoundRect(x, y, width, height, 16, 16);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 16, 16);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 18, y + 28);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        int rowY = y + 55;
        int rowHeight = 22;

        graphics.drawString("#", x + 18, rowY);
        graphics.drawString("Name", x + 55, rowY);
        graphics.drawString("Points", x + width - 125, rowY);
        graphics.drawString("Time", x + width - 65, rowY);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        for (int i = 0; i < runs.size(); i++) {
            if (rowY + rowHeight > y + height - 6) {
                break;
            }

            Run run = runs.get(i);
            rowY += rowHeight;

            graphics.drawString(String.valueOf(i + 1), x + 18, rowY);
            graphics.drawString(run.name, x + 55, rowY);
            graphics.drawString(String.valueOf(run.score), x + width - 125, rowY);
            graphics.drawString(formatTime(run.survivalTime), x + width - 65, rowY);
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainder = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    private synchronized void load() {
        runs.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        try {
            DataInputStream input = new DataInputStream(
                new BufferedInputStream(Files.newInputStream(store)));

            try {
                if (input.readInt() != MAGIC || input.readInt() != VERSION) {
                    return;
                }

                int count = input.readInt();
                if (count < 0 || count > MAX_ENTRIES) {
                    return;
                }

                for (int i = 0; i < count; i++) {
                    int score = input.readInt();
                    int survivalTime = input.readInt();
                    String name = input.readUTF();

                    if (name.length() > MAX_NAME_LENGTH || survivalTime < 0) {
                        runs.clear();
                        return;
                    }

                    runs.add(new Run(score, survivalTime, sanitizeName(name)));
                }
            } finally {
                input.close();
            }

            Collections.sort(runs, RUN_COMPARATOR);
        } catch (EOFException exception) {
            runs.clear();
        } catch (IOException exception) {
            runs.clear();
        } catch (RuntimeException exception) {
            runs.clear();
        }
    }

    private boolean persist() {
        Path parent = store.getParent();

        try {
            if (parent != null && !Files.exists(parent)) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            DataOutputStream output = new DataOutputStream(
                new BufferedOutputStream(Files.newOutputStream(temporary)));

            try {
                output.writeInt(MAGIC);
                output.writeInt(VERSION);
                output.writeInt(runs.size());

                for (Run run : runs) {
                    output.writeInt(run.score);
                    output.writeInt(run.survivalTime);
                    output.writeUTF(run.name);
                }
                output.flush();
            } finally {
                output.close();
            }

            try {
                Files.move(temporary, store,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }

            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private static String sanitizeName(String value) {
        if (value == null) {
            return "Player";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = trimmed.charAt(i);
            if (character >= 32 && character != 127) {
                result.append(character);
            }
        }

        if (result.length() == 0) {
            return "Player";
        }

        return result.toString();
    }

    private static final Comparator<Run> RUN_COMPARATOR = new Comparator<Run>() {
        @Override
        public int compare(Run first, Run second) {
            if (first.score < second.score) {
                return 1;
            }
            if (first.score > second.score) {
                return -1;
            }
            if (first.survivalTime < second.survivalTime) {
                return 1;
            }
            if (first.survivalTime > second.survivalTime) {
                return -1;
            }
            return first.name.compareToIgnoreCase(second.name);
        }
    };

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}