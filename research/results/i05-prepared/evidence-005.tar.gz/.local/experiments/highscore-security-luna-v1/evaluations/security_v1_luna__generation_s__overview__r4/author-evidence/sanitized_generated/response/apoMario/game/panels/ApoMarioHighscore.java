package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String VERSION = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.entries.add(new Entry(name, score, survivalTime));
        this.sortAndTrim();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(VERSION);
                writer.newLine();

                Base64.Encoder encoder = Base64.getEncoder();
                for (Entry entry : this.entries) {
                    writer.write(encoder.encodeToString(entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalSeconds = elapsedMilliseconds / 1000;
        String name = selected.getTeamName();

        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        this.storeRun(selected.getPoints(), survivalSeconds, name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(Color.WHITE);
        graphics.fillRect(x, y, width, height);
        graphics.setColor(Color.BLACK);
        graphics.drawRect(x, y, width - 1, height - 1);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        graphics.drawString("Player", x + 25, y + 58);
        graphics.drawString("Points", x + width / 2, y + 58);
        graphics.drawString("Time", x + width - 90, y + 58);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));

        int rowY = y + 82;
        int rowHeight = 22;
        int visibleRows = Math.max(0, (height - 90) / rowHeight);

        for (int i = 0; i < this.entries.size() && i < visibleRows; i++) {
            Entry entry = this.entries.get(i);
            graphics.drawString(Integer.toString(i + 1) + ".", x + 5, rowY);
            graphics.drawString(entry.name, x + 25, rowY);
            graphics.drawString(Integer.toString(entry.score), x + width / 2, rowY);
            graphics.drawString(formatTime(entry.survivalTime), x + width - 90, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatTime(int seconds) {
        if (seconds < 0) {
            seconds = 0;
        }

        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;

        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Entry> loaded = new ArrayList<Entry>();

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!VERSION.equals(header)) {
                return;
            }

            Base64.Decoder decoder = Base64.getDecoder();
            String line;

            while ((line = reader.readLine()) != null && loaded.size() < MAX_ENTRIES) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                String name;
                int score;
                int survivalTime;

                try {
                    name = new String(decoder.decode(values[0]), StandardCharsets.UTF_8);
                    score = Integer.parseInt(values[1]);
                    survivalTime = Integer.parseInt(values[2]);
                } catch (IllegalArgumentException ex) {
                    continue;
                }

                name = normalizeName(name);
                if (name.length() == 0 || score < 0 || survivalTime < 0) {
                    continue;
                }

                loaded.add(new Entry(name, score, survivalTime));
            }

            this.entries.clear();
            this.entries.addAll(loaded);
            this.sortAndTrim();
        } catch (IOException ex) {
            this.entries.clear();
        }
    }

    private void sortAndTrim() {
        this.entries.sort(new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });

        while (this.entries.size() > MAX_ENTRIES) {
            this.entries.remove(this.entries.size() - 1);
        }
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < 32; i++) {
            char character = trimmed.charAt(i);
            if (character >= 32 && character != '\t' && character != '\r' && character != '\n') {
                result.append(character);
            }
        }

        return result.toString();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}