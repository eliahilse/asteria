package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final List<Entry> entries;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int safeScore = Math.max(0, score);
        int safeTime = Math.max(0, survivalTime);

        entries.add(new Entry(name, safeScore, safeTime));
        sortEntries();

        if (entries.size() > MAX_ENTRIES) {
            entries.subList(MAX_ENTRIES, entries.size()).clear();
        }

        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (Entry entry : entries) {
                    writer.write(Base64.getEncoder().encodeToString(
                            entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                selected = player;
                break;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    selected = player;
                    break;
                }
            }
        }

        if (selected == null) {
            return;
        }

        String playerName = selected.getTeamName();
        int survivalTime = level.getPassedTime();
        storeRun(selected.getPoints(), survivalTime, playerName);
        persistAcrossRuns();
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 230));
        graphics.fillRoundRect(x, y, width, height, 20, 20);

        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        int rowY = y + 58;
        int rowHeight = 22;

        graphics.drawString("#", x + 18, rowY);
        graphics.drawString("Player", x + 48, rowY);
        graphics.drawString("Points", x + width - 145, rowY);
        graphics.drawString("Time", x + width - 75, rowY);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        for (int i = 0; i < entries.size() && rowY + rowHeight < y + height; i++) {
            Entry entry = entries.get(i);
            rowY += rowHeight;

            graphics.drawString(Integer.toString(i + 1), x + 18, rowY);
            graphics.drawString(entry.name, x + 48, rowY);
            graphics.drawString(Integer.toString(entry.score), x + width - 145, rowY);
            graphics.drawString(formatSurvivalTime(entry.survivalTime), x + width - 75, rowY);
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public synchronized String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        if (!Files.isRegularFile(store)) {
            return;
        }

        List<Entry> loaded = new ArrayList<Entry>();

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (score < 0 || survivalTime < 0) {
                    throw new IOException("Invalid highscore values");
                }

                loaded.add(new Entry(normalizeName(name), score, survivalTime));
            }

            entries.clear();
            entries.addAll(loaded);
            sortEntries();

            if (entries.size() > MAX_ENTRIES) {
                entries.subList(MAX_ENTRIES, entries.size()).clear();
            }
        } catch (Exception ex) {
            entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreResult = Integer.compare(second.score, first.score);
                if (scoreResult != 0) {
                    return scoreResult;
                }
                return Integer.compare(second.survivalTime, first.survivalTime);
            }
        });
    }

    private String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String normalized = playerName.trim();
        if (normalized.isEmpty()) {
            return "Player";
        }

        if (normalized.length() > 32) {
            return normalized.substring(0, 32);
        }

        return normalized;
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}