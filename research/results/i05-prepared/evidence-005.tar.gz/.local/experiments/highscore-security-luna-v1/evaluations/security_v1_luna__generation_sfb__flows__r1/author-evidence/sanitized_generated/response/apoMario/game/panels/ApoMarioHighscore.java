package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAGIC = 0x41504F48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 24;

    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int points = Math.max(0, score);
        int time = Math.max(0, survivalTime);

        entries.add(new Entry(name, points, time));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream output = new DataOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(temporary)));

            try {
                output.writeInt(MAGIC);
                output.writeInt(VERSION);
                output.writeInt(entries.size());

                for (Entry entry : entries) {
                    output.writeUTF(entry.name);
                    output.writeInt(entry.score);
                    output.writeInt(entry.survivalTime);
                }
            } finally {
                output.close();
            }

            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) {
                selected = player;
                break;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && player.isBVisible()) {
                    selected = player;
                    break;
                }
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalSeconds = elapsedMilliseconds / 1000;
        String name = selected.getTeamName();

        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        storeRun(selected.getPoints(), survivalSeconds, name);
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, 320, 240);
        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", 105, 28);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        int y = 52;

        for (int i = 0; i < entries.size(); i++) {
            Entry entry = entries.get(i);
            String rank = (i + 1) + ".";
            String time = formatTime(entry.survivalTime);
            graphics.drawString(rank, 20, y);
            graphics.drawString(entry.name, 48, y);
            graphics.drawString(String.valueOf(entry.score), 190, y);
            graphics.drawString(time, 245, y);
            y += 18;

            if (y > 228) {
                break;
            }
        }
    }

    public static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private synchronized void load() {
        entries.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            DataInputStream input = new DataInputStream(
                    new BufferedInputStream(Files.newInputStream(store)));

            try {
                if (input.readInt() != MAGIC || input.readInt() != VERSION) {
                    return;
                }

                int count = input.readInt();
                if (count < 0 || count > MAX_ENTRIES) {
                    return;
                }

                for (int i = 0; i < count; i++) {
                    String name = input.readUTF();
                    if (name.length() > MAX_NAME_LENGTH) {
                        return;
                    }

                    int score = input.readInt();
                    int survivalTime = input.readInt();

                    if (score < 0 || survivalTime < 0) {
                        return;
                    }

                    entries.add(new Entry(normalizeName(name), score, survivalTime));
                }
            } finally {
                input.close();
            }

            sortAndLimit();
        } catch (EOFException ex) {
            entries.clear();
        } catch (IOException ex) {
            entries.clear();
        } catch (RuntimeException ex) {
            entries.clear();
        }
    }

    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreOrder = Integer.compare(second.score, first.score);
                if (scoreOrder != 0) {
                    return scoreOrder;
                }

                int timeOrder = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeOrder != 0) {
                    return timeOrder;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });

        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return "Player";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = trimmed.charAt(i);
            if (character >= 32 && character != 127 && character != '\n'
                    && character != '\r' && character != '\t') {
                result.append(character);
            }
        }

        if (result.length() == 0) {
            return "Player";
        }

        return result.toString();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}