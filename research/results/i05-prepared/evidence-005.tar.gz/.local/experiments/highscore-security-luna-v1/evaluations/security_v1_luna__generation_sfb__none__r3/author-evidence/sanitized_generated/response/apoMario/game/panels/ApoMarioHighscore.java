package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;
        private final long sequence;

        private Run(String name, int score, int survivalTime, long sequence) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
            this.sequence = sequence;
        }
    }

    private final Path store;
    private final ArrayList<Run> runs;
    private long nextSequence;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.nextSequence = 0L;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.runs.add(new Run(name, score, time, this.nextSequence++));
        sortRuns();

        try {
            persistAcrossRuns();
            return true;
        } catch (RuntimeException ex) {
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : this.runs) {
                    writer.write(encode(run.name));
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to persist highscore", ex);
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsedMilliseconds = level.getPassedTime();
        int survivalSeconds = Math.max(0, elapsedMilliseconds / 1000);

        storeRun(
                player.getPoints(),
                survivalSeconds,
                player.getTeamName());
    }

    public static String formatSurvivalTime(int survivalTime) {
        int seconds = Math.max(0, survivalTime);
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Run> loaded = new ArrayList<Run>();

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore entry");
                }

                String name = normalizeName(decode(values[0]));
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (survivalTime < 0) {
                    throw new IOException("Invalid survival time");
                }

                loaded.add(new Run(
                        name,
                        score,
                        survivalTime,
                        this.nextSequence++));
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            sortRuns();
        } catch (IOException | NumberFormatException ex) {
            this.runs.clear();
            this.nextSequence = 0L;
        }
    }

    private void sortRuns() {
        this.runs.sort(new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Long.compare(first.sequence, second.sequence);
            }
        });
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String normalized = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return normalized.length() == 0 ? "Player" : normalized;
    }

    private static String encode(String value) {
        return value.replace("\\", "\\\\").replace("\t", "\\t");
    }

    private static String decode(String value) throws IOException {
        StringBuilder result = new StringBuilder(value.length());
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);

            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == '\\') {
                    result.append('\\');
                } else {
                    throw new IOException("Invalid escaped highscore name");
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            throw new IOException("Invalid escaped highscore name");
        }

        return result.toString();
    }
}