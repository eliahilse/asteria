package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final List<Run> runs;
    private final Set<ApoMarioLevel> recordedLevels;

    public ApoMarioHighscore(Path store) {
        this.store = Objects.requireNonNull(store, "store");
        this.runs = new ArrayList<Run>();
        this.recordedLevels = Collections.newSetFromMap(
                new IdentityHashMap<ApoMarioLevel, Boolean>());
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        if (name.length() == 0) {
            name = "Human";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        runs.add(new Run(score, survivalTime, name));
        sortRuns();
        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }

        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path absolute = store.toAbsolutePath();
        Path parent = absolute.getParent();

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, absolute,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, absolute,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ignored) {
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level)) {
            return;
        }

        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty() || players.get(0) == null) {
            return;
        }

        ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Human";
        }

        int elapsed = 0;
        try {
            elapsed = level.getPassedTime();
        } catch (RuntimeException ignored) {
            elapsed = 0;
        }

        if (elapsed < 0) {
            elapsed = 0;
        }

        storeRun(player.getPoints(), elapsed, name);
        recordedLevels.add(level);
    }

    public static String formatSurvivalTime(int milliseconds) {
        long seconds = milliseconds;
        if (seconds < 0) {
            seconds = 0;
        }

        if (seconds >= 1000) {
            seconds /= 1000;
        }

        long minutes = seconds / 60;
        long remainder = seconds % 60;
        return String.format("%02d:%02d", Long.valueOf(minutes),
                Long.valueOf(remainder));
    }

    private synchronized void load() {
        runs.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null && runs.size() < MAX_ENTRIES) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    if (score < 0 || survivalTime < 0) {
                        continue;
                    }

                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);
                    name = sanitizeName(name);
                    if (name.length() == 0) {
                        name = "Human";
                    }

                    runs.add(new Run(score, survivalTime, name));
                } catch (IllegalArgumentException ignored) {
                }
            }

            sortRuns();
        } catch (IOException | RuntimeException ignored) {
            runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreCompare = Integer.compare(second.score, first.score);
                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                int timeCompare = Integer.compare(second.survivalTime,
                        first.survivalTime);
                if (timeCompare != 0) {
                    return timeCompare;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private String sanitizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < 32; i++) {
            char character = value.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}