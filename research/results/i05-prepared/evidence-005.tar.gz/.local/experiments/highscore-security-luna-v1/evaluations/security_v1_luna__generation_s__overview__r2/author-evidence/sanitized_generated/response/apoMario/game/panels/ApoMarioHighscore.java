package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        int safeScore = score;
        int safeTime = Math.max(0, survivalTime);

        this.entries.add(new Entry(name, safeScore, safeTime));
        sortEntries();

        while (this.entries.size() > MAX_ENTRIES) {
            this.entries.remove(this.entries.size() - 1);
        }

        persistAcrossRuns();
        repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            for (Entry entry : this.entries) {
                String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(
                    temporary,
                    lines,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception exception) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selectedPlayer == null || player.getPoints() > selectedPlayer.getPoints()) {
                selectedPlayer = player;
            }
        }

        if (selectedPlayer == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selectedPlayer == null || player.getPoints() > selectedPlayer.getPoints()) {
                        selectedPlayer = player;
                    }
                }
            }
        }

        if (selectedPlayer == null) {
            return;
        }

        String name = selectedPlayer.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selectedPlayer.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalTime = elapsedMilliseconds / 1000;
        storeRun(selectedPlayer.getPoints(), survivalTime, name);
    }

    public synchronized String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, getWidth(), getHeight());

            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
            g.drawString("Highscore", 20, 35);

            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("Player", 20, 65);
            g.drawString("Points", 230, 65);
            g.drawString("Time", 320, 65);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            int y = 90;
            for (int i = 0; i < this.entries.size(); i++) {
                Entry entry = this.entries.get(i);
                g.drawString((i + 1) + ". " + entry.name, 20, y);
                g.drawString(String.valueOf(entry.score), 230, y);
                g.drawString(formatSurvivalTime(entry.survivalTime), 320, y);
                y += 22;
            }
        } finally {
            g.dispose();
        }
    }

    private void load() {
        if (this.store == null || !Files.exists(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                this.entries.clear();
                return;
            }

            for (int i = 1; i < lines.size() && this.entries.size() < MAX_ENTRIES; i++) {
                String line = lines.get(i);
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore record");
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (name.trim().length() == 0 || name.length() > 40 || survivalTime < 0) {
                    throw new IllegalArgumentException("Invalid highscore values");
                }

                this.entries.add(new Entry(name, score, survivalTime));
            }

            sortEntries();
        } catch (Exception exception) {
            this.entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                if (first.score != second.score) {
                    return first.score < second.score ? 1 : -1;
                }
                if (first.survivalTime != second.survivalTime) {
                    return first.survivalTime < second.survivalTime ? 1 : -1;
                }
                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private String sanitizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String name = playerName.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (name.length() == 0) {
            return "Player";
        }
        if (name.length() > 40) {
            return name.substring(0, 40);
        }
        return name;
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}