package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.setBackground(Color.WHITE);
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int safeScore = Math.max(0, score);
        int safeTime = Math.max(0, survivalTime);

        this.entries.add(new Entry(name, safeScore, safeTime));
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreCompare = Integer.compare(second.score, first.score);
                if (scoreCompare != 0) {
                    return scoreCompare;
                }
                return Integer.compare(second.survivalTime, first.survivalTime);
            }
        });

        while (this.entries.size() > MAX_ENTRIES) {
            this.entries.remove(this.entries.size() - 1);
        }

        this.persistAcrossRuns();
        this.repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            for (Entry entry : this.entries) {
                String encodedName = java.util.Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);

            try {
                Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer bestPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (bestPlayer == null || player.getPoints() > bestPlayer.getPoints()) {
                bestPlayer = player;
            }
        }

        if (bestPlayer == null) {
            return;
        }

        String playerName = bestPlayer.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = bestPlayer.getAuthor();
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = Math.max(0, level.getPassedTime());
        } catch (RuntimeException exception) {
            elapsedMilliseconds = 0;
        }

        int survivalSeconds = elapsedMilliseconds / 1000;
        this.storeRun(bestPlayer.getPoints(), survivalSeconds, playerName);
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = this.getWidth();
        int y = 36;

        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        String title = "Highscore";
        g.drawString(title, Math.max(10, (width - g.getFontMetrics().stringWidth(title)) / 2), y);

        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        y += 32;
        g.drawString("#", 16, y);
        g.drawString("Player", 52, y);
        g.drawString("Points", Math.max(150, width - 190), y);
        g.drawString("Time", Math.max(230, width - 90), y);

        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        y += 24;

        int row = 1;
        for (Entry entry : this.entries) {
            if (y > this.getHeight() - 12) {
                break;
            }

            g.drawString(String.valueOf(row), 16, y);
            g.drawString(entry.name, 52, y);
            g.drawString(String.valueOf(entry.score), Math.max(150, width - 190), y);
            g.drawString(formatTime(entry.survivalTime), Math.max(230, width - 90), y);

            y += 22;
            row++;
        }

        if (this.entries.isEmpty()) {
            g.setColor(Color.DARK_GRAY);
            g.drawString("No completed runs", 16, y + 10);
        }

        g.dispose();
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                return;
            }

            ArrayList<Entry> loaded = new ArrayList<Entry>();
            for (int i = 1; i < lines.size() && loaded.size() < MAX_ENTRIES; i++) {
                String line = lines.get(i);
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                String name = new String(java.util.Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (score < 0 || survivalTime < 0) {
                    continue;
                }

                loaded.add(new Entry(normalizeName(name), score, survivalTime));
            }

            this.entries.clear();
            this.entries.addAll(loaded);
            Collections.sort(this.entries, new Comparator<Entry>() {
                @Override
                public int compare(Entry first, Entry second) {
                    int scoreCompare = Integer.compare(second.score, first.score);
                    if (scoreCompare != 0) {
                        return scoreCompare;
                    }
                    return Integer.compare(second.survivalTime, first.survivalTime);
                }
            });
        } catch (Exception exception) {
            this.entries.clear();
        }
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return "Player";
        }
        if (name.length() > MAX_NAME_LENGTH) {
            return name.substring(0, MAX_NAME_LENGTH);
        }
        return name;
    }

    private static String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainder = seconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}