package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String FILE_HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        int points = Math.max(0, score);
        int time = Math.max(0, survivalTime);

        runs.add(new Run(name, points, time));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                writer.write(FILE_HEADER);
                writer.newLine();

                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encode(run.name));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = selectPlayer(level.getPlayers());
        if (selected == null) {
            return;
        }

        int elapsed = level.getStartTime() - level.getTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        storeRun(selected.getPoints(), elapsed, name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.setColor(Color.BLACK);
        graphics.drawString("Highscore", x, y);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int rowY = y + 28;

        for (int i = 0; i < runs.size(); i++) {
            Run run = runs.get(i);
            String text = (i + 1) + ". " + run.name
                    + "  " + run.score
                    + "  " + formatTime(run.survivalTime);

            if (width > 0) {
                int available = width - 4;
                while (text.length() > 0
                        && graphics.getFontMetrics().stringWidth(text) > available) {
                    text = text.substring(0, text.length() - 1);
                }
            }

            graphics.drawString(text, x, rowY);
            rowY += 20;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        int minutes = seconds / 60;
        seconds %= 60;

        return String.format("%02d:%02d", minutes, seconds);
    }

    private ApoMarioPlayer selectPlayer(List<ApoMarioPlayer> players) {
        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : players) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : players) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        return selected;
    }

    private void load() {
        runs.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        try {
            BufferedReader reader = Files.newBufferedReader(
                    store,
                    StandardCharsets.UTF_8);

            try {
                String header = reader.readLine();
                if (!FILE_HEADER.equals(header)) {
                    runs.clear();
                    return;
                }

                String line;
                int loaded = 0;

                while ((line = reader.readLine()) != null && loaded < MAX_ENTRIES) {
                    String[] fields = line.split("\t", -1);
                    if (fields.length != 3) {
                        runs.clear();
                        return;
                    }

                    int score = Integer.parseInt(fields[0]);
                    int survivalTime = Integer.parseInt(fields[1]);
                    String name = normalizeName(decode(fields[2]));

                    if (score < 0 || survivalTime < 0 || name.length() == 0) {
                        runs.clear();
                        return;
                    }

                    runs.add(new Run(name, score, survivalTime));
                    loaded++;
                }
            } finally {
                reader.close();
            }

            sortAndLimit();
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private void sortAndLimit() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(
                        first.survivalTime,
                        second.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });

        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }
    }

    private String normalizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = value.charAt(i);
            if (character >= 32 && character != 127
                    && character != '\t'
                    && character != '\r'
                    && character != '\n') {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private String encode(String value) {
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            if (character == '\\') {
                result.append("\\\\");
            } else if (character == '\t') {
                result.append("\\t");
            } else {
                result.append(character);
            }
        }

        return result.toString();
    }

    private String decode(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);

            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else {
                    result.append(character);
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }

        return result.toString();
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}