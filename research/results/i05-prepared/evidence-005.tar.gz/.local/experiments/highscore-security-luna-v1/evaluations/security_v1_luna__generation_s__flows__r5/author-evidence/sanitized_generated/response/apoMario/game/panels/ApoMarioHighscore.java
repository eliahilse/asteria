package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;

    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "human";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        entries.add(new Entry(name, score, survivalTime));
        sortEntries();

        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }

        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                for (Entry entry : entries) {
                    writer.write(escape(entry.name));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                if (selected == null || player.getPoints() > selected.getPoints()) {
                    selected = player;
                }
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds = 0;

        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = 0;
        }

        if (elapsedMilliseconds <= 0) {
            elapsedMilliseconds = level.getStartTime() - level.getTime();
        }

        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int elapsedSeconds = elapsedMilliseconds / 1000;
        String name = selected.getTeamName();

        if (name == null || normalizeName(name).length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || normalizeName(name).length() == 0) {
            name = "human";
        }

        storeRun(selected.getPoints(), elapsedSeconds, name);
        persistAcrossRuns();
    }

    public synchronized String getFormattedSurvivalTime(int index) {
        if (index < 0 || index >= entries.size()) {
            return "00:00";
        }

        int seconds = entries.get(index).survivalTime;
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;

        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, getWidth(), getHeight());

            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
            g.drawString("Highscore", 20, 30);

            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("Name", 20, 60);
            g.drawString("Points", 180, 60);
            g.drawString("Time", 280, 60);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));

            int y = 85;
            int rank = 1;
            for (Entry entry : entries) {
                g.drawString(rank + ". " + entry.name, 20, y);
                g.drawString(Integer.toString(entry.score), 180, y);
                g.drawString(formatTime(entry.survivalTime), 280, y);
                y += 22;
                rank++;

                if (y > getHeight() - 10) {
                    break;
                }
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        entries.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            BufferedReader reader = Files.newBufferedReader(
                    store,
                    StandardCharsets.UTF_8);

            try {
                String line;
                while ((line = reader.readLine()) != null && entries.size() < MAX_ENTRIES) {
                    parseLine(line);
                }
            } finally {
                reader.close();
            }

            sortEntries();
        } catch (IOException ex) {
            entries.clear();
        }
    }

    private void parseLine(String line) {
        if (line == null || line.length() == 0 || line.length() > 512) {
            return;
        }

        String[] values = line.split("\t", -1);
        if (values.length != 3) {
            return;
        }

        try {
            String name = normalizeName(unescape(values[0]));
            int score = Integer.parseInt(values[1]);
            int survivalTime = Integer.parseInt(values[2]);

            if (name.length() == 0 || score < 0 || survivalTime < 0) {
                return;
            }

            entries.add(new Entry(name, score, survivalTime));
        } catch (NumberFormatException ex) {
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(second.survivalTime, first.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = value.charAt(i);
            if (character >= 32 && character != 127 && character != '\t'
                    && character != '\r' && character != '\n') {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\")
                .replace("\t", "\\t")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }

    private static String unescape(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);

            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == 'r') {
                    result.append('\r');
                } else if (character == 'n') {
                    result.append('\n');
                } else {
                    result.append(character);
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }

        return result.toString();
    }

    private static String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}