package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) {
            name = "human";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        runs.add(new Run(name, score, survivalTime));
        sortRuns();

        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }

        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) {
                selected = player;
                break;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && player.getAi() == null) {
                    selected = player;
                    break;
                }
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "human";
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException exception) {
            survivalTime = 0;
        }

        storeRun(selected.getPoints(), survivalTime, name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(254, 254, 254, 235));
        graphics.fillRoundRect(x, y, width, height, 20, 20);

        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));

        int rowY = y + 58;
        int rowHeight = 22;
        int visibleRows = Math.max(0, (height - 70) / rowHeight);

        for (int i = 0; i < runs.size() && i < visibleRows; i++) {
            Run run = runs.get(i);
            String rank = String.valueOf(i + 1);
            String score = String.valueOf(run.score);
            String time = formatTime(run.survivalTime);

            graphics.drawString(rank, x + 20, rowY);
            graphics.drawString(run.name, x + 55, rowY);
            graphics.drawString(score, x + width - 125, rowY);
            graphics.drawString(time, x + width - 65, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatTime(int milliseconds) {
        long value = milliseconds;
        if (value < 0) {
            value = 0;
        }

        long totalSeconds = value / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;

        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
    }

    private void load() {
        runs.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        ArrayList<Run> loaded = new ArrayList<Run>();

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null && loaded.size() <= MAX_ENTRIES) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    runs.clear();
                    return;
                }

                String name = new String(
                    Base64.getUrlDecoder().decode(values[0]),
                    StandardCharsets.UTF_8
                );

                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (score < 0 || survivalTime < 0 || name.length() == 0) {
                    runs.clear();
                    return;
                }

                loaded.add(new Run(cleanName(name), score, survivalTime));
            }

            if (reader.readLine() != null) {
                runs.clear();
                return;
            }
        } catch (Exception exception) {
            runs.clear();
            return;
        }

        runs.addAll(loaded);
        sortRuns();

        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }
    }

    private boolean persist() {
        if (store == null) {
            return false;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : runs) {
                    String encodedName = Base64.getUrlEncoder().withoutPadding()
                        .encodeToString(run.name.getBytes(StandardCharsets.UTF_8));

                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                    temporary,
                    store,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
                );
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(
                    temporary,
                    store,
                    StandardCopyOption.REPLACE_EXISTING
                );
            }

            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreCompare = Integer.compare(second.score, first.score);
                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                int timeCompare = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeCompare != 0) {
                    return timeCompare;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String cleanName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < 32; i++) {
            char character = trimmed.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}