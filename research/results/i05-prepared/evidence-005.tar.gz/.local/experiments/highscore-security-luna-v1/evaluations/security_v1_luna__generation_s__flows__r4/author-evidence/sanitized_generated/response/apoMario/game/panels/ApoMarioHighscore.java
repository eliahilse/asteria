package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ai.ApoMarioAI;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String FORMAT_HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        int time = survivalTime;
        if (time < 0) {
            time = 0;
        }

        entries.add(new Entry(name, score, time));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                writer.write(FORMAT_HEADER);
                writer.newLine();

                for (Entry entry : entries) {
                    writer.write(Base64.getEncoder().encodeToString(
                            entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null
                || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = selectPlayer(level.getPlayers());
        if (selected == null) {
            return;
        }

        int score = selected.getPoints();
        String name = selected.getTeamName();

        ApoMarioAI ai = selected.getAi();
        if ((name == null || name.trim().length() == 0) && ai != null) {
            name = ai.getTeamName();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            survivalTime = level.getStartTime() - level.getTime();
        }

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        storeRun(score, survivalTime, name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y,
            int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(254, 254, 254, 235));
        graphics.fillRoundRect(x, y, width, height, 20, 20);

        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int rowY = y + 58;
        int rowHeight = 22;

        for (int i = 0; i < entries.size(); i++) {
            if (rowY + rowHeight > y + height - 8) {
                break;
            }

            Entry entry = entries.get(i);
            String line = (i + 1) + ". " + entry.name
                    + "    " + entry.score
                    + "    " + formatTime(entry.survivalTime);

            graphics.drawString(line, x + 20, rowY);
            rowY += rowHeight;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatTime(int milliseconds) {
        long seconds = milliseconds;
        if (seconds < 0) {
            seconds = 0;
        }

        if (seconds >= 1000) {
            seconds /= 1000;
        }

        long minutes = seconds / 60;
        long remainingSeconds = seconds % 60;

        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private ApoMarioPlayer selectPlayer(List<ApoMarioPlayer> players) {
        ApoMarioPlayer selectedHuman = null;
        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : players) {
            if (player == null) {
                continue;
            }

            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }

            if (player.getAi() == null
                    && (selectedHuman == null
                    || player.getPoints() > selectedHuman.getPoints())) {
                selectedHuman = player;
            }
        }

        return selectedHuman != null ? selectedHuman : selected;
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        ArrayList<Entry> loaded = new ArrayList<Entry>();

        try {
            BufferedReader reader = Files.newBufferedReader(
                    store, StandardCharsets.UTF_8);

            try {
                String header = reader.readLine();
                if (!FORMAT_HEADER.equals(header)) {
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null
                        && loaded.size() < MAX_ENTRIES) {
                    String[] parts = line.split("\t", -1);
                    if (parts.length != 3) {
                        continue;
                    }

                    try {
                        String name = new String(
                                Base64.getDecoder().decode(parts[0]),
                                StandardCharsets.UTF_8);
                        name = normalizeName(name);

                        if (name.length() == 0) {
                            continue;
                        }

                        int score = Integer.parseInt(parts[1]);
                        int survivalTime = Integer.parseInt(parts[2]);

                        if (survivalTime < 0) {
                            continue;
                        }

                        loaded.add(new Entry(name, score, survivalTime));
                    } catch (IllegalArgumentException ex) {
                    }
                }
            } finally {
                reader.close();
            }

            entries.clear();
            entries.addAll(loaded);
            sortAndLimit();
        } catch (IOException ex) {
            entries.clear();
        }
    }

    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreCompare = Integer.compare(second.score, first.score);
                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                int timeCompare = Integer.compare(
                        first.survivalTime, second.survivalTime);
                if (timeCompare != 0) {
                    return timeCompare;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });

        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }
    }

    private String normalizeName(String name) {
        if (name == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = name.trim();

        for (int i = 0; i < trimmed.length() && result.length() < 24; i++) {
            char character = trimmed.charAt(i);
            if (!Character.isISOControl(character)
                    && character != '\t'
                    && character != '\r'
                    && character != '\n') {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}