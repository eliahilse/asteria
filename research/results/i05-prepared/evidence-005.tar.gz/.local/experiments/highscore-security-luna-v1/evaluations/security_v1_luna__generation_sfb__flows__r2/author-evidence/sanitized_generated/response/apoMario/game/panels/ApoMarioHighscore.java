package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String FORMAT_HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_NAME_LENGTH = 32;

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Human";
        }

        int safeTime = Math.max(0, survivalTime);
        runs.add(new Run(name, score, safeTime));
        sortRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
                temporary = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            } else {
                temporary = Files.createTempFile("apomario-highscore-", ".tmp");
            }

            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                writer.write(FORMAT_HEADER);
                writer.newLine();

                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            temporary = null;
        } catch (IOException ex) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && player.getAi() == null) {
                selected = player;
                break;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && player.isBVisible()) {
                    selected = player;
                    break;
                }
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Human";
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            survivalTime = 0;
        }

        storeRun(selected.getPoints(), survivalTime, name);
        persistAcrossRuns();
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscores", x, y);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int rowY = y + 28;

        for (int i = 0; i < runs.size(); i++) {
            Run run = runs.get(i);
            String rank = Integer.toString(i + 1) + ".";
            String score = Integer.toString(run.score);
            String time = formatSurvivalTime(run.survivalTime);

            graphics.drawString(rank, x, rowY);
            graphics.drawString(run.name, x + 32, rowY);
            graphics.drawString(score, x + Math.max(120, width / 2), rowY);
            graphics.drawString(time, x + Math.max(190, width * 3 / 4), rowY);

            rowY += 22;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatSurvivalTime(int survivalTime) {
        long milliseconds = Math.max(0L, (long) survivalTime);
        long totalSeconds = milliseconds / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;

        return String.format("%02d:%02d", minutes, seconds);
    }

    private synchronized void load() {
        runs.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        try {
            BufferedReader reader = Files.newBufferedReader(
                    store,
                    StandardCharsets.UTF_8);

            try {
                String header = reader.readLine();
                if (!FORMAT_HEADER.equals(header)) {
                    runs.clear();
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.length() == 0) {
                        continue;
                    }

                    String[] values = line.split("\\t", -1);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore record");
                    }

                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    if (survivalTime < 0) {
                        throw new IOException("Invalid survival time");
                    }

                    byte[] decodedName = Base64.getDecoder().decode(values[2]);
                    String name = normalizeName(new String(
                            decodedName,
                            StandardCharsets.UTF_8));

                    if (name.length() == 0) {
                        throw new IOException("Invalid player name");
                    }

                    runs.add(new Run(name, score, survivalTime));
                }
            } finally {
                reader.close();
            }

            sortRuns();
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int nameComparison = first.name.compareToIgnoreCase(second.name);
                if (nameComparison != 0) {
                    return nameComparison;
                }

                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = trimmed.charAt(i);
            if (character >= 32 && character != 127 && character != '\t'
                    && character != '\r' && character != '\n') {
                result.append(character);
            }
        }

        return result.toString();
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}