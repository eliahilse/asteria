package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        entries.add(new Entry(name, score, survivalTime));
        sortEntries();

        if (entries.size() > MAX_ENTRIES) {
            entries.subList(MAX_ENTRIES, entries.size()).clear();
        }

        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Entry entry : entries) {
                    writer.write(encode(entry.name));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(store.resolveSibling(store.getFileName().toString() + ".tmp"));
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && player.getAi() == null) {
                selectedPlayer = player;
                break;
            }
        }

        if (selectedPlayer == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && player.isBVisible()) {
                    selectedPlayer = player;
                    break;
                }
            }
        }

        if (selectedPlayer == null) {
            selectedPlayer = level.getPlayers().get(0);
        }

        if (selectedPlayer == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = level.getStartTime() - level.getTime();
        }

        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalTime = elapsedMilliseconds / 1000;
        String playerName = selectedPlayer.getTeamName();

        if (playerName == null || normalizeName(playerName).length() == 0) {
            playerName = "Player";
        }

        if (storeRun(selectedPlayer.getPoints(), survivalTime, playerName)) {
            persistAcrossRuns();
        }
    }

    public static String formatSurvivalTime(int survivalTime) {
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        int minutes = survivalTime / 60;
        int seconds = survivalTime % 60;

        return String.format("%02d:%02d", minutes, seconds);
    }

    private synchronized void load() {
        entries.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        ArrayList<Entry> loaded = new ArrayList<Entry>();

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                if (loaded.size() >= MAX_ENTRIES) {
                    break;
                }

                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    entries.clear();
                    return;
                }

                String name = decode(values[0]);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (name.length() == 0 || score < 0 || survivalTime < 0) {
                    entries.clear();
                    return;
                }

                loaded.add(new Entry(name, score, survivalTime));
            }

            entries.addAll(loaded);
            sortEntries();
        } catch (IOException | RuntimeException ex) {
            entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < 24; i++) {
            char character = value.charAt(i);
            if (!Character.isISOControl(character) && character != '\t') {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private static String encode(String value) {
        return Base64.getEncoder().encodeToString(
                value.getBytes(StandardCharsets.UTF_8));
    }

    private static String decode(String value) {
        byte[] bytes = Base64.getDecoder().decode(value);
        return normalizeName(new String(bytes, StandardCharsets.UTF_8));
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}