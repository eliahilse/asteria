package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String DEFAULT_PLAYER_NAME = "Human";

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        int safeTime = Math.max(0, survivalTime);

        this.entries.add(new Entry(name, score, safeTime));
        sortEntries();
        while (this.entries.size() > MAX_ENTRIES) {
            this.entries.remove(this.entries.size() - 1);
        }

        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                for (Entry entry : this.entries) {
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(
                        this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null
                || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsed;
        try {
            elapsed = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsed = Math.max(0, level.getStartTime() - level.getTime());
        }

        storeRun(player.getPoints(), elapsed, player.getTeamName());
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        int width = ApoMarioConstants.GAME_WIDTH;
        int height = ApoMarioConstants.GAME_HEIGHT;

        graphics.setColor(new Color(254, 254, 254, 235));
        graphics.fillRoundRect(20, 15, width - 40, height - 30, 20, 20);

        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(20, 15, width - 40, height - 30, 20, 20);
        graphics.setFont(ApoMarioConstants.FONT_MENU);
        graphics.drawString("HIGHSCORES", 35, 45);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN,
                Math.max(10, ApoMarioConstants.APP_SIZE * 10)));

        int y = 70;
        int rowHeight = Math.max(18, ApoMarioConstants.APP_SIZE * 18);
        int limit = Math.min(this.entries.size(), 12);

        for (int i = 0; i < limit; i++) {
            Entry entry = this.entries.get(i);
            String rank = Integer.toString(i + 1) + ".";
            String line = entry.name + "  " + entry.score + "  "
                    + formatSurvivalTime(entry.survivalTime);

            graphics.drawString(rank, 35, y);
            graphics.drawString(line, 65, y);
            y += rowHeight;
        }

        if (this.entries.isEmpty()) {
            graphics.drawString("No runs recorded", 35, y);
        }
    }

    public static String formatSurvivalTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = seconds / 60L;
        long remainingSeconds = seconds % 60L;

        return String.format("%02d:%02d",
                Long.valueOf(minutes),
                Long.valueOf(remainingSeconds));
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Entry> loaded = new ArrayList<Entry>();

        try {
            BufferedReader reader = Files.newBufferedReader(
                    this.store, StandardCharsets.UTF_8);

            try {
                String line;
                int count = 0;

                while ((line = reader.readLine()) != null) {
                    if (line.length() == 0) {
                        continue;
                    }
                    if (++count > MAX_ENTRIES) {
                        throw new IOException("Too many highscore entries");
                    }

                    String[] values = line.split("\t", -1);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore entry");
                    }

                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    if (survivalTime < 0) {
                        throw new IOException("Invalid survival time");
                    }

                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);
                    name = sanitizeName(name);
                    loaded.add(new Entry(name, score, survivalTime));
                }
            } finally {
                reader.close();
            }

            this.entries.clear();
            this.entries.addAll(loaded);
            sortEntries();
        } catch (Exception ex) {
            this.entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreCompare = Integer.compare(second.score, first.score);
                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                int timeCompare = Integer.compare(first.survivalTime,
                        second.survivalTime);
                if (timeCompare != 0) {
                    return timeCompare;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String sanitizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < playerName.length() && result.length() < 24; i++) {
            char character = playerName.charAt(i);
            if (character >= 32 && character != 127
                    && character != '\t'
                    && character != '\r'
                    && character != '\n') {
                result.append(character);
            }
        }

        String name = result.toString().trim();
        return name.length() == 0 ? DEFAULT_PLAYER_NAME : name;
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}