package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;
import java.util.WeakHashMap;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String FORMAT_VERSION = "1";
    private static final WeakHashMap<ApoMarioLevel, Boolean> RECORDED_LEVELS =
            new WeakHashMap<ApoMarioLevel, Boolean>();

    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) {
            name = "Human";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        entries.add(new Entry(name, score, survivalTime));
        sortEntries();

        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }

        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>(entries.size());

            for (Entry entry : entries) {
                String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(FORMAT_VERSION + "\t" + entry.score + "\t"
                        + entry.survivalTime + "\t" + encodedName);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null
                || level.getPlayers().isEmpty()) {
            return;
        }

        synchronized (RECORDED_LEVELS) {
            if (Boolean.TRUE.equals(RECORDED_LEVELS.get(level))) {
                if (!level.isBAnalysis()) {
                    return;
                }
                RECORDED_LEVELS.remove(level);
            }
            RECORDED_LEVELS.put(level, Boolean.TRUE);
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        String name = player.getTeamName();
        if (name == null || cleanName(name).length() == 0) {
            name = "Human";
        }

        int elapsed = level.getPassedTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        int survivalTime;
        if (elapsed > 0) {
            survivalTime = elapsed / 1000;
            if (survivalTime == 0) {
                survivalTime = 1;
            }
        } else {
            survivalTime = 0;
        }

        storeRun(player.getPoints(), survivalTime, name);
    }

    public synchronized String getFormattedSurvivalTime(int index) {
        if (index < 0 || index >= entries.size()) {
            return "00:00";
        }
        return formatSurvivalTime(entries.get(index).survivalTime);
    }

    public static String formatSurvivalTime(int seconds) {
        if (seconds < 0) {
            seconds = 0;
        }

        int minutes = seconds / 60;
        int remainder = seconds % 60;

        return String.format("%02d:%02d", Integer.valueOf(minutes),
                Integer.valueOf(remainder));
    }

    public synchronized void render(Graphics2D graphics, int x, int y,
            int width, int rowHeight) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.WHITE);
        graphics.fillRect(x, y, width, Math.max(rowHeight, (entries.size() + 1) * rowHeight));

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        graphics.drawString("Highscore", x + 10, y + rowHeight);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        int currentY = y + rowHeight * 2;

        for (int i = 0; i < entries.size(); i++) {
            Entry entry = entries.get(i);
            String line = (i + 1) + ". " + entry.name + "  "
                    + entry.score + "  "
                    + formatSurvivalTime(entry.survivalTime);
            graphics.drawString(line, x + 10, currentY);
            currentY += rowHeight;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    private synchronized void load() {
        entries.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            for (String line : lines) {
                if (entries.size() >= MAX_ENTRIES) {
                    break;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 4 || !FORMAT_VERSION.equals(values[0])) {
                    continue;
                }

                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (score < 0 || survivalTime < 0) {
                    continue;
                }

                byte[] decoded = Base64.getDecoder().decode(values[3]);
                String name = cleanName(new String(decoded, StandardCharsets.UTF_8));

                if (name.length() == 0) {
                    continue;
                }

                entries.add(new Entry(name, score, survivalTime));
            }

            sortEntries();
        } catch (Exception ex) {
            entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreResult = Integer.compare(second.score, first.score);
                if (scoreResult != 0) {
                    return scoreResult;
                }

                int timeResult = Integer.compare(first.survivalTime,
                        second.survivalTime);
                if (timeResult != 0) {
                    return timeResult;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String cleanName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        int limit = Math.min(value.length(), 32);

        for (int i = 0; i < limit; i++) {
            char character = value.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}