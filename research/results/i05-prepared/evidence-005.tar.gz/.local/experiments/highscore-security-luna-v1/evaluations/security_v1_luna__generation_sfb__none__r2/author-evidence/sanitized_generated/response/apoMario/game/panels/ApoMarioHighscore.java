package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_ENTRIES = 100;

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
        setOpaque(true);
        setBackground(Color.WHITE);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        int time = Math.max(0, survivalTime);
        runs.add(new Run(name, score, time));
        sortRuns();
        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }

        persistAcrossRuns();
        repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            Base64.Encoder encoder = Base64.getEncoder();
            for (Run run : runs) {
                String encodedName = encoder.encodeToString(
                        run.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + run.score + "\t" + run.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception atomicMoveFailure) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) {
            return;
        }

        int survivalTime = Math.max(0, level.getPassedTime() / 1000);
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }

            String name = player.getTeamName();
            if (name == null || name.trim().length() == 0) {
                name = "Player";
            }
            storeRun(player.getPoints(), survivalTime, name);
            break;
        }
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
            g.drawString("Highscore", 20, 35);

            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("Player", 20, 65);
            g.drawString("Points", 190, 65);
            g.drawString("Time", 290, 65);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            int y = 90;
            for (Run run : runs) {
                g.drawString(run.name, 20, y);
                g.drawString(String.valueOf(run.score), 190, y);
                g.drawString(formatTime(run.survivalTime), 290, y);
                y += 22;
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        runs.clear();
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                return;
            }

            Base64.Decoder decoder = Base64.getDecoder();
            for (int i = 1; i < lines.size(); i++) {
                String[] parts = lines.get(i).split("\t", -1);
                if (parts.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore entry");
                }

                String name = new String(decoder.decode(parts[0]), StandardCharsets.UTF_8);
                int score = Integer.parseInt(parts[1]);
                int survivalTime = Integer.parseInt(parts[2]);

                if (name.trim().length() == 0 || survivalTime < 0) {
                    throw new IllegalArgumentException("Invalid highscore value");
                }
                runs.add(new Run(normalizeName(name), score, survivalTime));
            }

            sortRuns();
            while (runs.size() > MAX_ENTRIES) {
                runs.remove(runs.size() - 1);
            }
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "";
        }

        String normalized = name.replace('\t', ' ')
                .replace('\r', ' ')
                .replace('\n', ' ')
                .trim();

        if (normalized.length() > 32) {
            normalized = normalized.substring(0, 32);
        }
        return normalized;
    }

    private static String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }
}