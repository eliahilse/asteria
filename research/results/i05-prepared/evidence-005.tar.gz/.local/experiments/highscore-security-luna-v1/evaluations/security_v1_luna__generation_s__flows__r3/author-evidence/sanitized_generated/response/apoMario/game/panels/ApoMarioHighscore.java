package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        entries.add(new Entry(name, score, time));
        sortEntries();

        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }

        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                selected = player;
                break;
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }

        if (selected == null) {
            return;
        }

        int score = selected.getPoints();
        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalSeconds = elapsedMilliseconds / 1000;
        String name = selected.getTeamName();

        if (name == null || name.trim().length() == 0) {
            name = "Human";
        }

        storeRun(score, survivalSeconds, name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 230));
        graphics.fillRoundRect(x, y, width, height, 18, 18);

        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 18, 18);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        graphics.drawString("Highscore", x + 20, y + 32);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        graphics.drawString("Name", x + 20, y + 58);
        graphics.drawString("Points", x + width - 155, y + 58);
        graphics.drawString("Time", x + width - 75, y + 58);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));

        int rowY = y + 82;
        int rowHeight = 22;
        int maxRows = Math.max(0, (height - 90) / rowHeight);

        for (int i = 0; i < entries.size() && i < maxRows; i++) {
            Entry entry = entries.get(i);
            graphics.drawString((i + 1) + ". " + entry.name, x + 20, rowY);
            graphics.drawString(String.valueOf(entry.score), x + width - 155, rowY);
            graphics.drawString(formatTime(entry.survivalTime), x + width - 75, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainder = safeSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainder));
    }

    private synchronized void load() {
        if (!Files.isRegularFile(store)) {
            return;
        }

        ArrayList<Entry> loaded = new ArrayList<Entry>();

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null && loaded.size() <= MAX_ENTRIES) {
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3) {
                    return;
                }

                String name = new String(
                    Base64.getDecoder().decode(fields[0]),
                    StandardCharsets.UTF_8
                );

                int score = Integer.parseInt(fields[1]);
                int survivalTime = Integer.parseInt(fields[2]);

                if (survivalTime < 0 || name.length() == 0 || name.length() > 24) {
                    return;
                }

                loaded.add(new Entry(normalizeName(name), score, survivalTime));
            }

            if (loaded.size() > MAX_ENTRIES) {
                return;
            }

            entries.clear();
            entries.addAll(loaded);
            sortEntries();
        } catch (Exception exception) {
            entries.clear();
        }
    }

    private synchronized boolean persist() {
        Path parent = store.getParent();

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Entry entry : entries) {
                    String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8)
                    );

                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                    temporary,
                    store,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
                );
            } catch (IOException atomicMoveFailure) {
                Files.move(
                    temporary,
                    store,
                    StandardCopyOption.REPLACE_EXISTING
                );
            }

            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private void sortEntries() {
        entries.sort(new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreOrder = Integer.compare(second.score, first.score);
                if (scoreOrder != 0) {
                    return scoreOrder;
                }

                int timeOrder = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeOrder != 0) {
                    return timeOrder;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return "Unknown";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < 24; i++) {
            char character = trimmed.charAt(i);
            if (character >= 32 && character != 127 && character != '\t'
                    && character != '\r' && character != '\n') {
                result.append(character);
            }
        }

        if (result.length() == 0) {
            return "Unknown";
        }

        return result.toString();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}