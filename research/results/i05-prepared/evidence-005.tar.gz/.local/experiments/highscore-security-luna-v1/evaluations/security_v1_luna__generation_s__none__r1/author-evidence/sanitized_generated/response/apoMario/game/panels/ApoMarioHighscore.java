package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String DEFAULT_NAME = "Player";
    private static final int MAX_NAME_LENGTH =  forty();

    private final Path store;
    private final ArrayList<Run> runs;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            this.store = defaultStore();
        } else {
            this.store = store;
        }
        this.runs = new ArrayList<Run>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        int time = Math.max(0, survivalTime);
        runs.add(new Run(score, time, name));
        sortRuns();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                if (selected == null || player.getPoints() > selected.getPoints()) {
                    selected = player;
                }
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds = level.getPassedTime();
        int survivalSeconds = Math.max(0, (elapsedMilliseconds + 500) / 1000);
        String name = selected.getTeamName();

        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }

        storeRun(selected.getPoints(), survivalSeconds, name);
    }

    public synchronized String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainder = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(Color.WHITE);
        graphics.fillRoundRect(x, y, width, height, 16, 16);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 16, 16);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        int rowY = y + 58;
        int rowHeight = 22;

        for (int i = 0; i < runs.size(); i++) {
            if (rowY + rowHeight > y + height - 8) {
                break;
            }

            Run run = runs.get(i);
            graphics.drawString(String.valueOf(i + 1), x + 20, rowY);
            graphics.drawString(run.name, x + 52, rowY);
            graphics.drawString(String.valueOf(run.score), x + width - 145, rowY);
            graphics.drawString(formatSurvivalTime(run.survivalTime), x + width - 75, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    private static int forty() {
        return 40;
    }

    private static Path defaultStore() {
        String home = System.getProperty("user.home");
        if (home == null || home.length() == 0) {
            return Path.of("apoMario-highscores.dat");
        }
        return Path.of(home, ".apoMario-highscores.dat");
    }

    private synchronized void load() {
        runs.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                Run run = parse(line);
                if (run != null) {
                    runs.add(run);
                }
            }
            sortRuns();
        } catch (IOException | RuntimeException exception) {
            runs.clear();
        }
    }

    private Run parse(String line) {
        if (line == null) {
            return null;
        }

        int firstSeparator = line.indexOf('\t');
        int secondSeparator = firstSeparator < 0 ? -1 : line.indexOf('\t', firstSeparator + 1);

        if (firstSeparator <= 0 || secondSeparator <= firstSeparator) {
            return null;
        }

        try {
            int score = Integer.parseInt(line.substring(0, firstSeparator));
            int survivalTime = Integer.parseInt(line.substring(firstSeparator + 1, secondSeparator));
            String name = cleanName(line.substring(secondSeparator + 1));
            return new Run(score, Math.max(0, survivalTime), name);
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private synchronized boolean persist() {
        if (store == null) {
            return false;
        }

        try {
            Path parent = store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(run.name);
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }

            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });
    }

    private static String cleanName(String name) {
        if (name == null) {
            return DEFAULT_NAME;
        }

        String result = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();

        if (result.length() == 0) {
            return DEFAULT_NAME;
        }

        if (result.length() > MAX_NAME_LENGTH) {
            result = result.substring(0, MAX_NAME_LENGTH);
        }

        return result;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}