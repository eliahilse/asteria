package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_NAME_LENGTH = 64;
    private static final int MAX_ENTRIES = 1000;

    private final Path store;
    private final List<Run> runs;

    private ApoMarioLevel lastRecordedLevel;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        runs.add(new Run(name, score, survivalTime));
        sortRuns();

        if (runs.size() > MAX_ENTRIES) {
            runs.subList(MAX_ENTRIES, runs.size()).clear();
        }

        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
                temporary = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            } else {
                temporary = Files.createTempFile("apomario-highscore", ".tmp");
            }

            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                writer.write("APOMARIO_HIGHSCORE_1");
                writer.newLine();

                for (Run run : runs) {
                    writer.write(Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            temporary = null;
        } catch (IOException ex) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level == lastRecordedLevel) {
            return;
        }

        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : players) {
            if (player == null || !player.isBVisible() && selected != null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            selected = players.get(0);
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = 0;
        }

        int survivalTime = elapsedMilliseconds / 1000;
        if (elapsedMilliseconds > 0 && survivalTime == 0) {
            survivalTime = 1;
        }

        storeRun(selected.getPoints(), survivalTime, name);
        persistAcrossRuns();
        lastRecordedLevel = level;
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        int minutes = survivalTime / 60;
        int seconds = survivalTime % 60;

        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private void load() {
        if (!Files.isRegularFile(store)) {
            return;
        }

        List<Run> loaded = new ArrayList<Run>();

        try {
            BufferedReader reader = Files.newBufferedReader(
                    store,
                    StandardCharsets.UTF_8);

            try {
                String header = reader.readLine();
                if (!"APOMARIO_HIGHSCORE_1".equals(header)) {
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null) {
                    if (loaded.size() >= MAX_ENTRIES || line.length() > 4096) {
                        break;
                    }

                    String[] parts = line.split("\t", -1);
                    if (parts.length != 3) {
                        throw new IOException("Invalid highscore record");
                    }

                    String name = new String(
                            Base64.getDecoder().decode(parts[0]),
                            StandardCharsets.UTF_8);

                    int score = Integer.parseInt(parts[1]);
                    int survivalTime = Integer.parseInt(parts[2]);

                    name = sanitizeName(name);
                    if (name.length() == 0
                            || score < 0
                            || survivalTime < 0) {
                        throw new IOException("Invalid highscore values");
                    }

                    loaded.add(new Run(name, score, survivalTime));
                }
            } finally {
                reader.close();
            }

            runs.clear();
            runs.addAll(loaded);
            sortRuns();
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(
                        second.survivalTime,
                        first.survivalTime);

                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private String sanitizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = value.charAt(i);
            if (character == '\n'
                    || character == '\r'
                    || character == '\t'
                    || Character.isISOControl(character)) {
                continue;
            }
            result.append(character);
        }

        return result.toString().trim();
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}