package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int FILE_VERSION = 1;
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        entries.add(new Entry(name, score, survivalTime));
        sortEntries();

        if (entries.size() > MAX_ENTRIES) {
            entries.subList(MAX_ENTRIES, entries.size()).clear();
        }

        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            DataOutputStream output = new DataOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(temporary)));
            try {
                output.writeInt(FILE_VERSION);
                output.writeInt(entries.size());
                for (Entry entry : entries) {
                    output.writeUTF(entry.name);
                    output.writeInt(entry.score);
                    output.writeInt(entry.survivalTime);
                }
            } finally {
                output.close();
            }

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && (selected == null || player.getPoints() > selected.getPoints())) {
                    selected = player;
                }
            }
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = level.getStartTime() - level.getTime();
        }

        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalSeconds = elapsedMilliseconds / 1000;
        String playerName = selected.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            if (selected.getAi() != null && selected.getAi().getTeamName() != null) {
                playerName = selected.getAi().getTeamName();
            } else {
                playerName = "Player";
            }
        }

        storeRun(selected.getPoints(), survivalSeconds, playerName);
        persistAcrossRuns();
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(254, 254, 254, 235));
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        int lineHeight = 21;
        int lineY = y + 58;
        int maxRows = Math.max(0, (height - 70) / lineHeight);

        for (int i = 0; i < entries.size() && i < maxRows; i++) {
            Entry entry = entries.get(i);
            String rank = (i + 1) + ".";
            String score = String.valueOf(entry.score);
            String time = formatTime(entry.survivalTime);

            graphics.drawString(rank, x + 18, lineY);
            graphics.drawString(entry.name, x + 52, lineY);
            graphics.drawString(score, x + width - 115, lineY);
            graphics.drawString(time, x + width - 60, lineY);
            lineY += lineHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatTime(int seconds) {
        if (seconds < 0) {
            seconds = 0;
        }
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
    }

    private synchronized void load() {
        entries.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        DataInputStream input = null;
        try {
            input = new DataInputStream(
                    new BufferedInputStream(Files.newInputStream(store)));

            int version = input.readInt();
            if (version != FILE_VERSION) {
                return;
            }

            int count = input.readInt();
            if (count < 0 || count > MAX_ENTRIES * 10) {
                return;
            }

            for (int i = 0; i < count; i++) {
                String name = normalizeName(input.readUTF());
                int score = input.readInt();
                int survivalTime = input.readInt();

                if (score < 0) {
                    score = 0;
                }
                if (survivalTime < 0) {
                    survivalTime = 0;
                }

                entries.add(new Entry(name, score, survivalTime));
            }

            sortEntries();
            if (entries.size() > MAX_ENTRIES) {
                entries.subList(MAX_ENTRIES, entries.size()).clear();
            }
        } catch (EOFException ex) {
            entries.clear();
        } catch (IOException ex) {
            entries.clear();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String result = playerName.trim();
        if (result.length() == 0) {
            return "Player";
        }

        if (result.length() > 32) {
            result = result.substring(0, 32);
        }

        return result;
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}