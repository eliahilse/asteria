package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.setBackground(Color.WHITE);
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        int time = survivalTime;
        if (time < 0) {
            time = 0;
        }

        this.entries.add(new Entry(name, score, time));
        this.sortEntries();

        while (this.entries.size() > MAX_ENTRIES) {
            this.entries.remove(this.entries.size() - 1);
        }

        this.persistAcrossRuns();
        this.repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            ArrayList<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            for (Entry entry : this.entries) {
                String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(
                    temporary,
                    lines,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null) {
            return;
        }

        List<ApoMarioPlayer> players;
        try {
            players = level.getPlayers();
        } catch (Exception ex) {
            return;
        }

        if (players == null || players.isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = players.get(0);
        for (ApoMarioPlayer player : players) {
            if (player != null && player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            return;
        }

        int elapsed;
        try {
            elapsed = level.getPassedTime();
        } catch (Exception ex) {
            elapsed = level.getStartTime() - level.getTime();
        }

        if (elapsed < 0) {
            elapsed = 0;
        }

        String name = selected.getTeamName();
        if (name == null || normalizeName(name).length() == 0) {
            name = "human";
        }

        this.storeRun(selected.getPoints(), elapsed, name);
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        long milliseconds = survivalTime;
        if (milliseconds < 0) {
            milliseconds = 0;
        }

        long seconds;
        if (milliseconds >= 1000) {
            seconds = milliseconds / 1000;
        } else {
            seconds = milliseconds;
        }

        long minutes = seconds / 60;
        long remainder = seconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    public synchronized List<String> getFormattedSurvivalTimes() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(this.formatSurvivalTime(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            int width = this.getWidth();
            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
            g.drawString("Highscore", 20, 32);

            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("Name", 20, 62);
            g.drawString("Points", Math.max(150, width / 2), 62);
            g.drawString("Time", Math.max(250, width * 3 / 4), 62);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            int y = 86;
            int rank = 1;

            for (Entry entry : this.entries) {
                g.drawString(rank + ". " + entry.name, 20, y);
                g.drawString(String.valueOf(entry.score), Math.max(150, width / 2), y);
                g.drawString(
                        this.formatSurvivalTime(entry.survivalTime),
                        Math.max(250, width * 3 / 4),
                        y);
                y += 24;
                rank++;
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Entry> loaded = new ArrayList<Entry>();

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                return;
            }

            for (int i = 1; i < lines.size() && loaded.size() < MAX_ENTRIES; i++) {
                String line = lines.get(i);
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    return;
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                name = normalizeName(name);
                if (name.length() == 0) {
                    return;
                }

                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);
                if (survivalTime < 0) {
                    return;
                }

                loaded.add(new Entry(name, score, survivalTime));
            }

            this.entries.clear();
            this.entries.addAll(loaded);
            this.sortEntries();
        } catch (Exception ex) {
            this.entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int score = Integer.compare(second.score, first.score);
                if (score != 0) {
                    return score;
                }

                int time = Integer.compare(first.survivalTime, second.survivalTime);
                if (time != 0) {
                    return time;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private String normalizeName(String name) {
        if (name == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < name.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = name.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        return result.toString().trim();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}