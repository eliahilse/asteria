package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String DEFAULT_PLAYER_NAME = "human";

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.entries.add(new Entry(score, time, name));
        sortEntries();

        if (this.entries.size() > MAX_ENTRIES) {
            this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
        }

        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                for (Entry entry : this.entries) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            entry.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = 0;
        }

        int elapsedSeconds = Math.max(0, elapsedMilliseconds / 1000);
        String playerName = selected.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            playerName = DEFAULT_PLAYER_NAME;
        }

        storeRun(selected.getPoints(), elapsedSeconds, playerName);
    }

    public static String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private synchronized void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Entry> loaded = new ArrayList<Entry>();

        try {
            BufferedReader reader = Files.newBufferedReader(
                    this.store,
                    StandardCharsets.UTF_8);

            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.length() == 0) {
                        continue;
                    }

                    String[] values = line.split("\t", -1);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore entry");
                    }

                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    if (survivalTime < 0) {
                        throw new IOException("Invalid survival time");
                    }

                    byte[] decodedName = Base64.getDecoder().decode(values[2]);
                    String name = normalizeName(
                            new String(decodedName, StandardCharsets.UTF_8));

                    loaded.add(new Entry(score, survivalTime, name));

                    if (loaded.size() > MAX_ENTRIES) {
                        throw new IOException("Too many highscore entries");
                    }
                }
            } finally {
                reader.close();
            }

            this.entries.clear();
            this.entries.addAll(loaded);
            sortEntries();
        } catch (IOException ex) {
            this.entries.clear();
        } catch (RuntimeException ex) {
            this.entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String normalizeName(String value) {
        if (value == null) {
            return DEFAULT_PLAYER_NAME;
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < 32; i++) {
            char character = trimmed.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        if (result.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }

        return result.toString();
    }

    private static final class Entry {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Entry(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}