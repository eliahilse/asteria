package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_NAME_LENGTH = 32;

    private final Path store;
    private final List<Entry> entries;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.entries = new ArrayList<Entry>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);
        this.entries.add(new Entry(name, score, time));
        sortEntries();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || player.getAi() != null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player == null) {
                    continue;
                }
                if (selected == null
                        || (player.isBVisible() && !selected.isBVisible())
                        || (player.isBVisible() == selected.isBVisible()
                            && player.getPoints() > selected.getPoints())) {
                    selected = player;
                }
            }
        }

        if (selected == null) {
            return;
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException exception) {
            survivalTime = level.getStartTime() - level.getTime();
        }

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Human";
        }

        storeRun(selected.getPoints(), survivalTime, name);
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        int seconds = Math.max(0, survivalTime) / 1000;
        int minutes = seconds / 60;
        seconds %= 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        List<Entry> loaded = new ArrayList<Entry>();

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!HEADER.equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.length() == 0) {
                    continue;
                }

                String[] parts = line.split("\t", -1);
                if (parts.length != 3) {
                    entries.clear();
                    return;
                }

                String name = new String(
                        Base64.getDecoder().decode(parts[0]),
                        StandardCharsets.UTF_8);
                if (!name.equals(normalizeName(name))) {
                    entries.clear();
                    return;
                }

                int score = Integer.parseInt(parts[1]);
                int survivalTime = Integer.parseInt(parts[2]);
                if (survivalTime < 0) {
                    entries.clear();
                    return;
                }

                loaded.add(new Entry(name, score, survivalTime));
            }

            this.entries.clear();
            this.entries.addAll(loaded);
            sortEntries();
        } catch (IOException | RuntimeException exception) {
            this.entries.clear();
        }
    }

    private boolean persist() {
        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                writer.write(HEADER);
                writer.newLine();

                for (Entry entry : this.entries) {
                    writer.write(Base64.getEncoder().encodeToString(
                            entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException exception) {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            return true;
        } catch (IOException exception) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
            return false;
        }
    }

    private void sortEntries() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreCompare = Integer.compare(second.score, first.score);
                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                int timeCompare = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeCompare != 0) {
                    return timeCompare;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private String normalizeName(String name) {
        if (name == null) {
            return "Unknown";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = name.trim();

        for (int i = 0; i < trimmed.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = trimmed.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        if (result.length() == 0) {
            return "Unknown";
        }
        return result.toString();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}