package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store == null ? Paths.get("apoMario-highscores.dat") : store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        runs.add(new Run(name, score, survivalTime));
        sortRuns();

        if (runs.size() > MAX_ENTRIES) {
            runs.subList(MAX_ENTRIES, runs.size()).clear();
        }

        return write();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            if (selected.getAi() != null) {
                name = selected.getAi().getTeamName();
            }
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsedMilliseconds = 0;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException exception) {
            elapsedMilliseconds = level.getStartTime() - level.getTime();
        }

        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalSeconds = elapsedMilliseconds / 1000;
        storeRun(selected.getPoints(), survivalSeconds, name);
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics;
        int width = getWidth();
        int height = getHeight();

        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, height);

        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        g.drawString("Highscores", 24, 36);

        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        g.drawString("Player", 24, 68);
        g.drawString("Points", Math.max(180, width / 2), 68);
        g.drawString("Time", Math.max(280, width * 3 / 4), 68);

        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));

        int y = 94;
        int rowHeight = 24;
        for (int i = 0; i < runs.size() && y < height; i++) {
            Run run = runs.get(i);

            g.setColor(Color.DARK_GRAY);
            g.drawString((i + 1) + ".", 4, y);
            g.drawString(run.name, 24, y);
            g.drawString(String.valueOf(run.score), Math.max(180, width / 2), y);
            g.drawString(formatTime(run.survivalTime), Math.max(280, width * 3 / 4), y);

            y += rowHeight;
        }
    }

    private synchronized void load() {
        runs.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            int count = 0;

            for (String line : lines) {
                if (count >= MAX_ENTRIES) {
                    break;
                }

                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    continue;
                }

                String name = new String(
                    Base64.getDecoder().decode(values[0]),
                    StandardCharsets.UTF_8
                );

                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (score < 0 || survivalTime < 0) {
                    continue;
                }

                name = sanitizeName(name);
                if (name.length() == 0) {
                    continue;
                }

                runs.add(new Run(name, score, survivalTime));
                count++;
            }

            sortRuns();
        } catch (Exception exception) {
            runs.clear();
        }
    }

    private synchronized boolean write() {
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();

            for (Run run : runs) {
                String encodedName = Base64.getEncoder().encodeToString(
                    run.name.getBytes(StandardCharsets.UTF_8)
                );
                lines.add(encodedName + "\t" + run.score + "\t" + run.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);

            try {
                Files.move(
                    temporary,
                    store,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
                );
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(
                    temporary,
                    store,
                    StandardCopyOption.REPLACE_EXISTING
                );
            }

            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }
                return Integer.compare(first.survivalTime, second.survivalTime);
            }
        });
    }

    private static String sanitizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = trimmed.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        return result.toString();
    }

    private static String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}