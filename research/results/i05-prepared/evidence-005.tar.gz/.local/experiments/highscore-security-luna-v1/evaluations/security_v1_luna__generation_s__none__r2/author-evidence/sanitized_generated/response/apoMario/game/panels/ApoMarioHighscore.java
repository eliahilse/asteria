package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.load();
        this.setOpaque(true);
        this.setBackground(Color.WHITE);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        entries.add(new Entry(name, score, survivalTime));
        sortEntries();
        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }

        persistAcrossRuns();
        repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            Base64.Encoder encoder = Base64.getEncoder();
            for (Entry entry : entries) {
                String encodedName = encoder.encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);

            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsed = level.getStartTime() - level.getTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        int survivalSeconds = elapsed / 1000;
        storeRun(selected.getPoints(), survivalSeconds, name);
    }

    public synchronized void clear() {
        entries.clear();
        persistAcrossRuns();
        repaint();
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int y = 36;

            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
            g.drawString("Highscores", 20, y);

            y += 34;
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("Rank", 20, y);
            g.drawString("Player", 78, y);
            g.drawString("Points", Math.max(220, width - 190), y);
            g.drawString("Time", Math.max(300, width - 95), y);

            y += 8;
            g.drawLine(20, y, Math.max(20, width - 20), y);
            y += 25;

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            for (int i = 0; i < entries.size(); i++) {
                Entry entry = entries.get(i);
                g.drawString(String.valueOf(i + 1), 25, y);
                g.drawString(entry.name, 78, y);
                g.drawString(String.valueOf(entry.score), Math.max(220, width - 190), y);
                g.drawString(formatTime(entry.survivalTime), Math.max(300, width - 95), y);
                y += 23;
            }
        } finally {
            g.dispose();
        }
    }

    public synchronized void render(Graphics2D graphics) {
        paintComponent(graphics);
    }

    private synchronized void load() {
        entries.clear();
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                return;
            }

            Base64.Decoder decoder = Base64.getDecoder();
            for (int i = 1; i < lines.size(); i++) {
                String[] parts = lines.get(i).split("\t", -1);
                if (parts.length != 3) {
                    continue;
                }

                String name = new String(decoder.decode(parts[0]), StandardCharsets.UTF_8);
                int score = Integer.parseInt(parts[1]);
                int survivalTime = Integer.parseInt(parts[2]);

                if (score < 0 || survivalTime < 0) {
                    continue;
                }

                entries.add(new Entry(normalizeName(name), score, survivalTime));
            }
            sortEntries();
            while (entries.size() > MAX_ENTRIES) {
                entries.remove(entries.size() - 1);
            }
        } catch (Exception ex) {
            entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "Player";
        }

        String normalized = name.trim();
        if (normalized.length() == 0) {
            return "Player";
        }
        if (normalized.length() > 32) {
            return normalized.substring(0, 32);
        }
        return normalized;
    }

    private static String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}