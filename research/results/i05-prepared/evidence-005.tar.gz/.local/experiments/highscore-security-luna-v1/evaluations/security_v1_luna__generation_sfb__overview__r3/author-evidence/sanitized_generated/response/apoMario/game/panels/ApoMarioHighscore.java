package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
        setOpaque(true);
        setBackground(Color.WHITE);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int safeTime = Math.max(0, survivalTime);
        entries.add(new Entry(name, score, safeTime));
        sortAndLimit();
        persistAcrossRuns();
        repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            for (Entry entry : entries) {
                String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception exception) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if ((name == null || name.trim().length() == 0) && selected.getAi() != null) {
            name = selected.getAi().getTeamName();
        }

        int elapsed = level.getPassedTime();
        if (elapsed > 1000000) {
            elapsed /= 1000;
        }

        storeRun(selected.getPoints(), elapsed, name);
    }

    public synchronized void clearScores() {
        entries.clear();
        persistAcrossRuns();
        repaint();
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
            g.drawString("Highscores", 20, 35);

            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("#", 20, 65);
            g.drawString("Player", 55, 65);
            g.drawString("Score", 220, 65);
            g.drawString("Time", 300, 65);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            for (int i = 0; i < entries.size(); i++) {
                Entry entry = entries.get(i);
                int y = 90 + i * 22;
                g.drawString(String.valueOf(i + 1), 20, y);
                g.drawString(entry.name, 55, y);
                g.drawString(String.valueOf(entry.score), 220, y);
                g.drawString(formatTime(entry.survivalTime), 300, y);
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        entries.clear();
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                entries.clear();
                return;
            }

            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore record");
                }

                String name = new String(Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (name.length() == 0 || name.length() > MAX_NAME_LENGTH
                        || survivalTime < 0) {
                    throw new IllegalArgumentException("Invalid highscore value");
                }

                entries.add(new Entry(name, score, survivalTime));
                if (entries.size() > MAX_ENTRIES) {
                    throw new IllegalArgumentException("Too many highscore records");
                }
            }

            sortAndLimit();
        } catch (Exception exception) {
            entries.clear();
        }
    }

    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                return Integer.compare(second.score, first.score);
            }
        });

        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return "Player";
        }
        if (name.length() > MAX_NAME_LENGTH) {
            return name.substring(0, MAX_NAME_LENGTH);
        }
        return name;
    }

    private static String formatTime(int seconds) {
        int minutes = Math.max(0, seconds) / 60;
        int remainingSeconds = Math.max(0, seconds) % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }
}