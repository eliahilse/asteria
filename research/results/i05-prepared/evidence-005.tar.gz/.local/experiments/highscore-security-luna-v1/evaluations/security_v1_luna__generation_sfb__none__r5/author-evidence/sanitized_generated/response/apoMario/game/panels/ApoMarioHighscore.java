package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<Entry> entries = new ArrayList<Entry>();

	public ApoMarioHighscore(Path store) {
		this.store = store;
		load();
		setBackground(Color.WHITE);
		setForeground(Color.BLACK);
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		if (name.length() == 0) {
			name = "Player";
		}
		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		entries.add(new Entry(name, score, survivalTime));
		sortEntries();
		while (entries.size() > MAX_ENTRIES) {
			entries.remove(entries.size() - 1);
		}
		persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		ArrayList<String> result = new ArrayList<String>(entries.size());
		for (Entry entry : entries) {
			result.add(entry.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
		for (Entry entry : entries) {
			result.add(Integer.valueOf(entry.score));
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
		for (Entry entry : entries) {
			result.add(Integer.valueOf(entry.survivalTime));
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		if (store == null) {
			return;
		}
		try {
			Path parent = store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
			ArrayList<String> lines = new ArrayList<String>(entries.size());
			for (Entry entry : entries) {
				lines.add(encode(entry.name) + "\t" + entry.score + "\t" + entry.survivalTime);
			}
			Files.write(temporary, lines, StandardCharsets.UTF_8);

			try {
				Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (Exception exception) {
			try {
				Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
				Files.deleteIfExists(temporary);
			} catch (Exception ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player != null && player.isBVisible()) {
				if (selected == null || player.getPoints() > selected.getPoints()) {
					selected = player;
				}
			}
		}
		if (selected == null) {
			for (ApoMarioPlayer player : level.getPlayers()) {
				if (player != null) {
					if (selected == null || player.getPoints() > selected.getPoints()) {
						selected = player;
					}
				}
			}
		}
		if (selected == null) {
			return;
		}

		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}
		storeRun(selected.getPoints(), survivalTime, selected.getTeamName());
	}

	public synchronized String formatSurvivalTime(int milliseconds) {
		if (milliseconds < 0) {
			milliseconds = 0;
		}
		int totalSeconds = milliseconds / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setColor(Color.BLACK);
			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
			g.drawString("Highscore", 20, 30);

			g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
			g.drawString("#", 20, 58);
			g.drawString("Player", 55, 58);
			g.drawString("Points", 220, 58);
			g.drawString("Time", 310, 58);

			g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
			int y = 82;
			for (int i = 0; i < entries.size(); i++) {
				Entry entry = entries.get(i);
				g.drawString(Integer.toString(i + 1), 20, y);
				g.drawString(entry.name, 55, y);
				g.drawString(Integer.toString(entry.score), 220, y);
				g.drawString(formatSurvivalTime(entry.survivalTime), 310, y);
				y += 22;
			}
		} finally {
			g.dispose();
		}
	}

	private synchronized void load() {
		entries.clear();
		if (store == null || !Files.isRegularFile(store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
			for (String line : lines) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					throw new IllegalArgumentException("Invalid highscore record");
				}
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);
				if (score < 0 || survivalTime < 0) {
					throw new IllegalArgumentException("Invalid highscore value");
				}
				entries.add(new Entry(decode(values[0]), score, survivalTime));
			}
			sortEntries();
			while (entries.size() > MAX_ENTRIES) {
				entries.remove(entries.size() - 1);
			}
		} catch (Exception exception) {
			entries.clear();
		}
	}

	private void sortEntries() {
		Collections.sort(entries, new Comparator<Entry>() {
			@Override
			public int compare(Entry first, Entry second) {
				int score = Integer.compare(second.score, first.score);
				if (score != 0) {
					return score;
				}
				return Integer.compare(second.survivalTime, first.survivalTime);
			}
		});
	}

	private static String normalizeName(String name) {
		if (name == null) {
			return "";
		}
		String result = name.trim();
		if (result.length() > 40) {
			result = result.substring(0, 40);
		}
		return result;
	}

	private static String encode(String value) {
		return value.replace("\\", "\\\\").replace("\t", "\\t")
				.replace("\r", "\\r").replace("\n", "\\n");
	}

	private static String decode(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;
		for (int i = 0; i < value.length(); i++) {
			char character = value.charAt(i);
			if (escaped) {
				if (character == 't') {
					result.append('\t');
				} else if (character == 'r') {
					result.append('\r');
				} else if (character == 'n') {
					result.append('\n');
				} else {
					result.append(character);
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else {
				result.append(character);
			}
		}
		if (escaped) {
			result.append('\\');
		}
		return normalizeName(result.toString());
	}

	private static final class Entry {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Entry(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}
}