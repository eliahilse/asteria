package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;
	private static final String HEADER = "APOMARIO_HIGHSCORE\t1";
	private static final int MAX_ENTRIES = 10000;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		int safeSurvivalTime = Math.max(0, survivalTime);

		this.playersNames.add(name);
		this.playersScores.add(score);
		this.survivalTimes.add(safeSurvivalTime);
		this.sortEntries();

		if (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}

		return this.persistInternal();
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		this.persistInternal();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		String playerName = player.getTeamName();
		if (playerName == null || playerName.trim().length() == 0) {
			playerName = player.getAuthor();
		}

		int elapsedMilliseconds = level.getStartTime() - level.getTime();
		if (elapsedMilliseconds < 0) {
			elapsedMilliseconds = 0;
		}

		int survivalTime = elapsedMilliseconds / 1000;
		this.storeRun(player.getPoints(), survivalTime, playerName);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		this.render((Graphics2D) graphics);
	}

	public synchronized void render(Graphics2D graphics) {
		int width = this.getWidth();
		int height = this.getHeight();

		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, width, height);

		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		graphics.drawString("Highscore", 20, 30);

		graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		graphics.drawString("Player", 20, 58);
		graphics.drawString("Points", Math.max(150, width / 2), 58);
		graphics.drawString("Time", Math.max(240, width * 3 / 4), 58);

		graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
		int y = 82;
		for (int i = 0; i < this.playersNames.size() && y < height - 10; i++) {
			graphics.drawString((i + 1) + ". " + this.playersNames.get(i), 20, y);
			graphics.drawString(String.valueOf(this.playersScores.get(i)),
					Math.max(150, width / 2), y);
			graphics.drawString(formatTime(this.survivalTimes.get(i)),
					Math.max(240, width * 3 / 4), y);
			y += 22;
		}
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		ArrayList<String> loadedNames = new ArrayList<String>();
		ArrayList<Integer> loadedScores = new ArrayList<Integer>();
		ArrayList<Integer> loadedTimes = new ArrayList<Integer>();

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
				return;
			}

			for (int i = 1; i < lines.size(); i++) {
				String line = lines.get(i);
				if (line == null || line.trim().length() == 0) {
					continue;
				}

				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					throw new IllegalArgumentException("Invalid highscore record");
				}

				String name = new String(
						Base64.getDecoder().decode(values[0]),
						StandardCharsets.UTF_8);
				int score = Integer.parseInt(values[1]);
				int time = Integer.parseInt(values[2]);

				if (name.length() == 0 || name.length() > 64 || time < 0) {
					throw new IllegalArgumentException("Invalid highscore value");
				}

				loadedNames.add(name);
				loadedScores.add(score);
				loadedTimes.add(time);

				if (loadedNames.size() > MAX_ENTRIES) {
					throw new IllegalArgumentException("Too many highscore records");
				}
			}

			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
			this.playersNames.addAll(loadedNames);
			this.playersScores.addAll(loadedScores);
			this.survivalTimes.addAll(loadedTimes);
			this.sortEntries();
		} catch (Exception ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private synchronized boolean persistInternal() {
		if (this.store == null) {
			return false;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			ArrayList<String> lines = new ArrayList<String>();
			lines.add(HEADER);

			for (int i = 0; i < this.playersNames.size(); i++) {
				String encodedName = Base64.getEncoder().encodeToString(
						this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
				lines.add(encodedName + "\t"
						+ this.playersScores.get(i) + "\t"
						+ this.survivalTimes.get(i));
			}

			Path temporary = this.store.resolveSibling(
					this.store.getFileName().toString() + ".tmp");
			Files.write(temporary, lines, StandardCharsets.UTF_8);

			try {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException ex) {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	private void sortEntries() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			order.add(i);
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						playersScores.get(second), playersScores.get(first));
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return playersNames.get(first).compareToIgnoreCase(
						playersNames.get(second));
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : order) {
			sortedNames.add(this.playersNames.get(index));
			sortedScores.add(this.playersScores.get(index));
			sortedTimes.add(this.survivalTimes.get(index));
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.addAll(sortedTimes);
	}

	private static String normalizeName(String playerName) {
		if (playerName == null) {
			return "Player";
		}

		String name = playerName.trim();
		if (name.length() == 0) {
			return "Player";
		}
		if (name.length() > 64) {
			return name.substring(0, 64);
		}
		return name;
	}

	private static String formatTime(int seconds) {
		int safeSeconds = Math.max(0, seconds);
		int minutes = safeSeconds / 60;
		int remainingSeconds = safeSeconds % 60;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}
}