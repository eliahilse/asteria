package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local and deliberately bounded high-score table. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    /** Records player one's final score after ApoMarioLevel has applied its bonus. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < scores.size(); i++) {
                    out.write(scores.get(i).toString()); out.write('\t');
                    out.write(survivalTimes.get(i).toString()); out.write('\t');
                    out.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        names.clear(); scores.clear(); survivalTimes.clear();
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        String name = new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                        names.add(name); scores.add(Integer.valueOf(score)); survivalTimes.add(Integer.valueOf(time));
                    } catch (IllegalArgumentException ignored) { }
                }
            } finally { in.close(); }
            sortAndLimit();
        } catch (IOException ignored) { }
    }

    private void sortAndLimit() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                int c = scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
                return c != 0 ? c : a.compareTo(b);
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (int k = 0; k < order.size() && k < MAX_ENTRIES; k++) {
            int i = order.get(k).intValue(); n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i));
        }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235)); g.fillRoundRect(25, 20, width - 50, height - 40, 20, 20);
        g.setColor(Color.BLACK); g.drawRoundRect(25, 20, width - 50, height - 40, 20, 20);
        g.setFont(new Font("Dialog", Font.BOLD, 28)); g.drawString("HIGHSCORES", width / 2 - 90, 60);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int rows = Math.min(12, scores.size());
        for (int i = 0; i < rows; i++) {
            int y = 92 + i * 25;
            g.drawString(String.valueOf(i + 1), 55, y);
            g.drawString(names.get(i), 100, y);
            g.drawString(String.valueOf(scores.get(i)), width / 2, y);
            int seconds = survivalTimes.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 145, y);
        }
        if (rows == 0) g.drawString("No runs recorded", width / 2 - 55, 100);
        g.drawString("H / ESC: back", 45, height - 48);
    }
}