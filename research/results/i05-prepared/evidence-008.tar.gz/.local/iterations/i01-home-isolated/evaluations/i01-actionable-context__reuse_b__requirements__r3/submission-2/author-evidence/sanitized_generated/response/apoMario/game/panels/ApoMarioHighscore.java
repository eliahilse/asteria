package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.level.ApoMarioLevel;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Persistent, local highscore table. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized void recordRunEnd(apoMario.level.ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().size() == 0 || level.isBReplay()) return;
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || player.getAi() != null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            times.remove(times.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(store));
            try {
                out.writeInt(VERSION);
                out.writeInt(names.size());
                for (int i = 0; i < names.size(); i++) {
                    out.writeUTF(names.get(i));
                    out.writeInt(scores.get(i).intValue());
                    out.writeInt(times.get(i).intValue());
                }
            } finally { out.close(); }
        } catch (IOException ex) { /* A score must never stop the game. */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            try {
                if (in.readInt() != VERSION) return;
                int count = Math.min(MAX_ENTRIES, Math.max(0, in.readInt()));
                for (int i = 0; i < count; i++) {
                    names.add(in.readUTF());
                    scores.add(Integer.valueOf(in.readInt()));
                    times.add(Integer.valueOf(Math.max(0, in.readInt())));
                }
                sort();
            } finally { in.close(); }
        } catch (IOException | RuntimeException ex) { names.clear(); scores.clear(); times.clear(); }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(times.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
}