package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Lightweight dedicated renderer used by the menu for the local table. */
public class ApoMarioHighscoreView {
    private final ApoMarioPanel panel;
    public ApoMarioHighscoreView(ApoMarioPanel panel) { this.panel = panel; }
    public void render(Graphics2D g) {
        ApoMarioHighscore h = panel.getHighscore();
        List<String> n = h.getPlayersNames(); List<Integer> s = h.getPlayersScores(); List<Integer> t = h.getSurvivalTimes();
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", 40, 55);
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < n.size() && i < 12; i++) {
            int y = 95 + i * 25;
            int ms = Math.max(0, t.get(i)); int sec = ms / 1000;
            g.drawString((i + 1) + ".", 45, y);
            g.drawString(n.get(i), 80, y); g.drawString(String.valueOf(s.get(i)), 300, y);
            g.drawString(String.format("%02d:%02d", sec / 60, sec % 60), 420, y);
        }
        g.drawString("ESC: back", 40, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}