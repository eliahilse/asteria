package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreEntry;

/** Small value object useful to menu/view clients. */
public final class ApoMarioHighscoreEntry {
    private final String name;
    private final int score;
    private final int survivalTime;
    public ApoMarioHighscoreEntry(String name, int score, int survivalTime) { this.name = name; this.score = score; this.survivalTime = survivalTime; }
    public String getName() { return name; }
    public int getScore() { return score; }
    public int getSurvivalTime() { return survivalTime; }
}