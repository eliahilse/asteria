package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

/** Small named view type for integrations that want a dedicated high-score panel. */
public class ApoMarioHighscorePanel extends ApoMarioHighscore {
    public ApoMarioHighscorePanel(java.nio.file.Path store) { super(store); }
}