package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 32;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || score < -100000000 || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                out.write("APOMARIO_HIGHSCORE 1\n");
                out.write(Integer.toString(runs.size())); out.write('\n');
                for (Run r : runs) {
                    out.write(Integer.toString(r.score)); out.write('\t');
                    out.write(Integer.toString(r.time)); out.write('\t');
                    out.write(r.name.replace("\\", "\\\\").replace("\t", " ")); out.write('\n');
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed save must not stop the game. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APOMARIO_HIGHSCORE 1".equals(in.readLine())) return;
                String countLine = in.readLine();
                int count = Integer.parseInt(countLine);
                if (count < 0 || count > MAX_RECORDS) return;
                for (int i = 0; i < count; i++) {
                    String line = in.readLine();
                    if (line == null || line.length() > 256) return;
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) return;
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    String name = cleanName(p[2]);
                    if (name == null || time < 0) return;
                    runs.add(new Run(score, time, name));
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (Exception ex) { runs.clear(); }
    }

    private static String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isISOControl(c)) b.append(' '); else b.append(c);
        }
        s = b.toString().trim();
        return s.length() == 0 ? null : s;
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score == a.score ? a.name.compareTo(b.name) : (b.score < a.score ? -1 : 1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
}