package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504d48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 1000;
    private static final int MAX_NAME_BYTES = 96;
    private static final long MAX_FILE_BYTES = 1024L * 1024L;
    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null) return false;
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }
    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = null;
        try {
            Path target = store.toAbsolutePath();
            Path parent = target.getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = target.resolveSibling(target.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run run : runs) { out.writeInt(run.score); out.writeInt(run.time); out.writeUTF(run.name); }
            out.close();
            try { Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }
    private String cleanName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0) return null;
        byte[] bytes = name.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_NAME_BYTES) name = new String(bytes, 0, MAX_NAME_BYTES, StandardCharsets.UTF_8).trim();
        return name.length() == 0 ? null : name;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); } });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
    private void load() {
        if (store == null) return;
        try {
            Path target = store.toAbsolutePath();
            if (!Files.exists(target) || Files.size(target) > MAX_FILE_BYTES) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(target)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt(); int time = in.readInt(); String name = cleanName(in.readUTF());
                if (name == null || time < 0) { in.close(); return; }
                loaded.add(new Run(score, time, name));
            }
            in.close(); runs.clear(); runs.addAll(loaded); sortAndTrim();
        } catch (IOException ex) { runs.clear(); }
    }
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        g.drawString("Rank", 45, 90); g.drawString("Points", 125, 90); g.drawString("Player", 225, 90); g.drawString("Time", 430, 90);
        for (int i = 0; i < runs.size() && i < 15; i++) {
            Run run = runs.get(i); int y = 120 + i * 25; long seconds = run.time / 1000L;
            g.drawString(String.valueOf(i + 1), 50, y); g.drawString(String.valueOf(run.score), 125, y); g.drawString(run.name, 225, y);
            g.drawString(String.format("%02d:%02d", seconds / 60L, seconds % 60L), 430, y);
        }
    }
}