package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, file-backed highscore board.  Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_BYTES = 80;
    private static final long MAX_FILE_BYTES = 1024 * 1024;

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Records the final, already-scored human run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player == null ? "Player" : player.getTeamName();
        int score = player == null ? 0 : player.getPoints();
        int elapsed = level.getPassedTime();
        storeRun(score, elapsed, name);
    }

    public synchronized void renderBoard(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 235, 245));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", 25, 42);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int y = 75;
        for (int i = 0; i < runs.size() && i < 15; i++) {
            Run r = runs.get(i);
            g.drawString(String.valueOf(i + 1), 28, y);
            g.drawString(r.name, 70, y);
            g.drawString(String.valueOf(r.score), width - 180, y);
            g.drawString(formatTime(r.time), width - 85, y);
            y += 25;
        }
        g.drawString("ESC: back", 25, height - 20);
    }

    public static String formatTime(int milliseconds) {
        long ms = Math.max(0L, (long) milliseconds);
        long seconds = ms / 1000L;
        long minutes = seconds / 60L;
        seconds %= 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < 40; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127) b.append(c);
        }
        return b.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                if (a.score != b.score) return a.score < b.score ? 1 : -1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    private synchronized void load() {
        runs.clear();
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE_BYTES) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int magic = in.readInt(), version = in.readInt(), count = in.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt(), time = in.readInt(), length = in.readInt();
                if (score < 0 || time < 0 || length < 0 || length > MAX_NAME_BYTES) throw new IOException("invalid record");
                byte[] data = new byte[length];
                in.readFully(data);
                String name = cleanName(new String(data, StandardCharsets.UTF_8));
                if (name.length() == 0) throw new IOException("invalid name");
                loaded.add(new Run(score, time, name));
            }
            in.close();
            runs.addAll(loaded);
            sortAndTrim();
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private boolean persist() {
        if (store == null) return false;
        Path parent = store.toAbsolutePath().getParent();
        Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run run : runs) {
                byte[] data = run.name.getBytes(StandardCharsets.UTF_8);
                if (data.length > MAX_NAME_BYTES) data = cleanName(run.name).getBytes(StandardCharsets.UTF_8);
                out.writeInt(run.score); out.writeInt(run.time); out.writeInt(data.length); out.write(data);
            }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
            return false;
        }
    }
}