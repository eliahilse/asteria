package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.level.ApoMarioLevel;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Persistent, score-sorted run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private final java.util.Set<apoMario.level.ApoMarioLevel> recordedLevels = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<apoMario.level.ApoMarioLevel, Boolean>());

    public synchronized void recordRunEnd(apoMario.level.ApoMarioLevel level) {
        if (level == null || this.recordedLevels.contains(level)) return;
        java.util.List<apoMario.entity.ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty()) return;
        apoMario.entity.ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        if (this.storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) {
            this.recordedLevels.add(level);
        }
    }
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final int score;
        final int time;
        final String name;
        Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name == null || survivalTime < 0) {
            return false;
        }
        entries.add(new Entry(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(Integer.valueOf(entry.score));
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(Integer.valueOf(entry.time));
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Entry entry : entries) {
                lines.add(Integer.toString(entry.score) + "\t" + entry.time + "\t" +
                        Base64.getEncoder().encodeToString(entry.name.getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A highscore must never stop the game when its store is unavailable.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            int count = 0;
            for (String line : lines) {
                if (count++ >= MAX_ENTRIES || line.length() > 512) break;
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3) continue;
                try {
                    int score = Integer.parseInt(fields[0]);
                    int time = Integer.parseInt(fields[1]);
                    if (time < 0) continue;
                    String name = normalizeName(new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8));
                    if (name != null) entries.add(new Entry(score, time, name));
                } catch (IllegalArgumentException ex) {
                    // Ignore malformed records and continue loading valid ones.
                }
            }
            sortAndTrim();
        } catch (IOException ex) {
            // Missing, unreadable, or truncated stores are treated as empty.
        }
    }

    private static String normalizeName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return null;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return null;
        }
        return name;
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
}