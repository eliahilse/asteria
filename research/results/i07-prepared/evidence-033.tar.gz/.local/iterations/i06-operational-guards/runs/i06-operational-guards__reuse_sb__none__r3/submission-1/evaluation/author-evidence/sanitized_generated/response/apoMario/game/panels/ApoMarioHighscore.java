package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local highscore table for completed Mario runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            survivalTimes.remove(survivalTimes.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the actual winning player's score, name and elapsed level time. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && player.getPoints() > chosen.getPoints()) chosen = player;
        }
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(scores.get(i).toString()); out.write('\t');
                    out.write(survivalTimes.get(i).toString()); out.write('\t');
                    out.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        scores.add(Integer.valueOf(p[0]));
                        survivalTimes.add(Integer.valueOf(p[1]));
                        names.add(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                    } catch (IllegalArgumentException ignored) { }
                }
            } finally { in.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("Highscore", 20, 35);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        g.drawString("#", 20, 60); g.drawString("Points", 55, 60); g.drawString("Player", 135, 60); g.drawString("Time", 260, 60);
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 85 + i * 16;
            g.drawString(String.valueOf(i + 1), 20, y);
            g.drawString(String.valueOf(scores.get(i)), 55, y);
            g.drawString(names.get(i), 135, y);
            int seconds = survivalTimes.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 260, y);
        }
        g.drawString("Press Escape or H to return", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
}