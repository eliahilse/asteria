package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** Small dedicated renderer used by the menu for the local highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore board) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 95, 52);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        List<String> names = board.getPlayersNames();
        List<Integer> scores = board.getPlayersScores();
        List<Integer> times = board.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 80 + i * 15;
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ".", 42, y);
            g.drawString(names.get(i), 65, y);
            g.drawString(String.valueOf(scores.get(i)), 205, y);
            g.drawString(time, 260, y);
        }
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("ESC: back", 105, ApoMarioConstants.GAME_HEIGHT - 22);
    }
}