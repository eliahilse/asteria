package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local highscore table for ApoMario. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();
    private final java.util.Set<ApoMarioLevel> recordedLevels =
            java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<ApoMarioLevel, Boolean>());

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the final human player's score after ApoMarioLevel has applied bonuses. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level) || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) {
            recordedLevels.add(level);
        }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path parent = store.toAbsolutePath().getParent();
        Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, "apo-mario-highscore-", ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(runs.size());
            for (Run r : runs) { out.writeInt(r.score); out.writeInt(r.time); out.writeUTF(r.name); }
            out.flush(); out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            temp = null;
        } catch (IOException ex) {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 128 * 1024) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_RECORDS) { in.close(); return; }
            ArrayList<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt(), time = in.readInt();
                String name = normalizeName(in.readUTF());
                if (name == null || time < 0) { in.close(); return; }
                loaded.add(new Run(score, time, name));
            }
            in.close(); runs.addAll(loaded); sortAndTrim();
        } catch (IOException ex) { runs.clear(); }
    }
    private String normalizeName(String value) {
        if (value == null) return null;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return null;
        return s;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    /** Draws the dedicated menu view; stored time remains milliseconds until this point. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245,245,245,235)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 65, 32);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run r = runs.get(i); int y = 58 + i * 15;
            long seconds = r.time / 1000L; String time = String.format("%02d:%02d", seconds / 60L, seconds % 60L);
            g.drawString((i + 1) + ". " + r.name, 25, y);
            g.drawString(String.valueOf(r.score), width / 2 - 25, y);
            g.drawString(time, width - 65, y);
        }
        g.drawString("ESC / H: back", 10, height - 8);
    }
}