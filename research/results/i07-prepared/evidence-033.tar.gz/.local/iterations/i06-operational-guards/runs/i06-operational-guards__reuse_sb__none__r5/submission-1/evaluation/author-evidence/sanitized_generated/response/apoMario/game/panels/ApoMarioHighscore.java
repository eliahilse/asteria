package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent local highscore table for completed Mario runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            survivalTimes.remove(survivalTimes.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the actual winning/remaining player result from the finished level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (chosen == null || player.getPoints() > chosen.getPoints())) chosen = player;
        }
        if (chosen == null) chosen = level.getPlayers().get(0);
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) {
                String encoded = Base64.getEncoder().encodeToString(names.get(i).getBytes(Charset.forName("UTF-8")));
                lines.add(encoded + "\t" + scores.get(i) + "\t" + survivalTimes.get(i));
            }
            Files.write(store, lines, Charset.forName("UTF-8"));
        } catch (Exception ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, Charset.forName("UTF-8"))) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                names.add(new String(Base64.getDecoder().decode(p[0]), Charset.forName("UTF-8")));
                scores.add(Integer.valueOf(p[1]));
                survivalTimes.add(Integer.valueOf(p[2]));
            }
            sort();
        } catch (Exception ignored) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); scores.clear(); survivalTimes.clear(); names.addAll(n); scores.addAll(s); survivalTimes.addAll(t);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20, 15, width - 40, height - 30, 15, 15);
        g.setColor(Color.BLACK); g.drawRoundRect(20, 15, width - 40, height - 30, 15, 15);
        g.setFont(new Font("Dialog", Font.BOLD, 18)); g.drawString("HIGHSCORES", 35, 42);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 68 + i * 18;
            int ms = survivalTimes.get(i).intValue() / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(ms / 60), Integer.valueOf(ms % 60));
            g.drawString((i + 1) + ". " + names.get(i), 35, y);
            g.drawString(String.valueOf(scores.get(i)), width - 125, y);
            g.drawString(time, width - 70, y);
        }
        g.drawString("ESC / H: back", 35, height - 22);
    }
}