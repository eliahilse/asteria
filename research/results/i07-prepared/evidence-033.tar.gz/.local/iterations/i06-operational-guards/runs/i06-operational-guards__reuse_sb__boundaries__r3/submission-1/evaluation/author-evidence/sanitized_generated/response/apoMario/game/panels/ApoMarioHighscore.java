package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024L * 1024L;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        entries.add(new Entry(name, score, survivalTime));
        sort();
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
        return write();
    }

    public synchronized List<String> getPlayersNames() { return names(); }
    public synchronized List<Integer> getPlayersScores() { return scores(); }
    public synchronized List<Integer> getSurvivalTimes() { return times(); }

    public synchronized void persistAcrossRuns() { write(); }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || !player.isBVisible()) return;
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g) {
        int w = ApoMarioConstants.GAME_WIDTH, h = ApoMarioConstants.GAME_HEIGHT;
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20, 15, w-40, h-30, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(20, 15, w-40, h-30, 18, 18);
        g.setFont(ApoMarioConstants.FONT_MENU); g.drawString("HIGHSCORES", w/2-55, 42);
        g.setFont(new Font("Dialog", Font.PLAIN, Math.max(10, ApoMarioConstants.SIZE*10)));
        for (int i=0; i<entries.size() && i<10; i++) {
            Entry e = entries.get(i); int y = 68 + i*16;
            g.drawString(String.valueOf(i+1), 38, y);
            g.drawString(e.name, 65, y); g.drawString(String.valueOf(e.score), 190, y);
            g.drawString(formatTime(e.time), 245, y);
        }
        g.drawString("ESC: back", 38, h-25);
    }

    private String formatTime(int millis) {
        long seconds = Math.max(0L, (long)millis) / 1000L;
        long minutes = seconds / 60L;
        return String.format("%02d:%02d", minutes, seconds % 60L);
    }
    private String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i=0; i<value.length() && b.length()<MAX_NAME; i++) {
            char c=value.charAt(i); if (c >= 32 && c != 127) b.append(c);
        }
        return b.toString().trim();
    }
    private void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { int c=Integer.compare(b.score,a.score); return c != 0 ? c : a.name.compareTo(b.name); }}); }
    private List<String> names() { ArrayList<String> r=new ArrayList<String>(); for(Entry e:entries) r.add(e.name); return Collections.unmodifiableList(r); }
    private List<Integer> scores() { ArrayList<Integer> r=new ArrayList<Integer>(); for(Entry e:entries) r.add(e.score); return Collections.unmodifiableList(r); }
    private List<Integer> times() { ArrayList<Integer> r=new ArrayList<Integer>(); for(Entry e:entries) r.add(e.time); return Collections.unmodifiableList(r); }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int magic=in.readInt(), version=in.readInt(), count=in.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
            ArrayList<Entry> read=new ArrayList<Entry>();
            for(int i=0;i<count;i++) { String n=cleanName(in.readUTF()); int s=in.readInt(), t=in.readInt(); if(n.length()==0 || t<0) { in.close(); return; } read.add(new Entry(n,s,t)); }
            in.close(); entries.clear(); entries.addAll(read); sort();
        } catch (IOException ex) { entries.clear(); }
    }
    private boolean write() {
        if (store == null) return false;
        try {
            Path parent=store.toAbsolutePath().getParent(); if(parent!=null) Files.createDirectories(parent);
            Path temp=store.resolveSibling(store.getFileName().toString()+".tmp");
            DataOutputStream out=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(entries.size());
            for(Entry e:entries) { out.writeUTF(e.name); out.writeInt(e.score); out.writeInt(e.time); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch(AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) { return false; }
    }
}