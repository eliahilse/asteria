package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

/** Dedicated menu view facade for the file-backed highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
}