package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent local highscore board. Survival times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name;
        int score;
        int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(store));
            out.writeInt(MAGIC);
            out.writeInt(entries.size());
            for (Entry e : entries) {
                out.writeUTF(e.name);
                out.writeInt(e.score);
                out.writeInt(e.time);
            }
            out.close();
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != MAGIC) { in.close(); return; }
            int count = Math.min(MAX_ENTRIES, Math.max(0, in.readInt()));
            for (int i = 0; i < count; i++) entries.add(new Entry(in.readUTF(), in.readInt(), in.readInt()));
            in.close();
            sortAndTrim();
        } catch (IOException | RuntimeException ignored) { entries.clear(); }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    /** Records the best real player score at the end of the supplied run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible() && (best == null || p.getPoints() > best.getPoints())) best = p;
        }
        if (best == null) best = level.getPlayers().get(0);
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(best.getPoints(), level.getPassedTime(), name);
    }

    /** Lightweight rendering used directly by the menu. */
    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(245, 245, 245, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 16, 16);
        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", 105, 48);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g.drawString("ESC / H: back", 10, ApoMarioConstants.GAME_HEIGHT - 8);
        int y = 70;
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i);
            g.drawString(String.valueOf(i + 1), 42, y);
            g.drawString(e.name, 70, y);
            g.drawString(String.valueOf(e.score), 205, y);
            int seconds = e.time / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 270, y);
            y += 16;
        }
    }
}