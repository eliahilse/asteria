package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local and defensive highscore store for ApoMario. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < Integer.MIN_VALUE || survivalTime < 0) return false;
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the final, already-scored human run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path parent = store.toAbsolutePath().getParent();
        Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run run : runs) { out.writeInt(run.score); out.writeInt(run.time); out.writeUTF(run.name); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            temp = null;
        } catch (Exception ex) {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
        }
    }

    private synchronized void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_SIZE) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int magic = in.readInt(), version = in.readInt(), count = in.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt(), time = in.readInt();
                String name = in.readUTF();
                if (name.length() > MAX_NAME_LENGTH || time < 0) { in.close(); return; }
                loaded.add(new Run(score, time, cleanName(name)));
            }
            in.close();
            runs.clear(); runs.addAll(loaded); sortAndTrim();
        } catch (Exception ignored) { runs.clear(); }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127) b.append(c);
        }
        return b.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) {
            if (a.score != b.score) return a.score > b.score ? -1 : 1;
            return a.name.compareToIgnoreCase(b.name);
        }});
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 18));
        g.drawString("HIGHSCORES", width / 2 - 55, 30);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        for (int i = 0; i < runs.size() && i < 10; i++) {
            Run r = runs.get(i); int y = 55 + i * 17;
            g.drawString((i + 1) + ". " + r.name, 25, y);
            g.drawString(String.valueOf(r.score), width / 2, y);
            g.drawString(formatTime(r.time), width - 60, y);
        }
        g.drawString("ESC/H: back", 10, height - 10);
    }

    private static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = seconds / 60L;
        return String.format("%02d:%02d", minutes, seconds % 60L);
    }
}