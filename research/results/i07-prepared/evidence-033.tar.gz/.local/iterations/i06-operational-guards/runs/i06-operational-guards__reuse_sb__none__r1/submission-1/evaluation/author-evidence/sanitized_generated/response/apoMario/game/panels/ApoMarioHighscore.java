package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent local highscore table for the Mario game. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(score, survivalTime, name));
        sort();
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.survivalTime);
        return Collections.unmodifiableList(result);
    }

    /** Records the best real player result at the end of the current run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (best == null || player.getPoints() > best.getPoints())) best = player;
        }
        if (best == null) best = level.getPlayers().get(0);
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(best.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Entry e : entries) lines.add(e.score + "\t" + e.survivalTime + "\t" + e.name.replace("\t", " ").replace("\n", " "));
            Files.write(store, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ignored) { }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 255));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.drawString("HIGHSCORES", width / 2 - 65, 35);
        g.setFont(new Font("Dialog", Font.BOLD, 13));
        g.drawString("#", 25, 65); g.drawString("PLAYER", 55, 65); g.drawString("POINTS", width - 125, 65); g.drawString("TIME", width - 55, 65);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i); int y = 88 + i * 16;
            g.drawString(String.valueOf(i + 1), 25, y); g.drawString(e.name, 55, y);
            g.drawString(String.valueOf(e.score), width - 125, y);
            int seconds = e.survivalTime / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 55, y);
        }
        g.setFont(new Font("Dialog", Font.PLAIN, 11));
        g.drawString("Press H or Escape to return", 10, height - 10);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", 3);
                if (p.length == 3) entries.add(new Entry(Integer.parseInt(p[0]), Integer.parseInt(p[1]), p[2]));
            }
            sort();
        } catch (Exception ignored) { entries.clear(); }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
    }

    private static final class Entry {
        final int score, survivalTime; final String name;
        Entry(int score, int survivalTime, String name) { this.score = score; this.survivalTime = survivalTime; this.name = name; }
    }
}