package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, bounded, file-backed highscore board. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0) survivalTime = 0;
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (Run r : runs) {
                    out.write(r.score + "\t" + r.time + "\t" + r.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " "));
                    out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) { }
    }

    /** Records the final, already-scored human run exactly once per terminal analysis. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null && p.isBVisible()) { chosen = p; break; }
        }
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(chosen.getPoints(), elapsed, name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 70, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        for (int i = 0; i < runs.size() && i < 15; i++) {
            Run r = runs.get(i); int y = 62 + i * 18;
            g.drawString((i + 1) + ".", 25, y); g.drawString(r.name, 52, y);
            g.drawString(String.valueOf(r.score), width - 120, y);
            long seconds = ((long) r.time) / 1000L;
            g.drawString(String.format("%02d:%02d", seconds / 60L, seconds % 60L), width - 65, y);
        }
        g.drawString("ESC / H: back", 10, height - 10);
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.isRegularFile(store) || Files.size(store) > MAX_FILE) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            ArrayList<Run> read = new ArrayList<Run>(); String line;
            try {
                while ((line = in.readLine()) != null && read.size() < MAX_RECORDS) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try { int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                        String name = cleanName(p[2].replace("\\\\", "\\")); if (time >= 0 && name.length() > 0) read.add(new Run(score, time, name));
                    } catch (NumberFormatException ignored) { }
                }
            } finally { in.close(); }
            runs.addAll(read); sortAndTrim();
        } catch (IOException ignored) { }
    }
    private static String cleanName(String value) {
        if (value == null) return "";
        String s = value.replace('\\', ' ').replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return a.score == b.score ? Integer.compare(a.time, b.time) : (a.score > b.score ? -1 : 1); } });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
}