package apoMario.game.panels;

import apoMario.game.ApoMarioPanel;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated menu view for the persistent high-score table. */
public class ApoMarioHighscoreView extends ApoMarioModel {
    public ApoMarioHighscoreView(apoMario.game.ApoMarioPanel game) { super(game); }
    public void init() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE || button == KeyEvent.VK_ENTER) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function)) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(new Color(245,245,255)); g.fillRect(0,0,ApoMarioConstants.GAME_WIDTH,ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 20, 35);
        ApoMarioHighscore h = getGame().getHighscore(); List<String> n=h.getPlayersNames(); List<Integer> s=h.getPlayersScores(); List<Integer> t=h.getSurvivalTimes();
        g.setFont(ApoMarioConstants.FONT_MENU); int y=65; for (int i=0;i<n.size() && i<15;i++) { int sec=t.get(i)/1000; String time=(sec/60)+":"+(sec%60<10?"0":"")+(sec%60); g.drawString((i+1)+". "+n.get(i),20,y); g.drawString(String.valueOf(s.get(i)),190,y); g.drawString(time,250,y); y+=20; }
        g.drawString("ESC: back",20,ApoMarioConstants.GAME_HEIGHT-15);
    }
}