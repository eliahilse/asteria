package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name.length() == 0) return false;
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, name));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score == a.score ? a.name.compareTo(b.name) : (b.score > a.score ? 1 : -1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        persistAcrossRuns();
        return true;
    }

    /** Records the authoritative human player's finished run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) { selected = player; break; }
        }
        if (selected == null && !level.getPlayers().isEmpty()) selected = level.getPlayers().get(0);
        if (selected == null) return;
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add("APO_MARIO_HIGHSCORE_1");
            for (Run r : runs) lines.add(r.score + "\t" + r.time + "\t" + Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)));
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    /** Small rendering helper used by the live menu view. */
    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235)); g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(x, y, width, height, 18, 18);
        g.drawString("HIGHSCORES", x + 18, y + 28);
        int row = 48; int count = Math.min(runs.size(), 10);
        for (int i = 0; i < count; i++) {
            Run r = runs.get(i); int seconds = r.time / 1000;
            String time = (seconds / 60) + ":" + String.format("%02d", seconds % 60);
            g.drawString((i + 1) + ". " + r.name, x + 18, y + row);
            g.drawString(String.valueOf(r.score), x + width - 105, y + row);
            g.drawString(time, x + width - 55, y + row); row += 19;
        }
        if (count == 0) g.drawString("No runs recorded", x + 18, y + row);
        g.drawString("Press H or ESC to return", x + 18, y + height - 15);
    }

    private String normalize(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i); if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.size() == 0 || !"APO_MARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && runs.size() < MAX_RECORDS; i++) {
                String[] p = lines.get(i).split("\\t", -1); if (p.length != 3) continue;
                int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                if (time < 0 || p[2].length() > 256) continue;
                String name = normalize(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                if (name.length() > 0) runs.add(new Run(score, time, name));
            }
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return b.score == a.score ? a.name.compareTo(b.name) : (b.score > a.score ? 1 : -1); }
            });
        } catch (Exception ignored) { runs.clear(); }
    }
}