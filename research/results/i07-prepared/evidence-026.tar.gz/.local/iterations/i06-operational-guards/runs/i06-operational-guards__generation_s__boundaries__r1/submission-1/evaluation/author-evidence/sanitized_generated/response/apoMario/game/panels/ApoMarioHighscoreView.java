package apoMario.game.panels;

import apoMario.ApoMarioConstants;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Graphics2D;
import apoMario.game.ApoMarioPanel;

/** Dedicated menu view for the persistent highscore board. */
public class ApoMarioHighscoreView extends ApoMarioModel {
    private final ApoMarioPanel game;
    public ApoMarioHighscoreView(ApoMarioPanel game) { super(game); this.game = game; }
    public void init() { }
    public void keyButtonReleased(int button, char character) { if (button == java.awt.event.KeyEvent.VK_ESCAPE || button == java.awt.event.KeyEvent.VK_H) game.setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function)) game.setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) { game.getHighscore().render(g, 18, 18, apoMario.ApoMarioConstants.GAME_WIDTH - 36, apoMario.ApoMarioConstants.GAME_HEIGHT - 36); }
}