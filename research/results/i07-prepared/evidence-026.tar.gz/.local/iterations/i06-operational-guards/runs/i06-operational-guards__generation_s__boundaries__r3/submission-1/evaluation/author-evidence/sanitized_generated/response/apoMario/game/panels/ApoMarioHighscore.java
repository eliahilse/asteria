package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded high-score table. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 80;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the authoritative first human player's completed run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) { chosen = player; break; }
        }
        if (chosen == null) {
            for (ApoMarioPlayer player : level.getPlayers()) if (player != null && player.isBVisible()) { chosen = player; break; }
        }
        if (chosen != null) {
            String name = chosen.getTeamName();
            if (name == null || name.trim().length() == 0) name = "Player";
            storeRun(chosen.getPoints(), level.getPassedTime(), name);
        }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try { w.write("APOMARIO_HIGHSCORE_1"); w.newLine(); for (Entry e : entries) { w.write(e.score + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " ")); w.newLine(); } }
            finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line = r.readLine(); if (!"APOMARIO_HIGHSCORE_1".equals(line)) return;
                int count = 0;
                while (count++ < MAX_RECORDS && (line = r.readLine()) != null) {
                    String[] p = line.split("\\t", 3); if (p.length != 3) continue;
                    try { int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]); if (score < 0 || time < 0) continue; String n = cleanName(p[2]); if (n.length() > 0) entries.add(new Entry(n, score, time)); } catch (NumberFormatException ignored) { }
                }
            } finally { r.close(); }
            sortAndTrim();
        } catch (IOException ignored) { }
    }
    private static String cleanName(String name) {
        if (name == null) return "";
        StringBuilder b = new StringBuilder(); for (int i=0; i<name.length() && b.length()<MAX_NAME; i++) { char c=name.charAt(i); if (c >= 32 && c != '\t' && c != '\r' && c != '\n') b.append(c); }
        return b.toString().trim();
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score > a.score ? 1 : -1); } });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size()-1);
    }
}