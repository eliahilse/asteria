package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 20;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final ArrayList<Record> records = new ArrayList<Record>();

    private static final class Record {
        final int score;
        final int time;
        final String name;
        Record(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        records.add(new Record(score, survivalTime, name));
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score > a.score ? 1 : -1); }
        });
        while (records.size() > MAX_ENTRIES) records.remove(records.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                out.write("APO_MARIO_HIGHSCORE_1"); out.newLine();
                for (Record r : records) {
                    out.write(Integer.toString(r.score)); out.write('\t');
                    out.write(Integer.toString(r.time)); out.write('\t');
                    out.write(Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8))); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException e) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) { }
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(x, y, width, height, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", x + 20, y + 32);
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < records.size(); i++) {
            Record r = records.get(i); int yy = y + 62 + i * 18;
            if (yy > y + height - 8) break;
            String mins = Integer.toString(r.time / 60000);
            String secs = Integer.toString((r.time / 1000) % 60); if (secs.length() < 2) secs = "0" + secs;
            g.drawString((i + 1) + ". " + r.name, x + 18, yy);
            g.drawString(Integer.toString(r.score), x + width - 105, yy);
            g.drawString(mins + ":" + secs, x + width - 48, yy);
        }
        if (records.isEmpty()) g.drawString("No runs recorded", x + 20, y + 70);
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null && p.isBVisible()) { chosen = p; break; }
        }
        if (chosen == null && !level.getPlayers().isEmpty()) chosen = level.getPlayers().get(0);
        if (chosen == null) return;
        storeRun(chosen.getPoints(), Math.max(0, level.getPassedTime()), chosen.getTeamName());
    }

    private String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE_1".equals(in.readLine())) return;
                String line; int count = 0;
                while (count++ < 100 && (line = in.readLine()) != null && records.size() < MAX_ENTRIES) {
                    String[] p = line.split("\\t", -1); if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                        if (time < 0 || p[2].length() > 256) continue;
                        String name = new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                        name = cleanName(name); if (name.length() > 0) records.add(new Record(score, time, name));
                    } catch (RuntimeException ignored) { }
                }
            } finally { in.close(); }
        } catch (IOException ignored) { }
        Collections.sort(records, new Comparator<Record>() { public int compare(Record a, Record b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score > a.score ? 1 : -1); } });
    }
}