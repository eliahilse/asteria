package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small reusable renderer for the menu highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore score) {
        List<String> names = score.getPlayersNames();
        List<Integer> points = score.getPlayersScores();
        List<Integer> times = score.getSurvivalTimes();
        g.setColor(Color.WHITE); g.fillRoundRect(30, 25, ApoMarioConstants.GAME_WIDTH - 60, ApoMarioConstants.GAME_HEIGHT - 50, 12, 12);
        g.setColor(Color.BLACK); g.drawRoundRect(30, 25, ApoMarioConstants.GAME_WIDTH - 60, ApoMarioConstants.GAME_HEIGHT - 50, 12, 12);
        g.setFont(ApoMarioConstants.FONT_MENU); g.drawString("HIGHSCORES (ESC to return)", 55, 55);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        int rows = Math.min(names.size(), 10);
        for (int i = 0; i < rows; i++) {
            int y = 82 + i * 16;
            int ms = times.get(i); int sec = ms / 1000;
            String time = String.format("%02d:%02d", sec / 60, sec % 60);
            g.drawString((i + 1) + ". " + names.get(i), 55, y);
            g.drawString(Integer.toString(points.get(i)), 215, y);
            g.drawString(time, 270, y);
        }
    }
}