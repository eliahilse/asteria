package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; persistAcrossRuns(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim()); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(survivalTime));
        sortAndTrim(); write(); return true;
    }
    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() {
        names.clear(); scores.clear(); times.clear();
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > 1024L * 1024L) return;
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line; int count = 0;
            while (count < MAX_ENTRIES && (line = r.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                    if (score >= 0 && time >= 0 && validName(p[2])) { scores.add(score); times.add(time); names.add(p[2]); count++; }
                } catch (NumberFormatException ignored) { }
            }
            r.close(); sortAndTrim();
        } catch (IOException ignored) { names.clear(); scores.clear(); times.clear(); }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer p : level.getPlayers()) if (p != null && p.isBVisible()) { chosen = p; break; }
        if (chosen == null && !level.getPlayers().isEmpty()) chosen = level.getPlayers().get(0);
        if (chosen == null) return;
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        storeRun(chosen.getPoints(), Math.max(0, elapsed), name);
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String n = name.trim();
        if (n.length() == 0 || n.length() > MAX_NAME) return false;
        for (int i = 0; i < n.length(); i++) if (Character.isISOControl(n.charAt(i))) return false;
        return true;
    }
    private void sortAndTrim() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b).compareTo(scores.get(a)); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (int i = 0; i < order.size() && i < MAX_ENTRIES; i++) { int x = order.get(i); n.add(names.get(x)); s.add(scores.get(x)); t.add(times.get(x)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
    private void write() {
        if (store == null) return;
        Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            Path parent = store.getParent(); if (parent != null) Files.createDirectories(parent);
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            for (int i = 0; i < scores.size(); i++) w.write(scores.get(i) + "\t" + times.get(i) + "\t" + names.get(i) + "\n");
            w.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) { }
    }
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height); g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 22)); g.drawString("HIGHSCORES", width / 2 - 70, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        for (int i = 0; i < names.size() && i < 12; i++) {
            int y = 65 + i * 15; g.drawString((i + 1) + ". " + names.get(i), 35, y);
            g.drawString(String.valueOf(scores.get(i)), width / 2, y);
            int sec = times.get(i) / 1000; g.drawString(String.format("%02d:%02d", sec / 60, sec % 60), width - 65, y);
        }
        g.drawString("ESC / H: back", 10, height - 10);
    }
}