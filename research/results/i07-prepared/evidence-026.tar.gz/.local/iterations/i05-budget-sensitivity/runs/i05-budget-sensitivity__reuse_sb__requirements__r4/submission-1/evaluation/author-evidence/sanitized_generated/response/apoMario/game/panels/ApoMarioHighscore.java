package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import java.awt.*;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed, descending-score highscore table for ApoMario. */
public final class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private static final int MAX_FILE_BYTES = 128 * 1024;

    private static final class Run {
        final String name; final int score; final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private final Set<ApoMarioLevel> recordedLevels = Collections.newSetFromMap(
            new IdentityHashMap<ApoMarioLevel, Boolean>());

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        runs.add(new Run(playerName.trim(), score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the final first-player result once for a terminal level state. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level) || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (!validName(name)) name = "Player";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) recordedLevels.add(level);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run r : runs) { out.writeUTF(r.name); out.writeInt(r.score); out.writeInt(r.time); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // Persistence is deliberately non-fatal to gameplay.
        }
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }

    private void sortAndLimit() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private synchronized void load() {
        if (store == null) return;
        try {
            if (!Files.isRegularFile(store) || Files.size(store) > MAX_FILE_BYTES) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = in.readUTF(); int score = in.readInt(); int time = in.readInt();
                if (validName(name) && score >= 0 && time >= 0) runs.add(new Run(name.trim(), score, time));
            }
            in.close(); sortAndLimit();
        } catch (IOException ex) { runs.clear(); }
    }

    public synchronized void render(java.awt.Graphics2D g, int width, int height) {
        g.setColor(java.awt.Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(java.awt.Color.BLACK); g.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 18));
        g.drawString("HIGHSCORES", 20, 30);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
        for (int i = 0; i < runs.size(); i++) {
            Run r = runs.get(i); int y = 55 + i * 18;
            g.drawString((i + 1) + ". " + r.name, 20, y);
            g.drawString(String.valueOf(r.score), width / 2, y);
            int seconds = r.time / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 75, y);
        }
        g.drawString("H/ESC: back", 20, height - 10);
    }
}