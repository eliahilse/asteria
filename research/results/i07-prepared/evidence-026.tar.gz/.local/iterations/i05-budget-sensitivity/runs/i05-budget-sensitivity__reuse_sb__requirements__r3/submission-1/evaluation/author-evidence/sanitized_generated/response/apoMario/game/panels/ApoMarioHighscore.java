package apoMario.game.panels;

import apoMario.game.ApoMarioPanel;
import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed highscore board. Survival times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0xAMH501;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;

    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME) return false;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return false;
        }
        entries.add(new Entry(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the finalized result of a real (non-replay) run exactly once. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.isBAnalysis()) return;
        if (level.getComponent() instanceof apoMario.game.ApoMarioPanel
                && ((apoMario.game.ApoMarioPanel) level.getComponent()).isBSimulate()) return;
        ApoMarioPlayer player = null;
        if (level.getPlayers() != null) {
            for (ApoMarioPlayer candidate : level.getPlayers()) {
                if (candidate != null && candidate.isBVisible()) { player = candidate; break; }
            }
            if (player == null && !level.getPlayers().isEmpty()) player = level.getPlayers().get(0);
        }
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed;
        try { elapsed = Math.max(0, level.getPassedTime()); } catch (RuntimeException ex) { elapsed = 0; }
        storeRun(Math.max(0, player.getPoints()), elapsed, name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(entries.size());
            for (Entry e : entries) { out.writeInt(e.score); out.writeInt(e.time); byte[] n = e.name.getBytes(StandardCharsets.UTF_8); out.writeInt(n.length); out.write(n); }
            out.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* persistence must not stop gameplay */ }
    }

    public void render(Graphics2D g) {
        List<String> names = getPlayersNames(); List<Integer> scores = getPlayersScores(); List<Integer> times = getSurvivalTimes();
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(25, 25, ApoMarioConstants.GAME_WIDTH-50, ApoMarioConstants.GAME_HEIGHT-50, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(25, 25, ApoMarioConstants.GAME_WIDTH-50, ApoMarioConstants.GAME_HEIGHT-50, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 92, 58);
        g.setFont(new Font("Dialog", Font.BOLD, 12));
        int y = 82;
        for (int i=0; i<names.size() && i<10; i++, y+=18) {
            int seconds = times.get(i) / 1000; String mmss = String.format("%02d:%02d", seconds/60, seconds%60);
            g.drawString(String.valueOf(i+1), 45, y); g.drawString(names.get(i), 75, y); g.drawString(String.valueOf(scores.get(i)), 220, y); g.drawString(mmss, 275, y);
        }
        g.drawString("H / ESC: back", 105, ApoMarioConstants.GAME_HEIGHT-35);
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 64) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt(); if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i=0; i<count; i++) { int score=in.readInt(), time=in.readInt(), length=in.readInt(); if(score<0||time<0||length<1||length>MAX_NAME*4){in.close();return;} byte[] b=new byte[length];in.readFully(b);String n=new String(b,StandardCharsets.UTF_8);if(n.trim().length()==0||n.length()>MAX_NAME)continue;entries.add(new Entry(score,time,n)); }
            in.close(); sortAndTrim();
        } catch (IOException | RuntimeException ex) { entries.clear(); }
    }
    private void sortAndTrim() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score-a.score; } }); while(entries.size()>MAX_ENTRIES) entries.remove(entries.size()-1); }
    private static final class Entry { final int score,time; final String name; Entry(int s,int t,String n){score=s;time=t;name=n;} }
}