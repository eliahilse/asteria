package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscoreView extends ApoMarioModel {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioPanel game, ApoMarioHighscore highscore) { super(game); this.highscore = highscore; }
    public void init() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE || button == KeyEvent.VK_ENTER) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 20, 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames(); List<Integer> scores = highscore.getPlayersScores(); List<Integer> times = highscore.getSurvivalTimes();
        int y = 65;
        for (int i = 0; i < names.size() && i < 12; i++) {
            int seconds = times.get(i) / 1000; String time = (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 25, y); g.drawString(String.valueOf(scores.get(i)), 190, y); g.drawString(time, 260, y); y += 18;
        }
        g.drawString("ESC / ENTER: back", 20, ApoMarioConstants.GAME_HEIGHT - 15);
    }
}