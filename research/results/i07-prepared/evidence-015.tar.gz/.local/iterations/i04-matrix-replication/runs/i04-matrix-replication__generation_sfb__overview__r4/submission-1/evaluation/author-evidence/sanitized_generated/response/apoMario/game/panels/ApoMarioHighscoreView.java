package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used directly by the main menu. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore scores, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 65, height / 10 + 30);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
        List<String> n = scores.getPlayersNames();
        List<Integer> p = scores.getPlayersScores();
        List<Integer> t = scores.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 12; i++) {
            int ms = t.get(i).intValue();
            int sec = ms / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(sec / 60), Integer.valueOf(sec % 60));
            g.drawString(String.valueOf(i + 1), width / 6, height / 10 + 65 + i * 22);
            g.drawString(n.get(i), width / 6 + 28, height / 10 + 65 + i * 22);
            g.drawString(String.valueOf(p.get(i)), width / 2, height / 10 + 65 + i * 22);
            g.drawString(time, width * 2 / 3, height / 10 + 65 + i * 22);
        }
        g.drawString("Press H or Escape to return", width / 2 - 90, height * 9 / 10 - 8);
    }
}