package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private final Set<ApoMarioLevel> recordedLevels = Collections.newSetFromMap(new IdentityHashMap<ApoMarioLevel, Boolean>());

    private static final class Entry {
        private final int score;
        private final int time;
        private final String name;
        private Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || survivalTime < 0) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return false;
        entries.add(new Entry(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            out.writeInt(VERSION); out.writeInt(entries.size());
            for (Entry e : entries) { out.writeInt(e.score); out.writeInt(e.time); out.writeUTF(e.name); }
            out.close();
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level)) return;
        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty() || players.get(0) == null) return;
        ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName(); if (name == null || name.trim().length() == 0) name = "Player";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) recordedLevels.add(level);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt(); if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                int score = in.readInt(); int time = in.readInt(); String name = in.readUTF();
                if (time >= 0 && name.length() > 0 && name.length() <= MAX_NAME_LENGTH) entries.add(new Entry(score, time, name));
            }
            in.close(); sortAndTrim();
        } catch (IOException ex) { entries.clear(); }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score < b.score ? 1 : (a.score == b.score ? 0 : -1); } });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
}