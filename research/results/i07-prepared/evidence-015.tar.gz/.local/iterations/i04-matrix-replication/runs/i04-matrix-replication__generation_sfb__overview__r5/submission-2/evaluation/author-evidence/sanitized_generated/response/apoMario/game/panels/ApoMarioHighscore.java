package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-descending highscore table. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int last = names.size() - 1;
            names.remove(last);
            scores.remove(last);
            survivalTimes.remove(last);
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the finished participant(s), after the level has applied its final score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        int elapsed = Math.max(0, level.getPassedTime());
        // A run is one board entry. Player one is the authoritative participant
        // for the single-player highscore, including runs with an optional
        // second player or AI opponent.
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player != null) {
            String name = player.getTeamName();
            if (name == null || name.trim().length() == 0) {
                name = "Human";
            }
            storeRun(player.getPoints(), elapsed, name);
        }
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(names));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(scores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try {
                for (int i = 0; i < names.size(); i++) {
                    writer.write(encode(names.get(i)));
                    writer.write('\t');
                    writer.write(String.valueOf(scores.get(i)));
                    writer.write('\t');
                    writer.write(String.valueOf(survivalTimes.get(i)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
            try {
                Files.move(temp, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temp, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A failing store must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", -1);
                    if (parts.length != 3) continue;
                    try {
                        names.add(cleanName(decode(parts[0])));
                        scores.add(Integer.valueOf(parts[1]));
                        survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(parts[2]))));
                    } catch (RuntimeException ignored) {
                        // Ignore malformed records.
                    }
                }
            } finally {
                reader.close();
            }
            sort();
            while (names.size() > MAX_ENTRIES) {
                int i = names.size() - 1;
                names.remove(i); scores.remove(i); survivalTimes.remove(i);
            }
        } catch (IOException ignored) {
            // Treat an unreadable table as empty.
        }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    private static String cleanName(String value) {
        if (value == null) return "Unknown";
        String result = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) result = "Unknown";
        return result.length() > 32 ? result.substring(0, 32) : result;
    }
    private static String encode(String value) { return value.replace("%", "%25"); }
    private static String decode(String value) { return value.replace("%25", "%"); }
}