package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.level.ApoMarioLevel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Persistent, score-descending run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 40) name = name.substring(0, 40);
        if (survivalTime < 0) survivalTime = 0;
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(survivalTime));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int last = names.size() - 1;
            names.remove(last); scores.remove(last); survivalTimes.remove(last);
        }
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(names));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(scores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Records the first real player in a completed level. */
    public synchronized void recordRunEnd(apoMario.level.ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8);
                    int score = Integer.parseInt(p[1]);
                    int time = Integer.parseInt(p[2]);
                    if (name.length() > 0 && time >= 0) {
                        names.add(name.length() > 40 ? name.substring(0, 40) : name);
                        scores.add(Integer.valueOf(score));
                        survivalTimes.add(Integer.valueOf(time));
                    }
                } catch (IllegalArgumentException ignored) { }
            }
            sort();
            while (names.size() > MAX_ENTRIES) {
                int last = names.size() - 1;
                names.remove(last); scores.remove(last); survivalTimes.remove(last);
            }
        } catch (IOException ignored) { }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
                for (int i = 0; i < names.size(); i++) {
                    writer.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t'); writer.write(String.valueOf(scores.get(i)));
                    writer.write('\t'); writer.write(String.valueOf(survivalTimes.get(i))); writer.newLine();
                }
            }
            return true;
        } catch (IOException ignored) { return false; }
    }
}