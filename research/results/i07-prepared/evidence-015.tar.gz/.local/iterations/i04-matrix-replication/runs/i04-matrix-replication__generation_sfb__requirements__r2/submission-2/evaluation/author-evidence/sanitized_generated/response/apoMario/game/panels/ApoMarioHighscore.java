package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private boolean recorded;

    private static final class Run {
        final String name; final int score; final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = clean(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (recorded || level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int time = level.getPassedTime();
        if (time < 0) time = 0;
        if (storeRun(player.getPoints(), time, name)) recorded = true;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temp = null;
        try {
            Path absolute = store.toAbsolutePath();
            if (absolute.getParent() != null) Files.createDirectories(absolute.getParent());
            temp = Paths.get(store.toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) writer.write(escape(run.name) + "\t" + run.score + "\t" + run.time + "\n");
            } finally { writer.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { } }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = reader.readLine()) != null && count++ < MAX_ENTRIES) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3) continue;
                    try {
                        String name = clean(unescape(fields[0]));
                        int score = Integer.parseInt(fields[1]);
                        int time = Integer.parseInt(fields[2]);
                        if (name != null && time >= 0) runs.add(new Run(name, score, time));
                    } catch (RuntimeException ignored) { }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); } });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
    private static String clean(String value) {
        if (value == null) return null;
        String result = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return result.length() == 0 || result.length() > MAX_NAME_LENGTH ? null : result;
    }
    private static String escape(String value) { return value.replace("\\", "\\\\").replace("\t", "\\t"); }
    private static String unescape(String value) { return value.replace("\\t", "\t").replace("\\\\", "\\"); }

    public synchronized void render(Graphics2D g, int x, int y) {
        g.drawString("HIGHSCORES", x, y);
        for (int i = 0; i < runs.size(); i++) {
            Run run = runs.get(i);
            int seconds = run.time / 1000;
            g.drawString((i + 1) + ". " + run.name + "  " + run.score + "  " + (seconds / 60) + ":" + String.format("%02d", seconds % 60), x, y + (i + 1) * 20);
        }
    }
}