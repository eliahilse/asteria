package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, persistent highscore table and its small menu view. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score == a.score ? a.name.compareTo(b.name) : (b.score < a.score ? -1 : 1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        persistAcrossRuns();
        return true;
    }

    /** Records the finalized human player's result, after level scoring has run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) {
                String name = player.getTeamName();
                if (name == null || name.trim().length() == 0) name = "Player";
                storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
                return;
            }
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (Run r : runs) w.write(r.score + "\t" + r.time + "\t" + r.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " ")); w.newLine();
            } finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed save must not stop the game. */ }
    }

    private synchronized void load() {
        runs.clear();
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = r.readLine()) != null && count++ < MAX_RECORDS) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]);
                        String name = cleanName(p[2]);
                        if (score >= 0 && time >= 0 && name != null) runs.add(new Run(score, time, name));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { r.close(); }
            Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score == a.score ? a.name.compareTo(b.name) : (b.score < a.score ? -1 : 1); } });
        } catch (IOException ex) { runs.clear(); }
    }

    private static String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim(); if (s.length() == 0 || s.length() > MAX_NAME) return null;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return null;
        return s;
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> n = getPlayersNames(); List<Integer> s = getPlayersScores(); List<Integer> t = getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 15; i++) {
            int y = 90 + i * 25;
            g.drawString(String.valueOf(i + 1), 35, y); g.drawString(n.get(i), 75, y);
            g.drawString(String.valueOf(s.get(i)), width - 170, y);
            g.drawString(formatTime(t.get(i)), width - 80, y);
        }
        g.drawString("ESC: back", 20, height - 20);
    }

    public static String formatTime(int milliseconds) {
        long seconds = Math.max(0, milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}