package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

/** Marker type for the dedicated highscore menu view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
}