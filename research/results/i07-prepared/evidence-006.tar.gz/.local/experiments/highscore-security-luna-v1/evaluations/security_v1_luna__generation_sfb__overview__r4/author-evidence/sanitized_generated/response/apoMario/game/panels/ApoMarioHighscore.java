package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private static final int MAX_FILE_LINES = 1000;

    private final Path store;
    private final ArrayList<Entry> entries;
    private final Map<ApoMarioLevel, Boolean> recordedLevels;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.recordedLevels = new IdentityHashMap<ApoMarioLevel, Boolean>();
        this.setBackground(Color.WHITE);
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        entries.add(new Entry(name, score, survivalTime));
        sortEntries();

        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }

        persistAcrossRuns();
        repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) {
            result.add(Integer.valueOf(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add("APOMARIO_HIGHSCORE_1");

            for (Entry entry : entries) {
                String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);

            try {
                Files.move(temporary, store, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.containsKey(level)) {
            return;
        }

        ArrayList<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.size() == 0 || players.get(0) == null) {
            return;
        }

        ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int survivalTime = level.getPassedTime();
        if (survivalTime > 0) {
            survivalTime /= 1000;
        } else {
            survivalTime = 0;
        }

        recordedLevels.put(level, Boolean.TRUE);
        storeRun(player.getPoints(), survivalTime, name);
    }

    public synchronized void clearScores() {
        entries.clear();
        persistAcrossRuns();
        repaint();
    }

    public synchronized String formatSurvivalTime(int seconds) {
        if (seconds < 0) {
            seconds = 0;
        }

        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes),
                Integer.valueOf(remainingSeconds));
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            int width = getWidth();
            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
            g.drawString("Highscore", 20, 30);

            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("Player", 20, 58);
            g.drawString("Points", Math.max(150, width / 2), 58);
            g.drawString("Time", Math.max(250, width * 3 / 4), 58);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            int y = 82;
            for (Entry entry : entries) {
                g.drawString(entry.name, 20, y);
                g.drawString(String.valueOf(entry.score), Math.max(150, width / 2), y);
                g.drawString(formatSurvivalTime(entry.survivalTime),
                        Math.max(250, width * 3 / 4), y);
                y += 22;
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        entries.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.size() == 0 || !"APOMARIO_HIGHSCORE_1".equals(lines.get(0))
                    || lines.size() > MAX_FILE_LINES) {
                return;
            }

            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                String[] parts = line.split("\t", -1);
                if (parts.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore record");
                }

                String name = new String(Base64.getDecoder().decode(parts[0]),
                        StandardCharsets.UTF_8);
                name = normalizeName(name);

                int score = Integer.parseInt(parts[1]);
                int survivalTime = Integer.parseInt(parts[2]);

                if (name.length() == 0 || score < 0 || survivalTime < 0) {
                    throw new IllegalArgumentException("Invalid highscore values");
                }

                entries.add(new Entry(name, score, survivalTime));
                if (entries.size() >= MAX_ENTRIES) {
                    break;
                }
            }

            sortEntries();
        } catch (Exception ex) {
            entries.clear();
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                if (first.score != second.score) {
                    return first.score < second.score ? 1 : -1;
                }
                return 0;
            }
        });
    }

    private String normalizeName(String value) {
        if (value == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = trimmed.charAt(i);
            if (character != '\r' && character != '\n' && character != '\t'
                    && !Character.isISOControl(character)) {
                result.append(character);
            }
        }

        return result.toString();
    }

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}