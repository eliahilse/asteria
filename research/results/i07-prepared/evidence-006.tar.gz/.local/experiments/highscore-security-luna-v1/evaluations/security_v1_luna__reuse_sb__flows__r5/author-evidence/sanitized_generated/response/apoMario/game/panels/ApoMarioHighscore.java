package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_ENTRIES = 1000;
	private static final int MAX_NAME_LENGTH = 128;

	private static final class Run {
		private final String name;
		private final int score;
		private final int survivalTime;

		private Run(String name, int score, int survivalTime) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
		}
	}

	private final Path store;
	private final ArrayList<Run> runs;
	private final Map<ApoMarioLevel, Boolean> recordedLevels;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store must not be null");
		}
		this.store = store;
		this.runs = new ArrayList<Run>();
		this.recordedLevels = new IdentityHashMap<ApoMarioLevel, Boolean>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		if (name.length() == 0) {
			name = "Player";
		}
		if (score < Integer.MIN_VALUE || survivalTime < 0) {
			return false;
		}

		this.runs.add(new Run(name, score, survivalTime));
		this.sortRuns();
		while (this.runs.size() > MAX_ENTRIES) {
			this.runs.remove(this.runs.size() - 1);
		}
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		ArrayList<String> result = new ArrayList<String>();
		for (Run run : this.runs) {
			result.add(run.name);
		}
		return result;
	}

	public synchronized List<Integer> getPlayersScores() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Run run : this.runs) {
			result.add(run.score);
		}
		return result;
	}

	public synchronized List<Integer> getSurvivalTimes() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Run run : this.runs) {
			result.add(run.survivalTime);
		}
		return result;
	}

	public synchronized void persistAcrossRuns() {
		Path parent = this.store.getParent();
		try {
			if (parent != null) {
				Files.createDirectories(parent);
			}
			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(
					temporary,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE)) {
				for (Run run : this.runs) {
					writer.write(Integer.toString(run.score));
					writer.newLine();
					writer.write(Integer.toString(run.survivalTime));
					writer.newLine();
					writer.write(run.name);
					writer.newLine();
				}
			}
			try {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING,
						java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || this.recordedLevels.containsKey(level)) {
			return;
		}

		List<ApoMarioPlayer> players = level.getPlayers();
		if (players == null || players.isEmpty() || players.get(0) == null) {
			return;
		}

		ApoMarioPlayer player = players.get(0);
		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = player.getAuthor();
		}

		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.recordedLevels.put(level, Boolean.TRUE);
		this.storeRun(player.getPoints(), survivalTime, name);
	}

	public synchronized String getFormattedSurvivalTime(int index) {
		if (index < 0 || index >= this.runs.size()) {
			return "00:00";
		}
		return formatTime(this.runs.get(index).survivalTime);
	}

	public static String formatTime(int milliseconds) {
		if (milliseconds < 0) {
			milliseconds = 0;
		}
		long totalSeconds = milliseconds / 1000L;
		long minutes = totalSeconds / 60L;
		long seconds = totalSeconds % 60L;
		return String.format("%02d:%02d", minutes, seconds);
	}

	private void load() {
		if (!Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			while (this.runs.size() < MAX_ENTRIES) {
				String scoreLine = reader.readLine();
				String timeLine = reader.readLine();
				String nameLine = reader.readLine();
				if (scoreLine == null || timeLine == null || nameLine == null) {
					break;
				}

				try {
					int score = Integer.parseInt(scoreLine.trim());
					int survivalTime = Integer.parseInt(timeLine.trim());
					if (survivalTime < 0) {
						continue;
					}
					String name = normalizeName(nameLine);
					if (name.length() == 0) {
						name = "Player";
					}
					this.runs.add(new Run(name, score, survivalTime));
				} catch (NumberFormatException ignored) {
				}
			}
			this.sortRuns();
		} catch (IOException ex) {
			this.runs.clear();
		}
	}

	private void sortRuns() {
		Collections.sort(this.runs, new Comparator<Run>() {
			@Override
			public int compare(Run first, Run second) {
				int score = Integer.compare(second.score, first.score);
				if (score != 0) {
					return score;
				}
				return Integer.compare(first.survivalTime, second.survivalTime);
			}
		});
	}

	private static String normalizeName(String name) {
		if (name == null) {
			return "";
		}
		StringBuilder result = new StringBuilder();
		for (int i = 0; i < name.length() && result.length() < MAX_NAME_LENGTH; i++) {
			char character = name.charAt(i);
			if (character != '\n' && character != '\r') {
				result.append(character);
			}
		}
		return result.toString().trim();
	}
}