package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APO_MARIO_HIGHSCORE_1";

    private final Path store;
    private final List<String> playersNames;
    private final List<Integer> playersScores;
    private final List<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(this.playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(this.playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(this.survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                writer.write(HEADER);
                writer.newLine();

                for (int i = 0; i < this.playersNames.size(); i++) {
                    writer.write(Integer.toString(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(
                        this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = this.getScoringPlayer(level);
        if (player == null) {
            return;
        }

        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int survivalTime = level.getStartTime() - level.getTime();
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.storeRun(player.getPoints(), survivalTime, name);
    }

    public synchronized String getSurvivalTimeString(int index) {
        if (index < 0 || index >= this.survivalTimes.size()) {
            return "00:00";
        }
        return formatSurvivalTime(this.survivalTimes.get(index).intValue());
    }

    public static String formatSurvivalTime(int milliseconds) {
        long totalSeconds = Math.max(0, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
    }

    public synchronized void clear() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();
        this.persistAcrossRuns();
    }

    private ApoMarioPlayer getScoringPlayer(ApoMarioLevel level) {
        ApoMarioPlayer result = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (result == null || player.getPoints() > result.getPoints()) {
                result = player;
            }
        }

        return result;
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            BufferedReader reader = Files.newBufferedReader(
                    this.store,
                    StandardCharsets.UTF_8);

            try {
                String header = reader.readLine();
                if (!HEADER.equals(header)) {
                    this.clearInMemory();
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null) {
                    String[] values = line.split("\\t", -1);
                    if (values.length != 3) {
                        throw new IOException("Invalid highscore entry");
                    }

                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);

                    if (name.trim().length() == 0) {
                        name = "Player";
                    }

                    this.playersScores.add(Integer.valueOf(score));
                    this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
                    this.playersNames.add(name);
                }
            } finally {
                reader.close();
            }

            this.sort();
        } catch (Exception ex) {
            this.clearInMemory();
        }
    }

    private void clearInMemory() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreCompare = Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());

                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                return Integer.compare(
                        survivalTimes.get(first.intValue()).intValue(),
                        survivalTimes.get(second.intValue()).intValue());
            }
        });

        List<String> sortedNames = new ArrayList<String>();
        List<Integer> sortedScores = new ArrayList<Integer>();
        List<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            sortedNames.add(this.playersNames.get(i));
            sortedScores.add(this.playersScores.get(i));
            sortedTimes.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }
}