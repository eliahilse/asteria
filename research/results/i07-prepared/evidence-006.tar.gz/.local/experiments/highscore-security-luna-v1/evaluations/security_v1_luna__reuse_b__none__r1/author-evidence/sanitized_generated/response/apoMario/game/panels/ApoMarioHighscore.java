package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String SEPARATOR = "\t";

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.indexOf('\t') >= 0) {
			name = name.replace('\t', ' ');
		}
		if (name.indexOf('\n') >= 0) {
			name = name.replace('\n', ' ');
		}
		if (name.indexOf('\r') >= 0) {
			name = name.replace('\r', ' ');
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}
		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			ArrayList<String> lines = new ArrayList<String>();
			for (int i = 0; i < this.playersNames.size(); i++) {
				lines.add(this.playersScores.get(i) + SEPARATOR
						+ this.survivalTimes.get(i) + SEPARATOR
						+ this.playersNames.get(i));
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			Files.write(temporary, lines, StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE);
			try {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (Exception ex) {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (Exception ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(this.store.getFileName().toString() + ".tmp"));
			} catch (Exception ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int score = player.getPoints();
		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.storeRun(score, survivalTime, name);
		this.persistAcrossRuns();
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.exists(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			for (String line : lines) {
				String[] values = line.split(SEPARATOR, 3);
				if (values.length != 3) {
					continue;
				}
				int score = Integer.parseInt(values[0]);
				int time = Integer.parseInt(values[1]);
				this.playersScores.add(Integer.valueOf(score));
				this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
				this.playersNames.add(values[2]);
			}
			this.sort();
		} catch (Exception ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int result = Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()),
						ApoMarioHighscore.this.playersScores.get(first.intValue()));
				if (result != 0) {
					return result;
				}
				return Integer.compare(first.intValue(), second.intValue());
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : order) {
			sortedNames.add(this.playersNames.get(index.intValue()));
			sortedScores.add(this.playersScores.get(index.intValue()));
			sortedTimes.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.clear();
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(sortedTimes);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, this.getWidth(), this.getHeight());

		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("Dialog", Font.BOLD, 22));
		graphics.drawString("Highscore", 20, 32);

		graphics.setFont(new Font("Dialog", Font.BOLD, 14));
		graphics.drawString("Name", 30, 62);
		graphics.drawString("Points", 250, 62);
		graphics.drawString("Time", 350, 62);

		graphics.setFont(new Font("Dialog", Font.PLAIN, 14));
		for (int i = 0; i < this.playersNames.size(); i++) {
			int y = 88 + i * 24;
			graphics.drawString((i + 1) + ". " + this.playersNames.get(i), 30, y);
			graphics.drawString(String.valueOf(this.playersScores.get(i)), 250, y);
			graphics.drawString(formatTime(this.survivalTimes.get(i).intValue()), 350, y);
		}
	}

	private static String formatTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}
}