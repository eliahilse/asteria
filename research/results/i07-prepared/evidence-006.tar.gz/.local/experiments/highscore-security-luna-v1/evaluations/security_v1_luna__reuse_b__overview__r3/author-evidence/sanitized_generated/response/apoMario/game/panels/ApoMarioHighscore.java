package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        String name = playerName;
        if (name == null) {
            name = DEFAULT_PLAYER_NAME;
        }
        name = name.trim();
        if (name.length() == 0) {
            name = DEFAULT_PLAYER_NAME;
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(survivalTime));
        this.sort();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                for (int i = 0; i < this.playersScores.size(); i++) {
                    writer.write(Integer.toString(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(encode(this.playersNames.get(i)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(this.store.resolveSibling(this.store.getFileName().toString() + ".tmp"));
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().size() == 0) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = level.getStartTime() - level.getTime();
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        String playerName = player.getTeamName();
        this.storeRun(score, survivalTime, playerName);
        this.persistAcrossRuns();
    }

    public static String formatSurvivalTime(int survivalTime) {
        long seconds = survivalTime / 1000L;
        long minutes = seconds / 60L;
        long remainingSeconds = seconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(remainingSeconds));
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] values = line.split("\t", -1);
                    if (values.length != 3) {
                        continue;
                    }

                    try {
                        int score = Integer.parseInt(values[0]);
                        int survivalTime = Integer.parseInt(values[1]);
                        String name = decode(values[2]);

                        if (score >= 0 && survivalTime >= 0 && name.length() > 0) {
                            this.playersScores.add(Integer.valueOf(score));
                            this.survivalTimes.add(Integer.valueOf(survivalTime));
                            this.playersNames.add(name);
                        }
                    } catch (NumberFormatException ex) {
                    }
                }
            } finally {
                reader.close();
            }
            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indices = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            indices.add(Integer.valueOf(i));
        }

        Collections.sort(indices, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int result = Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());
                if (result != 0) {
                    return result;
                }
                return Integer.compare(first.intValue(), second.intValue());
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : indices) {
            int i = index.intValue();
            names.add(this.playersNames.get(i));
            scores.add(this.playersScores.get(i));
            times.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(names);
        this.playersScores.clear();
        this.playersScores.addAll(scores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(times);
    }

    private static String encode(String value) {
        return value.replace("\\", "\\\\")
                .replace("\t", "\\t")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }

    private static String decode(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == 'r') {
                    result.append('\r');
                } else if (character == 'n') {
                    result.append('\n');
                } else {
                    result.append(character);
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }
        return result.toString();
    }
}