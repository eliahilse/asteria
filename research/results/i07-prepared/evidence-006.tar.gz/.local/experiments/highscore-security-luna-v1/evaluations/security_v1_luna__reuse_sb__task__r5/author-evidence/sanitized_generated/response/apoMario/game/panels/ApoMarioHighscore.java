package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }

        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sortEntries();

        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (int i = 0; i < this.playersNames.size(); i++) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));

                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(Integer.toString(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }

            if (selectedPlayer == null
                    || player.getPoints() > selectedPlayer.getPoints()) {
                selectedPlayer = player;
            }
        }

        if (selectedPlayer == null) {
            return;
        }

        String playerName = selectedPlayer.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = selectedPlayer.getAuthor();
        }
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        this.storeRun(
                selectedPlayer.getPoints(),
                level.getPassedTime(),
                playerName);
        this.persistAcrossRuns();
    }

    public static String formatSurvivalTime(int survivalTime) {
        long totalSeconds = Math.max(0L, survivalTime) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    String name = new String(
                            Base64.getDecoder().decode(values[0]),
                            StandardCharsets.UTF_8);
                    int score = Integer.parseInt(values[1]);
                    int survivalTime = Integer.parseInt(values[2]);

                    if (name.trim().length() == 0) {
                        name = "Player";
                    }

                    this.playersNames.add(name);
                    this.playersScores.add(Integer.valueOf(score));
                    this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
                } catch (IllegalArgumentException ex) {
                    this.playersNames.clear();
                    this.playersScores.clear();
                    this.survivalTimes.clear();
                    return;
                }
            }

            this.sortEntries();

            while (this.playersNames.size() > MAX_ENTRIES) {
                int last = this.playersNames.size() - 1;
                this.playersNames.remove(last);
                this.playersScores.remove(last);
                this.survivalTimes.remove(last);
            }
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sortEntries() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreCompare = Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());

                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                return Integer.compare(first.intValue(), second.intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            sortedNames.add(this.playersNames.get(i));
            sortedScores.add(this.playersScores.get(i));
            sortedTimes.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }
}