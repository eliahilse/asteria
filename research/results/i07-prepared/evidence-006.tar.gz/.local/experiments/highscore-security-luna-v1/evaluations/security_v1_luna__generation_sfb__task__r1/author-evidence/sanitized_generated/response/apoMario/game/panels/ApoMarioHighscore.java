package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        runs.add(new Run(name, score, time));
        sortAndLimit();
        return writeStore();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        writeStore();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = 0;
        try {
            survivalTime = Math.max(0, level.getPassedTime() / 1000);
        } catch (RuntimeException ignored) {
            survivalTime = 0;
        }

        storeRun(score, survivalTime, player.getTeamName());
    }

    private synchronized void load() {
        runs.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            if (Files.size(store) > 1024L * 1024L) {
                return;
            }

            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String header = reader.readLine();
                if (!HEADER.equals(header)) {
                    runs.clear();
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().isEmpty()) {
                        continue;
                    }

                    String[] values = line.split("\\t", -1);
                    if (values.length != 3) {
                        runs.clear();
                        return;
                    }

                    String name = new String(
                            Base64.getUrlDecoder().decode(values[0]),
                            StandardCharsets.UTF_8);
                    int score = Integer.parseInt(values[1]);
                    int survivalTime = Integer.parseInt(values[2]);

                    if (!isValidName(name) || survivalTime < 0) {
                        runs.clear();
                        return;
                    }

                    runs.add(new Run(name, score, survivalTime));
                    if (runs.size() > MAX_ENTRIES) {
                        runs.clear();
                        return;
                    }
                }
            } finally {
                reader.close();
            }

            sortAndLimit();
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private synchronized boolean writeStore() {
        if (store == null) {
            return false;
        }

        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            temporary = Files.createTempFile(
                    parent == null ? store.toAbsolutePath().getParent() : parent,
                    "apomario-highscore-", ".tmp");

            BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8);
            try {
                writer.write(HEADER);
                writer.newLine();

                for (Run run : runs) {
                    String encodedName = Base64.getUrlEncoder().withoutPadding()
                            .encodeToString(run.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(encodedName);
                    writer.write('\t');
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            return true;
        } catch (IOException ex) {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
            }
            return false;
        }
    }

    private void sortAndLimit() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreComparison = Integer.compare(second.score, first.score);
                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                int timeComparison = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeComparison != 0) {
                    return timeComparison;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });

        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }
    }

    private String normalizeName(String playerName) {
        if (playerName == null) {
            return "Human";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = playerName.trim();

        for (int i = 0; i < trimmed.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = trimmed.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        if (result.length() == 0) {
            return "Human";
        }

        return result.toString();
    }

    private boolean isValidName(String name) {
        return name != null
                && name.length() > 0
                && name.length() <= MAX_NAME_LENGTH
                && normalizeName(name).equals(name);
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}