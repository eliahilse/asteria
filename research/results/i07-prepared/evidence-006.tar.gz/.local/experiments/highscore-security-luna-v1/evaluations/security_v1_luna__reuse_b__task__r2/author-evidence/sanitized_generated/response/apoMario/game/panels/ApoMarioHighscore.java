package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 32) {
			name = name.substring(0, 32);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}
		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}
			try (BufferedWriter writer = Files.newBufferedWriter(
					this.store,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE)) {
				for (int i = 0; i < this.playersScores.size(); i++) {
					writer.write(Integer.toString(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
					writer.write('\t');
					writer.write(escape(this.playersNames.get(i)));
					writer.newLine();
				}
			}
		} catch (IOException ex) {
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int score = player.getPoints();
		int survivalTime = 0;
		try {
			survivalTime = level.getPassedTime();
		} catch (RuntimeException ex) {
			survivalTime = Math.max(0, level.getStartTime() - level.getTime());
		}

		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		this.storeRun(score, survivalTime, name);
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", 3);
				if (values.length != 3) {
					continue;
				}
				try {
					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					names.add(unescape(values[2]));
					scores.add(Integer.valueOf(score));
					times.add(Integer.valueOf(Math.max(0, time)));
				} catch (NumberFormatException ex) {
				}
			}
		} catch (IOException ex) {
			return;
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(names);
		this.playersScores.addAll(scores);
		this.survivalTimes.addAll(times);
		this.sort();
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(names);
		this.playersScores.addAll(scores);
		this.survivalTimes.addAll(times);
	}

	private static String escape(String value) {
		return value.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r");
	}

	private static String unescape(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;
		for (int i = 0; i < value.length(); i++) {
			char c = value.charAt(i);
			if (escaped) {
				if (c == 't') {
					result.append('\t');
				} else if (c == 'n') {
					result.append('\n');
				} else if (c == 'r') {
					result.append('\r');
				} else {
					result.append(c);
				}
				escaped = false;
			} else if (c == '\\') {
				escaped = true;
			} else {
				result.append(c);
			}
		}
		if (escaped) {
			result.append('\\');
		}
		return result.toString();
	}

	private static String formatTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, getWidth(), getHeight());

			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 26));
			g.drawString("Highscore", 24, 38);

			g.setFont(new Font("Dialog", Font.BOLD, 16));
			g.drawString("#", 28, 72);
			g.drawString("Name", 70, 72);
			g.drawString("Score", 300, 72);
			g.drawString("Time", 410, 72);

			g.setFont(new Font("Dialog", Font.PLAIN, 16));
			int y = 100;
			for (int i = 0; i < this.playersNames.size(); i++) {
				g.drawString(Integer.toString(i + 1), 28, y);
				g.drawString(this.playersNames.get(i), 70, y);
				g.drawString(Integer.toString(this.playersScores.get(i).intValue()), 300, y);
				g.drawString(formatTime(this.survivalTimes.get(i).intValue()), 410, y);
				y += 24;
			}
		} finally {
			g.dispose();
		}
	}
}