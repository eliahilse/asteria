package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_RECORDS = 1000;
    private static final int MAX_LINE_LENGTH = 8192;

    private final Path store;
    private final List<Run> runs;
    private final Map<ApoMarioLevel, Boolean> recordedLevels;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.recordedLevels = new IdentityHashMap<ApoMarioLevel, Boolean>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        if (name.length() > 256) {
            name = name.substring(0, 256);
        }

        this.runs.add(new Run(score, Math.max(0, survivalTime), name));
        this.sortRuns();
        while (this.runs.size() > MAX_RECORDS) {
            this.runs.remove(this.runs.size() - 1);
        }
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (Run run : this.runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || this.recordedLevels.containsKey(level)) {
            return;
        }

        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        int selectedIndex = 0;

        for (int i = 0; i < players.size(); i++) {
            ApoMarioPlayer player = players.get(i);
            if (player == null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
                selectedIndex = i;
            }
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            if (selected.getAi() != null && selected.getAi().getTeamName() != null) {
                name = selected.getAi().getTeamName();
            }
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player " + (selectedIndex + 1);
        }

        int survivalTime = level.getStartTime() - level.getTime();
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.storeRun(selected.getPoints(), survivalTime, name);
        this.recordedLevels.put(level, Boolean.TRUE);
        this.persistAcrossRuns();
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(254, 254, 254, 230));
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int rowY = y + 58;
        int rowHeight = 22;
        int visibleRows = Math.max(0, (height - 70) / rowHeight);

        for (int i = 0; i < this.runs.size() && i < visibleRows; i++) {
            Run run = this.runs.get(i);
            graphics.drawString(Integer.toString(i + 1), x + 18, rowY);
            graphics.drawString(run.name, x + 52, rowY);
            graphics.drawString(Integer.toString(run.score), x + width - 145, rowY);
            graphics.drawString(formatSurvivalTime(run.survivalTime), x + width - 78, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatSurvivalTime(int milliseconds) {
        long totalSeconds = Math.max(0, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        List<Run> loaded = new ArrayList<Run>();

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.length() > MAX_LINE_LENGTH) {
                    throw new IOException("Highscore record is too long");
                }

                String[] parts = line.split("\\t", -1);
                if (parts.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(parts[0]);
                int survivalTime = Integer.parseInt(parts[1]);
                if (survivalTime < 0) {
                    throw new IOException("Invalid survival time");
                }

                String name = new String(
                        Base64.getDecoder().decode(parts[2]),
                        StandardCharsets.UTF_8).trim();
                if (name.length() == 0 || name.length() > 256) {
                    throw new IOException("Invalid player name");
                }

                loaded.add(new Run(score, survivalTime, name));
                if (loaded.size() > MAX_RECORDS) {
                    throw new IOException("Too many highscore records");
                }
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            this.sortRuns();
        } catch (IOException | IllegalArgumentException ex) {
            this.runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}