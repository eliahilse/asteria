package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(survivalTime));
        this.sort();
        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer bestPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (bestPlayer == null || player.getPoints() > bestPlayer.getPoints()) {
                bestPlayer = player;
            }
        }

        if (bestPlayer == null) {
            return;
        }

        String name = bestPlayer.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = bestPlayer.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsed;
        try {
            elapsed = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsed = level.getStartTime() - level.getTime();
        }

        this.storeRun(bestPlayer.getPoints(), Math.max(0, elapsed), name);
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8)) {
                for (int i = 0; i < this.playersNames.size(); i++) {
                    writer.write(encode(this.playersNames.get(i)));
                    writer.write('\t');
                    writer.write(String.valueOf(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
                    writer.newLine();
                }
            }
        } catch (IOException ex) {
            // A failed write must not interrupt the running game.
        }
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        Object oldAntialiasing = graphics.getRenderingHint(
                RenderingHints.KEY_TEXT_ANTIALIASING);
        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));

        graphics.drawString("Highscore", 20, 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        graphics.drawString("#", 20, 58);
        graphics.drawString("Name", 50, 58);
        graphics.drawString("Points", 230, 58);
        graphics.drawString("Time", 320, 58);

        int y = 82;
        for (int i = 0; i < this.playersNames.size(); i++) {
            graphics.drawString(String.valueOf(i + 1), 20, y);
            graphics.drawString(this.playersNames.get(i), 50, y);
            graphics.drawString(String.valueOf(this.playersScores.get(i)), 230, y);
            graphics.drawString(formatSurvivalTime(this.survivalTimes.get(i)), 320, y);
            y += 22;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
        if (oldAntialiasing != null) {
            graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    oldAntialiasing);
        }
    }

    public static String formatSurvivalTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = seconds / 60L;
        long remainingSeconds = seconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes),
                Long.valueOf(remainingSeconds));
    }

    private synchronized void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    String name = decode(values[0]);
                    int score = Integer.parseInt(values[1]);
                    int time = Integer.parseInt(values[2]);
                    if (name.length() == 0 || score < 0 || time < 0) {
                        continue;
                    }
                    this.playersNames.add(name);
                    this.playersScores.add(Integer.valueOf(score));
                    this.survivalTimes.add(Integer.valueOf(time));
                } catch (NumberFormatException ex) {
                    // Ignore malformed records and retain valid records.
                }
            }
            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreCompare = Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());
                if (scoreCompare != 0) {
                    return scoreCompare;
                }
                return Integer.compare(first.intValue(), second.intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int value = index.intValue();
            sortedNames.add(this.playersNames.get(value));
            sortedScores.add(this.playersScores.get(value));
            sortedTimes.add(this.survivalTimes.get(value));
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.addAll(sortedTimes);
    }

    private static String encode(String value) {
        return value.replace("\\", "\\\\")
                .replace("\t", "\\t")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }

    private static String decode(String value) {
        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            if (escaped) {
                if (character == 't') {
                    result.append('\t');
                } else if (character == 'r') {
                    result.append('\r');
                } else if (character == 'n') {
                    result.append('\n');
                } else {
                    result.append(character);
                }
                escaped = false;
            } else if (character == '\\') {
                escaped = true;
            } else {
                result.append(character);
            }
        }

        if (escaped) {
            result.append('\\');
        }
        return result.toString();
    }
}