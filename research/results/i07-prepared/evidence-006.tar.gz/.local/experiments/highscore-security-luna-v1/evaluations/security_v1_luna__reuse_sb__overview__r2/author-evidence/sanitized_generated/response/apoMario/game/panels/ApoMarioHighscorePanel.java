package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;
import apoMario.game.panels.ApoMarioModelMenu;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.nio.file.Path;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscorePanel extends ApoMarioModelMenu {

	public static final String FUNCTION_HIGHSCORE_BACK = "backHighscore";

	private final ApoMarioHighscore highscore;

	public ApoMarioHighscorePanel(ApoMarioPanel game, Path store) {
		super(game);
		this.highscore = new ApoMarioHighscore(store);
	}

	public ApoMarioHighscore getHighscore() {
		return this.highscore;
	}

	@Override
	public void init() {
		super.init();
	}

	@Override
	public void makeBackground() {
		this.setIBackground(this.getGame().getBackgroundImage());
	}

	@Override
	public void makeBackgroundAnimation() {
	}

	@Override
	public void makeRunner() {
	}

	@Override
	public void makeSearch() {
	}

	@Override
	public void keyButtonReleased(int button, char character) {
		if (button == KeyEvent.VK_ESCAPE) {
			this.getGame().setMenu();
		}
	}

	@Override
	public void mouseButtonFunction(String function) {
		if (FUNCTION_HIGHSCORE_BACK.equals(function)) {
			this.getGame().setMenu();
		}
	}

	@Override
	public void releasedEnter() {
		this.getGame().setMenu();
	}

	@Override
	public void excecuteFunction() {
	}

	@Override
	public void mouseButtonReleased(int x, int y) {
	}

	@Override
	public boolean mouseMoved(int x, int y) {
		return false;
	}

	@Override
	public boolean mouseDragged(int x, int y) {
		return false;
	}

	@Override
	public boolean mousePressed(int x, int y, boolean bRight) {
		return false;
	}

	@Override
	public void think(int delta) {
	}

	@Override
	public void render(Graphics2D g) {
		if (this.getIBackground() != null) {
			g.drawImage(this.getIBackground(), 0, 0, null);
		}

		g.setColor(Color.BLACK);
		g.setFont(ApoMarioConstants.FONT_MENU);

		String title = "Highscore";
		int titleWidth = g.getFontMetrics().stringWidth(title);
		g.drawString(title,
				ApoMarioConstants.GAME_WIDTH / 2 - titleWidth / 2,
				35);

		List<String> names = this.highscore.getPlayersNames();
		List<Integer> scores = this.highscore.getPlayersScores();
		List<Integer> times = this.highscore.getSurvivalTimes();

		g.setFont(ApoMarioConstants.FONT_STATISTICS);
		for (int i = 0; i < names.size(); i++) {
			int y = 65 + i * 18;
			int seconds = times.get(i).intValue() / 1000;
			int minutes = seconds / 60;
			seconds %= 60;

			String time = String.format("%02d:%02d", Integer.valueOf(minutes),
					Integer.valueOf(seconds));

			g.drawString(String.valueOf(i + 1), 25, y);
			g.drawString(names.get(i), 55, y);
			g.drawString(String.valueOf(scores.get(i)), 190, y);
			g.drawString(time, 255, y);
		}
	}
}