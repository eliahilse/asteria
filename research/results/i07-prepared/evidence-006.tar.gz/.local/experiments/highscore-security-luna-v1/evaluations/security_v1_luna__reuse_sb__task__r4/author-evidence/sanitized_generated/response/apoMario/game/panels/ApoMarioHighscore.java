package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int FILE_MAGIC = 0x41504D48;
    private static final int FILE_VERSION = 1;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store == null ? Paths.get("apoMario-highscores.dat") : store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        DataOutputStream output = null;
        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            output = new DataOutputStream(Files.newOutputStream(temporary));
            output.writeInt(FILE_MAGIC);
            output.writeInt(FILE_VERSION);
            output.writeInt(this.playersNames.size());

            for (int i = 0; i < this.playersNames.size(); i++) {
                output.writeUTF(this.playersNames.get(i));
                output.writeInt(this.playersScores.get(i).intValue());
                output.writeInt(this.survivalTimes.get(i).intValue());
            }
            output.flush();
            output.close();
            output = null;

            try {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (output != null) {
                try {
                    output.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            if (selected.getAi() != null && selected.getAi().getTeamName() != null) {
                name = selected.getAi().getTeamName();
            } else {
                name = "Player";
            }
        }

        int elapsed = level.getStartTime() - level.getTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        this.storeRun(selected.getPoints(), elapsed, name);
    }

    public synchronized String formatSurvivalTime(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        DataInputStream input = null;
        try {
            input = new DataInputStream(Files.newInputStream(this.store));
            int magic = input.readInt();
            int version = input.readInt();
            int count = input.readInt();

            if (magic != FILE_MAGIC || version != FILE_VERSION || count < 0 || count > 100000) {
                this.clear();
                return;
            }

            for (int i = 0; i < count; i++) {
                String name = input.readUTF();
                int score = input.readInt();
                int survivalTime = input.readInt();
                this.playersNames.add(name);
                this.playersScores.add(Integer.valueOf(score));
                this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
            }
            this.sort();
        } catch (EOFException ex) {
            this.clear();
        } catch (IOException | RuntimeException ex) {
            this.clear();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private void clear() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();
    }

    private void sort() {
        ArrayList<Integer> indices = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            indices.add(Integer.valueOf(i));
        }

        Collections.sort(indices, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : indices) {
            int position = index.intValue();
            sortedNames.add(this.playersNames.get(position));
            sortedScores.add(this.playersScores.get(position));
            sortedTimes.add(this.survivalTimes.get(position));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }
}