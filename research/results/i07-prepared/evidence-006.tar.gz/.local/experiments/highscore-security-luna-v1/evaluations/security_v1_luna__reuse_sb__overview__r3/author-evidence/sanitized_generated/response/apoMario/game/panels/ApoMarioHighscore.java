package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int VERSION = 1;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        return this.write();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        this.write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selectedPlayer == null || player.getPoints() > selectedPlayer.getPoints()) {
                selectedPlayer = player;
            }
        }

        if (selectedPlayer == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selectedPlayer == null || player.getPoints() > selectedPlayer.getPoints()) {
                        selectedPlayer = player;
                    }
                }
            }
        }

        if (selectedPlayer == null) {
            return;
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException exception) {
            survivalTime = Math.max(0, level.getStartTime() - level.getTime());
        }

        String name = selectedPlayer.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        this.storeRun(selectedPlayer.getPoints(), survivalTime, name);
    }

    public static String formatSurvivalTime(int survivalTime) {
        long seconds = Math.max(0L, survivalTime);
        if (seconds > 360000L) {
            seconds /= 1000L;
        }
        long minutes = seconds / 60L;
        long remainder = seconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(remainder));
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int score = Integer.compare(
                        ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
                        ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
                return score != 0 ? score : Integer.compare(first.intValue(), second.intValue());
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            names.add(this.playersNames.get(i));
            scores.add(this.playersScores.get(i));
            times.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(names);
        this.playersScores.clear();
        this.playersScores.addAll(scores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(times);
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try {
            DataInputStream input = new DataInputStream(
                    new BufferedInputStream(Files.newInputStream(this.store)));

            int version = input.readInt();
            if (version != VERSION) {
                input.close();
                return;
            }

            int count = input.readInt();
            if (count < 0 || count > 100000) {
                input.close();
                return;
            }

            for (int i = 0; i < count; i++) {
                this.playersNames.add(input.readUTF());
                this.playersScores.add(Integer.valueOf(input.readInt()));
                this.survivalTimes.add(Integer.valueOf(input.readInt()));
            }

            input.close();
            this.sort();
        } catch (EOFException exception) {
            this.clear();
        } catch (IOException exception) {
            this.clear();
        } catch (RuntimeException exception) {
            this.clear();
        }
    }

    private boolean write() {
        Path parent = this.store.getParent();
        Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            DataOutputStream output = new DataOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(temporary)));

            output.writeInt(VERSION);
            output.writeInt(this.playersNames.size());

            for (int i = 0; i < this.playersNames.size(); i++) {
                output.writeUTF(this.playersNames.get(i));
                output.writeInt(this.playersScores.get(i).intValue());
                output.writeInt(this.survivalTimes.get(i).intValue());
            }

            output.flush();
            output.close();

            try {
                Files.move(temporary, this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
            }

            return true;
        } catch (IOException exception) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
            return false;
        }
    }

    private void clear() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();
    }
}