package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String SEPARATOR = "\t";
	private static final int DEFAULT_WIDTH = 640;
	private static final int DEFAULT_HEIGHT = 480;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;
	private final Map<ApoMarioLevel, String> recordedRuns;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.recordedRuns = new IdentityHashMap<ApoMarioLevel, String>();
		this.setBackground(Color.WHITE);
		this.setPreferredSize(new java.awt.Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sort();
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			ArrayList<String> lines = new ArrayList<String>();
			for (int i = 0; i < this.playersNames.size(); i++) {
				String name = this.playersNames.get(i)
						.replace("\\", "\\\\")
						.replace("\t", "\\t")
						.replace("\n", "\\n")
						.replace("\r", "\\r");
				lines.add(this.playersScores.get(i) + SEPARATOR
						+ this.survivalTimes.get(i) + SEPARATOR + name);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName() + ".tmp");
			Files.write(temporary, lines, StandardCharsets.UTF_8);
			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			// A failed write must not interrupt the game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int score = Math.max(0, player.getPoints());
		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		String playerName = player.getTeamName();
		if (playerName == null || playerName.trim().length() == 0) {
			playerName = "Player";
		}

		String signature = score + ":" + survivalTime + ":" + playerName;
		String previous = this.recordedRuns.get(level);
		if (signature.equals(previous)) {
			return;
		}

		this.recordedRuns.put(level, signature);
		this.storeRun(score, survivalTime, playerName);
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			for (String line : lines) {
				String[] values = line.split(SEPARATOR, 3);
				if (values.length != 3) {
					continue;
				}

				try {
					int score = Integer.parseInt(values[0]);
					int survivalTime = Integer.parseInt(values[1]);
					String name = this.unescape(values[2]);
					if (name.length() == 0) {
						name = "Player";
					}
					if (score < 0 || survivalTime < 0) {
						continue;
					}
					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(survivalTime));
					this.playersNames.add(name);
				} catch (NumberFormatException ex) {
					this.playersNames.clear();
					this.playersScores.clear();
					this.survivalTimes.clear();
					break;
				}
			}
			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private String unescape(String value) {
		StringBuilder result = new StringBuilder();
		boolean escaped = false;

		for (int i = 0; i < value.length(); i++) {
			char character = value.charAt(i);
			if (escaped) {
				if (character == 't') {
					result.append('\t');
				} else if (character == 'n') {
					result.append('\n');
				} else if (character == 'r') {
					result.append('\r');
				} else {
					result.append(character);
				}
				escaped = false;
			} else if (character == '\\') {
				escaped = true;
			} else {
				result.append(character);
			}
		}

		if (escaped) {
			result.append('\\');
		}
		return result.toString();
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()),
						ApoMarioHighscore.this.playersScores.get(first.intValue()));
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			names.add(this.playersNames.get(index.intValue()));
			scores.add(this.playersScores.get(index.intValue()));
			times.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private String formatTime(int milliseconds) {
		int totalSeconds = milliseconds / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 28));
			g.drawString("Highscore", 30, 45);

			g.setFont(new Font("Dialog", Font.BOLD, 16));
			g.drawString("#", 35, 80);
			g.drawString("Name", 80, 80);
			g.drawString("Points", 370, 80);
			g.drawString("Time", 500, 80);

			g.setFont(new Font("Dialog", Font.PLAIN, 16));
			int y = 110;
			for (int i = 0; i < this.playersNames.size(); i++) {
				g.drawString(String.valueOf(i + 1), 35, y);
				g.drawString(this.playersNames.get(i), 80, y);
				g.drawString(String.valueOf(this.playersScores.get(i)), 370, y);
				g.drawString(this.formatTime(this.survivalTimes.get(i)), 500, y);
				y += 25;
			}
		} finally {
			g.dispose();
		}
	}
}