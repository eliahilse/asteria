package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_ENTRIES = 100;
	private static final String HEADER = "APOMARIO_HIGHSCORE_1";

	private static final class Run {
		private final String name;
		private final int score;
		private final int survivalTime;
		private final long order;

		private Run(String name, int score, int survivalTime, long order) {
			this.name = name;
			this.score = score;
			this.survivalTime = survivalTime;
			this.order = order;
		}
	}

	private final Path store;
	private final ArrayList<Run> runs;
	private long nextOrder;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store must not be null");
		}
		this.store = store;
		this.runs = new ArrayList<Run>();
		this.nextOrder = 0L;
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 64) {
			name = name.substring(0, 64);
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.runs.add(new Run(name, score, survivalTime, this.nextOrder++));
		this.sort();
		while (this.runs.size() > MAX_ENTRIES) {
			this.runs.remove(this.runs.size() - 1);
		}
		return this.write();
	}

	public synchronized List<String> getPlayersNames() {
		ArrayList<String> result = new ArrayList<String>();
		for (Run run : this.runs) {
			result.add(run.name);
		}
		return result;
	}

	public synchronized List<Integer> getPlayersScores() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Run run : this.runs) {
			result.add(run.score);
		}
		return result;
	}

	public synchronized List<Integer> getSurvivalTimes() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Run run : this.runs) {
			result.add(run.survivalTime);
		}
		return result;
	}

	public synchronized void persistAcrossRuns() {
		this.write();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int score = player.getPoints();
		String playerName = player.getTeamName();
		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.storeRun(score, survivalTime, playerName);
	}

	public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
		if (graphics == null) {
			return;
		}

		Color oldColor = graphics.getColor();
		Font oldFont = graphics.getFont();

		graphics.setColor(new Color(255, 255, 255, 225));
		graphics.fillRoundRect(x, y, width, height, 20, 20);
		graphics.setColor(Color.BLACK);
		graphics.drawRoundRect(x, y, width, height, 20, 20);

		graphics.setFont(new Font("Dialog", Font.BOLD, 24));
		graphics.drawString("Highscore", x + 20, y + 35);

		graphics.setFont(new Font("Dialog", Font.BOLD, 14));
		graphics.drawString("#", x + 20, y + 62);
		graphics.drawString("Name", x + 60, y + 62);
		graphics.drawString("Points", x + width - 150, y + 62);
		graphics.drawString("Time", x + width - 75, y + 62);

		graphics.setFont(new Font("Dialog", Font.PLAIN, 14));
		int rowHeight = 22;
		int visibleRows = Math.max(0, (height - 72) / rowHeight);
		for (int i = 0; i < this.runs.size() && i < visibleRows; i++) {
			Run run = this.runs.get(i);
			int rowY = y + 84 + i * rowHeight;
			graphics.drawString(String.valueOf(i + 1), x + 20, rowY);
			graphics.drawString(run.name, x + 60, rowY);
			graphics.drawString(String.valueOf(run.score), x + width - 150, rowY);
			graphics.drawString(formatTime(run.survivalTime), x + width - 75, rowY);
		}

		graphics.setColor(oldColor);
		graphics.setFont(oldFont);
	}

	public synchronized void render(Graphics2D graphics) {
		render(graphics, 0, 0, 640, 480);
	}

	public static String formatTime(int seconds) {
		if (seconds < 0) {
			seconds = 0;
		}
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	private void sort() {
		this.runs.sort(new Comparator<Run>() {
			@Override
			public int compare(Run first, Run second) {
				int scoreComparison = Integer.compare(second.score, first.score);
				if (scoreComparison != 0) {
					return scoreComparison;
				}
				return Long.compare(first.order, second.order);
			}
		});
	}

	private void load() {
		if (!Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line = reader.readLine();
			if (!HEADER.equals(line)) {
				return;
			}

			while ((line = reader.readLine()) != null && this.runs.size() < MAX_ENTRIES) {
				String[] values = line.split("\\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					int score = Integer.parseInt(values[0]);
					int survivalTime = Integer.parseInt(values[1]);
					String name = new String(Base64.getDecoder().decode(values[2]), StandardCharsets.UTF_8);
					if (name.length() == 0 || name.length() > 64 || survivalTime < 0) {
						continue;
					}
					this.runs.add(new Run(name, score, survivalTime, this.nextOrder++));
				} catch (IllegalArgumentException exception) {
					continue;
				}
			}
			this.sort();
		} catch (IOException exception) {
			this.runs.clear();
		}
	}

	private boolean write() {
		Path parent = this.store.toAbsolutePath().getParent();
		if (parent != null) {
			try {
				Files.createDirectories(parent);
			} catch (IOException exception) {
				return false;
			}
		}

		Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
		try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
			writer.write(HEADER);
			writer.newLine();
			for (Run run : this.runs) {
				writer.write(Integer.toString(run.score));
				writer.write('\t');
				writer.write(Integer.toString(run.survivalTime));
				writer.write('\t');
				writer.write(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
				writer.newLine();
			}
		} catch (IOException exception) {
			try {
				Files.deleteIfExists(temporary);
			} catch (IOException ignored) {
			}
			return false;
		}

		try {
			Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
					StandardCopyOption.ATOMIC_MOVE);
		} catch (AtomicMoveNotSupportedException exception) {
			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException moveException) {
				return false;
			}
		} catch (IOException exception) {
			return false;
		}
		return true;
	}
}