package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int FILE_VERSION = 1;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store");
		}
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sort();
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return new ArrayList<String>(this.playersNames);
	}

	public synchronized List<Integer> getPlayersScores() {
		return new ArrayList<Integer>(this.playersScores);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return new ArrayList<Integer>(this.survivalTimes);
	}

	public synchronized void persistAcrossRuns() {
		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			DataOutputStream output = new DataOutputStream(
					new BufferedOutputStream(Files.newOutputStream(temporary)));

			output.writeInt(FILE_VERSION);
			output.writeInt(this.playersNames.size());

			for (int i = 0; i < this.playersNames.size(); i++) {
				output.writeUTF(this.playersNames.get(i));
				output.writeInt(this.playersScores.get(i).intValue());
				output.writeInt(this.survivalTimes.get(i).intValue());
			}

			output.flush();
			output.close();

			try {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING,
						java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			// A failed write does not invalidate the in-memory board.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null) {
				continue;
			}
			if (selected == null || player.getPoints() > selected.getPoints()) {
				selected = player;
			}
		}

		if (selected == null) {
			return;
		}

		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}

		String name = selected.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = selected.getAuthor();
		}

		this.storeRun(selected.getPoints(), elapsed, name);
	}

	private synchronized void load() {
		if (!Files.isRegularFile(this.store)) {
			return;
		}

		try {
			DataInputStream input = new DataInputStream(
					new BufferedInputStream(Files.newInputStream(this.store)));

			int version = input.readInt();
			if (version != FILE_VERSION) {
				input.close();
				return;
			}

			int count = input.readInt();
			if (count < 0 || count > 100000) {
				input.close();
				return;
			}

			for (int i = 0; i < count; i++) {
				this.playersNames.add(input.readUTF());
				this.playersScores.add(Integer.valueOf(input.readInt()));
				this.survivalTimes.add(Integer.valueOf(input.readInt()));
			}

			input.close();
			this.sort();
		} catch (EOFException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}
}