package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final Comparator<Run> SCORE_ORDER = new Comparator<Run>() {
        @Override
        public int compare(Run first, Run second) {
            int result = Integer.compare(second.score, first.score);
            if (result != 0) {
                return result;
            }
            return Integer.compare(second.survivalTime, first.survivalTime);
        }
    };

    private final Path store;
    private final List<Run> runs;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.runs.add(new Run(score, Math.max(0, survivalTime), name));
        Collections.sort(this.runs, SCORE_ORDER);
        return this.write();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        this.write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                selectedPlayer = player;
                break;
            }
        }
        if (selectedPlayer == null) {
            selectedPlayer = level.getPlayers().get(0);
        }
        if (selectedPlayer == null) {
            return;
        }

        String playerName = selectedPlayer.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException exception) {
            survivalTime = Math.max(0, level.getStartTime() - level.getTime());
        }

        this.storeRun(selectedPlayer.getPoints(), survivalTime, playerName);
    }

    public static String formatSurvivalTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = seconds / 60L;
        long remainingSeconds = seconds % 60L;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private synchronized void load() {
        this.runs.clear();
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);

                    if (name.length() == 0) {
                        name = "Player";
                    }
                    this.runs.add(new Run(score, Math.max(0, survivalTime), name));
                } catch (IllegalArgumentException exception) {
                    this.runs.clear();
                    return;
                }
            }
            Collections.sort(this.runs, SCORE_ORDER);
        } catch (IOException exception) {
            this.runs.clear();
        }
    }

    private synchronized boolean write() {
        if (this.store == null) {
            return false;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                for (Run run : this.runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException exception) {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}