package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String HEADER = "APOMARIO_HIGHSCORE_1";
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final List<String> playersNames;
	private final List<Integer> playersScores;
	private final List<Integer> survivalTimes;
	private final Map<ApoMarioLevel, Boolean> recordedLevels;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.recordedLevels = new WeakHashMap<ApoMarioLevel, Boolean>();
		this.load();
		setBackground(Color.WHITE);
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 32) {
			name = name.substring(0, 32);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}
		repaint();
		return true;
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || this.recordedLevels.containsKey(level)) {
			return;
		}

		List<ApoMarioPlayer> players = level.getPlayers();
		if (players == null || players.isEmpty() || players.get(0) == null) {
			return;
		}

		ApoMarioPlayer player = players.get(0);
		String name = this.getPlayerName(player);
		int survivalTime;
		try {
			survivalTime = level.getPassedTime();
		} catch (RuntimeException ex) {
			survivalTime = Math.max(0, level.getStartTime() - level.getTime());
		}

		this.recordedLevels.put(level, Boolean.TRUE);
		this.storeRun(player.getPoints(), survivalTime, name);
		this.persistAcrossRuns();
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(
					temporary, StandardCharsets.UTF_8)) {
				writer.write(HEADER);
				writer.newLine();

				for (int i = 0; i < this.playersNames.size(); i++) {
					String encodedName = Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(Integer.toString(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
					writer.write('\t');
					writer.write(encodedName);
					writer.newLine();
				}
			}

			try {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException ex) {
				Files.move(temporary, this.store,
						StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(
						this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		int width = getWidth();
		int y = 32;

		g.setColor(Color.BLACK);
		g.setFont(new Font("Dialog", Font.BOLD, 22));
		g.drawString("Highscore", 20, y);

		y += 30;
		g.setFont(new Font("Dialog", Font.BOLD, 14));
		g.drawString("#", 20, y);
		g.drawString("Name", 60, y);
		g.drawString("Points", Math.max(180, width - 210), y);
		g.drawString("Time", Math.max(270, width - 100), y);

		g.setFont(new Font("Dialog", Font.PLAIN, 14));
		for (int i = 0; i < this.playersNames.size(); i++) {
			y += 24;
			g.drawString(Integer.toString(i + 1), 20, y);
			g.drawString(this.playersNames.get(i), 60, y);
			g.drawString(Integer.toString(this.playersScores.get(i).intValue()),
					Math.max(180, width - 210), y);
			g.drawString(formatTime(this.survivalTimes.get(i).intValue()),
					Math.max(270, width - 100), y);
		}

		g.dispose();
	}

	private String getPlayerName(ApoMarioPlayer player) {
		try {
			Object value = player.getClass().getMethod("getPlayer").invoke(player);
			if (value != null && value.toString().trim().length() > 0) {
				return value.toString();
			}
		} catch (Exception ignored) {
		}

		String teamName = player.getTeamName();
		return teamName == null || teamName.trim().length() == 0
				? "Player" : teamName;
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(
				this.store, StandardCharsets.UTF_8)) {
			String header = reader.readLine();
			if (!HEADER.equals(header)) {
				return;
			}

			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					String name = new String(
							Base64.getDecoder().decode(values[2]),
							StandardCharsets.UTF_8);

					if (name.length() == 0) {
						name = "Player";
					}
					this.playersNames.add(name);
					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
				} catch (IllegalArgumentException ex) {
					this.playersNames.clear();
					this.playersScores.clear();
					this.survivalTimes.clear();
					return;
				}
			}
			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		List<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						playersScores.get(second.intValue()).intValue(),
						playersScores.get(first.intValue()).intValue());
			}
		});

		List<String> names = new ArrayList<String>();
		List<Integer> scores = new ArrayList<Integer>();
		List<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private static String formatTime(int milliseconds) {
		long seconds = Math.max(0, milliseconds) / 1000L;
		long minutes = seconds / 60L;
		long remainingSeconds = seconds % 60L;
		return String.format("%02d:%02d", Long.valueOf(minutes),
				Long.valueOf(remainingSeconds));
	}
}