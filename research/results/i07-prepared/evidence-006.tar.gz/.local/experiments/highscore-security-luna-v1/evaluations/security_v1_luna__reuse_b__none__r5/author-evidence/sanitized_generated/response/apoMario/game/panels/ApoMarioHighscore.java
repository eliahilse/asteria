package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store must not be null");
		}
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 32) {
			name = name.substring(0, 32);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(Math.max(0, score)));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}
		return this.write();
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		this.write();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}
		this.storeRun(player.getPoints(), elapsed / 1000, name);
	}

	public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
		if (graphics == null) {
			return;
		}

		Color oldColor = graphics.getColor();
		Font oldFont = graphics.getFont();

		graphics.setColor(new Color(255, 255, 255, 220));
		graphics.fillRoundRect(x, y, width, height, 20, 20);
		graphics.setColor(Color.BLACK);
		graphics.drawRoundRect(x, y, width, height, 20, 20);

		graphics.setFont(new Font("Dialog", Font.BOLD, 24));
		graphics.drawString("Highscore", x + 24, y + 36);

		graphics.setFont(new Font("Dialog", Font.BOLD, 14));
		graphics.drawString("#", x + 24, y + 64);
		graphics.drawString("Points", x + width / 3, y + 64);
		graphics.drawString("Player", x + width / 2, y + 64);
		graphics.drawString("Time", x + width - 100, y + 64);

		graphics.setFont(new Font("Dialog", Font.PLAIN, 14));
		int rowY = y + 88;
		int rowHeight = 24;

		for (int i = 0; i < this.playersNames.size(); i++) {
			if (rowY + rowHeight > y + height) {
				break;
			}
			graphics.drawString(String.valueOf(i + 1), x + 24, rowY);
			graphics.drawString(String.valueOf(this.playersScores.get(i)), x + width / 3, rowY);
			graphics.drawString(this.playersNames.get(i), x + width / 2, rowY);
			graphics.drawString(formatTime(this.survivalTimes.get(i).intValue()), x + width - 100, rowY);
			rowY += rowHeight;
		}

		graphics.setColor(oldColor);
		graphics.setFont(oldFont);
	}

	public synchronized void clear() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
	}

	private void load() {
		if (!Files.isRegularFile(this.store)) {
			return;
		}

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}
				try {
					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					String name = values[2];
					if (name.length() == 0) {
						name = "Player";
					}
					scores.add(Integer.valueOf(Math.max(0, score)));
					times.add(Integer.valueOf(Math.max(0, time)));
					names.add(name);
				} catch (NumberFormatException ex) {
					names.clear();
					scores.clear();
					times.clear();
					break;
				}
			}
		} catch (IOException ex) {
			return;
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(names);
		this.playersScores.addAll(scores);
		this.survivalTimes.addAll(times);
		this.sort();
	}

	private boolean write() {
		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
				for (int i = 0; i < this.playersNames.size(); i++) {
					writer.write(String.valueOf(this.playersScores.get(i)));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i)));
					writer.write('\t');
					writer.write(this.playersNames.get(i).replace('\t', ' '));
					writer.newLine();
				}
			}

			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException ex) {
			return false;
		}
	}

	private void sort() {
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			indexes.add(Integer.valueOf(i));
		}

		Collections.sort(indexes, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return Integer.compare(
						ApoMarioHighscore.this.survivalTimes.get(first.intValue()).intValue(),
						ApoMarioHighscore.this.survivalTimes.get(second.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : indexes) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(names);
		this.playersScores.addAll(scores);
		this.survivalTimes.addAll(times);
	}

	private static String formatTime(int seconds) {
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(remainingSeconds));
	}
}