package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final int MAX_RECORDS = 1000;

	private final Path store;
	private final ArrayList<Run> runs;

	public ApoMarioHighscore(Path store) {
		this.store = Objects.requireNonNull(store, "store");
		this.runs = new ArrayList<Run>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 80) {
			name = name.substring(0, 80);
		}

		this.runs.add(new Run(score, Math.max(0, survivalTime), name));
		this.sortRuns();

		if (this.runs.size() > MAX_RECORDS) {
			this.runs.subList(MAX_RECORDS, this.runs.size()).clear();
		}

		return this.write();
	}

	public synchronized List<String> getPlayersNames() {
		ArrayList<String> result = new ArrayList<String>(this.runs.size());
		for (Run run : this.runs) {
			result.add(run.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
		for (Run run : this.runs) {
			result.add(run.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
		for (Run run : this.runs) {
			result.add(run.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		this.write();
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int elapsed;
		try {
			elapsed = level.getPassedTime();
		} catch (RuntimeException ex) {
			elapsed = level.getStartTime() - level.getTime();
		}

		if (elapsed < 0) {
			elapsed = 0;
		}

		String name = player.getPlayer();
		if (name == null || name.trim().length() == 0) {
			name = player.getTeamName();
		}

		this.storeRun(player.getPoints(), elapsed, name);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, getWidth(), getHeight());

			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 24));
			g.drawString("Highscore", 24, 36);

			g.setFont(new Font("Dialog", Font.PLAIN, 16));
			int y = 68;
			int row = 26;

			for (int i = 0; i < this.runs.size(); i++) {
				Run run = this.runs.get(i);
				g.drawString(String.valueOf(i + 1), 24, y);
				g.drawString(run.name, 70, y);
				g.drawString(String.valueOf(run.score), 250, y);
				g.drawString(formatTime(run.survivalTime), 350, y);
				y += row;

				if (y > getHeight() - 10) {
					break;
				}
			}
		} finally {
			g.dispose();
		}
	}

	private synchronized void load() {
		if (!Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null && this.runs.size() < MAX_RECORDS) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					int score = Integer.parseInt(values[0]);
					int survivalTime = Integer.parseInt(values[1]);
					String name = new String(
							Base64.getDecoder().decode(values[2]),
							StandardCharsets.UTF_8);

					if (name.length() == 0 || name.length() > 80 || survivalTime < 0) {
						continue;
					}

					this.runs.add(new Run(score, survivalTime, name));
				} catch (IllegalArgumentException ex) {
					continue;
				}
			}
			this.sortRuns();
		} catch (IOException ex) {
			this.runs.clear();
		}
	}

	private synchronized boolean write() {
		Path parent = this.store.toAbsolutePath().getParent();
		if (parent == null) {
			parent = this.store.toAbsolutePath().getParent();
		}

		try {
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

			try (BufferedWriter writer = Files.newBufferedWriter(
					temporary,
					StandardCharsets.UTF_8)) {
				for (Run run : this.runs) {
					String encodedName = Base64.getEncoder().encodeToString(
							run.name.getBytes(StandardCharsets.UTF_8));
					writer.write(Integer.toString(run.score));
					writer.write('\t');
					writer.write(Integer.toString(run.survivalTime));
					writer.write('\t');
					writer.write(encodedName);
					writer.newLine();
				}
			}

			try {
				Files.move(
						temporary,
						this.store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException ex) {
				Files.move(
						temporary,
						this.store,
						StandardCopyOption.REPLACE_EXISTING);
			}

			return true;
		} catch (IOException ex) {
			return false;
		}
	}

	private void sortRuns() {
		Collections.sort(this.runs, new Comparator<Run>() {
			@Override
			public int compare(Run first, Run second) {
				return Integer.compare(second.score, first.score);
			}
		});
	}

	private static String formatTime(int seconds) {
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", minutes, remainingSeconds);
	}

	private static final class Run {
		private final int score;
		private final int survivalTime;
		private final String name;

		private Run(int score, int survivalTime, String name) {
			this.score = score;
			this.survivalTime = survivalTime;
			this.name = name;
		}
	}
}