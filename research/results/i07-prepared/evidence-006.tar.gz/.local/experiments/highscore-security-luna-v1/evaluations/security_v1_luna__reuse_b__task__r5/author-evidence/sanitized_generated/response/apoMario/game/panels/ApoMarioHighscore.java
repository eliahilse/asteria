package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			ArrayList<String> lines = new ArrayList<String>();
			lines.add("APOMARIO_HIGHSCORE_1");

			for (int i = 0; i < this.playersNames.size(); i++) {
				String encodedName = Base64.getEncoder().encodeToString(
						this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
				lines.add(this.playersScores.get(i) + "\t"
						+ this.survivalTimes.get(i) + "\t"
						+ encodedName);
			}

			Files.write(this.store, lines, StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE);
		} catch (Exception ex) {
			// A failed write must not invalidate the in-memory highscore.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int score = player.getPoints();
		int survivalTime = level.getStartTime() - level.getTime();
		String playerName = player.getTeamName();

		this.storeRun(score, Math.max(0, survivalTime), playerName);
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			for (int i = 0; i < lines.size(); i++) {
				String line = lines.get(i);
				if (i == 0 && "APOMARIO_HIGHSCORE_1".equals(line)) {
					continue;
				}
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}

				int score = Integer.parseInt(values[0]);
				int time = Integer.parseInt(values[1]);
				String name = new String(
						Base64.getDecoder().decode(values[2]),
						StandardCharsets.UTF_8);

				if (name.length() == 0) {
					name = "Player";
				}

				this.playersScores.add(Integer.valueOf(score));
				this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
				this.playersNames.add(name);
			}
			this.sort();
		} catch (Exception ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int result = Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()),
						ApoMarioHighscore.this.playersScores.get(first.intValue()));
				return result != 0 ? result : Integer.compare(
						first.intValue(), second.intValue());
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : order) {
			sortedNames.add(this.playersNames.get(index.intValue()));
			sortedScores.add(this.playersScores.get(index.intValue()));
			sortedTimes.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.clear();
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(sortedTimes);
	}

	private String formatTime(int seconds) {
		int minutes = seconds / 60;
		int remainingSeconds = seconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes),
				Integer.valueOf(remainingSeconds));
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		g.setColor(Color.BLACK);
		g.setFont(new Font("Dialog", Font.BOLD, 24));
		g.drawString("Highscore", 30, 40);

		g.setFont(new Font("Dialog", Font.BOLD, 16));
		g.drawString("Name", 30, 75);
		g.drawString("Score", 260, 75);
		g.drawString("Time", 380, 75);

		g.setFont(new Font("Dialog", Font.PLAIN, 16));
		for (int i = 0; i < this.playersNames.size(); i++) {
			int y = 105 + i * 25;
			g.drawString((i + 1) + ". " + this.playersNames.get(i), 30, y);
			g.drawString(String.valueOf(this.playersScores.get(i)), 260, y);
			g.drawString(this.formatTime(this.survivalTimes.get(i)), 380, y);
		}

		g.dispose();
	}
}