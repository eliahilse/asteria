package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int FILE_VERSION = 1;
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        if (name.length() > 64) {
            name = name.substring(0, 64);
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        return this.write();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        this.write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            return;
        }

        int elapsed = level.getStartTime() - level.getTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        this.storeRun(selected.getPoints(), elapsed, name);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 230));
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        int rowY = y + 58;
        int rowHeight = 22;
        int visible = Math.min(this.playersNames.size(), Math.max(0, (height - 70) / rowHeight));

        for (int i = 0; i < visible; i++) {
            String position = String.valueOf(i + 1);
            String name = this.playersNames.get(i);
            String score = String.valueOf(this.playersScores.get(i));
            String time = formatTime(this.survivalTimes.get(i).intValue());

            graphics.drawString(position, x + 15, rowY);
            graphics.drawString(name, x + 55, rowY);
            graphics.drawString(score, x + width - 145, rowY);
            graphics.drawString(time, x + width - 75, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatTime(int milliseconds) {
        long totalSeconds = Math.max(0, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
    }

    private synchronized void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (DataInputStream input = new DataInputStream(Files.newInputStream(this.store))) {
            if (input.readInt() != FILE_VERSION) {
                return;
            }

            int count = input.readInt();
            if (count < 0 || count > MAX_ENTRIES * 10) {
                return;
            }

            for (int i = 0; i < count; i++) {
                String name = input.readUTF();
                int score = input.readInt();
                int time = input.readInt();
                this.playersNames.add(name);
                this.playersScores.add(Integer.valueOf(score));
                this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
            }
            this.sort();
        } catch (IOException | RuntimeException exception) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private synchronized boolean write() {
        if (this.store == null) {
            return false;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (DataOutputStream output = new DataOutputStream(Files.newOutputStream(this.store))) {
                output.writeInt(FILE_VERSION);
                output.writeInt(this.playersNames.size());
                for (int i = 0; i < this.playersNames.size(); i++) {
                    output.writeUTF(this.playersNames.get(i));
                    output.writeInt(this.playersScores.get(i).intValue());
                    output.writeInt(this.survivalTimes.get(i).intValue());
                }
            }
            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                    ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
                    ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue()
                );
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : order) {
            int value = index.intValue();
            names.add(this.playersNames.get(value));
            scores.add(this.playersScores.get(value));
            times.add(this.survivalTimes.get(value));
        }

        this.playersNames.clear();
        this.playersNames.addAll(names);
        this.playersScores.clear();
        this.playersScores.addAll(scores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(times);
    }
}