package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    public static final String FUNCTION_BACK = "backHighscore";

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final ArrayList<Entry> entries;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.entries.add(new Entry(name, score, survivalTime));
        this.sort();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry entry : this.entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            ArrayList<String> lines = new ArrayList<String>();
            for (Entry entry : this.entries) {
                String encodedName = Base64.getEncoder().encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t" + entry.survivalTime);
            }

            Files.write(this.store, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
        } catch (Exception ex) {
            // A damaged or inaccessible store must not stop the game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if ((name == null || name.trim().length() == 0) && selected.getAi() != null) {
            name = selected.getAi().getTeamName();
        }

        this.storeRun(selected.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void init() {
        this.load();
    }

    public synchronized void think(int delta) {
    }

    public synchronized void keyButtonReleased(int button, char character) {
    }

    public synchronized void mouseButtonFunction(String function) {
    }

    public synchronized void mouseButtonReleased(int x, int y) {
    }

    public synchronized boolean mouseMoved(int x, int y) {
        return false;
    }

    public synchronized boolean mouseDragged(int x, int y) {
        return false;
    }

    public synchronized boolean mousePressed(int x, int y, boolean bRight) {
        return false;
    }

    public synchronized List<String> getFormattedSurvivalTimes() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry entry : this.entries) {
            result.add(formatTime(entry.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, 320, 240);
        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", 105, 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        int y = 55;
        int rank = 1;

        for (Entry entry : this.entries) {
            if (y > 225) {
                break;
            }

            graphics.drawString(String.valueOf(rank), 18, y);
            graphics.drawString(entry.name, 45, y);
            graphics.drawString(String.valueOf(entry.score), 180, y);
            graphics.drawString(formatTime(entry.survivalTime), 245, y);

            rank++;
            y += 20;
        }
    }

    private synchronized void load() {
        this.entries.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            for (String line : lines) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                String name = new String(
                        Base64.getDecoder().decode(values[0]),
                        StandardCharsets.UTF_8);
                int score = Integer.parseInt(values[1]);
                int survivalTime = Integer.parseInt(values[2]);

                if (name.length() > 0 && score >= 0 && survivalTime >= 0) {
                    this.entries.add(new Entry(name, score, survivalTime));
                }
            }
            this.sort();
        } catch (Exception ex) {
            this.entries.clear();
        }
    }

    private void sort() {
        Collections.sort(this.entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int score = Integer.compare(second.score, first.score);
                if (score != 0) {
                    return score;
                }
                return Integer.compare(second.survivalTime, first.survivalTime);
            }
        });
    }

    private static String formatTime(int milliseconds) {
        int totalSeconds = milliseconds / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
}