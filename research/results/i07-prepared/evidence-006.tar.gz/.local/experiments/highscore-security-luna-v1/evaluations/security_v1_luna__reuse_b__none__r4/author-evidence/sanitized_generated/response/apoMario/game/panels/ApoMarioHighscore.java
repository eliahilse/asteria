package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

import javax.swing.JPanel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;

    private static final int MAX_ENTRIES = 100;
    private static final String SEPARATOR = "\t";

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.setBackground(Color.WHITE);
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        name = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ');

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        if (this.playersNames.size() > MAX_ENTRIES) {
            this.playersNames.subList(MAX_ENTRIES, this.playersNames.size()).clear();
            this.playersScores.subList(MAX_ENTRIES, this.playersScores.size()).clear();
            this.survivalTimes.subList(MAX_ENTRIES, this.survivalTimes.size()).clear();
        }
        this.persistAcrossRuns();
        this.repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (int i = 0; i < this.playersNames.size(); i++) {
                    writer.write(this.playersScores.get(i).toString());
                    writer.write(SEPARATOR);
                    writer.write(this.survivalTimes.get(i).toString());
                    writer.write(SEPARATOR);
                    writer.write(this.playersNames.get(i));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.isBVisible()) {
                player = candidate;
                break;
            }
        }
        if (player == null) {
            player = level.getPlayers().get(0);
        }
        if (player == null) {
            return;
        }

        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int survivalTime = 0;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            survivalTime = Math.max(0, level.getStartTime() - level.getTime());
        }

        this.storeRun(player.getPoints(), survivalTime, name);
    }

    public synchronized void clearScores() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();
        this.persistAcrossRuns();
        this.repaint();
    }

    private synchronized void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(SEPARATOR, 3);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[0]);
                int time = Integer.parseInt(values[1]);
                String name = values[2];

                if (name.length() == 0) {
                    name = "Player";
                }

                this.playersScores.add(Integer.valueOf(score));
                this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
                this.playersNames.add(name);
            }
            this.sort();

            if (this.playersNames.size() > MAX_ENTRIES) {
                this.playersNames.subList(MAX_ENTRIES, this.playersNames.size()).clear();
                this.playersScores.subList(MAX_ENTRIES, this.playersScores.size()).clear();
                this.survivalTimes.subList(MAX_ENTRIES, this.survivalTimes.size()).clear();
            }
        } catch (IOException | NumberFormatException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int result = Integer.compare(
                        ApoMarioHighscore.this.playersScores.get(second.intValue()),
                        ApoMarioHighscore.this.playersScores.get(first.intValue()));
                if (result != 0) {
                    return result;
                }
                return Integer.compare(first.intValue(), second.intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            sortedNames.add(this.playersNames.get(index.intValue()));
            sortedScores.add(this.playersScores.get(index.intValue()));
            sortedTimes.add(this.survivalTimes.get(index.intValue()));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(
                RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.drawString("Highscore", 24, 32);

        g.setFont(new Font("Dialog", Font.BOLD, 14));
        g.drawString("#", 24, 60);
        g.drawString("Points", 70, 60);
        g.drawString("Player", 150, 60);
        g.drawString("Time", 330, 60);

        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        int y = 84;
        for (int i = 0; i < this.playersNames.size(); i++) {
            g.drawString(String.valueOf(i + 1), 24, y);
            g.drawString(String.valueOf(this.playersScores.get(i)), 70, y);
            g.drawString(this.playersNames.get(i), 150, y);
            g.drawString(formatTime(this.survivalTimes.get(i).intValue()), 330, y);
            y += 22;
            if (y > this.getHeight() - 8) {
                break;
            }
        }

        g.dispose();
    }

    private static String formatTime(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }
}