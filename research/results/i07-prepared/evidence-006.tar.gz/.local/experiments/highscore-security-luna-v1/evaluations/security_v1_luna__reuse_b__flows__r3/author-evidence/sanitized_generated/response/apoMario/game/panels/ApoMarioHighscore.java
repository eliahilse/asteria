package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<Run> runs;
	private final Map<ApoMarioLevel, Boolean> recordedLevels;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.runs = new ArrayList<Run>();
		this.recordedLevels = new IdentityHashMap<ApoMarioLevel, Boolean>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		if (score < 0 || survivalTime < 0 || playerName == null) {
			return false;
		}

		String name = playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > 64) {
			name = name.substring(0, 64);
		}

		this.runs.add(new Run(score, survivalTime, name));
		this.sortRuns();
		while (this.runs.size() > MAX_ENTRIES) {
			this.runs.remove(this.runs.size() - 1);
		}
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		ArrayList<String> result = new ArrayList<String>();
		for (Run run : this.runs) {
			result.add(run.name);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getPlayersScores() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Run run : this.runs) {
			result.add(run.score);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (Run run : this.runs) {
			result.add(run.survivalTime);
		}
		return Collections.unmodifiableList(result);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			BufferedWriter writer = Files.newBufferedWriter(
					temporary,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE);

			try {
				for (Run run : this.runs) {
					writer.write(Integer.toString(run.score));
					writer.write('\t');
					writer.write(Integer.toString(run.survivalTime));
					writer.write('\t');
					writer.write(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
					writer.newLine();
				}
			} finally {
				writer.close();
			}

			try {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING,
						java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
				Files.deleteIfExists(temporary);
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || this.recordedLevels.containsKey(level)) {
			return;
		}

		ArrayList<ApoMarioPlayer> players = level.getPlayers();
		if (players == null || players.size() == 0 || players.get(0) == null) {
			return;
		}

		ApoMarioPlayer player = players.get(0);
		int score = player.getPoints();
		int survivalTime;

		try {
			survivalTime = level.getPassedTime();
		} catch (RuntimeException ex) {
			survivalTime = level.getStartTime() - level.getTime();
		}

		if (survivalTime < 0) {
			survivalTime = 0;
		}

		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		if (this.storeRun(score, survivalTime, name)) {
			this.recordedLevels.put(level, Boolean.TRUE);
			this.persistAcrossRuns();
		}
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		BufferedReader reader = null;
		try {
			reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8);
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					continue;
				}

				int score;
				int survivalTime;
				String name;
				try {
					score = Integer.parseInt(values[0]);
					survivalTime = Integer.parseInt(values[1]);
					name = new String(Base64.getDecoder().decode(values[2]), StandardCharsets.UTF_8);
				} catch (RuntimeException ex) {
					continue;
				}

				if (score < 0 || survivalTime < 0 || name.trim().length() == 0) {
					continue;
				}
				if (name.length() > 64) {
					name = name.substring(0, 64);
				}
				this.runs.add(new Run(score, survivalTime, name));
				if (this.runs.size() >= MAX_ENTRIES) {
					break;
				}
			}
			this.sortRuns();
		} catch (IOException ex) {
			this.runs.clear();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException ignored) {
				}
			}
		}
	}

	private void sortRuns() {
		Collections.sort(this.runs, new Comparator<Run>() {
			@Override
			public int compare(Run first, Run second) {
				return Integer.compare(second.score, first.score);
			}
		});
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, getWidth(), getHeight());

			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 20));
			g.drawString("Highscores", 20, 30);

			g.setFont(new Font("Dialog", Font.PLAIN, 14));
			int y = 60;
			for (int i = 0; i < this.runs.size(); i++) {
				Run run = this.runs.get(i);
				String line = (i + 1) + ". " + run.name + "    "
						+ run.score + "    " + formatTime(run.survivalTime);
				g.drawString(line, 20, y);
				y += 22;
				if (y > getHeight() - 10) {
					break;
				}
			}
		} finally {
			g.dispose();
		}
	}

	private static String formatTime(int milliseconds) {
		int totalSeconds = milliseconds / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", minutes, seconds);
	}

	private static final class Run {
		private final int score;
		private final int survivalTime;
		private final String name;

		private Run(int score, int survivalTime, String name) {
			this.score = score;
			this.survivalTime = survivalTime;
			this.name = name;
		}
	}
}