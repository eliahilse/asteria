package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;
        private final long sequence;

        private Entry(String name, int score, int survivalTime, long sequence) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
            this.sequence = sequence;
        }
    }

    private final Path store;
    private final List<Entry> entries;
    private final Set<ApoMarioLevel> recordedLevels;
    private long nextSequence;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.recordedLevels = Collections.newSetFromMap(
                new IdentityHashMap<ApoMarioLevel, Boolean>());
        this.nextSequence = 0L;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        int safeTime = Math.max(0, survivalTime);
        entries.add(new Entry(name, score, safeTime, nextSequence++));
        sortEntries();

        if (entries.size() > MAX_ENTRIES) {
            entries.subList(MAX_ENTRIES, entries.size()).clear();
        }

        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary, StandardCharsets.UTF_8)) {
                writer.write("APOMARIO_HIGHSCORE_1");
                writer.newLine();

                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = store.resolveSibling(
                        store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level)) {
            return;
        }

        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty() || players.get(0) == null) {
            return;
        }

        ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = 0;
        }

        int elapsedSeconds = Math.max(0, elapsedMilliseconds / 1000);
        storeRun(player.getPoints(), elapsedSeconds, name);
        recordedLevels.add(level);
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        int seconds = Math.max(0, survivalTime);
        int minutes = seconds / 60;
        int remainder = seconds % 60;
        return String.format("%02d:%02d", minutes, remainder);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        List<Entry> loaded = new ArrayList<Entry>();

        try (BufferedReader reader = Files.newBufferedReader(
                store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!"APOMARIO_HIGHSCORE_1".equals(header)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null
                    && loaded.size() < MAX_ENTRIES) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    if (survivalTime < 0) {
                        continue;
                    }

                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);
                    name = sanitizeName(name);
                    if (name.length() == 0) {
                        continue;
                    }

                    loaded.add(new Entry(name, score, survivalTime, nextSequence++));
                } catch (IllegalArgumentException ex) {
                    loaded.clear();
                    break;
                }
            }
        } catch (IOException ex) {
            loaded.clear();
        }

        entries.clear();
        entries.addAll(loaded);
        sortEntries();

        if (entries.size() > MAX_ENTRIES) {
            entries.subList(MAX_ENTRIES, entries.size()).clear();
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int scoreOrder = Integer.compare(second.score, first.score);
                if (scoreOrder != 0) {
                    return scoreOrder;
                }

                int timeOrder = Integer.compare(
                        first.survivalTime, second.survivalTime);
                if (timeOrder != 0) {
                    return timeOrder;
                }

                return Long.compare(first.sequence, second.sequence);
            }
        });
    }

    private String sanitizeName(String name) {
        if (name == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < name.length() && result.length() < 32; i++) {
            char character = name.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        return result.toString().trim();
    }
}