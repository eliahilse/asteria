package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAGIC = 0x41504F48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        int points = Math.max(0, score);
        int time = Math.max(0, survivalTime);

        runs.add(new Run(points, time, name));
        sortRuns();

        if (runs.size() > MAX_ENTRIES) {
            runs.subList(MAX_ENTRIES, runs.size()).clear();
        }

        try {
            writeStore();
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        try {
            writeStore();
        } catch (IOException ex) {
            runs.clear();
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && player.getAi() == null) {
                selected = player;
                break;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && player.isBVisible()) {
                    selected = player;
                    break;
                }
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = 0;
        }

        int survivalSeconds = Math.max(0, elapsedMilliseconds / 1000);
        storeRun(selected.getPoints(), survivalSeconds, selected.getTeamName());
    }

    public static String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private synchronized void load() {
        runs.clear();

        if (!Files.isRegularFile(store)) {
            return;
        }

        try (InputStream input = Files.newInputStream(store);
             DataInputStream data = new DataInputStream(input)) {

            if (data.readInt() != MAGIC || data.readInt() != VERSION) {
                return;
            }

            int count = data.readInt();
            if (count < 0 || count > MAX_ENTRIES) {
                return;
            }

            for (int i = 0; i < count; i++) {
                int score = data.readInt();
                int survivalTime = data.readInt();
                String name = data.readUTF();

                if (score < 0 || survivalTime < 0 || name.length() > MAX_NAME_LENGTH) {
                    runs.clear();
                    return;
                }

                runs.add(new Run(score, survivalTime, cleanName(name)));
            }

            sortRuns();
        } catch (IOException | RuntimeException ex) {
            runs.clear();
        }
    }

    private void writeStore() throws IOException {
        Path parent = store.toAbsolutePath().getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }

        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

        try (OutputStream output = Files.newOutputStream(temporary);
             DataOutputStream data = new DataOutputStream(output)) {

            data.writeInt(MAGIC);
            data.writeInt(VERSION);
            data.writeInt(runs.size());

            for (Run run : runs) {
                data.writeInt(run.score);
                data.writeInt(run.survivalTime);
                data.writeUTF(run.name);
            }
        }

        try {
            Files.move(temporary, store,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            Files.move(temporary, store,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreCompare = Integer.compare(second.score, first.score);
                if (scoreCompare != 0) {
                    return scoreCompare;
                }

                int timeCompare = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeCompare != 0) {
                    return timeCompare;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String cleanName(String playerName) {
        if (playerName == null) {
            return "human";
        }

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < playerName.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = playerName.charAt(i);
            if (character >= 32 && character != 127) {
                result.append(character);
            }
        }

        String name = result.toString().trim();
        return name.length() == 0 ? "human" : name;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}