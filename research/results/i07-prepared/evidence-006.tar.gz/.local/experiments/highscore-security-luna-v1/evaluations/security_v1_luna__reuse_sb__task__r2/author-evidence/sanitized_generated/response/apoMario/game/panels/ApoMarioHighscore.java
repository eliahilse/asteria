package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final Comparator<Run> SCORE_ORDER = new Comparator<Run>() {
        @Override
        public int compare(Run first, Run second) {
            int result = Integer.compare(second.score, first.score);
            if (result != 0) {
                return result;
            }
            return Integer.compare(second.survivalTime, first.survivalTime);
        }
    };

    private final Path store;
    private final ArrayList<Run> runs;
    private boolean persisted;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.persisted = false;
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.runs.add(new Run(score, survivalTime, name));
        Collections.sort(this.runs, SCORE_ORDER);
        this.persisted = false;
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = this.store.toAbsolutePath().getParent();
        Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (Run run : this.runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        this.store,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            this.persisted = true;
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
            this.persisted = false;
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = level.getStartTime() - level.getTime();
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        String playerName = player.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = player.getAuthor();
        }

        this.storeRun(score, survivalTime, playerName);
        this.persistAcrossRuns();
    }

    public static String formatSurvivalTime(int survivalTime) {
        int totalSeconds = Math.max(0, survivalTime) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    public synchronized boolean isPersisted() {
        return this.persisted;
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8).trim();

                    if (name.length() == 0) {
                        name = "Player";
                    }
                    if (score < 0 || survivalTime < 0) {
                        continue;
                    }

                    this.runs.add(new Run(score, survivalTime, name));
                } catch (IllegalArgumentException ex) {
                    continue;
                }
            }

            Collections.sort(this.runs, SCORE_ORDER);
            this.persisted = true;
        } catch (IOException ex) {
            this.runs.clear();
            this.persisted = false;
        }
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}