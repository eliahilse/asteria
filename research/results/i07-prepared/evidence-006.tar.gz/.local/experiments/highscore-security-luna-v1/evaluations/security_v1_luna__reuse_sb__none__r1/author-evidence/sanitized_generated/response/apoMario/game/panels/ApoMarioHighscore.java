package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import java.awt.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int FILE_VERSION = 1;
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		if (store == null) {
			throw new IllegalArgumentException("store must not be null");
		}
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sort();

		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}

		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return new ArrayList<String>(this.playersNames);
	}

	public synchronized List<Integer> getPlayersScores() {
		return new ArrayList<Integer>(this.playersScores);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return new ArrayList<Integer>(this.survivalTimes);
	}

	public synchronized void persistAcrossRuns() {
		Path parent = this.store.getParent();
		try {
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			OutputStream output = Files.newOutputStream(temporary);
			DataOutputStream data = new DataOutputStream(output);
			try {
				data.writeInt(FILE_VERSION);
				data.writeInt(this.playersNames.size());
				for (int i = 0; i < this.playersNames.size(); i++) {
					data.writeUTF(this.playersNames.get(i));
					data.writeInt(this.playersScores.get(i).intValue());
					data.writeInt(this.survivalTimes.get(i).intValue());
				}
			} finally {
				data.close();
			}

			try {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING,
						java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (java.nio.file.AtomicMoveNotSupportedException ex) {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = null;
		for (ApoMarioPlayer candidate : level.getPlayers()) {
			if (candidate != null && candidate.isBVisible()) {
				if (player == null || candidate.getPoints() > player.getPoints()) {
					player = candidate;
				}
			}
		}

		if (player == null) {
			player = level.getPlayers().get(0);
		}
		if (player == null) {
			return;
		}

		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}

		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			if (player.getAi() != null) {
				name = player.getAi().getTeamName();
			}
		}
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		this.storeRun(player.getPoints(), elapsed, name);
	}

	public synchronized String formatSurvivalTime(int survivalTime) {
		int seconds = Math.max(0, survivalTime) / 1000;
		int minutes = seconds / 60;
		seconds %= 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	public synchronized void render(java.awt.Graphics2D graphics, int x, int y, int width, int rowHeight) {
		if (graphics == null) {
			return;
		}

		graphics.setColor(java.awt.Color.BLACK);
		graphics.drawString("Highscores", x, y);
		int currentY = y + rowHeight;

		for (int i = 0; i < this.playersNames.size(); i++) {
			String line = (i + 1) + ". " + this.playersNames.get(i)
					+ "  " + this.playersScores.get(i)
					+ "  " + this.formatSurvivalTime(this.survivalTimes.get(i));
			graphics.drawString(line, x, currentY);
			currentY += rowHeight;
			if (currentY > y + width) {
				break;
			}
		}
	}

	private void load() {
		if (!Files.exists(this.store)) {
			return;
		}

		InputStream input = null;
		try {
			input = Files.newInputStream(this.store);
			DataInputStream data = new DataInputStream(input);
			int version = data.readInt();
			if (version != FILE_VERSION) {
				this.clear();
				return;
			}

			int size = data.readInt();
			if (size < 0 || size > MAX_ENTRIES * 10) {
				this.clear();
				return;
			}

			for (int i = 0; i < size; i++) {
				String name = data.readUTF();
				int score = data.readInt();
				int survivalTime = data.readInt();
				if (name.length() == 0) {
					name = "Player";
				}
				if (survivalTime < 0) {
					survivalTime = 0;
				}
				this.playersNames.add(name);
				this.playersScores.add(Integer.valueOf(score));
				this.survivalTimes.add(Integer.valueOf(survivalTime));
			}
			this.sort();
		} catch (IOException ex) {
			this.clear();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException ignored) {
				}
			}
		}
	}

	private void clear() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						playersScores.get(second.intValue()).intValue(),
						playersScores.get(first.intValue()).intValue());
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return Integer.compare(
						survivalTimes.get(second.intValue()).intValue(),
						survivalTimes.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}
}