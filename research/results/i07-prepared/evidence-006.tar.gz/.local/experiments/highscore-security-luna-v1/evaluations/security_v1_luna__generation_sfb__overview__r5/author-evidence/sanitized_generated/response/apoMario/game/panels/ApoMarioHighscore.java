package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private static final int MAX_SURVIVAL_TIME = Integer.MAX_VALUE;

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (store == null) {
            return false;
        }

        String name = normalizeName(playerName);
        int safeScore = score;
        int safeTime = Math.max(0, Math.min(MAX_SURVIVAL_TIME, survivalTime));

        runs.add(new Run(safeScore, safeTime, name));
        sortRuns();

        if (runs.size() > MAX_ENTRIES) {
            runs.subList(MAX_ENTRIES, runs.size()).clear();
        }

        return writeStore();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        writeStore();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsedMilliseconds = level.getStartTime() - level.getTime();
        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalTime = elapsedMilliseconds / 1000;
        String playerName = player.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            playerName = player.getAuthor();
        }
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        storeRun(player.getPoints(), survivalTime, playerName);
    }

    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        if (graphics == null) {
            return;
        }

        Color oldColor = graphics.getColor();
        Font oldFont = graphics.getFont();

        graphics.setColor(new Color(255, 255, 255, 230));
        graphics.fillRoundRect(x, y, width, height, 20, 20);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 20, 20);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", x + 20, y + 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int rowY = y + 55;
        int rowHeight = 21;
        int count = Math.min(runs.size(), Math.max(0, (height - 65) / rowHeight));

        for (int i = 0; i < count; i++) {
            Run run = runs.get(i);
            String time = formatSurvivalTime(run.survivalTime);
            graphics.drawString(String.valueOf(i + 1), x + 16, rowY);
            graphics.drawString(run.name, x + 45, rowY);
            graphics.drawString(String.valueOf(run.score), x + width - 120, rowY);
            graphics.drawString(time, x + width - 62, rowY);
            rowY += rowHeight;
        }

        graphics.setColor(oldColor);
        graphics.setFont(oldFont);
    }

    public static String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        runs.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        ArrayList<Run> loaded = new ArrayList<Run>();

        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (header == null || !header.equals("APOMARIO_HIGHSCORE " + VERSION)) {
                return;
            }

            String line;
            while ((line = reader.readLine()) != null) {
                if (loaded.size() >= MAX_ENTRIES) {
                    break;
                }

                String[] values = line.split("\\t", -1);
                if (values.length != 3) {
                    return;
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                if (survivalTime < 0) {
                    return;
                }

                byte[] encodedName = Base64.getDecoder().decode(values[2]);
                String name = normalizeName(new String(encodedName, StandardCharsets.UTF_8));
                loaded.add(new Run(score, survivalTime, name));
            }

            runs.addAll(loaded);
            sortRuns();
        } catch (Exception exception) {
            runs.clear();
        }
    }

    private boolean writeStore() {
        if (store == null) {
            return false;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                writer.write("APOMARIO_HIGHSCORE " + VERSION);
                writer.newLine();

                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(
                        temporary,
                        store,
                        StandardCopyOption.REPLACE_EXISTING);
            }

            return true;
        } catch (IOException exception) {
            return false;
        }
    }

    private void sortRuns() {
        runs.sort(new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String name = playerName.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (name.length() == 0) {
            return "Player";
        }
        if (name.length() > MAX_NAME_LENGTH) {
            return name.substring(0, MAX_NAME_LENGTH);
        }
        return name;
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}