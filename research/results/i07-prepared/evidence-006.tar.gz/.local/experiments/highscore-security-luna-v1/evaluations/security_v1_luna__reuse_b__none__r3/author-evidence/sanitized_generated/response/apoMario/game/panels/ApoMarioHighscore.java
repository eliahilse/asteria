package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String SEPARATOR = "\t";
	private static final String DEFAULT_PLAYER_NAME = "Player";
	private static final int MAX_ENTRIES = 100;

	private final Path store;

	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
		this.setBackground(Color.WHITE);
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = this.normalizeName(playerName);
		int time = Math.max(0, survivalTime);

		this.playersNames.add(name);
		this.playersScores.add(score);
		this.survivalTimes.add(time);
		this.sortEntries();

		while (this.playersNames.size() > MAX_ENTRIES) {
			int last = this.playersNames.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}

		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return new ArrayList<String>(this.playersNames);
	}

	public synchronized List<Integer> getPlayersScores() {
		return new ArrayList<Integer>(this.playersScores);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return new ArrayList<Integer>(this.survivalTimes);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			ArrayList<String> lines = new ArrayList<String>();
			for (int i = 0; i < this.playersNames.size(); i++) {
				String encodedName = Base64.getEncoder().encodeToString(
						this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
				lines.add(this.playersScores.get(i) + SEPARATOR
						+ this.survivalTimes.get(i) + SEPARATOR + encodedName);
			}

			Files.write(this.store, lines, StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE);
		} catch (Exception ex) {
			// Persistence failures must not interrupt the running game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		int score = player.getPoints();
		int survivalTime = Math.max(0, level.getStartTime() - level.getTime());
		String playerName = player.getTeamName();

		this.storeRun(score, survivalTime, playerName);
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
			for (String line : lines) {
				if (line == null || line.trim().length() == 0) {
					continue;
				}

				String[] values = line.split(SEPARATOR, -1);
				if (values.length != 3) {
					throw new IllegalArgumentException("Invalid highscore entry");
				}

				int score = Integer.parseInt(values[0]);
				int time = Integer.parseInt(values[1]);
				String name = new String(
						Base64.getDecoder().decode(values[2]),
						StandardCharsets.UTF_8);

				this.playersScores.add(score);
				this.survivalTimes.add(Math.max(0, time));
				this.playersNames.add(this.normalizeName(name));
			}
			this.sortEntries();
		} catch (Exception ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private String normalizeName(String name) {
		if (name == null) {
			return DEFAULT_PLAYER_NAME;
		}

		String normalized = name.trim();
		if (normalized.length() == 0) {
			return DEFAULT_PLAYER_NAME;
		}
		return normalized;
	}

	private void sortEntries() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersNames.size(); i++) {
			order.add(i);
		}

		order.sort(new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						playersScores.get(second),
						playersScores.get(first));
				if (scoreCompare != 0) {
					return scoreCompare;
				}
				return Integer.compare(
						survivalTimes.get(first),
						survivalTimes.get(second));
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : order) {
			sortedNames.add(this.playersNames.get(index));
			sortedScores.add(this.playersScores.get(index));
			sortedTimes.add(this.survivalTimes.get(index));
		}

		this.playersNames.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.clear();
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(sortedTimes);
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 22));
			g.drawString("Highscore", 24, 34);

			g.setFont(new Font("Dialog", Font.BOLD, 14));
			g.drawString("#", 24, 62);
			g.drawString("Name", 62, 62);
			g.drawString("Points", 260, 62);
			g.drawString("Time", 350, 62);

			g.setFont(new Font("Dialog", Font.PLAIN, 14));
			for (int i = 0; i < this.playersNames.size(); i++) {
				int y = 88 + i * 23;
				g.drawString(String.valueOf(i + 1), 24, y);
				g.drawString(this.playersNames.get(i), 62, y);
				g.drawString(String.valueOf(this.playersScores.get(i)), 260, y);
				g.drawString(this.formatTime(this.survivalTimes.get(i)), 350, y);
			}
		} finally {
			g.dispose();
		}
	}

	private String formatTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", minutes, seconds);
	}
}