package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int MAX_ENTRIES = 100;

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;
        private final long order;

        private Entry(String name, int score, int survivalTime, long order) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
            this.order = order;
        }
    }

    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();
    private long nextOrder;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.setOpaque(true);
        this.setBackground(Color.WHITE);
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        int time = Math.max(0, survivalTime);

        entries.add(new Entry(name, score, time, nextOrder++));
        sortEntries();

        if (entries.size() > MAX_ENTRIES) {
            entries.subList(MAX_ENTRIES, entries.size()).clear();
        }

        persistAcrossRuns();
        repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(entries.size());
        for (Entry entry : entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            Base64.Encoder encoder = Base64.getEncoder();
            for (Entry entry : entries) {
                String encodedName = encoder.encodeToString(
                        entry.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encodedName + "\t" + entry.score + "\t"
                        + entry.survivalTime);
            }

            Files.write(temporary, lines, StandardCharsets.UTF_8);

            try {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            try {
                Path temporary = store.resolveSibling(
                        store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (Exception ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null
                || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int survivalTime = 0;
        try {
            survivalTime = level.getPassedTime();
        } catch (Exception ex) {
            survivalTime = Math.max(0, level.getStartTime() - level.getTime());
        }

        String playerName = player.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "human";
        }

        storeRun(player.getPoints(), survivalTime, playerName);
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        long seconds = Math.max(0, survivalTime) / 1000L;
        long minutes = seconds / 60L;
        long remainingSeconds = seconds % 60L;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            int width = getWidth();
            int y = 32;

            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
            g.drawString("Highscore", 20, y);

            y += 30;
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("#", 20, y);
            g.drawString("Name", 55, y);
            g.drawString("Score", Math.max(150, width - 190), y);
            g.drawString("Time", Math.max(230, width - 90), y);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            y += 24;

            for (int i = 0; i < entries.size(); i++) {
                Entry entry = entries.get(i);
                g.drawString(String.valueOf(i + 1), 20, y);
                g.drawString(entry.name, 55, y);
                g.drawString(String.valueOf(entry.score),
                        Math.max(150, width - 190), y);
                g.drawString(formatSurvivalTime(entry.survivalTime),
                        Math.max(230, width - 90), y);
                y += 22;
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        entries.clear();
        nextOrder = 0;

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                return;
            }

            Base64.Decoder decoder = Base64.getDecoder();
            for (int i = 1; i < lines.size() && entries.size() < MAX_ENTRIES; i++) {
                String line = lines.get(i);
                String[] parts = line.split("\t", -1);
                if (parts.length != 3) {
                    throw new IllegalArgumentException("Invalid highscore entry");
                }

                String name = sanitizeName(
                        new String(decoder.decode(parts[0]), StandardCharsets.UTF_8));
                int score = Integer.parseInt(parts[1]);
                int survivalTime = Integer.parseInt(parts[2]);

                if (survivalTime < 0) {
                    throw new IllegalArgumentException("Invalid survival time");
                }

                entries.add(new Entry(name, score, survivalTime, nextOrder++));
            }

            sortEntries();
        } catch (Exception ex) {
            entries.clear();
            nextOrder = 0;
        }
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                int score = Integer.compare(second.score, first.score);
                if (score != 0) {
                    return score;
                }

                int time = Integer.compare(first.survivalTime,
                        second.survivalTime);
                if (time != 0) {
                    return time;
                }

                return Long.compare(first.order, second.order);
            }
        });
    }

    private String sanitizeName(String playerName) {
        if (playerName == null) {
            return "human";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = playerName.trim();

        for (int i = 0; i < trimmed.length() && result.length() < 24; i++) {
            char character = trimmed.charAt(i);
            if (!Character.isISOControl(character)
                    && character != '\t'
                    && character != '\r'
                    && character != '\n') {
                result.append(character);
            }
        }

        if (result.length() == 0) {
            return "human";
        }
        return result.toString();
    }
}