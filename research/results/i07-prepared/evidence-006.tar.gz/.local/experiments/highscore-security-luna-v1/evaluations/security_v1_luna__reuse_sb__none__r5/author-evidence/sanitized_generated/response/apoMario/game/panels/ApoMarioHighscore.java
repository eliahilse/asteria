package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final String HEADER = "APOMARIO_HIGHSCORE_1";
	private static final int MAX_ENTRIES = 100;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(score);
		this.survivalTimes.add(survivalTime);
		this.sort();
		this.trim();
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			try (BufferedWriter writer = Files.newBufferedWriter(
					this.store,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE)) {

				writer.write(HEADER);
				writer.newLine();

				for (int i = 0; i < this.playersScores.size(); i++) {
					writer.write(Integer.toString(this.playersScores.get(i)));
					writer.write('\t');
					writer.write(Integer.toString(this.survivalTimes.get(i)));
					writer.write('\t');
					writer.write(Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8)));
					writer.newLine();
				}
			}
		} catch (IOException ex) {
			// Persistence failures do not interrupt the running game.
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selectedPlayer = null;

		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null || !player.isBVisible()) {
				continue;
			}
			if (selectedPlayer == null || player.getPoints() > selectedPlayer.getPoints()) {
				selectedPlayer = player;
			}
		}

		if (selectedPlayer == null) {
			for (ApoMarioPlayer player : level.getPlayers()) {
				if (player != null && (selectedPlayer == null
						|| player.getPoints() > selectedPlayer.getPoints())) {
					selectedPlayer = player;
				}
			}
		}

		if (selectedPlayer == null) {
			return;
		}

		String playerName = selectedPlayer.getTeamName();
		if (playerName == null || playerName.trim().length() == 0) {
			playerName = selectedPlayer.getAuthor();
		}
		if (playerName == null || playerName.trim().length() == 0) {
			playerName = "Player";
		}

		int survivalTime = level.getStartTime() - level.getTime();
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.storeRun(selectedPlayer.getPoints(), survivalTime, playerName);
	}

	public synchronized void render(Graphics2D graphics) {
		if (graphics == null) {
			return;
		}

		int width = this.getWidth();
		int height = this.getHeight();

		if (width <= 0) {
			width = 480;
		}
		if (height <= 0) {
			height = 360;
		}

		graphics.setRenderingHint(
				RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);

		graphics.setColor(new Color(245, 245, 245));
		graphics.fillRect(0, 0, width, height);

		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
		graphics.drawString("Highscore", 20, 32);

		graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
		graphics.drawString("Rank", 20, 60);
		graphics.drawString("Player", 80, 60);
		graphics.drawString("Score", 285, 60);
		graphics.drawString("Time", 375, 60);

		graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));

		for (int i = 0; i < this.playersScores.size(); i++) {
			int y = 85 + i * 24;
			if (y > height - 8) {
				break;
			}

			graphics.drawString(Integer.toString(i + 1), 25, y);
			graphics.drawString(this.playersNames.get(i), 80, y);
			graphics.drawString(Integer.toString(this.playersScores.get(i)), 285, y);
			graphics.drawString(formatTime(this.survivalTimes.get(i)), 375, y);
		}
	}

	@Override
	protected synchronized void paintComponent(java.awt.Graphics graphics) {
		super.paintComponent(graphics);
		this.render((Graphics2D) graphics);
	}

	private void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line = reader.readLine();
			if (!HEADER.equals(line)) {
				return;
			}

			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\\t", -1);
				if (values.length != 3) {
					continue;
				}

				try {
					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					String name = new String(
							Base64.getDecoder().decode(values[2]),
							StandardCharsets.UTF_8);

					if (name.length() == 0) {
						name = "Player";
					}
					if (time < 0) {
						time = 0;
					}

					scores.add(score);
					times.add(time);
					names.add(name);
				} catch (IllegalArgumentException ex) {
					// Ignore malformed records and retain valid records.
				}
			}

			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
			this.playersNames.addAll(names);
			this.playersScores.addAll(scores);
			this.survivalTimes.addAll(times);
			this.sort();
			this.trim();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(i);
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second),
						ApoMarioHighscore.this.playersScores.get(first));
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : order) {
			sortedNames.add(this.playersNames.get(index));
			sortedScores.add(this.playersScores.get(index));
			sortedTimes.add(this.survivalTimes.get(index));
		}

		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.addAll(sortedTimes);
	}

	private void trim() {
		while (this.playersScores.size() > MAX_ENTRIES) {
			int last = this.playersScores.size() - 1;
			this.playersNames.remove(last);
			this.playersScores.remove(last);
			this.survivalTimes.remove(last);
		}
	}

	private static String formatTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", minutes, seconds);
	}
}