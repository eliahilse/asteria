package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName;
		if (name == null) {
			name = "";
		}
		name = name.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sort();
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			try (BufferedWriter writer = Files.newBufferedWriter(
					this.store,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE)) {
				for (int i = 0; i < this.playersScores.size(); i++) {
					String name = Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(Integer.toString(this.playersScores.get(i)));
					writer.write('\t');
					writer.write(Integer.toString(this.survivalTimes.get(i)));
					writer.write('\t');
					writer.write(name);
					writer.newLine();
				}
			}
		} catch (IOException ex) {
			// A missing or inaccessible score store must not stop the game.
		}
	}

	public void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null || !player.isBVisible()) {
				continue;
			}
			if (selected == null || player.getPoints() > selected.getPoints()) {
				selected = player;
			}
		}

		if (selected == null) {
			selected = level.getPlayers().get(0);
		}
		if (selected == null) {
			return;
		}

		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}

		String name = selected.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		this.storeRun(selected.getPoints(), elapsed, name);
	}

	private void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				try {
					String[] values = line.split("\t", -1);
					if (values.length != 3) {
						continue;
					}

					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					String name = new String(
							Base64.getDecoder().decode(values[2]),
							StandardCharsets.UTF_8);

					if (name.length() == 0) {
						name = "Player";
					}

					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
					this.playersNames.add(name);
				} catch (RuntimeException ex) {
					this.playersNames.clear();
					this.playersScores.clear();
					this.survivalTimes.clear();
					return;
				}
			}
			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()),
						ApoMarioHighscore.this.playersScores.get(first.intValue()));
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			names.add(this.playersNames.get(index.intValue()));
			scores.add(this.playersScores.get(index.intValue()));
			times.add(this.survivalTimes.get(index.intValue()));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private String formatTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	@Override
	protected void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		g.setRenderingHint(
				RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		g.setColor(Color.WHITE);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());

		g.setColor(Color.BLACK);
		g.setFont(new Font("Dialog", Font.BOLD, 24));
		g.drawString("Highscore", 24, 36);

		g.setFont(new Font("Dialog", Font.BOLD, 14));
		g.drawString("#", 24, 66);
		g.drawString("Points", 64, 66);
		g.drawString("Player", 150, 66);
		g.drawString("Time", 330, 66);

		g.setFont(new Font("Dialog", Font.PLAIN, 14));
		int y = 92;
		for (int i = 0; i < this.playersScores.size(); i++) {
			g.drawString(Integer.toString(i + 1), 24, y);
			g.drawString(Integer.toString(this.playersScores.get(i)), 64, y);
			g.drawString(this.playersNames.get(i), 150, y);
			g.drawString(this.formatTime(this.survivalTimes.get(i)), 330, y);
			y += 24;
			if (y > this.getHeight() - 10) {
				break;
			}
		}

		g.dispose();
	}
}