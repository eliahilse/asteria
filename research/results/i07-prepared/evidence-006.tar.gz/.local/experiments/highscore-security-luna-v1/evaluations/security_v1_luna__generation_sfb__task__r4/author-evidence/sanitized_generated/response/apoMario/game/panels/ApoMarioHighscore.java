package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {
    private static final long serialVersionUID = 1L;

    private static final int MAGIC = 0x41504F48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
        setOpaque(true);
        setBackground(Color.WHITE);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < Integer.MIN_VALUE) {
            return false;
        }

        String name = cleanName(playerName);
        int time = Math.max(0, survivalTime);

        runs.add(new Run(name, score, time));
        sortRuns();

        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }

        persistAcrossRuns();
        repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(runs.size());
        for (Run run : runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(Integer.valueOf(run.score));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(runs.size());
        for (Run run : runs) {
            result.add(Integer.valueOf(run.survivalTime));
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsedMilliseconds = level.getPassedTime();
        int survivalSeconds = Math.max(0, elapsedMilliseconds / 1000);
        storeRun(player.getPoints(), survivalSeconds, player.getTeamName());
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }

        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (DataOutputStream output = new DataOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(temporary)))) {
                output.writeInt(MAGIC);
                output.writeInt(VERSION);
                output.writeInt(runs.size());

                for (Run run : runs) {
                    output.writeUTF(run.name);
                    output.writeInt(run.score);
                    output.writeInt(run.survivalTime);
                }
            }

            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailure) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
        }
    }

    public static String formatSurvivalTime(int seconds) {
        int safeSeconds = Math.max(0, seconds);
        int minutes = safeSeconds / 60;
        int remainingSeconds = safeSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes),
                Integer.valueOf(remainingSeconds));
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
            g.drawString("Highscore", 20, 30);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            int y = 58;
            int rank = 1;

            for (Run run : runs) {
                g.drawString(rank + ".", 20, y);
                g.drawString(run.name, 55, y);
                g.drawString(String.valueOf(run.score), 190, y);
                g.drawString(formatSurvivalTime(run.survivalTime), 270, y);
                y += 24;
                rank++;
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        runs.clear();

        if (store == null || !Files.isRegularFile(store)) {
            return;
        }

        try (DataInputStream input = new DataInputStream(
                new BufferedInputStream(Files.newInputStream(store)))) {
            if (input.readInt() != MAGIC || input.readInt() != VERSION) {
                return;
            }

            int count = input.readInt();
            if (count < 0 || count > MAX_ENTRIES) {
                runs.clear();
                return;
            }

            for (int i = 0; i < count; i++) {
                String name = cleanName(input.readUTF());
                int score = input.readInt();
                int survivalTime = input.readInt();

                if (survivalTime < 0) {
                    throw new IOException("Invalid survival time");
                }

                runs.add(new Run(name, score, survivalTime));
            }

            sortRuns();
        } catch (IOException | RuntimeException ex) {
            runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                int scoreOrder = Integer.compare(second.score, first.score);
                if (scoreOrder != 0) {
                    return scoreOrder;
                }

                int timeOrder = Integer.compare(first.survivalTime, second.survivalTime);
                if (timeOrder != 0) {
                    return timeOrder;
                }

                return first.name.compareToIgnoreCase(second.name);
            }
        });
    }

    private static String cleanName(String value) {
        if (value == null) {
            return "Human";
        }

        StringBuilder result = new StringBuilder();
        String trimmed = value.trim();

        for (int i = 0; i < trimmed.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = trimmed.charAt(i);
            if (!Character.isISOControl(character)) {
                result.append(character);
            }
        }

        if (result.length() == 0) {
            return "Human";
        }

        return result.toString();
    }

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }
}