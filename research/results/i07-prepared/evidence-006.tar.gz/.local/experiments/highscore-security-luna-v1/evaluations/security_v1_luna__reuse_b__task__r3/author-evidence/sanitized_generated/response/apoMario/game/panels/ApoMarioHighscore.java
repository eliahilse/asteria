package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }

        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int points = Math.max(0, score);
        int time = Math.max(0, survivalTime);

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(points));
        this.survivalTimes.add(Integer.valueOf(time));
        this.sort();

        try {
            this.persistAcrossRuns();
            return true;
        } catch (RuntimeException ex) {
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        Path parent = this.store.toAbsolutePath().getParent();

        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");

            try (BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8)) {
                for (int i = 0; i < this.playersScores.size(); i++) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));

                    writer.write(Integer.toString(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            }

            try {
                Files.move(
                        temporary,
                        this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(
                        temporary,
                        this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to persist highscores", ex);
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int score = player.getPoints();
        int survivalTime = level.getStartTime() - level.getTime();

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        String playerName = player.getTeamName();
        this.storeRun(score, survivalTime, playerName);
    }

    private synchronized void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<String> loadedNames = new ArrayList<String>();
        ArrayList<Integer> loadedScores = new ArrayList<Integer>();
        ArrayList<Integer> loadedTimes = new ArrayList<Integer>();

        try (BufferedReader reader = Files.newBufferedReader(
                this.store,
                StandardCharsets.UTF_8)) {
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore record");
                }

                int score = Integer.parseInt(values[0]);
                int time = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);

                loadedScores.add(Integer.valueOf(Math.max(0, score)));
                loadedTimes.add(Integer.valueOf(Math.max(0, time)));
                loadedNames.add(normalizeName(name));
            }

            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();

            this.playersNames.addAll(loadedNames);
            this.playersScores.addAll(loadedScores);
            this.survivalTimes.addAll(loadedTimes);
            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        } catch (RuntimeException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indices = new ArrayList<Integer>();

        for (int i = 0; i < this.playersScores.size(); i++) {
            indices.add(Integer.valueOf(i));
        }

        Collections.sort(indices, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : indices) {
            int position = index.intValue();
            sortedNames.add(this.playersNames.get(position));
            sortedScores.add(this.playersScores.get(position));
            sortedTimes.add(this.survivalTimes.get(position));
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        this.playersNames.addAll(sortedNames);
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.addAll(sortedTimes);
    }

    private String normalizeName(String playerName) {
        if (playerName == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }

        return name;
    }
}