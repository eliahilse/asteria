package apoMario.game.panels;

import apoMario.game.ApoMarioSearch;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;
import apoMario.game.panels.ApoMarioModelMenu;
import org.apogames.entity.ApoAnimation;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.nio.file.Path;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscorePanel extends ApoMarioModelMenu {

	public static final String FUNCTION_BACK = "backHighscore";

	private final ApoMarioHighscore highscore;

	public ApoMarioHighscorePanel(ApoMarioPanel game, Path store) {
		super(game);
		this.highscore = new ApoMarioHighscore(store);
	}

	public ApoMarioHighscore getHighscore() {
		return this.highscore;
	}

	@Override
	public void init() {
		super.init();
		this.makeBackground();
		this.makeBackgroundAnimation();
		this.makeRunner();
		this.makeSearch();
	}

	@Override
	public void makeBackground() {
		this.setIBackground(this.getGame().getBackgroundImage());
	}

	@Override
	public void makeBackgroundAnimation() {
		this.setBackgroundAnimation(new java.util.ArrayList<org.apogames.entity.ApoAnimation>());
	}

	@Override
	public void makeRunner() {
	}

	@Override
	public void makeSearch() {
		this.setSearch(new apoMario.game.ApoMarioSearch());
	}

	@Override
	public void keyButtonReleased(int button, char character) {
		if (button == KeyEvent.VK_ESCAPE || button == KeyEvent.VK_ENTER) {
			this.getGame().setMenu();
		}
	}

	@Override
	public void mouseButtonFunction(String function) {
		if (FUNCTION_BACK.equals(function)) {
			this.getGame().setMenu();
		}
	}

	@Override
	public void releasedEnter() {
		this.getGame().setMenu();
	}

	@Override
	public void excecuteFunction() {
		if (FUNCTION_BACK.equals(this.getExcecuteFunction())) {
			this.getGame().setMenu();
		}
	}

	@Override
	public void mouseButtonReleased(int x, int y) {
	}

	@Override
	public boolean mouseDragged(int x, int y) {
		return false;
	}

	@Override
	public boolean mouseMoved(int x, int y) {
		return false;
	}

	@Override
	public boolean mousePressed(int x, int y, boolean bRight) {
		return false;
	}

	@Override
	public void think(int delta) {
	}

	@Override
	public void render(Graphics2D g) {
		if (this.getIBackground() != null) {
			g.drawImage(this.getIBackground(), 0, 0, null);
		}

		g.setColor(Color.BLACK);
		g.setFont(ApoMarioConstants.FONT_MENU);

		String title = "HIGHSCORE";
		int titleWidth = g.getFontMetrics().stringWidth(title);
		g.drawString(title, ApoMarioConstants.GAME_WIDTH / 2 - titleWidth / 2, 35);

		List<String> names = this.highscore.getPlayersNames();
		List<Integer> scores = this.highscore.getPlayersScores();
		List<Integer> times = this.highscore.getSurvivalTimes();

		g.setFont(ApoMarioConstants.FONT_STATISTICS);
		g.drawString("NAME", 35, 65);
		g.drawString("POINTS", 170, 65);
		g.drawString("TIME", 270, 65);

		int max = Math.min(names.size(), 10);
		for (int i = 0; i < max; i++) {
			int y = 90 + i * 18;
			g.drawString((i + 1) + ". " + names.get(i), 20, y);
			g.drawString(String.valueOf(scores.get(i)), 170, y);
			g.drawString(ApoMarioHighscore.formatTime(times.get(i)), 270, y);
		}

		g.drawString("ESC: BACK", 20, ApoMarioConstants.GAME_HEIGHT - 15);
	}
}