package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

	private static final int MAX_NAME_LENGTH = 256;

	private final Path store;
	private final ArrayList<String> names;
	private final ArrayList<Integer> scores;
	private final ArrayList<Integer> survivalTimes;

	private ApoMarioLevel lastRecordedLevel;
	private String lastRecordedName;
	private int lastRecordedScore;
	private int lastRecordedTime;
	private boolean hasLastRecordedRun;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.names = new ArrayList<String>();
		this.scores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		if (name.length() == 0) {
			name = "Player";
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.names.add(name);
		this.scores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sort();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return new ArrayList<String>(this.names);
	}

	public synchronized List<Integer> getPlayersScores() {
		return new ArrayList<Integer>(this.scores);
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return new ArrayList<Integer>(this.survivalTimes);
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		Path parent = this.store.toAbsolutePath().getParent();
		Path temporary = null;

		try {
			if (parent != null) {
				Files.createDirectories(parent);
				temporary = Files.createTempFile(parent, this.store.getFileName().toString(), ".tmp");
			} else {
				temporary = Files.createTempFile("apo-mario-highscore", ".tmp");
			}

			BufferedWriter writer = Files.newBufferedWriter(
					temporary,
					StandardCharsets.UTF_8);

			try {
				for (int i = 0; i < this.scores.size(); i++) {
					String encodedName = Base64.getEncoder().encodeToString(
							this.names.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(Integer.toString(this.scores.get(i).intValue()));
					writer.write('\t');
					writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
					writer.write('\t');
					writer.write(encodedName);
					writer.newLine();
				}
			} finally {
				writer.close();
			}

			try {
				Files.move(
						temporary,
						this.store,
						StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException ex) {
				Files.move(
						temporary,
						this.store,
						StandardCopyOption.REPLACE_EXISTING);
			}
			temporary = null;
		} catch (IOException ex) {
			// Persistence failures do not interrupt the running game.
		} finally {
			if (temporary != null) {
				try {
					Files.deleteIfExists(temporary);
				} catch (IOException ex) {
					// The temporary file can be removed on the next run.
				}
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selected = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null) {
				continue;
			}
			if (selected == null || player.getPoints() > selected.getPoints()) {
				selected = player;
			}
		}

		if (selected == null) {
			return;
		}

		String name = normalizeName(selected.getTeamName());
		if (name.length() == 0) {
			name = "Player";
		}

		int score = selected.getPoints();
		int survivalTime = getSurvivalTime(level);

		if (this.hasLastRecordedRun
				&& this.lastRecordedLevel == level
				&& this.lastRecordedScore == score
				&& this.lastRecordedTime == survivalTime
				&& this.lastRecordedName.equals(name)) {
			return;
		}

		this.storeRun(score, survivalTime, name);
		this.lastRecordedLevel = level;
		this.lastRecordedScore = score;
		this.lastRecordedTime = survivalTime;
		this.lastRecordedName = name;
		this.hasLastRecordedRun = true;
		this.persistAcrossRuns();
	}

	private int getSurvivalTime(ApoMarioLevel level) {
		int elapsed;

		try {
			elapsed = level.getPassedTime();
		} catch (RuntimeException ex) {
			elapsed = level.getStartTime() - level.getTime();
		}

		if (elapsed < 0) {
			elapsed = 0;
		}
		return elapsed;
	}

	private synchronized void load() {
		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		ArrayList<String> loadedNames = new ArrayList<String>();
		ArrayList<Integer> loadedScores = new ArrayList<Integer>();
		ArrayList<Integer> loadedTimes = new ArrayList<Integer>();

		try {
			BufferedReader reader = Files.newBufferedReader(
					this.store,
					StandardCharsets.UTF_8);

			try {
				String line;
				while ((line = reader.readLine()) != null) {
					String[] values = line.split("\t", -1);
					if (values.length != 3) {
						throw new IOException("Invalid highscore record");
					}

					int score = Integer.parseInt(values[0]);
					int time = Integer.parseInt(values[1]);
					byte[] decoded = Base64.getDecoder().decode(values[2]);
					String name = normalizeName(new String(decoded, StandardCharsets.UTF_8));

					if (name.length() == 0 || name.length() > MAX_NAME_LENGTH || time < 0) {
						throw new IOException("Invalid highscore value");
					}

					loadedScores.add(Integer.valueOf(score));
					loadedTimes.add(Integer.valueOf(time));
					loadedNames.add(name);
				}
			} finally {
				reader.close();
			}

			this.names.clear();
			this.scores.clear();
			this.survivalTimes.clear();
			this.names.addAll(loadedNames);
			this.scores.addAll(loadedScores);
			this.survivalTimes.addAll(loadedTimes);
			this.sort();
		} catch (IOException ex) {
			this.names.clear();
			this.scores.clear();
			this.survivalTimes.clear();
		} catch (RuntimeException ex) {
			this.names.clear();
			this.scores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.scores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						scores.get(second.intValue()).intValue(),
						scores.get(first.intValue()).intValue());
				return scoreCompare != 0
						? scoreCompare
						: Integer.compare(
								survivalTimes.get(first.intValue()).intValue(),
								survivalTimes.get(second.intValue()).intValue());
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			sortedNames.add(this.names.get(i));
			sortedScores.add(this.scores.get(i));
			sortedTimes.add(this.survivalTimes.get(i));
		}

		this.names.clear();
		this.scores.clear();
		this.survivalTimes.clear();
		this.names.addAll(sortedNames);
		this.scores.addAll(sortedScores);
		this.survivalTimes.addAll(sortedTimes);
	}

	private String normalizeName(String name) {
		if (name == null) {
			return "";
		}
		String normalized = name.trim();
		if (normalized.length() > MAX_NAME_LENGTH) {
			return normalized.substring(0, MAX_NAME_LENGTH);
		}
		return normalized;
	}
}