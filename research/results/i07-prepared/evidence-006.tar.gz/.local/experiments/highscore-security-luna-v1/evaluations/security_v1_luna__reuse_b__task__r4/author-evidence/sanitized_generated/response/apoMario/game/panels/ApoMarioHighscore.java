package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final int FILE_VERSION = 1;
	private static final int MAX_NAME_LENGTH = 64;

	private final Path store;

	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.setBackground(Color.WHITE);
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}
		if (name.length() > MAX_NAME_LENGTH) {
			name = name.substring(0, MAX_NAME_LENGTH);
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
		this.sortEntries();
		this.persistAcrossRuns();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (DataOutputStream output = new DataOutputStream(
					new BufferedOutputStream(Files.newOutputStream(temporary)))) {
				output.writeInt(FILE_VERSION);
				output.writeInt(this.playersScores.size());

				for (int i = 0; i < this.playersScores.size(); i++) {
					output.writeInt(this.playersScores.get(i).intValue());
					output.writeInt(this.survivalTimes.get(i).intValue());

					byte[] name = this.playersNames.get(i).getBytes(StandardCharsets.UTF_8);
					output.writeInt(name.length);
					output.write(name);
				}
			}

			try {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING,
						java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (java.nio.file.AtomicMoveNotSupportedException ex) {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
				Files.deleteIfExists(temporary);
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		String name = player.getTeamName();
		if (name == null || name.trim().length() == 0) {
			if (player.getAi() != null) {
				name = player.getAi().getTeamName();
			}
		}
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		int survivalTime = 0;
		try {
			survivalTime = level.getPassedTime();
		} catch (RuntimeException ex) {
			survivalTime = Math.max(0, level.getStartTime() - level.getTime());
		}

		this.storeRun(player.getPoints(), survivalTime, name);
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (DataInputStream input = new DataInputStream(
				new BufferedInputStream(Files.newInputStream(this.store)))) {
			if (input.readInt() != FILE_VERSION) {
				return;
			}

			int count = input.readInt();
			if (count < 0 || count > 100000) {
				return;
			}

			for (int i = 0; i < count; i++) {
				int score = input.readInt();
				int survivalTime = input.readInt();
				int nameLength = input.readInt();

				if (nameLength < 0 || nameLength > MAX_NAME_LENGTH * 4) {
					throw new IOException("Invalid highscore name length");
				}

				byte[] nameBytes = new byte[nameLength];
				input.readFully(nameBytes);

				String name = new String(nameBytes, StandardCharsets.UTF_8).trim();
				if (name.length() == 0) {
					name = "Player";
				}

				this.playersScores.add(Integer.valueOf(score));
				this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
				this.playersNames.add(name);
			}

			this.sortEntries();
		} catch (EOFException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		} catch (IOException | RuntimeException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sortEntries() {
		ArrayList<Integer> indices = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			indices.add(Integer.valueOf(i));
		}

		Collections.sort(indices, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				int scoreCompare = Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
				return scoreCompare != 0 ? scoreCompare : Integer.compare(
						first.intValue(), second.intValue());
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : indices) {
			int i = index.intValue();
			sortedNames.add(this.playersNames.get(i));
			sortedScores.add(this.playersScores.get(i));
			sortedTimes.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.clear();
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(sortedTimes);
	}

	private String formatTime(int milliseconds) {
		int totalSeconds = Math.max(0, milliseconds) / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 24));
			g.drawString("Highscore", 24, 36);

			g.setFont(new Font("Dialog", Font.BOLD, 14));
			g.drawString("#", 24, 68);
			g.drawString("Player", 64, 68);
			g.drawString("Points", 270, 68);
			g.drawString("Time", 370, 68);

			g.setFont(new Font("Dialog", Font.PLAIN, 14));
			for (int i = 0; i < this.playersScores.size(); i++) {
				int y = 94 + i * 24;
				g.drawString(String.valueOf(i + 1), 24, y);
				g.drawString(this.playersNames.get(i), 64, y);
				g.drawString(String.valueOf(this.playersScores.get(i)), 270, y);
				g.drawString(this.formatTime(this.survivalTimes.get(i)), 370, y);
			}
		} finally {
			g.dispose();
		}
	}
}