package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;

	private static final int DEFAULT_WIDTH = 640;
	private static final int DEFAULT_HEIGHT = 480;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.setOpaque(true);
		this.setBackground(Color.WHITE);
		this.load();
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = playerName == null ? "" : playerName.trim();
		if (name.length() == 0) {
			name = "Player";
		}

		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sortEntries();
		this.persistAcrossRuns();
		this.repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.toAbsolutePath().getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
				for (int i = 0; i < this.playersScores.size(); i++) {
					String encodedName = Base64.getEncoder().encodeToString(
							this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
					writer.write(encodedName);
					writer.write('\t');
					writer.write(String.valueOf(this.playersScores.get(i).intValue()));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
					writer.newLine();
				}
			}

			try {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING,
						StandardCopyOption.ATOMIC_MOVE);
			} catch (IOException ex) {
				Files.move(temporary, this.store, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer selectedPlayer = null;
		for (ApoMarioPlayer player : level.getPlayers()) {
			if (player == null) {
				continue;
			}
			if (selectedPlayer == null
					|| player.getPoints() > selectedPlayer.getPoints()
					|| (!selectedPlayer.isBVisible() && player.isBVisible())) {
				selectedPlayer = player;
			}
		}

		if (selectedPlayer == null) {
			return;
		}

		int elapsed = level.getStartTime() - level.getTime();
		if (elapsed < 0) {
			elapsed = 0;
		}

		String name = selectedPlayer.getTeamName();
		if (name == null || name.trim().length() == 0) {
			name = "Player";
		}

		this.storeRun(selectedPlayer.getPoints(), elapsed, name);
	}

	public synchronized String getSurvivalTimeText(int index) {
		if (index < 0 || index >= this.survivalTimes.size()) {
			return "00:00";
		}
		return formatTime(this.survivalTimes.get(index).intValue());
	}

	public static String formatTime(int milliseconds) {
		long seconds = Math.max(0L, milliseconds) / 1000L;
		long minutes = seconds / 60L;
		long remainingSeconds = seconds % 60L;
		return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(remainingSeconds));
	}

	public void render(Graphics2D graphics) {
		if (graphics == null) {
			return;
		}

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, this.getWidth(), this.getHeight());

			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 26));
			g.drawString("Highscore", 30, 42);

			g.setFont(new Font("Dialog", Font.BOLD, 16));
			g.drawString("#", 35, 78);
			g.drawString("Name", 80, 78);
			g.drawString("Score", 360, 78);
			g.drawString("Time", 470, 78);

			g.setFont(new Font("Dialog", Font.PLAIN, 16));
			synchronized (this) {
				for (int i = 0; i < this.playersScores.size(); i++) {
					int y = 108 + i * 26;
					g.drawString(String.valueOf(i + 1), 35, y);
					g.drawString(this.playersNames.get(i), 80, y);
					g.drawString(String.valueOf(this.playersScores.get(i)), 360, y);
					g.drawString(formatTime(this.survivalTimes.get(i)), 470, y);
				}
			}
		} finally {
			g.dispose();
		}
	}

	@Override
	protected void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		this.render((Graphics2D) graphics);
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\t", -1);
				if (values.length != 3) {
					throw new IOException("Invalid highscore record");
				}

				String name = new String(Base64.getDecoder().decode(values[0]), StandardCharsets.UTF_8);
				int score = Integer.parseInt(values[1]);
				int survivalTime = Integer.parseInt(values[2]);

				if (name.trim().length() == 0 || score < 0 || survivalTime < 0) {
					throw new IOException("Invalid highscore values");
				}

				this.playersNames.add(name);
				this.playersScores.add(Integer.valueOf(score));
				this.survivalTimes.add(Integer.valueOf(survivalTime));
			}
			this.sortEntries();
		} catch (Exception ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sortEntries() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
						ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> sortedNames = new ArrayList<String>();
		ArrayList<Integer> sortedScores = new ArrayList<Integer>();
		ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			sortedNames.add(this.playersNames.get(i));
			sortedScores.add(this.playersScores.get(i));
			sortedTimes.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersNames.addAll(sortedNames);
		this.playersScores.clear();
		this.playersScores.addAll(sortedScores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(sortedTimes);
	}

	@Override
	public java.awt.Dimension getPreferredSize() {
		return new java.awt.Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT);
	}
}