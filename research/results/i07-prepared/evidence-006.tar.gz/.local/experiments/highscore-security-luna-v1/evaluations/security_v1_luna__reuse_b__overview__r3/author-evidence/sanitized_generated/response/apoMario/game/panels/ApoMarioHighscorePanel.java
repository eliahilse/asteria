package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.nio.file.Path;
import java.util.List;

import javax.swing.JPanel;

public class ApoMarioHighscorePanel extends JPanel {

    private static final long serialVersionUID = 1L;

    private final ApoMarioHighscore highscore;

    public ApoMarioHighscorePanel(Path store) {
        this.highscore = new ApoMarioHighscore(store);
        this.setBackground(Color.WHITE);
    }

    public ApoMarioHighscore getHighscore() {
        return this.highscore;
    }

    public void refresh() {
        this.highscore.persistAcrossRuns();
        this.repaint();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setRenderingHint(
                    RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            List<String> names = this.highscore.getPlayersNames();
            List<Integer> scores = this.highscore.getPlayersScores();
            List<Integer> times = this.highscore.getSurvivalTimes();

            g.setColor(Color.BLACK);
            g.setFont(new Font("Dialog", Font.BOLD, 24));
            g.drawString("Highscore", 24, 36);

            g.setFont(new Font("Dialog", Font.BOLD, 14));
            g.drawString("#", 24, 68);
            g.drawString("Name", 60, 68);
            g.drawString("Points", 250, 68);
            g.drawString("Time", 350, 68);

            g.setFont(new Font("Dialog", Font.PLAIN, 14));
            int y = 94;
            for (int i = 0; i < names.size(); i++) {
                g.drawString(Integer.toString(i + 1), 24, y);
                g.drawString(names.get(i), 60, y);
                g.drawString(Integer.toString(scores.get(i).intValue()), 250, y);
                g.drawString(
                        ApoMarioHighscore.formatSurvivalTime(times.get(i).intValue()),
                        350,
                        y);
                y += 22;
            }

            if (names.isEmpty()) {
                g.setColor(Color.DARK_GRAY);
                g.drawString("No runs recorded", 60, 94);
            }
        } finally {
            g.dispose();
        }
    }
}