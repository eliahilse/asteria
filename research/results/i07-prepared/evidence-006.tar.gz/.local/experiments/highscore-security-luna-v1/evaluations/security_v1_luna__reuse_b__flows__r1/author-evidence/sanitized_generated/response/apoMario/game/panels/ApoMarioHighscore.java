package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

public class ApoMarioHighscore {

    private static final int MAX_NAME_LENGTH = 64;
    private static final int MAX_ENTRIES = 1000;

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final ArrayList<Entry> entries;
    private final Set<ApoMarioLevel> recordedLevels;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.entries = new ArrayList<Entry>();
        this.recordedLevels = Collections.newSetFromMap(
                new IdentityHashMap<ApoMarioLevel, Boolean>());
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int safeScore = Math.max(0, score);
        int safeTime = Math.max(0, survivalTime);

        this.entries.add(new Entry(name, safeScore, safeTime));
        this.sortEntries();

        if (this.entries.size() > MAX_ENTRIES) {
            this.entries.subList(MAX_ENTRIES, this.entries.size()).clear();
        }

        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.entries.size());
        for (Entry entry : this.entries) {
            result.add(entry.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {
                for (Entry entry : this.entries) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            entry.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            }
        } catch (IOException ex) {
            // A failed save must not interrupt the running game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || this.recordedLevels.contains(level)) {
            return;
        }

        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty() || players.get(0) == null) {
            return;
        }

        ApoMarioPlayer player = players.get(0);
        String playerName = player.getTeamName();
        int score = player.getPoints();
        int survivalTime = level.getPassedTime();

        this.storeRun(score, survivalTime, playerName);
        this.recordedLevels.add(level);
    }

    public static String formatSurvivalTime(int milliseconds) {
        long totalSeconds = Math.max(0, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private synchronized void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(
                this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null
                    && this.entries.size() < MAX_ENTRIES) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    if (score < 0 || survivalTime < 0) {
                        continue;
                    }

                    byte[] decoded = Base64.getDecoder().decode(values[2]);
                    String name = normalizeName(new String(decoded, StandardCharsets.UTF_8));
                    this.entries.add(new Entry(name, score, survivalTime));
                } catch (IllegalArgumentException ex) {
                    // Ignore malformed records and retain valid records.
                }
            }
            this.sortEntries();
        } catch (IOException ex) {
            this.entries.clear();
        }
    }

    private void sortEntries() {
        this.entries.sort(new Comparator<Entry>() {
            @Override
            public int compare(Entry first, Entry second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return "Player";
        }
        if (name.length() > MAX_NAME_LENGTH) {
            return name.substring(0, MAX_NAME_LENGTH);
        }
        return name;
    }
}