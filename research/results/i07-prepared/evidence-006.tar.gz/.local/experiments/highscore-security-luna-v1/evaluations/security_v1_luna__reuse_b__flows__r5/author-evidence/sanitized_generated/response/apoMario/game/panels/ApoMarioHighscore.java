package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;
    private static final String SEPARATOR = "\t";

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;

        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    private final Path store;
    private final ArrayList<Run> runs;
    private final Map<ApoMarioLevel, Boolean> recordedLevels;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        this.recordedLevels = new IdentityHashMap<ApoMarioLevel, Boolean>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.runs.add(new Run(name, score, survivalTime));
        this.sortRuns();
        if (this.runs.size() > MAX_ENTRIES) {
            this.runs.subList(MAX_ENTRIES, this.runs.size()).clear();
        }

        try {
            this.write();
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        try {
            this.write();
        } catch (IOException ex) {
            // Persistence failures must not terminate the game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || this.recordedLevels.containsKey(level)) {
            return;
        }

        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty() || players.get(0) == null) {
            return;
        }

        ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName();
        int score = player.getPoints();
        int survivalTime = level.getPassedTime();

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.recordedLevels.put(level, Boolean.TRUE);
        this.storeRun(score, survivalTime, name);
    }

    public static String formatSurvivalTime(int survivalTime) {
        int seconds = Math.max(0, survivalTime) / 1000;
        int minutes = seconds / 60;
        seconds %= 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void load() {
        if (!Files.exists(this.store)) {
            return;
        }

        ArrayList<Run> loaded = new ArrayList<Run>();
        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            for (String line : lines) {
                if (line.trim().length() == 0) {
                    continue;
                }

                String[] values = line.split(SEPARATOR, -1);
                if (values.length != 3) {
                    throw new IOException("Invalid highscore entry");
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);

                if (score < 0 || survivalTime < 0 || name.length() == 0) {
                    throw new IOException("Invalid highscore value");
                }

                loaded.add(new Run(normalizeName(name), score, survivalTime));
            }

            this.runs.clear();
            this.runs.addAll(loaded);
            this.sortRuns();
            if (this.runs.size() > MAX_ENTRIES) {
                this.runs.subList(MAX_ENTRIES, this.runs.size()).clear();
            }
        } catch (Exception ex) {
            this.runs.clear();
        }
    }

    private void sortRuns() {
        Collections.sort(this.runs, new Comparator<Run>() {
            @Override
            public int compare(Run first, Run second) {
                return Integer.compare(second.score, first.score);
            }
        });
    }

    private void write() throws IOException {
        Path parent = this.store.toAbsolutePath().getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }

        Path absoluteStore = this.store.toAbsolutePath();
        Path temporary = Files.createTempFile(
                absoluteStore.getParent(),
                absoluteStore.getFileName().toString(),
                ".tmp");

        ArrayList<String> lines = new ArrayList<String>(this.runs.size());
        for (Run run : this.runs) {
            String encodedName = Base64.getEncoder().encodeToString(
                    run.name.getBytes(StandardCharsets.UTF_8));
            lines.add(run.score + SEPARATOR + run.survivalTime + SEPARATOR + encodedName);
        }

        try {
            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(
                        temporary,
                        absoluteStore,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(
                        temporary,
                        absoluteStore,
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "";
        }

        String normalized = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (normalized.length() > 64) {
            normalized = normalized.substring(0, 64);
        }
        return normalized;
    }
}