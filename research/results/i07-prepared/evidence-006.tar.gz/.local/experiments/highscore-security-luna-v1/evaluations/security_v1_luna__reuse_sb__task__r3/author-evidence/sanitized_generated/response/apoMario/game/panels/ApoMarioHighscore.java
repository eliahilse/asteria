package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(score);
        this.survivalTimes.add(survivalTime);
        this.sort();
        return this.write();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        this.write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.isBVisible()) {
                player = candidate;
                break;
            }
        }
        if (player == null) {
            player = level.getPlayers().get(0);
        }
        if (player == null) {
            return;
        }

        int survivalTime;
        try {
            survivalTime = level.getPassedTime();
        } catch (RuntimeException ex) {
            survivalTime = level.getStartTime() - level.getTime();
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.storeRun(player.getPoints(), survivalTime, player.getTeamName());
    }

    public static String formatSurvivalTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = seconds / 60L;
        long remainingSeconds = seconds % 60L;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    private void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<String> loadedNames = new ArrayList<String>();
        ArrayList<Integer> loadedScores = new ArrayList<Integer>();
        ArrayList<Integer> loadedTimes = new ArrayList<Integer>();

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line = reader.readLine();
            if (!HEADER.equals(line)) {
                return;
            }

            while ((line = reader.readLine()) != null) {
                if (line.length() == 0) {
                    continue;
                }

                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    return;
                }

                int score = Integer.parseInt(values[0]);
                int time = Integer.parseInt(values[1]);
                String name = new String(
                    Base64.getDecoder().decode(values[2]),
                    StandardCharsets.UTF_8
                );

                loadedScores.add(score);
                loadedTimes.add(Math.max(0, time));
                loadedNames.add(name.length() == 0 ? "Player" : name);
            }
        } catch (IOException | RuntimeException ex) {
            return;
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        this.playersNames.addAll(loadedNames);
        this.playersScores.addAll(loadedScores);
        this.survivalTimes.addAll(loadedTimes);
        this.sort();
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(i);
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreResult = Integer.compare(
                    playersScores.get(second),
                    playersScores.get(first)
                );
                if (scoreResult != 0) {
                    return scoreResult;
                }
                return Integer.compare(
                    survivalTimes.get(first),
                    survivalTimes.get(second)
                );
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            sortedNames.add(this.playersNames.get(index));
            sortedScores.add(this.playersScores.get(index));
            sortedTimes.add(this.survivalTimes.get(index));
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        this.playersNames.addAll(sortedNames);
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.addAll(sortedTimes);
    }

    private boolean write() {
        Path parent = this.store.toAbsolutePath().getParent();
        if (parent != null) {
            try {
                Files.createDirectories(parent);
            } catch (IOException ex) {
                return false;
            }
        }

        Path temporary = this.store.resolveSibling(this.store.getFileName() + ".tmp");

        try (BufferedWriter writer = Files.newBufferedWriter(
                temporary,
                StandardCharsets.UTF_8)) {
            writer.write(HEADER);
            writer.newLine();

            for (int i = 0; i < this.playersScores.size(); i++) {
                writer.write(Integer.toString(this.playersScores.get(i)));
                writer.write('\t');
                writer.write(Integer.toString(this.survivalTimes.get(i)));
                writer.write('\t');
                writer.write(Base64.getEncoder().encodeToString(
                    this.playersNames.get(i).getBytes(StandardCharsets.UTF_8)
                ));
                writer.newLine();
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {
            }
            return false;
        }

        try {
            Files.move(
                temporary,
                this.store,
                StandardCopyOption.REPLACE_EXISTING,
                StandardCopyOption.ATOMIC_MOVE
            );
        } catch (IOException ex) {
            try {
                Files.move(
                    temporary,
                    this.store,
                    StandardCopyOption.REPLACE_EXISTING
                );
            } catch (IOException fallback) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {
                }
                return false;
            }
        }

        return true;
    }
}