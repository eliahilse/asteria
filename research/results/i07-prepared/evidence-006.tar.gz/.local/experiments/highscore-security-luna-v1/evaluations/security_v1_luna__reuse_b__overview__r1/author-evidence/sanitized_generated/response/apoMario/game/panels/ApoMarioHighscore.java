package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

	private static final long serialVersionUID = 1L;
	private static final String HEADER = "APOMARIO_HIGHSCORE_1";
	private static final int DEFAULT_WIDTH = 640;
	private static final int DEFAULT_HEIGHT = 480;

	private final Path store;
	private final ArrayList<String> playersNames;
	private final ArrayList<Integer> playersScores;
	private final ArrayList<Integer> survivalTimes;

	public ApoMarioHighscore(Path store) {
		this.store = store;
		this.playersNames = new ArrayList<String>();
		this.playersScores = new ArrayList<Integer>();
		this.survivalTimes = new ArrayList<Integer>();
		this.load();
		setBackground(Color.WHITE);
		setPreferredSize(new java.awt.Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
	}

	public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
		String name = normalizeName(playerName);
		if (score < 0) {
			score = 0;
		}
		if (survivalTime < 0) {
			survivalTime = 0;
		}

		this.playersNames.add(name);
		this.playersScores.add(Integer.valueOf(score));
		this.survivalTimes.add(Integer.valueOf(survivalTime));
		this.sort();
		this.persistAcrossRuns();
		repaint();
		return true;
	}

	public synchronized List<String> getPlayersNames() {
		return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
	}

	public synchronized List<Integer> getPlayersScores() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
	}

	public synchronized List<Integer> getSurvivalTimes() {
		return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
	}

	public synchronized void persistAcrossRuns() {
		if (this.store == null) {
			return;
		}

		try {
			Path parent = this.store.getParent();
			if (parent != null) {
				Files.createDirectories(parent);
			}

			Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
			BufferedWriter writer = Files.newBufferedWriter(
					temporary,
					StandardCharsets.UTF_8);

			try {
				writer.write(HEADER);
				writer.newLine();

				for (int i = 0; i < this.playersNames.size(); i++) {
					writer.write(encode(this.playersNames.get(i)));
					writer.write('\t');
					writer.write(String.valueOf(this.playersScores.get(i)));
					writer.write('\t');
					writer.write(String.valueOf(this.survivalTimes.get(i)));
					writer.newLine();
				}
			} finally {
				writer.close();
			}

			try {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING,
						java.nio.file.StandardCopyOption.ATOMIC_MOVE);
			} catch (java.nio.file.AtomicMoveNotSupportedException ex) {
				Files.move(temporary, this.store,
						java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException ex) {
			try {
				Files.deleteIfExists(this.store.resolveSibling(
						this.store.getFileName().toString() + ".tmp"));
			} catch (IOException ignored) {
			}
		}
	}

	public synchronized void recordRunEnd(ApoMarioLevel level) {
		if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
			return;
		}

		ApoMarioPlayer player = level.getPlayers().get(0);
		if (player == null) {
			return;
		}

		String name = player.getTeamName();
		if ((name == null) || (name.trim().length() == 0)) {
			name = "Player";
		}

		int elapsedTime;
		try {
			elapsedTime = level.getPassedTime();
		} catch (RuntimeException ex) {
			elapsedTime = level.getStartTime() - level.getTime();
		}

		this.storeRun(player.getPoints(), elapsedTime, name);
	}

	public static String formatSurvivalTime(int milliseconds) {
		if (milliseconds < 0) {
			milliseconds = 0;
		}

		int totalSeconds = milliseconds / 1000;
		int minutes = totalSeconds / 60;
		int seconds = totalSeconds % 60;
		return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
	}

	@Override
	protected synchronized void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);

		Graphics2D g = (Graphics2D) graphics.create();
		try {
			g.setColor(Color.BLACK);
			g.setFont(new Font("Dialog", Font.BOLD, 24));
			g.drawString("Highscore", 30, 40);

			g.setFont(new Font("Dialog", Font.BOLD, 15));
			g.drawString("Rank", 30, 75);
			g.drawString("Points", 110, 75);
			g.drawString("Player", 210, 75);
			g.drawString("Time", 480, 75);

			g.setFont(new Font("Dialog", Font.PLAIN, 15));
			int y = 105;
			for (int i = 0; i < this.playersNames.size(); i++) {
				g.drawString(String.valueOf(i + 1), 35, y);
				g.drawString(String.valueOf(this.playersScores.get(i)), 110, y);
				g.drawString(this.playersNames.get(i), 210, y);
				g.drawString(formatSurvivalTime(this.survivalTimes.get(i).intValue()), 480, y);
				y += 25;
			}
		} finally {
			g.dispose();
		}
	}

	private synchronized void load() {
		this.playersNames.clear();
		this.playersScores.clear();
		this.survivalTimes.clear();

		if (this.store == null || !Files.isRegularFile(this.store)) {
			return;
		}

		try {
			BufferedReader reader = Files.newBufferedReader(
					this.store,
					StandardCharsets.UTF_8);

			try {
				String header = reader.readLine();
				if (!HEADER.equals(header)) {
					return;
				}

				String line;
				while ((line = reader.readLine()) != null) {
					String[] values = line.split("\\t", -1);
					if (values.length != 3) {
						throw new IOException("Invalid highscore record");
					}

					String name = new String(
							Base64.getDecoder().decode(values[0]),
							StandardCharsets.UTF_8);
					int score = Integer.parseInt(values[1]);
					int time = Integer.parseInt(values[2]);

					if (score < 0 || time < 0) {
						throw new IOException("Invalid highscore value");
					}

					this.playersNames.add(normalizeName(name));
					this.playersScores.add(Integer.valueOf(score));
					this.survivalTimes.add(Integer.valueOf(time));
				}
			} finally {
				reader.close();
			}

			this.sort();
		} catch (IOException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		} catch (IllegalArgumentException ex) {
			this.playersNames.clear();
			this.playersScores.clear();
			this.survivalTimes.clear();
		}
	}

	private void sort() {
		ArrayList<Integer> order = new ArrayList<Integer>();
		for (int i = 0; i < this.playersScores.size(); i++) {
			order.add(Integer.valueOf(i));
		}

		Collections.sort(order, new Comparator<Integer>() {
			@Override
			public int compare(Integer first, Integer second) {
				return Integer.compare(
						playersScores.get(second.intValue()).intValue(),
						playersScores.get(first.intValue()).intValue());
			}
		});

		ArrayList<String> names = new ArrayList<String>();
		ArrayList<Integer> scores = new ArrayList<Integer>();
		ArrayList<Integer> times = new ArrayList<Integer>();

		for (Integer index : order) {
			int i = index.intValue();
			names.add(this.playersNames.get(i));
			scores.add(this.playersScores.get(i));
			times.add(this.survivalTimes.get(i));
		}

		this.playersNames.clear();
		this.playersNames.addAll(names);
		this.playersScores.clear();
		this.playersScores.addAll(scores);
		this.survivalTimes.clear();
		this.survivalTimes.addAll(times);
	}

	private static String normalizeName(String name) {
		if (name == null) {
			return "Player";
		}

		String result = name.trim();
		if (result.length() == 0) {
			return "Player";
		}
		return result;
	}

	private static String encode(String value) {
		return Base64.getEncoder().encodeToString(
				value.getBytes(StandardCharsets.UTF_8));
	}
}