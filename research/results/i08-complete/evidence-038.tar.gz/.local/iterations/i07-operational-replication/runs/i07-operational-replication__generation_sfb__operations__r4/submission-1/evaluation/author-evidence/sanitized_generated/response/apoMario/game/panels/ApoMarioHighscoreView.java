package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated renderer for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        int w = ApoMarioConstants.GAME_WIDTH - 30 * ApoMarioConstants.SIZE;
        int h = ApoMarioConstants.GAME_HEIGHT - 30 * ApoMarioConstants.SIZE;
        int x = (ApoMarioConstants.GAME_WIDTH - w) / 2;
        int y = (ApoMarioConstants.GAME_HEIGHT - h) / 2;
        g.setColor(new Color(255, 255, 255, 235)); g.fillRoundRect(x, y, w, h, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(x, y, w, h, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", x + 20, y + 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> n = scores.getPlayersNames(); List<Integer> p = scores.getPlayersScores(); List<Integer> t = scores.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 10; i++) {
            int seconds = t.get(i) / 1000; String time = String.format("%d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + n.get(i), x + 20, y + 70 + i * 20);
            g.drawString(String.valueOf(p.get(i)), x + w - 110, y + 70 + i * 20);
            g.drawString(time, x + w - 55, y + 70 + i * 20);
        }
        g.setFont(ApoMarioConstants.FONT_FPS); g.drawString("Press H or ESC to return", x + 20, y + h - 15);
    }
}