package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small dedicated renderer for the menu highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(Color.WHITE);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        String title = "HIGHSCORES";
        g.drawString(title, ApoMarioConstants.GAME_WIDTH / 2 - g.getFontMetrics().stringWidth(title) / 2, 45);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int minutes = times.get(i) / 60000;
            int seconds = (times.get(i) / 1000) % 60;
            String time = String.format("%02d:%02d", minutes, seconds);
            String row = (i + 1) + ". " + names.get(i) + "   " + scores.get(i) + "   " + time;
            g.drawString(row, 35, 75 + i * 18);
        }
        g.setFont(ApoMarioConstants.FONT_FPS);
        g.drawString("H: menu    ESC: back", 35, ApoMarioConstants.GAME_HEIGHT - 15);
    }
}