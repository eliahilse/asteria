package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Renderer for the menu's highscore page. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(Color.WHITE);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 20, 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        int y = 65;
        int count = Math.min(names.size(), Math.min(scores.size(), times.size()));
        for (int i = 0; i < count && i < 12; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 25, y);
            g.drawString(scores.get(i) + " pts", 190, y);
            g.drawString(time, 270, y);
            y += 16;
        }
        if (count == 0) g.drawString("No runs recorded yet", 25, y);
        g.drawString("Press H or ESC to return", 25, ApoMarioConstants.GAME_HEIGHT - 15);
    }
}