package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Renderer for the menu's highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore scores, int width, int height) {
        g.setColor(new Color(255, 255, 255, 230));
        g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 12, 12);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 12, 12);
        g.drawString("HIGHSCORES", width / 2 - 45, height / 10 + 25);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int minutes = times.get(i) / 60000;
            int seconds = (times.get(i) / 1000) % 60;
            String time = String.format("%02d:%02d", minutes, seconds);
            g.drawString((i + 1) + ". " + names.get(i), width / 5, height / 10 + 52 + i * 14);
            g.drawString(Integer.toString(points.get(i)), width / 2, height / 10 + 52 + i * 14);
            g.drawString(time, width * 3 / 5, height / 10 + 52 + i * 14);
        }
        g.drawString("H: back", width / 2 - 20, height * 9 / 10);
    }
}