package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A local persistent highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        names.add(cleanName(playerName));
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(names));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(scores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Reads the final player score and elapsed level time from the completed run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(250, 250, 250, 235));
        g.fillRoundRect(20, 20, width - 40, height - 40, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(20, 20, width - 40, height - 40, 20, 20);
        g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", width / 2 - 75, 60);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int y = 95;
        for (int i = 0; i < names.size() && i < 15; i++) {
            g.drawString(String.valueOf(i + 1), 45, y);
            g.drawString(names.get(i), 85, y);
            g.drawString(String.valueOf(scores.get(i)), width - 190, y);
            g.drawString(formatTime(survivalTimes.get(i).intValue()), width - 95, y);
            y += 23;
        }
        if (names.isEmpty()) {
            g.drawString("No runs recorded", width / 2 - 55, 105);
        }
        g.drawString("ESC / H: back", 35, height - 35);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return String.format("%02d:%02d", Long.valueOf(seconds / 60L), Long.valueOf(seconds % 60L));
    }

    private static String cleanName(String value) {
        if (value == null) return "Player";
        String result = value.replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) result = "Player";
        return result.length() > 32 ? result.substring(0, 32) : result;
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer left, Integer right) {
                return scores.get(right.intValue()).compareTo(scores.get(left.intValue()));
            }
        });
        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();
        for (Integer index : order) {
            sortedNames.add(names.get(index.intValue()));
            sortedScores.add(scores.get(index.intValue()));
            sortedTimes.add(survivalTimes.get(index.intValue()));
        }
        names.clear(); names.addAll(sortedNames);
        scores.clear(); scores.addAll(sortedScores);
        survivalTimes.clear(); survivalTimes.addAll(sortedTimes);
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(scores.get(i).toString());
                    out.write('\t');
                    out.write(survivalTimes.get(i).toString());
                    out.write('\t');
                    out.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    out.newLine();
                }
            } finally {
                out.close();
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3) continue;
                    try {
                        scores.add(Integer.valueOf(fields[0]));
                        survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(fields[1]))));
                        names.add(cleanName(new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8)));
                    } catch (RuntimeException ignored) {
                        // Ignore malformed records while retaining valid records.
                    }
                }
            } finally {
                in.close();
            }
            sort();
        } catch (IOException ignored) {
            // A missing, empty, or unreadable store is an empty board.
        }
    }
}