package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.nio.file.Path;

/** Compatibility view name for integrations that distinguish the board view from its model. */
public class ApoMarioHighscorePanel extends ApoMarioHighscore {
    public ApoMarioHighscorePanel(Path store) {
        super(store);
    }
}