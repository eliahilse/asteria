package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Local, durable highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        return persist();
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() { persist(); }

    private String cleanName(String value) {
        if (value == null || value.trim().length() == 0) return "Player";
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        if (s.length() > 24) s = s.substring(0, 24);
        return s.length() == 0 ? "Player" : s;
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    String n = new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8);
                    names.add(cleanName(n));
                    scores.add(Integer.valueOf(p[1]));
                    times.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[2]))));
                } catch (RuntimeException ex) { /* ignore damaged rows */ }
            }
            sort();
        } catch (IOException ex) { /* an unavailable store behaves as an empty table */ }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                for (int i = 0; i < scores.size(); i++) {
                    w.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    w.write('\t'); w.write(String.valueOf(scores.get(i))); w.write('\t');
                    w.write(String.valueOf(times.get(i))); w.newLine();
                }
            }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) { return false; }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 18));
        int count = Math.min(15, names.size());
        if (count == 0) g.drawString("No runs recorded", width / 2 - 70, 100);
        for (int i = 0; i < count; i++) {
            int y = 95 + i * 25;
            g.drawString(String.valueOf(i + 1), 45, y);
            g.drawString(names.get(i), 90, y);
            g.drawString(String.valueOf(scores.get(i)), width - 180, y);
            g.drawString(formatTime(times.get(i)), width - 90, y);
        }
        g.drawString("Time", width - 90, 75);
    }

    private String formatTime(int millis) {
        long seconds = Math.max(0, millis) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    /** Records the first (human) player after ApoMarioLevel has applied final scoring. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        String name = p.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(p.getPoints(), level.getPassedTime(), name);
    }
}