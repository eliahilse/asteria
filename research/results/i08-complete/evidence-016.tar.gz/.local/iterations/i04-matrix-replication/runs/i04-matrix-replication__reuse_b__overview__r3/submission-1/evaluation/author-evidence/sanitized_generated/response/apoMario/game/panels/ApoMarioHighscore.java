package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** A small, local, durable high-score table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_NAME = 32;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        names.add(cleanName(playerName));
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        return persistAcrossRuns();
    }

    public synchronized boolean persistAcrossRuns() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(Integer.toString(scores.get(i)));
                    out.write('\t');
                    out.write(Integer.toString(survivalTimes.get(i)));
                    out.write('\t');
                    out.write(names.get(i).replace('\t', ' '));
                    out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) { return false; }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    /** Renders the dedicated menu view; conversion to mm:ss happens only here. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("HIGHSCORES", width / 2 - 80, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int y = 80;
        for (int i = 0; i < names.size() && i < 12; i++) {
            g.drawString((i + 1) + ". " + names.get(i), 50, y);
            g.drawString(Integer.toString(scores.get(i)), width / 2, y);
            g.drawString(formatTime(survivalTimes.get(i)), width - 110, y);
            y += 25;
        }
        g.drawString("H/ESC: back", 20, height - 20);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0, millis) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
    private static String cleanName(String value) {
        if (value == null) return "Player";
        String s = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (s.length() == 0) s = "Player";
        return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s;
    }
    private synchronized void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        try { scores.add(Integer.valueOf(p[0])); survivalTimes.add(Math.max(0, Integer.parseInt(p[1]))); names.add(cleanName(p[2])); }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { in.close(); }
            sort();
        } catch (IOException ignored) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }
}