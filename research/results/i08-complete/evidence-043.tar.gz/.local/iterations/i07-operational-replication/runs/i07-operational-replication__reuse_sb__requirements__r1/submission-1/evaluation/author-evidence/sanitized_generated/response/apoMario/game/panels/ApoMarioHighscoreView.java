package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small renderer used by the menu for the persisted highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore score) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("Highscores", 20, 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = score.getPlayersNames();
        List<Integer> points = score.getPlayersScores();
        List<Integer> times = score.getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            int millis = times.get(i);
            int seconds = millis / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString(String.valueOf(i + 1), 20, 65 + i * 16);
            g.drawString(names.get(i), 50, 65 + i * 16);
            g.drawString(String.valueOf(points.get(i)), 190, 65 + i * 16);
            g.drawString(time, 260, 65 + i * 16);
        }
        g.drawString("Esc: back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
}