package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** File-backed highscore store. Survival times are always milliseconds. */
public final class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        runs.add(new Run(score, survivalTime, playerName.trim()));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = null;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream output = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            output.writeInt(MAGIC);
            output.writeInt(VERSION);
            output.writeInt(runs.size());
            for (Run run : runs) {
                output.writeInt(run.score);
                output.writeInt(run.time);
                output.writeUTF(run.name);
            }
            output.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    public synchronized void render(Graphics2D graphics, int width, int height) {
        graphics.setColor(new Color(245, 245, 245, 235));
        graphics.fillRoundRect(20, 15, width - 40, height - 30, 18, 18);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(20, 15, width - 40, height - 30, 18, 18);
        graphics.setFont(new Font("Dialog", Font.BOLD, 18));
        graphics.drawString("HIGHSCORES", 35, 42);
        graphics.setFont(new Font("Dialog", Font.PLAIN, 13));
        int y = 70;
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run run = runs.get(i);
            int seconds = run.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            graphics.drawString((i + 1) + ".", 35, y);
            graphics.drawString(run.name, 65, y);
            graphics.drawString(String.valueOf(run.score), width - 125, y);
            graphics.drawString(time, width - 65, y);
            y += 19;
        }
        graphics.drawString("Press ESC or H to return", 35, height - 25);
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_SIZE) return;
            DataInputStream input = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (input.readInt() != MAGIC || input.readInt() != VERSION) { input.close(); return; }
            int count = input.readInt();
            if (count < 0 || count > MAX_ENTRIES) { input.close(); return; }
            for (int i = 0; i < count; i++) {
                int score = input.readInt();
                int time = input.readInt();
                String name = input.readUTF();
                if (score >= 0 && time >= 0 && validName(name)) runs.add(new Run(score, time, name.trim()));
            }
            input.close();
            sortAndTrim();
        } catch (IOException | RuntimeException ex) {
            runs.clear();
        }
    }

    private static boolean validName(String name) {
        if (name == null) return false;
        String value = name.trim();
        if (value.length() == 0 || value.length() > MAX_NAME) return false;
        for (int i = 0; i < value.length(); i++) if (Character.isISOControl(value.charAt(i))) return false;
        return true;
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) { return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
}