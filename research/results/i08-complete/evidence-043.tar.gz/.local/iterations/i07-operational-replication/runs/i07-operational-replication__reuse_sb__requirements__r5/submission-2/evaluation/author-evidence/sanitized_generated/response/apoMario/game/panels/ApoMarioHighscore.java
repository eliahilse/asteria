package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = validName(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        names.add(name); scores.add(Integer.valueOf(score)); survivalTimes.add(Integer.valueOf(survivalTime));
        sortAndTrim(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try { out.write(Integer.toString(names.size())); out.newLine(); for (int i=0;i<names.size();i++) { out.write(Integer.toString(scores.get(i))); out.newLine(); out.write(Integer.toString(survivalTimes.get(i))); out.newLine(); out.write(names.get(i)); out.newLine(); } } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); } catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : level.getPlayers()) if (player != null && player.isBVisible() && (best == null || player.getPoints() > best.getPoints())) best = player;
        if (best == null) best = level.getPlayers().get(0);
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(best.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height); g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 18)); g.drawString("HIGHSCORES", width/2-55, 30); g.setFont(new Font("Dialog", Font.PLAIN, 13));
        for (int i=0;i<names.size() && i<12;i++) { int y=55+i*15; g.drawString(Integer.toString(i+1),20,y); g.drawString(names.get(i),48,y); g.drawString(Integer.toString(scores.get(i)),width-125,y); g.drawString(formatTime(survivalTimes.get(i)),width-65,y); }
        g.drawString("H: back", 10, height-10);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try { if (Files.size(store)>131072) return; BufferedReader in=Files.newBufferedReader(store,StandardCharsets.UTF_8); try { String first=in.readLine(); int count=Integer.parseInt(first==null?"0":first); if(count<0||count>MAX_ENTRIES)return; for(int i=0;i<count;i++){String s=in.readLine(),t=in.readLine(),n=in.readLine(); if(s==null||t==null||n==null)break; int score=Integer.parseInt(s),time=Integer.parseInt(t); String name=validName(n); if(score>=0&&time>=0&&name!=null){scores.add(score);survivalTimes.add(time);names.add(name);}} } finally {in.close();} sortAndTrim(); } catch(Exception ex){names.clear();scores.clear();survivalTimes.clear();}
    }
    private String validName(String value) { if(value==null)return null; String n=value.trim(); if(n.length()==0||n.length()>MAX_NAME_LENGTH)return null; for(int i=0;i<n.length();i++)if(Character.isISOControl(n.charAt(i)))return null; return n; }
    private void sortAndTrim() { List<Integer> order=new ArrayList<Integer>(); for(int i=0;i<scores.size();i++)order.add(i); Collections.sort(order,new Comparator<Integer>(){public int compare(Integer a,Integer b){return scores.get(b).compareTo(scores.get(a));}}); List<String> n=new ArrayList<String>();List<Integer>s=new ArrayList<Integer>();List<Integer>t=new ArrayList<Integer>();for(int i=0;i<order.size()&&i<MAX_ENTRIES;i++){int k=order.get(i);n.add(names.get(k));s.add(scores.get(k));t.add(survivalTimes.get(k));}names.clear();names.addAll(n);scores.clear();scores.addAll(s);survivalTimes.clear();survivalTimes.addAll(t); }
    private static String formatTime(int milliseconds) { long seconds=Math.max(0,milliseconds)/1000L; return String.format("%02d:%02d",seconds/60L,seconds%60L); }
}