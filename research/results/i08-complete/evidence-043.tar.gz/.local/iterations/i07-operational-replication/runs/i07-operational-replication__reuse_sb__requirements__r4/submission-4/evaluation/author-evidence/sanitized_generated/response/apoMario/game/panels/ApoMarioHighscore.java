package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private static final long MAX_FILE_SIZE = 131072L;

    private static final class Run {
        private final String name;
        private final int score;
        private final int time;
        private Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        runs.add(new Run(playerName.trim(), score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(Math.max(0, player.getPoints()), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = null;
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(runs.size());
            for (Run run : runs) {
                out.writeUTF(run.name);
                out.writeInt(run.score);
                out.writeInt(run.time);
            }
            out.close();
            try {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(245, 245, 245));
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 20, 35);
        g.setFont(new Font("Dialog", Font.BOLD, 12));
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run run = runs.get(i);
            int seconds = run.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            int y = 60 + i * 14;
            g.drawString((i + 1) + ".", 20, y);
            g.drawString(run.name, 45, y);
            g.drawString(String.valueOf(run.score), 190, y);
            g.drawString(time, 250, y);
        }
        g.drawString("ESC / H: back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String value = name.trim();
        if (value.length() == 0 || value.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < value.length(); i++) if (Character.isISOControl(value.charAt(i))) return false;
        return true;
    }

    private void sortAndLimit() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                return first.score == second.score ? 0 : (first.score < second.score ? 1 : -1);
            }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private void load() {
        if (store == null) return;
        try {
            Path absolute = store.toAbsolutePath();
            if (!Files.exists(absolute) || Files.size(absolute) > MAX_FILE_SIZE) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(absolute)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = in.readUTF();
                int score = in.readInt();
                int time = in.readInt();
                if (validName(name) && score >= 0 && time >= 0) runs.add(new Run(name.trim(), score, time));
            }
            in.close();
            sortAndLimit();
        } catch (IOException ex) {
            runs.clear();
        } catch (RuntimeException ex) {
            runs.clear();
        }
    }
}