package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.level.ApoMarioLevel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** A small, local and durable highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024 * 1024;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final int score, time;
        final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private static String cleanName(String name) {
        if (name == null) return null;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return null;
        return s;
    }

    public synchronized void recordRunEnd(apoMario.level.ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(score, survivalTime, name));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> r = new ArrayList<String>(); for (Entry e : entries) r.add(e.name); return r;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.score); return r;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.time); return r;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(tmp));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(entries.size());
            for (Entry e : entries) { out.writeInt(e.score); out.writeInt(e.time); byte[] b = e.name.getBytes(StandardCharsets.UTF_8); out.writeInt(b.length); out.write(b); }
            out.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* scores remain valid in memory */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE) return;
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt(); if (count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Entry> read = new ArrayList<Entry>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt(), time = in.readInt(), len = in.readInt();
                if (time < 0 || len <= 0 || len > MAX_NAME * 4) { in.close(); return; }
                byte[] b = new byte[len]; in.readFully(b); String name = cleanName(new String(b, StandardCharsets.UTF_8));
                if (name == null) { in.close(); return; } read.add(new Entry(score, time, name));
            }
            in.close(); entries.clear(); entries.addAll(read);
            Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); } });
        } catch (IOException ex) { /* ignore malformed stores */ }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245, 235)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 18));
        g.drawString("HIGHSCORES", width / 2 - 65, 28);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        for (int i = 0; i < entries.size() && i < 12; i++) {
            Entry e = entries.get(i); int y = 55 + i * 15;
            int seconds = e.time / 1000; String t = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ".", 25, y); g.drawString(e.name, 50, y); g.drawString(String.valueOf(e.score), 190, y); g.drawString(t, 250, y);
        }
        if (entries.isEmpty()) g.drawString("No runs recorded", width / 2 - 45, 65);
    }
}