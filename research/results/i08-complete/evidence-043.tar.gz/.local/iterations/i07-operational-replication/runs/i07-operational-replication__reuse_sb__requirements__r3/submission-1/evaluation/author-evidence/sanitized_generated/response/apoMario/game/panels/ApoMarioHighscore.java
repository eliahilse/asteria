package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed, bounded highscore table for real Mario runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim());
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                out.write("APOMARIO_HIGHSCORE_1"); out.newLine();
                out.write(String.valueOf(names.size())); out.newLine();
                for (int i = 0; i < names.size(); i++) {
                    out.write(scores.get(i) + "\t" + survivalTimes.get(i) + "\t" + names.get(i)); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* storage failure must not stop the game */ }
    }

    private synchronized void load() {
        names.clear(); scores.clear(); survivalTimes.clear();
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 1024) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APOMARIO_HIGHSCORE_1".equals(in.readLine())) return;
                String countLine = in.readLine();
                int count = Integer.parseInt(countLine);
                if (count < 0 || count > MAX_ENTRIES) return;
                for (int i = 0; i < count; i++) {
                    String line = in.readLine();
                    if (line == null) break;
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        if (score >= 0 && time >= 0 && validName(p[2])) { names.add(p[2]); scores.add(score); survivalTimes.add(time); }
                    }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (Exception ex) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }

    private void sortAndTrim() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b) - scores.get(a); } });
        ArrayList<String> n = new ArrayList<String>(); ArrayList<Integer> s = new ArrayList<Integer>(); ArrayList<Integer> t = new ArrayList<Integer>();
        for (int i = 0; i < order.size() && i < MAX_ENTRIES; i++) { int at = order.get(i); n.add(names.get(at)); s.add(scores.get(at)); t.add(survivalTimes.get(at)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) if (p != null && p.isBVisible() && p.getPoints() > best.getPoints()) best = p;
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(best.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(255,255,255,235)); g.fillRect(20, 20, 280, 200);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 18)); g.drawString("HIGHSCORES", 95, 48);
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 70 + i * 15; int ms = survivalTimes.get(i); int sec = ms / 1000;
            g.drawString((i + 1) + ". " + names.get(i), 30, y);
            g.drawString(String.valueOf(scores.get(i)), 180, y);
            g.drawString(String.format("%02d:%02d", sec / 60, sec % 60), 230, y);
        }
        g.drawString("H / ESC: back", 30, 210);
    }
}