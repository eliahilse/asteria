package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed, bounded highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;
    private static final int MAX_FILE_ENTRIES = 1000;

    private static final class Entry {
        String name;
        int score;
        int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        entries.add(new Entry(playerName.trim(), score, survivalTime));
        sortAndTrim();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the authoritative first player result from a finished level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void persistAcrossRuns() { persist(); }

    private boolean validName(String name) {
        if (name == null) return false;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)))) {
            if (in.readInt() != MAGIC || in.readInt() != VERSION) return;
            int count = in.readInt();
            if (count < 0 || count > MAX_FILE_ENTRIES) return;
            for (int i = 0; i < count; i++) {
                int length = in.readUnsignedShort();
                if (length > MAX_NAME) return;
                String name = in.readUTF();
                int score = in.readInt();
                int time = in.readInt();
                if (validName(name) && score >= 0 && time >= 0) entries.add(new Entry(name.trim(), score, time));
            }
            sortAndTrim();
        } catch (IOException | RuntimeException ex) {
            entries.clear();
        }
    }

    private boolean persist() {
        if (store == null) return false;
        Path parent = store.toAbsolutePath().getParent();
        Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)))) {
                out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(entries.size());
                for (Entry e : entries) { out.writeUTF(e.name); out.writeInt(e.score); out.writeInt(e.time); }
            }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException | RuntimeException ex) {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
            return false;
        }
    }
}