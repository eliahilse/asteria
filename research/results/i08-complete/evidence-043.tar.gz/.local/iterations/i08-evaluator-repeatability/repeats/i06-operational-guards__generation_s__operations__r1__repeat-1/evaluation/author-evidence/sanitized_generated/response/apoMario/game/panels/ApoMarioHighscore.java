package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 32;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final String name; final int score; final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String cleanName(String name) {
        if (name == null) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < name.length() && b.length() < MAX_NAME; i++) {
            char c = name.charAt(i);
            if (c >= 32 && c != 127 && c != '\t') b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? null : s;
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                if (a.score != b.score) return a.score > b.score ? -1 : 1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sort();
        return persist();
    }

    /** Records the first human player in the completed level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null) { chosen = p; break; }
        }
        if (chosen == null) return;
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(chosen.getPoints(), elapsed, chosen.getTeamName() == null ? "Player" : chosen.getTeamName());
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE) return;
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line; int count = 0;
            while ((line = r.readLine()) != null && count++ < MAX_RECORDS) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                String name = cleanName(p[0]);
                try {
                    int score = Integer.parseInt(p[1]);
                    int time = Integer.parseInt(p[2]);
                    if (name != null && time >= 0) runs.add(new Run(name, score, time));
                } catch (NumberFormatException ignored) { }
            }
            r.close();
            sort();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        if (store == null) return false;
        Path parent = store.toAbsolutePath().getParent();
        try {
            if (parent != null) Files.createDirectories(parent);
            Path tmp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            for (Run run : runs) w.write(run.name + "\t" + run.score + "\t" + run.time + "\n");
            w.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException e) { return false; }
    }

    public synchronized void persistAcrossRuns() { persist(); }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> out = new ArrayList<String>(); for (Run r : runs) out.add(r.name); return out;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> out = new ArrayList<Integer>(); for (Run r : runs) out.add(r.score); return out;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> out = new ArrayList<Integer>(); for (Run r : runs) out.add(r.time); return out;
    }
}