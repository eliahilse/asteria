package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small dedicated renderer used by the menu highscore screen. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setColor(Color.BLACK); g.drawRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 80, 55);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> n = scores.getPlayersNames(); List<Integer> p = scores.getPlayersScores(); List<Integer> t = scores.getSurvivalTimes();
        int rows = Math.min(n.size(), 10);
        for (int i = 0; i < rows; i++) {
            int ms = t.get(i); int sec = ms / 1000;
            String time = String.format("%02d:%02d", sec / 60, sec % 60);
            g.drawString((i + 1) + ". " + n.get(i), 45, 85 + i * 16);
            g.drawString(String.valueOf(p.get(i)), 205, 85 + i * 16);
            g.drawString(time, 270, 85 + i * 16);
        }
        if (rows == 0) g.drawString("No runs recorded", 90, 100);
        g.setFont(ApoMarioConstants.FONT_FPS); g.drawString("Press H or Escape to return", 80, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}