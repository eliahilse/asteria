package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final int score;
        private final int time;
        private final String name;
        private Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return result;
    }

    /** Records the first active player when the live level reaches an end state. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.time));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
        } catch (IOException ignored) {
            // A read-only game directory must not prevent playing.
        }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", -1);
                    if (parts.length != 3) continue;
                    try {
                        String name = new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8);
                        entries.add(new Entry(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), name));
                    } catch (IllegalArgumentException ignored) { }
                }
            } finally {
                reader.close();
            }
            Collections.sort(entries, new Comparator<Entry>() {
                public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
            });
        } catch (IOException ignored) { }
    }
}