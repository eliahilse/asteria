package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Graphics2D;

/** Dedicated menu view for the local highscore board. */
public final class ApoMarioHighscorePanel {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscorePanel(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g, int width, int height) { highscore.render(g, width, height); }
}