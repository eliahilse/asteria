package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_BYTES = 64;
    private static final long MAX_FILE_SIZE = 128 * 1024L;

    private static final class Run {
        String name; int score; int time; long order;
        Run(String name, int score, int time, long order) {
            this.name = name; this.score = score; this.time = time; this.order = order;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private long nextOrder;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private static boolean validName(String name) {
        if (name == null) return false;
        String n = name.trim();
        if (n.length() == 0 || n.length() > 32) return false;
        for (int i = 0; i < n.length(); i++) if (Character.isISOControl(n.charAt(i))) return false;
        return true;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (!validName(playerName) || survivalTime < 0) return false;
        String name = playerName.trim();
        if (name.getBytes(StandardCharsets.UTF_8).length > MAX_NAME_BYTES) return false;
        runs.add(new Run(name, score, survivalTime, nextOrder++));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                if (first.score != second.score) return first.score > second.score ? -1 : 1;
                return first.order < second.order ? -1 : (first.order == second.order ? 0 : 1);
            }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE_SIZE) return;
            DataInputStream input = new DataInputStream(Files.newInputStream(store));
            int magic = input.readInt();
            int version = input.readInt();
            int count = input.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_ENTRIES) {
                input.close(); return;
            }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int length = input.readUnsignedShort();
                if (length <= 0 || length > MAX_NAME_BYTES) throw new IOException("invalid name");
                byte[] bytes = new byte[length];
                input.readFully(bytes);
                String name = new String(bytes, StandardCharsets.UTF_8);
                int score = input.readInt();
                int time = input.readInt();
                if (!validName(name) || time < 0) throw new IOException("invalid run");
                loaded.add(new Run(name, score, time, nextOrder++));
            }
            input.close();
            runs.clear(); runs.addAll(loaded); sortAndTrim();
        } catch (IOException ignored) {
            // Invalid storage is ignored without damaging the current valid state.
        }
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temporary = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            DataOutputStream output = new DataOutputStream(Files.newOutputStream(temporary));
            output.writeInt(MAGIC); output.writeInt(VERSION); output.writeInt(runs.size());
            for (Run run : runs) {
                byte[] name = run.name.getBytes(StandardCharsets.UTF_8);
                output.writeShort(name.length); output.write(name);
                output.writeInt(run.score); output.writeInt(run.time);
            }
            output.flush(); output.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ignored) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignoredAgain) { }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (!validName(name)) name = "Human";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D graphics) {
        int width = ApoMarioConstants.GAME_WIDTH;
        int height = ApoMarioConstants.GAME_HEIGHT;
        graphics.setColor(new Color(255, 255, 255, 235));
        graphics.fillRoundRect(20, 15, width - 40, height - 30, 16, 16);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(20, 15, width - 40, height - 30, 16, 16);
        graphics.setFont(new Font("Dialog", Font.BOLD, 18));
        graphics.drawString("HIGHSCORES", 25, 38);
        graphics.setFont(new Font("Dialog", Font.PLAIN, 12));
        for (int i = 0; i < runs.size() && i < 10; i++) {
            Run run = runs.get(i);
            int y = 62 + i * 17;
            int seconds = run.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            graphics.drawString((i + 1) + ". " + run.name, 32, y);
            graphics.drawString(String.valueOf(run.score), width / 2, y);
            graphics.drawString(time, width - 75, y);
        }
        graphics.drawString("H/ESC: back", 25, height - 20);
    }
}