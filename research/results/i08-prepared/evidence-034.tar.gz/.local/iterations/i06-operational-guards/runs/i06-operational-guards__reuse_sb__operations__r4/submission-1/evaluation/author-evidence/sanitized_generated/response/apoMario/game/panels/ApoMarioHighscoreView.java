package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioMenu;

import java.awt.Graphics2D;

/** Small dedicated menu view used by ApoMarioMenu for the highscore board. */
public final class ApoMarioHighscoreView {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioHighscore highscore) {
        this.highscore = highscore;
    }
    public void render(Graphics2D g) {
        highscore.renderBoard(g, 20, 20, 280, 200);
    }
}