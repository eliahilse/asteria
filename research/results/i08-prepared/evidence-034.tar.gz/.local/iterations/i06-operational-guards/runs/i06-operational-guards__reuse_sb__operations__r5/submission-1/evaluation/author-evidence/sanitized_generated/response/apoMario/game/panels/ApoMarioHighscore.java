package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, local highscore board. Durations are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private static final long MAX_FILE = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private boolean loaded;

    private static final class Entry {
        final int score; final int time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private static boolean validName(String n) {
        if (n == null || n.trim().length() == 0 || n.length() > MAX_NAME) return false;
        for (int i = 0; i < n.length(); i++) if (Character.isISOControl(n.charAt(i))) return false;
        return true;
    }
    private static boolean valid(int score, int time, String name) {
        return score >= -1000000000 && score <= 1000000000 && time >= 0 && validName(name);
    }
    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) {
            return a.score == b.score ? a.name.compareTo(b.name) : (a.score < b.score ? 1 : -1);
        }});
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (loaded) return; loaded = true;
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int magic = in.readInt(), version = in.readInt(), count = in.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            List<Entry> read = new ArrayList<Entry>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt(), time = in.readInt(), length = in.readInt();
                if (length < 0 || length > MAX_NAME * 4) { in.close(); return; }
                byte[] bytes = new byte[length]; in.readFully(bytes);
                String name = new String(bytes, StandardCharsets.UTF_8);
                if (!valid(score, time, name)) { in.close(); return; }
                read.add(new Entry(score, time, name));
            }
            in.close(); entries.clear(); entries.addAll(read); sort();
        } catch (IOException ex) { /* retain a safe empty board */ }
    }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (!valid(score, survivalTime, playerName)) return false;
        entries.add(new Entry(score, survivalTime, playerName.trim())); sort();
        return true;
    }
    public synchronized List<String> getPlayersNames() { List<String> r = new ArrayList<String>(); for (Entry e: entries) r.add(e.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r = new ArrayList<Integer>(); for (Entry e: entries) r.add(e.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r = new ArrayList<Integer>(); for (Entry e: entries) r.add(e.time); return Collections.unmodifiableList(r); }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path tmp = null;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            tmp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(entries.size());
            for (Entry e: entries) { byte[] b = e.name.getBytes(StandardCharsets.UTF_8); out.writeInt(e.score); out.writeInt(e.time); out.writeInt(b.length); out.write(b); }
            out.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { if (tmp != null) try { Files.deleteIfExists(tmp); } catch (IOException ignored) {} }
    }
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty() || level.isBReplay()) return;
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) if (p != null && p.isBVisible() && p.getPoints() > selected.getPoints()) selected = p;
        String name = selected.getTeamName(); if (!validName(name)) name = "Player";
        if (storeRun(selected.getPoints(), Math.max(0, level.getPassedTime()), name)) persistAcrossRuns();
    }
    public void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20, 15, width-40, height-30, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(20, 15, width-40, height-30, 18, 18);
        g.setFont(new Font("Dialog", Font.BOLD, 20)); g.drawString("HIGHSCORES", width/2-65, 45);
        g.setFont(ApoMarioConstants.FONT_STATISTICS); List<String> n=getPlayersNames(); List<Integer> s=getPlayersScores(); List<Integer> t=getSurvivalTimes();
        for (int i=0; i<n.size() && i<10; i++) { int y=75+i*16; int sec=t.get(i)/1000; String time=String.format("%02d:%02d", sec/60, sec%60); g.drawString((i+1)+". "+n.get(i), 35,y); g.drawString(String.valueOf(s.get(i)), width-120,y); g.drawString(time,width-65,y); }
        g.setFont(new Font("Dialog", Font.PLAIN, 12)); g.drawString("ESC: back", 35, height-25);
    }
}