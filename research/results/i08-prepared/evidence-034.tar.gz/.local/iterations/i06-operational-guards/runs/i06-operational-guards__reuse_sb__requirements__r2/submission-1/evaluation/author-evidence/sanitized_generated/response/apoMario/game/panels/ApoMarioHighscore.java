package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** File-backed, bounded highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim());
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> out = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) {
                out.add(scores.get(i) + "\t" + times.get(i) + "\t" + names.get(i));
            }
            Files.write(tmp, out, Charset.forName("UTF-8"));
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) { /* persistence must not stop the game */ }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (!validName(name)) name = "Player";
        storeRun(Math.max(0, player.getPoints()), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 16));
        g.drawString("HIGHSCORES", x, y);
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        for (int i = 0; i < names.size(); i++) {
            int ms = times.get(i).intValue();
            String time = String.format("%02d:%02d", ms / 60000, (ms / 1000) % 60);
            g.drawString((i + 1) + ". " + names.get(i), x, y + 22 + i * 16);
            g.drawString(String.valueOf(scores.get(i)), x + width - 95, y + 22 + i * 16);
            g.drawString(time, x + width - 45, y + 22 + i * 16);
        }
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }
    private void sortAndLimit() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b) - scores.get(a); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (int i = 0; i < order.size() && i < MAX_ENTRIES; i++) { int k = order.get(i); n.add(names.get(k)); s.add(scores.get(k)); t.add(times.get(k)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, Charset.forName("UTF-8"));
            for (int i = 0; i < lines.size() && names.size() < MAX_ENTRIES; i++) {
                String[] p = lines.get(i).split("\\t", 3);
                if (p.length != 3) continue;
                try { int s = Integer.parseInt(p[0]); int t = Integer.parseInt(p[1]); if (s >= 0 && t >= 0 && validName(p[2])) { scores.add(s); times.add(t); names.add(p[2].trim()); } }
                catch (RuntimeException ex) { }
            }
            sortAndLimit();
        } catch (Exception ex) { names.clear(); scores.clear(); times.clear(); }
    }
}