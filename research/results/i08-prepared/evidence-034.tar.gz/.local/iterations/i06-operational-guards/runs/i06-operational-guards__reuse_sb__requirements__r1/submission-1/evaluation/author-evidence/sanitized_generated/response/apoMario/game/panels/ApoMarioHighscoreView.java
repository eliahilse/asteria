package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small menu-owned view for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private final ApoMarioHighscore scores;
    public ApoMarioHighscoreView(ApoMarioHighscore scores) { this.scores = scores; }
    public void render(Graphics2D g) {
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 95, 35);
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 60 + i * 16;
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 35, y);
            g.drawString(String.valueOf(points.get(i)), 190, y);
            g.drawString(time, 245, y);
        }
        if (names.isEmpty()) g.drawString("No runs recorded", 85, 70);
        g.drawString("ESC/H: back", 105, ApoMarioConstants.GAME_HEIGHT - 15);
    }
}