package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** A small, local and durable highscore table. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_BYTES = 80;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = null;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(temporary));
            out.writeInt(VERSION);
            out.writeInt(runs.size());
            for (Run run : runs) {
                out.writeInt(run.score);
                out.writeInt(run.time);
                byte[] bytes = run.name.getBytes(StandardCharsets.UTF_8);
                out.writeInt(bytes.length);
                out.write(bytes);
            }
            out.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 1024) return;
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            int version = in.readInt();
            int count = in.readInt();
            if (version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt();
                int time = in.readInt();
                int length = in.readInt();
                if (time < 0 || length < 1 || length > MAX_NAME_BYTES) { in.close(); return; }
                byte[] bytes = new byte[length];
                in.readFully(bytes);
                String name = normalize(new String(bytes, StandardCharsets.UTF_8));
                if (name == null) { in.close(); return; }
                loaded.add(new Run(score, time, name));
            }
            in.close();
            runs.clear();
            runs.addAll(loaded);
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
            });
        } catch (IOException ex) {
            // Keep the empty (or previously valid) table when the file is malformed.
        }
    }

    private static String normalize(String value) {
        if (value == null) return null;
        String trimmed = value.trim();
        if (trimmed.length() == 0) return null;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            if (c < 32 || c == 127) continue;
            result.append(c);
        }
        if (result.length() == 0) return null;
        while (result.toString().getBytes(StandardCharsets.UTF_8).length > MAX_NAME_BYTES) {
            result.setLength(result.length() - 1);
        }
        return result.toString();
    }
}