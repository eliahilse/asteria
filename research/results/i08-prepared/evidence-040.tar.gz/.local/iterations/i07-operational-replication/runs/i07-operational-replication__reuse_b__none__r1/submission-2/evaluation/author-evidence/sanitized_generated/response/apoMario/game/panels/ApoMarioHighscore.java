package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local highscore table for the Mario game. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() >  forty()) name = name.substring(0, forty());
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            survivalTimes.remove(survivalTimes.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    private int forty() { return 40; }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(names));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(scores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(scores.get(i) + "\t" + survivalTimes.get(i) + "\t" + Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    /** Records the first human/player result at the end of the live run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = player.getAi() == null ? "Player" : player.getAi().getAuthor();
        }
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void load() {
        if (store == null || !Files.isReadable(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3) continue;
                    scores.add(Integer.valueOf(p[0]));
                    survivalTimes.add(Integer.valueOf(p[1]));
                    names.add(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                }
            } finally { in.close(); }
            sort();
        } catch (Exception ignored) {
            names.clear(); scores.clear(); survivalTimes.clear();
        }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
}