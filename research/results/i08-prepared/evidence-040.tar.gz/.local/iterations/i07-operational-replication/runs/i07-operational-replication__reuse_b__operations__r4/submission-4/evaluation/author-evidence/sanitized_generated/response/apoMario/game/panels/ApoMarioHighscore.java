package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_BYTES = 80;

    private static final class Run {
        final String name;
        final int score;
        final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || playerName == null) return false;
        String name = clean(playerName);
        if (name.length() == 0 || name.getBytes(StandardCharsets.UTF_8).length > MAX_NAME_BYTES) return false;
        runs.add(new Run(name, score, survivalTime));
        sortRuns();
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        return true;
    }

    /** Records the finalized human player's result exactly once for this level run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isHighscoreRecorded() || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) {
            level.setHighscoreRecorded(true);
            persistAcrossRuns();
        }
    }

    private String clean(String value) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < 40; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) result.append(c);
        }
        return result.toString().trim();
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
            }
        });
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            out.writeInt(VERSION);
            out.writeInt(runs.size());
            for (Run run : runs) {
                out.writeInt(run.score);
                out.writeInt(run.time);
                out.writeUTF(run.name);
            }
            out.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024L * 1024L) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int version = in.readInt();
            int count = in.readInt();
            if (version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt();
                int time = in.readInt();
                String name = in.readUTF();
                if (score < 0 || time < 0 || name.length() == 0 || name.getBytes(StandardCharsets.UTF_8).length > MAX_NAME_BYTES) { in.close(); return; }
                loaded.add(new Run(clean(name), score, time));
            }
            in.close();
            runs.clear();
            runs.addAll(loaded);
            sortRuns();
        } catch (IOException ex) {
            // Ignore malformed or unavailable stores.
        }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(250, 250, 250, 235));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 30, 42);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        g.drawString("Name", 35, 78);
        g.drawString("Points", width - 210, 78);
        g.drawString("Time", width - 95, 78);
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run run = runs.get(i);
            int y = 108 + i * 27;
            g.drawString((i + 1) + ". " + run.name, 25, y);
            g.drawString(String.valueOf(run.score), width - 210, y);
            g.drawString(formatTime(run.time), width - 95, y);
        }
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        g.drawString("Press H or Escape to return", 25, height - 20);
    }

    private String formatTime(int milliseconds) {
        long seconds = milliseconds / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}