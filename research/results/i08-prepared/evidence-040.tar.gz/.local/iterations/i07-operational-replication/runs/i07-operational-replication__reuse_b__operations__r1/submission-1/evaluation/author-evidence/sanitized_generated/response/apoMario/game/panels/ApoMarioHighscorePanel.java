package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** Simple dedicated renderer used by the menu highscore view. */
public final class ApoMarioHighscorePanel {
    private ApoMarioHighscorePanel() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 25, 40);
        List<String> names = scores.getPlayersNames(); List<Integer> points = scores.getPlayersScores(); List<Integer> times = scores.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 15; i++) {
            int ms = times.get(i); int seconds = ms / 1000; int minutes = seconds / 60;
            String time = String.format("%02d:%02d", minutes, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 35, 75 + i * 24);
            g.drawString(points.get(i) + " pts", 300, 75 + i * 24);
            g.drawString(time, 430, 75 + i * 24);
        }
        g.drawString("ESC: back", 25, ApoMarioConstants.GAME_HEIGHT - 20);
    }
}