package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, file backed highscore table for completed Mario runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> playersNames = new ArrayList<String>();
    private final List<Integer> playersScores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        name = name.replace('\n', ' ').replace('\r', ' ');
        playersNames.add(name);
        playersScores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (playersNames.size() > MAX_ENTRIES) {
            int last = playersNames.size() - 1;
            playersNames.remove(last);
            playersScores.remove(last);
            survivalTimes.remove(last);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(playersScores));
    }

    /** Survival durations are milliseconds, not formatted display strings. */
    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < playersNames.size(); i++) {
                    writer.write(Integer.toString(playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(playersNames.get(i));
                    writer.newLine();
                }
            } finally { writer.close(); }
        } catch (IOException ignored) {
            // A highscore must never stop the game from running.
        }
    }

    /** Records player one's score at the actual end of the live run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        try {
                            playersScores.add(Integer.valueOf(p[0]));
                            survivalTimes.add(Integer.valueOf(p[1]));
                            playersNames.add(p[2]);
                        } catch (NumberFormatException ignored) { }
                    }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        final List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < playersNames.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return playersScores.get(b.intValue()).compareTo(playersScores.get(a.intValue()));
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(playersNames.get(i)); s.add(playersScores.get(i)); t.add(survivalTimes.get(i)); }
        playersNames.clear(); playersNames.addAll(n);
        playersScores.clear(); playersScores.addAll(s);
        survivalTimes.clear(); survivalTimes.addAll(t);
    }
}