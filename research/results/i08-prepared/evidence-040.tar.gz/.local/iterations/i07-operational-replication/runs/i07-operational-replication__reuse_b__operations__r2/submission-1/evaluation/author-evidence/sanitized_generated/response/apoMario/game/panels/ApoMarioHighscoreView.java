package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Rendering helper used by the menu's dedicated highscore screen. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores, int width, int height) {
        g.setColor(new Color(245, 245, 245, 235));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.drawString("HIGHSCORES", width / 2 - 55, 45);
        g.drawString("ESC / H: back", 15, height - 15);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 15; i++) {
            int y = 80 + i * 25;
            g.drawString(String.valueOf(i + 1), 35, y);
            g.drawString(names.get(i), 75, y);
            g.drawString(String.valueOf(points.get(i)), width - 150, y);
            int seconds = times.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 75, y);
        }
        if (names.isEmpty()) g.drawString("No runs recorded", width / 2 - 50, 90);
    }
}