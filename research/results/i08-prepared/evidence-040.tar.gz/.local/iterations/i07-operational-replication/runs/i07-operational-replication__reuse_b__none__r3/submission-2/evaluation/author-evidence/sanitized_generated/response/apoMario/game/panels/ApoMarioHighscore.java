package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import java.awt.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        names.add(playerName == null || playerName.trim().length() == 0 ? "Player" : playerName.trim());
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > 100) {
            int last = names.size() - 1;
            names.remove(last); scores.remove(last); times.remove(last);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(scores.get(i) + "\t" + times.get(i) + "\t" + names.get(i).replace('\t', ' '));
                    out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) try {
                        scores.add(Integer.valueOf(p[0]));
                        times.add(Integer.valueOf(p[1]));
                        names.add(p[2]);
                    } catch (NumberFormatException ignored) { }
                }
            } finally { in.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b).compareTo(scores.get(a)); }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    public synchronized void render(java.awt.Graphics2D g, int width, int height) {
        g.setColor(java.awt.Color.WHITE); g.fillRect(20, 20, width - 40, height - 40);
        g.setColor(java.awt.Color.BLACK); g.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 24));
        g.drawString("HIGHSCORES", 40, 60);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 15));
        for (int i = 0; i < names.size() && i < 15; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
            int y = 90 + i * 25;
            g.drawString((i + 1) + ". " + names.get(i), 45, y);
            g.drawString(String.valueOf(scores.get(i)), width - 180, y);
            g.drawString(time, width - 90, y);
        }
        g.drawString("Press H or ESC to return", 40, height - 35);
    }
}