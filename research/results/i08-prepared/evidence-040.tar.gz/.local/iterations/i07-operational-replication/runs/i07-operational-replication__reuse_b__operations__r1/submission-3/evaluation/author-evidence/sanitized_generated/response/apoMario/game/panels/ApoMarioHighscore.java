package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.level.ApoMarioLevel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Persistent, local highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 1000;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final int score;
        final int time;
        final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store == null ? Paths.get("apomario-highscores.dat") : store;
        load();
    }

    public synchronized void recordRunEnd(apoMario.level.ApoMarioLevel level) {
        if (level == null || level.isHighscoreRecorded() || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || player.getAi() != null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed;
        try { elapsed = Math.max(0, level.getPassedTime()); }
        catch (RuntimeException ex) { elapsed = Math.max(0, level.getStartTime() - level.getTime()); }
        if (storeRun(player.getPoints(), elapsed, name)) {
            level.setHighscoreRecorded(true);
            persistAcrossRuns();
        }
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(score, survivalTime, name));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) { out.write(Integer.toString(e.score)); out.write('\t'); out.write(Integer.toString(e.time)); out.write('\t'); out.write(e.name); out.newLine(); }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
        }
    }

    private synchronized void load() {
        if (!Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 1024) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = in.readLine()) != null && count++ < MAX_ENTRIES) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        try { int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]); if (storeRun(score, time, p[2])) { } }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { in.close(); }
        } catch (IOException ignored) { }
    }

    private static String normalize(String value) {
        if (value == null) return null;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return null;
        return s;
    }
}