package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated renderer for the local highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(35, 25, ApoMarioConstants.GAME_WIDTH - 70, ApoMarioConstants.GAME_HEIGHT - 50, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(35, 25, ApoMarioConstants.GAME_WIDTH - 70, ApoMarioConstants.GAME_HEIGHT - 50, 20, 20);
        g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 55, 60);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 15; i++) {
            int y = 90 + i * 25;
            int millis = times.get(i);
            int seconds = millis / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString(String.valueOf(i + 1), 60, y);
            g.drawString(names.get(i), 100, y);
            g.drawString(String.valueOf(points.get(i)), 330, y);
            g.drawString(time, 430, y);
        }
        g.drawString("ESC / H: back", 55, ApoMarioConstants.GAME_HEIGHT - 45);
    }
}