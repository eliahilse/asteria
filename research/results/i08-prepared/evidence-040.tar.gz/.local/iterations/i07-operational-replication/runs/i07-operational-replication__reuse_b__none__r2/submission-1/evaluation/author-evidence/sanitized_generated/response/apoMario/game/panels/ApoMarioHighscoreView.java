package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

/** Marker type for integrations that want to refer to the menu's highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
}