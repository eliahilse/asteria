package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 1000;
    private static final int MAX_NAME_LENGTH = 64;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private static final class Entry { int score, time; String name; Entry(int s, int t, String n) { score=s; time=t; name=n; } }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = clean(playerName); if (name.length() == 0) name = "Player";
        entries.add(new Entry(score, Math.max(0, survivalTime), name)); sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { List<String> r=new ArrayList<String>(); for(Entry e:entries)r.add(e.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r=new ArrayList<Integer>(); for(Entry e:entries)r.add(e.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r=new ArrayList<Integer>(); for(Entry e:entries)r.add(e.time); return Collections.unmodifiableList(r); }
    public synchronized void persistAcrossRuns() {
        if (store == null) return; Path temp = null;
        try { Path file=store.toAbsolutePath(); Path parent=file.getParent(); if(parent!=null)Files.createDirectories(parent); temp=file.resolveSibling(file.getFileName()+".tmp");
            BufferedWriter w=Files.newBufferedWriter(temp, StandardCharsets.UTF_8); try { for(Entry e:entries) { w.write(e.score+"\t"+e.time+"\t"+Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8))); w.newLine(); } } finally { w.close(); }
            try { Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); } catch(AtomicMoveNotSupportedException x) { Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING); }
        } catch(IOException x) { if(temp!=null)try{Files.deleteIfExists(temp);}catch(IOException ignored){} }
    }
    public synchronized void recordRunEnd(ApoMarioLevel level) { if(level==null||level.getPlayers()==null||level.getPlayers().isEmpty())return; ApoMarioPlayer p=level.getPlayers().get(0); if(p!=null)storeRun(p.getPoints(),level.getPassedTime(),p.getTeamName()); }
    private void load() { if(store==null)return; try { if(!Files.exists(store)||Files.size(store)>MAX_FILE_SIZE)return; List<Entry> r=new ArrayList<Entry>(); BufferedReader b=Files.newBufferedReader(store,StandardCharsets.UTF_8); try { String line; while((line=b.readLine())!=null&&r.size()<MAX_RECORDS){String[] f=line.split("\\t",-1); if(f.length!=3)continue; int s=Integer.parseInt(f[0]),t=Integer.parseInt(f[1]); if(t<0)continue; String n=clean(new String(Base64.getDecoder().decode(f[2]),StandardCharsets.UTF_8)); if(n.length()>0)r.add(new Entry(s,t,n));}} finally{b.close();} entries.clear();entries.addAll(r);sort(); } catch(Exception x){entries.clear();} }
    private String clean(String s) { if(s==null)return ""; s=s.replace('\t',' ').replace('\r',' ').replace('\n',' ').trim(); return s.length()>MAX_NAME_LENGTH?s.substring(0,MAX_NAME_LENGTH):s; }
    private void sort() { Collections.sort(entries,new Comparator<Entry>(){public int compare(Entry a,Entry b){return a.score==b.score?0:(a.score<b.score?1:-1);}}); while(entries.size()>MAX_RECORDS)entries.remove(entries.size()-1); }
}