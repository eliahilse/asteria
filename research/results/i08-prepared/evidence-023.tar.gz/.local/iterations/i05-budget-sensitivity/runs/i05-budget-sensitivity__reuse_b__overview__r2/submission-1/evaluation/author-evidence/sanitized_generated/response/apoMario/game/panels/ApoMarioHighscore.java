package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local, path-backed highscore table. */
public class ApoMarioHighscore {
    private static final int MAX_NAME = 32;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name;
        int score;
        int time;
        Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store");
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sort();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Records the completed human run after ApoMarioLevel has applied its final score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 255, 235));
        g.fillRoundRect(20, 20, width - 40, height - 40, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 40, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        g.drawString("#", 45, 85);
        g.drawString("Player", 85, 85);
        g.drawString("Points", width - 210, 85);
        g.drawString("Time", width - 100, 85);
        for (int i = 0; i < entries.size() && i < 15; i++) {
            Entry e = entries.get(i);
            int y = 112 + i * 25;
            g.drawString(String.valueOf(i + 1), 45, y);
            g.drawString(e.name, 85, y);
            g.drawString(String.valueOf(e.score), width - 210, y);
            g.drawString(formatTime(e.time), width - 100, y);
        }
        g.drawString("Press Escape to return", 40, height - 35);
    }

    public static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    private String cleanName(String value) {
        if (value == null) value = "Player";
        value = value.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').trim();
        if (value.length() == 0) value = "Player";
        return value.length() > MAX_NAME ? value.substring(0, MAX_NAME) : value;
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
    }

    private void load() {
        entries.clear();
        if (!Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    entries.add(new Entry(cleanName(p[0]), Integer.parseInt(p[1]), Math.max(0, Integer.parseInt(p[2]))));
                } catch (NumberFormatException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                for (Entry e : entries) writer.write(e.name + "\t" + e.score + "\t" + e.time + "\n");
            }
            try {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }
}