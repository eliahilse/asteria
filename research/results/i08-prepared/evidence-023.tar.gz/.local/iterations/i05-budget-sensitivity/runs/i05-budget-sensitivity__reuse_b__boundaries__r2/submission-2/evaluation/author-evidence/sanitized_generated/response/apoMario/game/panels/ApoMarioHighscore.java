package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        names.add(cleanName(playerName));
        scores.add(Math.max(0, score));
        times.add(Math.max(0, survivalTime));
        sort();
        while (names.size() > MAX_RECORDS) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            times.remove(times.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = null;
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    writer.write(Integer.toString(scores.get(i)));
                    writer.write('\t');
                    writer.write(Integer.toString(times.get(i)));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    private void load() {
        if (store == null) return;
        try {
            Path absolute = store.toAbsolutePath();
            if (!Files.exists(absolute) || Files.size(absolute) > MAX_FILE_SIZE) return;
            BufferedReader reader = Files.newBufferedReader(absolute, StandardCharsets.UTF_8);
            try {
                String line;
                while (names.size() < MAX_RECORDS && (line = reader.readLine()) != null) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        String name = new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8);
                        if (score >= 0 && time >= 0 && name.length() > 0 && name.length() <= MAX_NAME_LENGTH) {
                            names.add(cleanName(name)); scores.add(score); times.add(time);
                        }
                    } catch (RuntimeException ignored) { }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ex) {
            names.clear(); scores.clear(); times.clear();
        }
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        String result = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) result = "Player";
        return result.length() > MAX_NAME_LENGTH ? result.substring(0, MAX_NAME_LENGTH) : result;
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer left, Integer right) {
                int result = scores.get(right).compareTo(scores.get(left));
                return result != 0 ? result : left.compareTo(right);
            }
        });
        List<String> sortedNames = new ArrayList<String>();
        List<Integer> sortedScores = new ArrayList<Integer>();
        List<Integer> sortedTimes = new ArrayList<Integer>();
        for (Integer index : order) {
            sortedNames.add(names.get(index)); sortedScores.add(scores.get(index)); sortedTimes.add(times.get(index));
        }
        names.clear(); names.addAll(sortedNames);
        scores.clear(); scores.addAll(sortedScores);
        times.clear(); times.addAll(sortedTimes);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        storeRun(player.getPoints(), level.getPassedTime(), player.getTeamName());
    }

    public synchronized void render(Graphics2D graphics, int width, int height) {
        graphics.setColor(Color.WHITE); graphics.fillRect(0, 0, width, height);
        graphics.setColor(Color.BLACK); graphics.setFont(new Font("Dialog", Font.BOLD, 24));
        graphics.drawString("Highscores", 30, 40);
        graphics.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < names.size() && i < 20; i++) {
            int y = 75 + i * 24;
            graphics.drawString((i + 1) + ". " + names.get(i), 35, y);
            graphics.drawString(Integer.toString(scores.get(i)), width / 2, y);
            graphics.drawString(formatTime(times.get(i)), width * 3 / 4, y);
        }
        graphics.drawString("Esc: back", 30, height - 20);
    }

    private String formatTime(int milliseconds) {
        long seconds = Math.max(0L, (long) milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}