package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.game.ApoMarioPanel;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends ApoMarioModel {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;

    private static final class Run {
        private final int score;
        private final int time;
        private final String name;
        private Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private boolean dirty;

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public ApoMarioHighscore(ApoMarioPanel game, Path store) {
        super(game);
        this.store = store;
        load();
    }

    private String safeName(String value) {
        if (value == null) return "Player";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\t' && c != '\r' && c != '\n') result.append(c);
        }
        String name = result.toString().trim();
        return name.length() == 0 ? "Player" : name;
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                if (a.score != b.score) return a.score < b.score ? 1 : -1;
                return a.name.compareTo(b.name);
            }
        });
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        runs.add(new Run(score, Math.max(0, survivalTime), safeName(playerName)));
        sort();
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        dirty = true;
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (!dirty || store == null) return;
        Path temporary = null;
        try {
            Path absolute = store.toAbsolutePath();
            if (absolute.getParent() != null) Files.createDirectories(absolute.getParent());
            temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.time));
                    writer.write('\t');
                    writer.write(run.name);
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING); }
            dirty = false;
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    private synchronized void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_SIZE) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            List<Run> loaded = new ArrayList<Run>();
            try {
                String line;
                while (loaded.size() < MAX_RECORDS && (line = reader.readLine()) != null) {
                    String[] fields = line.split("\\t", 3);
                    if (fields.length != 3) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        if (time >= 0) loaded.add(new Run(score, time, safeName(fields[2])));
                    } catch (NumberFormatException ignored) { }
                }
            } finally { reader.close(); }
            runs.clear();
            runs.addAll(loaded);
            sort();
        } catch (IOException ex) { runs.clear(); }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null && player.getAi() != null) name = player.getAi().getAuthor();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private String displayTime(int milliseconds) {
        long seconds = Math.max(0L, (long) milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    public void init() { }
    public void think(int delta) { }
    public void mouseButtonFunction(String function) { if ("back".equals(function)) getGame().setMenu(); }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean right) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }

    public void render(Graphics2D g) {
        g.setColor(new Color(245, 245, 255));
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        List<String> names = getPlayersNames();
        List<Integer> scores = getPlayersScores();
        List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 20; i++) {
            int y = 85 + i * 24;
            g.drawString((i + 1) + ". " + names.get(i), 35, y);
            g.drawString(Integer.toString(scores.get(i)), 300, y);
            g.drawString(displayTime(times.get(i)), 420, y);
        }
        if (names.isEmpty()) g.drawString("No runs recorded yet", 35, 85);
        g.drawString("Esc: back", 35, ApoMarioConstants.GAME_HEIGHT - 20);
    }
}