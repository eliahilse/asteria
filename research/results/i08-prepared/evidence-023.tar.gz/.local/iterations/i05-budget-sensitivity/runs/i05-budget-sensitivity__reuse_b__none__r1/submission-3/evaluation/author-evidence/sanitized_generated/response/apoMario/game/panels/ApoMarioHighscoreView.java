package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255,255,255,235));
        g.fillRoundRect(35,25,ApoMarioConstants.GAME_WIDTH-70,ApoMarioConstants.GAME_HEIGHT-50,18,18);
        g.setColor(Color.BLACK); g.drawRoundRect(35,25,ApoMarioConstants.GAME_WIDTH-70,ApoMarioConstants.GAME_HEIGHT-50,18,18);
        g.setFont(new Font("Dialog",Font.BOLD,24)); g.drawString("HIGHSCORES",55,60);
        g.setFont(new Font("Dialog",Font.PLAIN,16));
        List<String> n=scores.getPlayersNames(); List<Integer> p=scores.getPlayersScores(); List<Integer> t=scores.getSurvivalTimes();
        for (int i=0;i<n.size() && i<12;i++) { int y=90+i*24; g.drawString(String.valueOf(i+1),55,y); g.drawString(n.get(i),95,y); g.drawString(String.valueOf(p.get(i)),330,y); g.drawString(ApoMarioHighscore.formatTime(t.get(i).intValue()),430,y); }
        g.drawString("ESC / H: back",55,ApoMarioConstants.GAME_HEIGHT-35);
    }
}