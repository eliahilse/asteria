package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import java.util.*;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Font;

import apoMario.ApoMarioConstants;

/** Small dedicated renderer used by the menu for the local highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore score) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(35, 35, ApoMarioConstants.GAME_WIDTH - 70, ApoMarioConstants.GAME_HEIGHT - 70, 20, 20);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 55, 75);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        java.util.List<String> n = score.getPlayersNames(); java.util.List<Integer> p = score.getPlayersScores(); java.util.List<Integer> t = score.getSurvivalTimes();
        int max = Math.min(15, n.size());
        for (int i = 0; i < max; i++) {
            int ms = Math.max(0, t.get(i)); int sec = ms / 1000;
            String time = String.format("%02d:%02d", sec / 60, sec % 60);
            g.drawString((i + 1) + ". " + n.get(i), 65, 105 + i * 22);
            g.drawString(String.valueOf(p.get(i)), 330, 105 + i * 22);
            g.drawString(time, 430, 105 + i * 22);
        }
        if (max == 0) g.drawString("No runs recorded yet", 65, 115);
        g.drawString("Press H or Escape to return", 65, ApoMarioConstants.GAME_HEIGHT - 45);
    }
}