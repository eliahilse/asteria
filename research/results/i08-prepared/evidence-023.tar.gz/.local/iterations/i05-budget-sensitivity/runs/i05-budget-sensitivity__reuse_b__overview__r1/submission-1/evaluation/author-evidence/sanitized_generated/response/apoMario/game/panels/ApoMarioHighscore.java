package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local, path-backed highscore table. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final String name;
        private final int score;
        private final int time;
        private Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sort();
        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }
        try {
            persist();
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return Collections.unmodifiableList(result);
    }

    /** Rewrites the current table, retaining it for future game launches. */
    public synchronized void persistAcrossRuns() {
        try {
            persist();
        } catch (IOException ex) {
            // The game remains playable when the selected store is unavailable.
        }
    }

    /** Records the final, already-scored player state exactly once per level end. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    /** Used by the Mario menu; time is converted only at presentation time. */
    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 20));
        g.drawString("HIGHSCORES", x, y);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        if (entries.isEmpty()) {
            g.drawString("No runs recorded", x, y + 35);
            return;
        }
        for (int i = 0; i < entries.size() && i < 12; i++) {
            Entry e = entries.get(i);
            int row = y + 35 + i * 22;
            g.drawString(String.valueOf(i + 1), x, row);
            g.drawString(e.name, x + 30, row);
            g.drawString(String.valueOf(e.score), x + width - 150, row);
            g.drawString(formatTime(e.time), x + width - 70, row);
        }
    }

    public static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    private void load() {
        if (!Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            int magic = in.readInt();
            int version = in.readInt();
            int count = in.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_ENTRIES) {
                in.close();
                return;
            }
            for (int i = 0; i < count; i++) {
                entries.add(new Entry(cleanName(in.readUTF()), in.readInt(), Math.max(0, in.readInt())));
            }
            in.close();
            sort();
        } catch (IOException | RuntimeException ex) {
            entries.clear();
        }
    }

    private void persist() throws IOException {
        Path parent = store.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
        DataOutputStream out = new DataOutputStream(Files.newOutputStream(temporary));
        out.writeInt(MAGIC);
        out.writeInt(VERSION);
        out.writeInt(entries.size());
        for (Entry entry : entries) {
            out.writeUTF(entry.name);
            out.writeInt(entry.score);
            out.writeInt(entry.time);
        }
        out.close();
        try {
            Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException ex) {
            Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
            }
        });
    }

    private static String cleanName(String name) {
        if (name == null) return "Player";
        String value = name.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').trim();
        if (value.length() == 0) return "Player";
        return value.length() > 32 ? value.substring(0, 32) : value;
    }
}