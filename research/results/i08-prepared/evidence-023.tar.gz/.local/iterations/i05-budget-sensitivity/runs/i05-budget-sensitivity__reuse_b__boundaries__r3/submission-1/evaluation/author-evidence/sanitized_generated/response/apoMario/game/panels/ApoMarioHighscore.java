package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local-only, file-backed high score board. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE_BYTES = 1024L * 1024L;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store");
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temporary = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                writer.write("APO_MARIO_HIGHSCORE_1"); writer.newLine();
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score)); writer.write('\t');
                    writer.write(Integer.toString(run.time)); writer.write('\t');
                    writer.write(run.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " ").replace("\r", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    /** Records the authoritative post-terminal score of the human player. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || player.getAi() != null) return;
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.drawString("HIGHSCORES", x, y);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run run = runs.get(i);
            long seconds = ((long)run.time) / 1000L;
            long minutes = seconds / 60L;
            String time = String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds % 60L));
            g.drawString((i + 1) + ". " + run.name, x, y + 28 + i * 22);
            g.drawString(Integer.toString(run.score), x + width / 2, y + 28 + i * 22);
            g.drawString(time, x + width - 65, y + 28 + i * 22);
        }
    }

    private void load() {
        if (!Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE_BYTES) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            List<Run> loaded = new ArrayList<Run>();
            try {
                String line = reader.readLine();
                if (!"APO_MARIO_HIGHSCORE_1".equals(line)) return;
                while ((line = reader.readLine()) != null && loaded.size() < MAX_RECORDS) {
                    String[] fields = line.split("\\t", 3);
                    if (fields.length != 3) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        String name = cleanName(fields[2]);
                        if (name.length() > 0 && time >= 0) loaded.add(new Run(score, time, name));
                    } catch (NumberFormatException ignored) { }
                }
            } finally { reader.close(); }
            runs.clear(); runs.addAll(loaded); sortAndTrim();
        } catch (IOException ignored) { }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\\' && c != '\t' && c != '\r' && c != '\n') result.append(c);
        }
        return result.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); } });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
}