package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        names.add(name); scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) { int i = names.size() - 1; names.remove(i); scores.remove(i); survivalTimes.remove(i); }
        persistAcrossRuns();
        return true;
    }
    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes)); }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(store)));
            out.writeInt(VERSION); out.writeInt(names.size());
            for (int i = 0; i < names.size(); i++) { out.writeUTF(names.get(i)); out.writeInt(scores.get(i).intValue()); out.writeInt(survivalTimes.get(i).intValue()); }
            out.close();
        } catch (IOException ignored) { }
    }
    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != VERSION) { in.close(); return; }
            int count = Math.min(MAX_ENTRIES, Math.max(0, in.readInt()));
            for (int i = 0; i < count; i++) { names.add(in.readUTF()); scores.add(Integer.valueOf(in.readInt())); survivalTimes.add(Integer.valueOf(Math.max(0, in.readInt()))); }
            in.close(); sort();
        } catch (EOFException ignored) { names.clear(); scores.clear(); survivalTimes.clear(); }
        catch (IOException ignored) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }
    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(survivalTimes.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
    public static String formatTime(int milliseconds) { int seconds = Math.max(0, milliseconds) / 1000; return String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60)); }
}