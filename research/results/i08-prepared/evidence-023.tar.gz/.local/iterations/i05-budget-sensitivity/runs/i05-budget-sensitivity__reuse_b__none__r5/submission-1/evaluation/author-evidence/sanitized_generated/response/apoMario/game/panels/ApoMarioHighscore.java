package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Persistent local highscore table. Times are kept in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int i = names.size() - 1;
            names.remove(i); scores.remove(i); survivalTimes.remove(i);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) {
                lines.add(scores.get(i) + "|" + survivalTimes.get(i) + "|" +
                        Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(store, lines, StandardCharsets.UTF_8);
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\|", 3);
                if (p.length != 3) continue;
                try {
                    scores.add(Integer.valueOf(p[0]));
                    survivalTimes.add(Integer.valueOf(p[1]));
                    names.add(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                } catch (IllegalArgumentException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); scores.clear(); survivalTimes.clear(); names.addAll(n); scores.addAll(s); survivalTimes.addAll(t);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("HIGHSCORES", width / 2 - 85, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < names.size() && i < 15; i++) {
            int y = 90 + i * 25;
            g.drawString((i + 1) + ".", 45, y);
            g.drawString(names.get(i), 80, y);
            g.drawString(String.valueOf(scores.get(i)), width - 190, y);
            int seconds = survivalTimes.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 95, y);
        }
        g.drawString("Press ESC or H to return", 20, height - 20);
    }
}