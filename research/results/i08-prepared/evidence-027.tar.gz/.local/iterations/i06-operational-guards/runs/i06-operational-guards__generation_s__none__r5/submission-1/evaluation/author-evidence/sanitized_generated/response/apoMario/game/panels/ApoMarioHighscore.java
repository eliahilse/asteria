package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered results for completed runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 50;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.survivalTime);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score));
                    writer.write("\t");
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.write("\t");
                    writer.write(entry.name.replace("\\", "\\\\").replace("\t", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
        } catch (IOException ignored) { }
    }

    /** Records the real primary player's result at the end of a live run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    /** Draws the board; survival times remain milliseconds until this point. */
    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(Color.BLACK);
        g.drawString("HIGHSCORES", x, y);
        int row = y + 24;
        int count = Math.min(entries.size(), 12);
        for (int i = 0; i < count; i++) {
            Entry e = entries.get(i);
            long seconds = Math.max(0, e.survivalTime) / 1000L;
            String time = String.format("%02d:%02d", seconds / 60L, seconds % 60L);
            g.drawString((i + 1) + ". " + e.name, x, row);
            g.drawString(Integer.toString(e.score), x + width / 2, row);
            g.drawString(time, x + width - 55, row);
            row += 18;
        }
        if (count == 0) g.drawString("No completed runs", x, row);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", 3);
                    if (parts.length == 3) {
                        try { entries.add(new Entry(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), parts[2])); }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { reader.close(); }
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private static final class Entry {
        final int score, survivalTime; final String name;
        Entry(int score, int survivalTime, String name) { this.score = score; this.survivalTime = survivalTime; this.name = name; }
    }
}