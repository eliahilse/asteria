package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

/** Marker view type for integrations that need a dedicated highscore panel. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
}