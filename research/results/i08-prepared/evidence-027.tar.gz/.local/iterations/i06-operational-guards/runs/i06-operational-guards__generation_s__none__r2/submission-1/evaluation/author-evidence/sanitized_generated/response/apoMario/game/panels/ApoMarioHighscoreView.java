package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small dedicated menu view for the persistent highscore table. */
public class ApoMarioHighscoreView {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g) {
        int x = 28 * ApoMarioConstants.SIZE;
        int y = 28 * ApoMarioConstants.SIZE;
        int w = ApoMarioConstants.GAME_WIDTH - 56 * ApoMarioConstants.SIZE;
        int h = ApoMarioConstants.GAME_HEIGHT - 48 * ApoMarioConstants.SIZE;
        g.setColor(new Color(255, 255, 255, 235)); g.fillRoundRect(x, y, w, h, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(x, y, w, h, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", x + 18, y + 28);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        int rows = Math.min(names.size(), 8);
        for (int i = 0; i < rows; i++) {
            int minutes = times.get(i) / 60000;
            int seconds = (times.get(i) % 60000) / 1000;
            String time = String.format("%02d:%02d", minutes, seconds);
            g.drawString((i + 1) + ". " + names.get(i), x + 18, y + 58 + i * 20);
            g.drawString(String.valueOf(scores.get(i)), x + w - 125, y + 58 + i * 20);
            g.drawString(time, x + w - 65, y + 58 + i * 20);
        }
        g.setFont(ApoMarioConstants.FONT_FPS); g.drawString("H / ESC: back", x + 18, y + h - 12);
    }
}