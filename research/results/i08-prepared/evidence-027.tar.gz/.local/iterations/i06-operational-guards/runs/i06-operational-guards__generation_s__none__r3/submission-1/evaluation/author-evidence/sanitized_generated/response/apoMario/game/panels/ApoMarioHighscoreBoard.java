package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreBoard;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small dedicated renderer used by the menu for the persistent highscore. */
public class ApoMarioHighscoreBoard {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreBoard(ApoMarioHighscore highscore) {
        this.highscore = highscore;
    }
    public void render(Graphics2D g) {
        int size = ApoMarioConstants.SIZE;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(20 * size, 18 * size, ApoMarioConstants.GAME_WIDTH - 40 * size,
                ApoMarioConstants.GAME_HEIGHT - 36 * size, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(20 * size, 18 * size, ApoMarioConstants.GAME_WIDTH - 40 * size,
                ApoMarioConstants.GAME_HEIGHT - 36 * size, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 35 * size, 35 * size);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        int rows = Math.min(names.size(), 8);
        for (int i = 0; i < rows; i++) {
            int y = (43 + i * 12) * size;
            g.drawString((i + 1) + ". " + names.get(i), 32 * size, y);
            g.drawString(String.valueOf(scores.get(i)), 170 * size, y);
            int seconds = times.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 235 * size, y);
        }
        g.drawString("H / ESC: back", 32 * size, ApoMarioConstants.GAME_HEIGHT - 25 * size);
    }
}