package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** The menu's dedicated high-score view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20, 15, ApoMarioConstants.GAME_WIDTH-40, ApoMarioConstants.GAME_HEIGHT-30, 18, 18);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 30, 45);
        List<String> n = scores.getPlayersNames(); List<Integer> p = scores.getPlayersScores(); List<Integer> t = scores.getSurvivalTimes();
        g.setFont(ApoMarioConstants.FONT_MENU);
        if (n.isEmpty()) g.drawString("No runs recorded yet", 45, 80);
        for (int i=0; i<n.size() && i<12; i++) { int ms=t.get(i); long sec=ms/1000L; String time=(sec/60)+":"+String.format("%02d", sec%60); g.drawString((i+1)+". "+n.get(i), 40, 78+i*18); g.drawString(String.valueOf(p.get(i)), 190, 78+i*18); g.drawString(time, 255, 78+i*18); }
        g.drawString("Press H or Escape to return", 40, ApoMarioConstants.GAME_HEIGHT-25);
    }
}