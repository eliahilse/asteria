package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, score-ordered run history and its small menu view. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 48;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name;
        final int score;
        final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0 || playerName == null) return false;
        String name = cleanName(playerName);
        if (name.length() == 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add("APO_MARIO_HIGHSCORE_1");
            for (Entry e : entries) {
                String encoded = Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encoded + "\t" + e.score + "\t" + e.time);
            }
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) {
            // A failed save must not interrupt a run.
        }
    }

    /** Captures the authoritative player score and elapsed level time once a run ends. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null) { chosen = p; break; }
        }
        if (chosen == null) return;
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = chosen.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        Color old = g.getColor();
        g.setColor(new Color(255,255,255,235));
        g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 18, 18);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", x + 18, y + 30);
        int row = g.getFontMetrics().getHeight() + 5;
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i);
            int minutes = e.time / 60000;
            int seconds = (e.time / 1000) % 60;
            String time = String.format("%02d:%02d", minutes, seconds);
            g.drawString((i + 1) + ". " + e.name, x + 18, y + 30 + row * (i + 1));
            g.drawString(String.valueOf(e.score), x + width - 105, y + 30 + row * (i + 1));
            g.drawString(time, x + width - 55, y + 30 + row * (i + 1));
        }
        g.setColor(old);
    }

    private synchronized void load() {
        try {
            if (!Files.isRegularFile(store)) return;
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.size() == 0 || !"APO_MARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && entries.size() < MAX_ENTRIES; i++) {
                String[] p = lines.get(i).split("\\t", -1);
                if (p.length != 3 || p[0].length() > 128) continue;
                try {
                    String name = cleanName(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8));
                    int score = Integer.parseInt(p[1]);
                    int time = Integer.parseInt(p[2]);
                    if (name.length() > 0 && time >= 0) entries.add(new Entry(name, score, time));
                } catch (Exception ignored) { }
            }
            sortAndTrim();
        } catch (Exception ignored) { }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private static String cleanName(String value) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }
}