package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu's dedicated highscore mode. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 10, height / 12, width * 8 / 10, height * 5 / 6, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(width / 10, height / 12, width * 8 / 10, height * 5 / 6, 18, 18);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 65, height / 8 + 10);
        List<String> n = scores.getPlayersNames(); List<Integer> p = scores.getPlayersScores(); List<Integer> t = scores.getSurvivalTimes();
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
        for (int i = 0; i < n.size() && i < 12; i++) {
            int y = height / 5 + i * 18;
            int seconds = t.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + n.get(i), width / 5, y);
            g.drawString(Integer.toString(p.get(i)), width / 2, y);
            g.drawString(time, width * 3 / 5, y);
        }
        if (n.isEmpty()) g.drawString("No runs recorded", width / 2 - 50, height / 2);
        g.drawString("Press H or Escape to return", width / 2 - 85, height * 9 / 10);
    }
}