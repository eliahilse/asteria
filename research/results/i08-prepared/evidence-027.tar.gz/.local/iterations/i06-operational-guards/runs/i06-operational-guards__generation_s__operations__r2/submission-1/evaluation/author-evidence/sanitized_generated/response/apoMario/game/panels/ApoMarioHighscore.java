package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 32;
    private static final long MAX_BYTES = 128 * 1024;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String cleanName(String value) {
        if (value == null) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\t') b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? null : s;
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                if (a.score != b.score) return a.score < b.score ? 1 : -1;
                return a.name.compareTo(b.name);
            }
        });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_BYTES) return;
            List<String> lines = Files.readAllLines(store, Charset.forName("UTF-8"));
            for (String line : lines) {
                if (entries.size() >= MAX_RECORDS || line.length() > 256) break;
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                String n = cleanName(p[0]);
                int score, time;
                try { score = Integer.parseInt(p[1]); time = Integer.parseInt(p[2]); }
                catch (NumberFormatException ex) { continue; }
                if (n != null && time >= 0) entries.add(new Entry(n, score, time));
            }
            sort();
        } catch (Exception ex) { entries.clear(); }
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String n = cleanName(playerName);
        if (n == null || survivalTime < 0) return false;
        entries.add(new Entry(n, score, survivalTime));
        sort();
        return persist();
    }

    public synchronized void persistAcrossRuns() { persist(); }

    private boolean persist() {
        if (store == null) return false;
        Path parent = store.toAbsolutePath().getParent();
        try {
            if (parent != null) Files.createDirectories(parent);
            Path tmp = Files.createTempFile(parent, "highscore", ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            for (Entry e : entries) lines.add(e.name + "\t" + e.score + "\t" + e.time);
            Files.write(tmp, lines, Charset.forName("UTF-8"), StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (Exception ex) { return false; }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> r = new ArrayList<String>(); for (Entry e : entries) r.add(e.name); return r;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.score); return r;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.time); return r;
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null && p.isBVisible()) { chosen = p; break; }
        }
        if (chosen == null) return;
        String name = level.getPlayerName(chosen);
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(chosen.getPoints(), elapsed, name);
    }

    public synchronized void renderBoard(Graphics2D g, int x, int y, int width) {
        g.setColor(Color.BLACK); g.drawString("HIGHSCORES", x, y);
        List<String> n = getPlayersNames(); List<Integer> s = getPlayersScores(); List<Integer> t = getSurvivalTimes();
        if (n.isEmpty()) { g.drawString("No runs recorded", x, y + 24); return; }
        int row = 22;
        for (int i = 0; i < n.size() && i < 12; i++) {
            int seconds = t.get(i) / 1000;
            String tm = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + n.get(i), x, y + row * (i + 1));
            g.drawString(String.valueOf(s.get(i)), x + width / 2, y + row * (i + 1));
            g.drawString(tm, x + width - 55, y + row * (i + 1));
        }
    }
}