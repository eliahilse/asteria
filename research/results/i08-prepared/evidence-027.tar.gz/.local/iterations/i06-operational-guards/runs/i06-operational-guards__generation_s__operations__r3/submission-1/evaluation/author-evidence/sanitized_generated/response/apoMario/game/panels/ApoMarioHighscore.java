package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 32;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String cleanName(String value) {
        if (value == null) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\t' && c != '\r' && c != '\n') b.append(c);
        }
        String result = b.toString().trim();
        return result.length() == 0 ? "Player" : result;
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                if (a.score != b.score) return a.score < b.score ? 1 : -1;
                return a.name.compareTo(b.name);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sort();
        return persist();
    }

    public synchronized void persistAcrossRuns() { persist(); }

    private boolean persist() {
        if (store == null) return false;
        Path parent = store.toAbsolutePath().getParent();
        if (parent == null) parent = store.toAbsolutePath().getParent();
        try {
            if (parent != null) Files.createDirectories(parent);
            Path temp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Run r : runs) {
                    String encoded = Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8));
                    out.write(Integer.toString(r.score)); out.write('\t');
                    out.write(Integer.toString(r.time)); out.write('\t');
                    out.write(encoded); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException e) { return false; }
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = in.readLine()) != null && count++ < MAX_RECORDS) {
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3 || p[2].length() > 256) continue;
                    try {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        if (time < 0) continue;
                        String name = cleanName(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                        if (name != null) runs.add(new Run(score, time, name));
                    } catch (RuntimeException e) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sort();
        } catch (IOException e) { runs.clear(); }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return result;
    }

    /** Records the first human player in the finished level, after terminal scoring. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null) { selected = p; break; }
        }
        if (selected == null) return;
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        String name = cleanName(selected.getTeamName());
        storeRun(selected.getPoints(), elapsed, name);
    }
}