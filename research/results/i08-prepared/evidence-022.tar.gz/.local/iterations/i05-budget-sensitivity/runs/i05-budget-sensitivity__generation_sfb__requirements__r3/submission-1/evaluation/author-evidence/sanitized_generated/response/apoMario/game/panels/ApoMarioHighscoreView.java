package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Lightweight renderer for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 45, 55);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        int rows = Math.min(names.size(), 10);
        for (int i = 0; i < rows; i++) {
            int seconds = Math.max(0, times.get(i)) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 50, 85 + i * 18);
            g.drawString(String.valueOf(points.get(i)), 210, 85 + i * 18);
            g.drawString(time, 270, 85 + i * 18);
        }
        if (rows == 0) g.drawString("No runs recorded yet", 50, 90);
        g.drawString("Press H or ESC to return", 50, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}