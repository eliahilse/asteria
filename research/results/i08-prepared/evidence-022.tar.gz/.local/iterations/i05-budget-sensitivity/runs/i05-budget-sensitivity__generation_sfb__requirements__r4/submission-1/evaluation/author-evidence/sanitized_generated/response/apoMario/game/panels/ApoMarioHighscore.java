package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;

/** Persistent scores and the small, self-contained highscore board view. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504f48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 32;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first terminal result observed for this level instance. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        if (!level.markHighscoreRecorded()) {
            return;
        }
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(runs.size());
            for (Run run : runs) {
                out.writeInt(run.score);
                out.writeInt(run.time);
                out.writeUTF(run.name);
            }
            out.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A read-only or unavailable score file must not stop the game.
        }
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(245, 245, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 90, 55);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("ESC: back", 15, ApoMarioConstants.GAME_HEIGHT - 12);
        int y = 82;
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run run = runs.get(i);
            g.drawString((i + 1) + ".", 42, y);
            g.drawString(run.name, 68, y);
            g.drawString(String.valueOf(run.score), 190, y);
            g.drawString(formatTime(run.time), 255, y);
            y += 13;
        }
        if (runs.isEmpty()) g.drawString("No runs recorded", 85, 100);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    private static String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        StringBuilder result = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isISOControl(c)) return null;
            result.append(c);
        }
        return result.toString();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                int score = in.readInt();
                int time = in.readInt();
                String name = cleanName(in.readUTF());
                if (name == null || time < 0) { in.close(); runs.clear(); return; }
                runs.add(new Run(score, time, name));
            }
            in.close();
            sortAndTrim();
        } catch (IOException ex) {
            runs.clear();
        }
    }
}