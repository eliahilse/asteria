package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run records. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Record> records = new ArrayList<Record>();

    private static final class Record {
        String name;
        int score;
        int time;
        Record(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name.length() == 0 || score < Integer.MIN_VALUE || survivalTime < 0) return false;
        records.add(new Record(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the authoritative first human player's result before the level is reset. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null && p.isBVisible()) { chosen = p; break; }
        }
        if (chosen == null) chosen = level.getPlayers().get(0);
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(Integer.valueOf(r.score));
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(Integer.valueOf(r.time));
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                out.write("APO_MARIO_HIGHSCORE_1"); out.newLine();
                for (Record r : records) {
                    out.write(Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)));
                    out.write('\t'); out.write(Integer.toString(r.score));
                    out.write('\t'); out.write(Integer.toString(r.time)); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed highscore must not stop the game. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE_1".equals(in.readLine())) return;
                String line;
                while (records.size() < MAX_RECORDS && (line = in.readLine()) != null) {
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3 || p[0].length() > 256) continue;
                    try {
                        String name = normalize(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8));
                        int score = Integer.parseInt(p[1]);
                        int time = Integer.parseInt(p[2]);
                        if (name.length() > 0 && time >= 0) records.add(new Record(name, score, time));
                    } catch (RuntimeException ex) { /* ignore malformed persisted records */ }
                }
            } finally { in.close(); }
        } catch (IOException ex) { /* missing or unreadable stores are treated as empty */ }
        sortAndTrim();
    }

    private String normalize(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
    }
}