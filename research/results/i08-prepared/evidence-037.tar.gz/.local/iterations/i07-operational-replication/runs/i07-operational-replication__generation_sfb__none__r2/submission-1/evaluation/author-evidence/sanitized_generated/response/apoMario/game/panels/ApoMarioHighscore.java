package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Unknown" : playerName.trim();
        if (name.length() == 0) name = "Unknown";
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, name));
        sort();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Records the best actual player in the finished level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (best == null || player.getPoints() > best.getPoints())) best = player;
        }
        if (best == null) best = level.getPlayers().get(0);
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(best.getPoints(), level.getPassedTime(), name);
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, UTF8)) {
                String[] p = line.split("\\t", -1);
                if (p.length == 3) {
                    try { runs.add(new Run(Integer.parseInt(p[0]), Integer.parseInt(p[1]), p[2])); }
                    catch (NumberFormatException ignored) { }
                }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Run run : runs) lines.add(run.score + "\t" + run.time + "\t" + run.name.replace("\t", " ").replace("\n", " "));
            Files.write(store, lines, UTF8);
            return true;
        } catch (IOException ignored) { return false; }
    }
}