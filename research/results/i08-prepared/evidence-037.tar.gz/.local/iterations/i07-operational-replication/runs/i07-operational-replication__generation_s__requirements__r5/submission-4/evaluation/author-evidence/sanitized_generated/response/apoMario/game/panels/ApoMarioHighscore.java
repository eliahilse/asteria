package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 48;

    private static final class Run {
        String name;
        int score;
        int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private final Map<ApoMarioLevel, Boolean> recordedLevels = new IdentityHashMap<ApoMarioLevel, Boolean>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score > b.score ? -1 : 1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(Integer.valueOf(run.score));
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(Integer.valueOf(run.time));
        return Collections.unmodifiableList(result);
    }

    /** Records the first human player at the authoritative end of this level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        String key = level.getClass().getName() + ":" + player.getPoints() + ":" + level.getPassedTime() + ":" + name;
        if (recordedLevels.containsKey(level)) return;
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) recordedLevels.put(level, Boolean.TRUE);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run run : runs) { out.writeUTF(run.name); out.writeInt(run.score); out.writeInt(run.time); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException e) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) {
            // A read-only or unavailable store must not stop the game.
        }
    }

    private String cleanName(String value) {
        if (value == null) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        String result = b.toString().trim();
        return result.length() == 0 ? null : result;
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = cleanName(in.readUTF()); int score = in.readInt(); int time = in.readInt();
                if (name != null && time >= 0) runs.add(new Run(name, score, time));
            }
            in.close();
            Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        } catch (IOException e) { runs.clear(); }
    }
}