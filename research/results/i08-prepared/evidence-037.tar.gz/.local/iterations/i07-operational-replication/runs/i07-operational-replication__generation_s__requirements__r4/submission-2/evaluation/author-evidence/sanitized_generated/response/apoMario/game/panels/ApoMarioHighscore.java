package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();
    private ApoMarioLevel recordedLevel;

    private static final class Entry {
        private final String name;
        private final int score;
        private final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level == recordedLevel || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (normalize(name) == null) name = "Player";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) recordedLevel = level;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    private String normalize(String value) {
        if (value == null) return null;
        String result = value.trim().replace('\t', ' ').replace('\r', ' ').replace('\n', ' ');
        if (result.length() == 0) return null;
        return result.length() > MAX_NAME_LENGTH ? result.substring(0, MAX_NAME_LENGTH) : result;
    }
    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line; int count = 0;
            while ((line = reader.readLine()) != null && count++ < MAX_ENTRIES) {
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3) continue;
                try {
                    String name = normalize(fields[0]);
                    int score = Integer.parseInt(fields[1]);
                    int time = Integer.parseInt(fields[2]);
                    if (name != null && time >= 0) entries.add(new Entry(name, score, time));
                } catch (NumberFormatException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                for (Entry e : entries) writer.write(e.name + "\t" + e.score + "\t" + e.time + "\n");
            }
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) { }
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, 190, 12, 12);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, 190, 12, 12);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        g.drawString("HIGHSCORES", x + 12, y + 22);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
        for (int i = 0; i < entries.size() && i < 8; i++) {
            Entry e = entries.get(i);
            int row = y + 42 + i * 18;
            int seconds = e.time / 1000;
            g.drawString((i + 1) + ". " + e.name, x + 12, row);
            g.drawString(String.valueOf(e.score), x + width - 105, row);
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), x + width - 55, row);
        }
    }
}