package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Graphics2D;

/** Small dedicated menu view facade for the persistent high-score board. */
public class ApoMarioHighscoreView {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g) { highscore.renderBoard(g, 35, 35); }
}