package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, score-sorted run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 20;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final int score;
        private final int time;
        private final String name;
        private Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String safeName = playerName == null ? "Player" : playerName.trim();
        if (safeName.length() == 0) safeName = "Player";
        entries.add(new Entry(score, Math.max(0, survivalTime), safeName));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score));
                    writer.write("\t");
                    writer.write(Integer.toString(entry.time));
                    writer.write("\t");
                    writer.write(entry.name.replace("\\", "\\\\").replace("\t", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", 3);
                    if (parts.length == 3) {
                        try { entries.add(new Entry(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), parts[2])); }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { reader.close(); }
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) { return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.drawString("HIGHSCORES", x, y);
        List<String> names = getPlayersNames();
        List<Integer> scores = getPlayersScores();
        List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            int millis = times.get(i);
            int seconds = millis / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), x, y + 25 + i * 18);
            g.drawString(Integer.toString(scores.get(i)), x + width / 2, y + 25 + i * 18);
            g.drawString(time, x + width * 3 / 4, y + 25 + i * 18);
        }
    }

    /** Records the best real player in the completed run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (best == null || player.getPoints() > best.getPoints())) best = player;
        }
        if (best == null) best = level.getPlayers().get(0);
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = best.getAuthor();
        storeRun(best.getPoints(), level.getPassedTime(), name);
    }
}