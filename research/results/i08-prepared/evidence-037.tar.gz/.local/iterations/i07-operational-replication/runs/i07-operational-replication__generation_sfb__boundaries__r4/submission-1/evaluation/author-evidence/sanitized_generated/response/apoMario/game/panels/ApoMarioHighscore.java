package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run records. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 80;
    private final Path store;
    private final ArrayList<Record> records = new ArrayList<Record>();

    private static final class Record {
        final int score;
        final int time;
        final String name;
        Record(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private static String cleanName(String value) {
        if (value == null) return "Player";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? "Player" : s;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0) survivalTime = 0;
        records.add(new Record(score, survivalTime, cleanName(playerName)));
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                out.write("APO_MARIO_HIGHSCORE_1"); out.newLine();
                for (Record r : records) {
                    out.write(Integer.toString(r.score)); out.write('\t');
                    out.write(Integer.toString(r.time)); out.write('\t');
                    out.write(r.name.replace("\\", "\\\\").replace("\t", " ")); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* Highscore must not stop the game. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line = in.readLine();
                if (!"APO_MARIO_HIGHSCORE_1".equals(line)) return;
                while (records.size() < MAX_RECORDS && (line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        if (time >= 0) records.add(new Record(score, time, cleanName(p[2])));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
        } catch (IOException ex) { /* missing or unreadable stores are empty */ }
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis / 1000L);
        return (seconds / 60L) + ":" + String.format("%02d", seconds % 60L);
    }

    /** Renders the menu's dedicated highscore view. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 255, 235));
        g.fillRoundRect(20, 15, width - 40, height - 30, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 65, 45);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        for (int i = 0; i < records.size() && i < 12; i++) {
            Record r = records.get(i);
            int y = 70 + i * 18;
            g.drawString((i + 1) + ". " + r.name, 45, y);
            g.drawString(Integer.toString(r.score), width / 2, y);
            g.drawString(formatTime(r.time), width - 90, y);
        }
        g.drawString("Press H to return", width / 2 - 50, height - 40);
    }
}