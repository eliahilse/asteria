package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Graphics2D;

/** Small menu view adapter used by the menu renderer. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore highscore, int width, int height) {
        highscore.render(g, width / 8, height / 8, width * 3 / 4);
        g.drawString("Press ESC to return", width / 8, height - 20);
    }
}