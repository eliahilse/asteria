package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered results for completed runs. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private static String cleanName(String name) {
        if (name == null) return "Player";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < name.length() && b.length() < MAX_NAME; i++) {
            char c = name.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? "Player" : s;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, cleanName(playerName)));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score > a.score ? 1 : -1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> out = new ArrayList<String>(); for (Run r : runs) out.add(r.name); return out;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> out = new ArrayList<Integer>(); for (Run r : runs) out.add(r.score); return out;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> out = new ArrayList<Integer>(); for (Run r : runs) out.add(r.time); return out;
    }

    /** Records the authoritative human player's finished run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        storeRun(p.getPoints(), level.getPassedTime(), p.getTeamName());
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add("APO_MARIO_HIGHSCORE_1");
            for (Run r : runs) {
                String n = Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8));
                lines.add(r.score + "|" + r.time + "|" + n);
            }
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) { /* a highscore store must never stop the game */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !"APO_MARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && runs.size() < MAX_RECORDS; i++) {
                String[] p = lines.get(i).split("\\|", -1);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    if (time < 0 || p[2].length() > 256) continue;
                    String name = new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                    runs.add(new Run(score, time, cleanName(name)));
                } catch (Exception ex) { /* ignore malformed persisted entries */ }
            }
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score > a.score ? 1 : -1); }
            });
        } catch (Exception ex) { /* ignore unreadable stores */ }
    }

    /** Small rendering helper used by the menu's dedicated highscore view. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20, 15, width - 40, height - 30, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(20, 15, width - 40, height - 30, 18, 18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20)); g.drawString("HIGHSCORES", width / 2 - 65, 45);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int y = 70;
        for (int i = 0; i < runs.size() && y < height - 15; i++, y += 18) {
            Run r = runs.get(i); int seconds = r.time / 1000;
            String t = (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60);
            g.drawString((i + 1) + ". " + r.name, 38, y);
            g.drawString(String.valueOf(r.score), width - 125, y);
            g.drawString(t, width - 75, y);
        }
        if (runs.isEmpty()) g.drawString("No completed runs yet", width / 2 - 65, 85);
    }
}