package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded high-score table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String clean(String name) {
        if (name == null) return "Player";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < name.length() && b.length() < MAX_NAME; i++) {
            char c = name.charAt(i);
            if (c >= 32 && c != '\t' && c != '\r' && c != '\n') b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? "Player" : s;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, clean(playerName)));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> r = new ArrayList<String>(); for (Run x : runs) r.add(x.name); return r;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.score); return r;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.time); return r;
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        String name = p.getTeamName();
        if (name == null || name.trim().length() == 0 || "Human".equals(name)) name = "Player";
        storeRun(p.getPoints(), level.getPassedTime(), name);
        persistAcrossRuns();
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                w.write("APO_MARIO_HIGHSCORE_1"); w.newLine();
                for (Run x : runs) { w.write(Integer.toString(x.score)); w.write('\t'); w.write(Integer.toString(x.time)); w.write('\t'); w.write(x.name); w.newLine(); }
            } finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* scores must never stop the game */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line = r.readLine();
                if (!"APO_MARIO_HIGHSCORE_1".equals(line)) return;
                while ((line = r.readLine()) != null && runs.size() < MAX_RECORDS) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3 || p[2].length() > MAX_NAME) continue;
                    try { storeRun(Integer.parseInt(p[0]), Integer.parseInt(p[1]), p[2]); } catch (RuntimeException ex) { }
                }
            } finally { r.close(); }
        } catch (IOException ex) { }
    }

    /** Renders the board; conversion to mm:ss happens only here. */
    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(x, y, width, height, 18, 18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18)); g.drawString("HIGHSCORES", x + 20, y + 28);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int row = y + 52;
        for (int i = 0; i < runs.size() && row < y + height - 8; i++, row += 18) {
            Run a = runs.get(i); int sec = a.time / 1000; int min = sec / 60; sec %= 60;
            String t = min + ":" + (sec < 10 ? "0" : "") + sec;
            g.drawString((i + 1) + ". " + a.name, x + 18, row);
            g.drawString(Integer.toString(a.score), x + width - 105, row);
            g.drawString(t, x + width - 55, row);
        }
        if (runs.isEmpty()) g.drawString("No runs recorded yet", x + 20, row);
    }
}