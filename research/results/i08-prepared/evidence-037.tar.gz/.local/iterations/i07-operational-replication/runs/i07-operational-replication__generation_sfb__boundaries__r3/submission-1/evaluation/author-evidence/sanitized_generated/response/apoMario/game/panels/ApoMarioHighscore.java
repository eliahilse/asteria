package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run records. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final ArrayList<Record> records = new ArrayList<Record>();

    private static final class Record {
        final String name;
        final int score;
        final int time;
        Record(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        records.add(new Record(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            lines.add("APO_MARIO_HIGHSCORE_1");
            for (Record r : records) lines.add(r.score + "\t" + r.time + "\t" + r.name.replace("\t", " "));
            Files.write(temp, lines, Charset.forName("UTF-8"));
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    /** Records the first (human) player at the authoritative end-of-run boundary. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, (long) milliseconds) / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, Charset.forName("UTF-8"));
            if (lines.size() == 0 || !"APO_MARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && records.size() < MAX_RECORDS; i++) {
                String[] p = lines.get(i).split("\\t", 3);
                if (p.length != 3 || p[2].length() > MAX_NAME) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    if (time >= 0) records.add(new Record(normalize(p[2]), score, time));
                } catch (Exception ignored) { }
            }
            sortAndTrim();
        } catch (Exception ignored) { }
    }

    private String normalize(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(12, 12, width - 24, height - 24, 18, 18);
        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        g.drawString("HIGHSCORES", 28, 42);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int y = 68;
        for (int i = 0; i < records.size() && i < 12; i++) {
            Record r = records.get(i);
            g.drawString((i + 1) + ". " + r.name, 30, y);
            g.drawString(String.valueOf(r.score), width / 2, y);
            g.drawString(formatTime(r.time), width - 90, y);
            y += 19;
        }
        if (records.isEmpty()) g.drawString("No runs recorded yet", 30, y);
        g.drawString("Press H or Escape to return", 28, height - 24);
    }
}