package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered highscore table. Durations are milliseconds. */
public class ApoMarioHighscore {
    private static final String HEADER = "APOMARIO_HIGHSCORE 1";
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;

    private static final class Run {
        private final String name;
        private final int score;
        private final int time;
        private Run(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private String lastRecordedName;
    private int lastRecordedScore;
    private int lastRecordedTime;
    private boolean hasLastRecorded;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0 || playerName == null) {
            return false;
        }
        String name = normalize(playerName);
        if (name.length() == 0) {
            name = "Player";
        }
        runs.add(new Run(name, score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    /** Saves a complete snapshot without exposing the file format to the game. */
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add(HEADER);
            for (Run run : runs) {
                lines.add(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8))
                        + "|" + run.score + "|" + run.time);
            }
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            // A failed save must not make the running game fail.
        }
    }

    /** Records the first player once, after the level's final score transition. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        int score = player.getPoints();
        int elapsed = Math.max(0, level.getPassedTime());
        String name = normalize(player.getTeamName());
        if (name.length() == 0) name = "Player";
        // Completion callbacks can be delivered more than once.  Deduplicate
        // only the exact terminal snapshot; a changed score/time is a new run.
        if (this.hasLastRecorded && this.lastRecordedScore == score
                && this.lastRecordedTime == elapsed && this.lastRecordedName.equals(name)) {
            return;
        }
        if (storeRun(score, elapsed, name)) {
            this.lastRecordedScore = score;
            this.lastRecordedTime = elapsed;
            this.lastRecordedName = name;
            this.hasLastRecorded = true;
        }
    }

    /** Small rendering helper used by the live menu view. */
    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(Color.BLACK);
        g.drawString("HIGHSCORES", x, y);
        int row = y + 22;
        int count = Math.min(runs.size(), 12);
        for (int i = 0; i < count; i++) {
            Run run = runs.get(i);
            int seconds = run.time / 1000;
            String time = String.format("%d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + run.name, x, row);
            g.drawString(String.valueOf(run.score), x + width / 2, row);
            g.drawString(time, x + width - 45, row);
            row += 18;
        }
        if (count == 0) g.drawString("No runs recorded", x, row);
        g.drawString("Press H or Escape to return", x, row + 24);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 1024) return;
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) return;
            int limit = Math.min(lines.size(), MAX_ENTRIES + 1);
            for (int i = 1; i < limit; i++) {
                String[] fields = lines.get(i).split("\\|", -1);
                if (fields.length != 3) continue;
                try {
                    String name = normalize(new String(Base64.getDecoder().decode(fields[0]), StandardCharsets.UTF_8));
                    int score = Integer.parseInt(fields[1]);
                    int time = Integer.parseInt(fields[2]);
                    if (name.length() > 0 && time >= 0) runs.add(new Run(name, score, time));
                } catch (Exception ex) {
                    // Ignore only the malformed record.
                }
            }
            sortAndLimit();
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private String normalize(String value) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) result.append(c);
        }
        return result.toString().trim();
    }

    private void sortAndLimit() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return Integer.compare(b.score, a.score); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
}