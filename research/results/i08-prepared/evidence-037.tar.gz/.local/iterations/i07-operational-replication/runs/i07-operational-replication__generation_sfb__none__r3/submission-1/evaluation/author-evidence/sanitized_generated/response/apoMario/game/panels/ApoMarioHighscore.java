package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, points-sorted run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final String SEPARATOR = "\t";
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name;
        int score;
        int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, Charset.forName("UTF-8"))) {
                String[] p = line.split(SEPARATOR, -1);
                if (p.length == 3) entries.add(new Entry(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2])));
            }
            sort();
        } catch (Exception ignored) { /* a damaged score file must not stop the game */ }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        name = name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Entry e : entries) lines.add(e.name + SEPARATOR + e.score + SEPARATOR + e.time);
            Files.write(store, lines, Charset.forName("UTF-8"), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (Exception ignored) { }
    }

    /** Records the actual first player's score, configured name, and elapsed milliseconds. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 225));
        g.fillRoundRect(x, y, width, height, 14, 14);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 14, 14);
        g.drawString("HIGHSCORES", x + 12, y + 24);
        int row = 0;
        for (Entry e : entries) {
            if (row >= 8) break;
            int totalSeconds = e.time / 1000;
            String time = String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60);
            g.drawString((row + 1) + ". " + e.name + "  " + e.score + "  " + time, x + 15, y + 48 + row * 18);
            row++;
        }
        if (entries.isEmpty()) g.drawString("No runs recorded", x + 15, y + 50);
    }
}