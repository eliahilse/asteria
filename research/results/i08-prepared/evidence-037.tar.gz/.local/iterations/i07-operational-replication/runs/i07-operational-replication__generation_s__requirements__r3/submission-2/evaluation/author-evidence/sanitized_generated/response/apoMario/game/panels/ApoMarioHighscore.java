package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded high-score table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;

    private static final class Run {
        String name; int score; int time;
        Run(String n, int s, int t) { name = n; score = s; time = t; }
    }

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(Integer.valueOf(r.score));
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(Integer.valueOf(r.time));
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run r : runs) { out.writeUTF(r.name); out.writeInt(r.score); out.writeInt(r.time); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { /* A failed save must not stop the game. */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = cleanName(in.readUTF()); int score = in.readInt(); int time = in.readInt();
                if (name != null && time >= 0) runs.add(new Run(name, score, time));
            }
            in.close(); sortAndTrim();
        } catch (IOException | RuntimeException e) { runs.clear(); }
    }

    private static String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isISOControl(c)) b.append('?'); else b.append(c);
        }
        return b.toString();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) {
            return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
        }});
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    /** Records the real terminal state of the supplied live level. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) if (p.getAi() == null && p.isBVisible()) { selected = p; break; }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(selected.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    /** Draws the board; conversion to mm:ss happens only here. */
    public synchronized void renderBoard(Graphics2D g, int x, int y) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", x, y);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run r = runs.get(i); int seconds = r.time / 1000;
            String t = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + r.name, x, y + 25 + i * 18);
            g.drawString(String.valueOf(r.score), x + 170, y + 25 + i * 18);
            g.drawString(t, x + 245, y + 25 + i * 18);
        }
    }
}