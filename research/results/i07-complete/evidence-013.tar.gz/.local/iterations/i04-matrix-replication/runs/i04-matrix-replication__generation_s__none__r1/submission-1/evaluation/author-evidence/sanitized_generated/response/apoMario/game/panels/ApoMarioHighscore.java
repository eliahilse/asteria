package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered records of completed runs. */
public class ApoMarioHighscore {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final int score;
        private final int survivalTime;
        private final String name;
        private Entry(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, UTF8)) {
                String[] p = line.split("\\t", -1);
                if (p.length >= 3) {
                    try {
                        entries.add(new Entry(Integer.parseInt(p[0]), Integer.parseInt(p[1]), p[2]));
                    } catch (NumberFormatException ignored) { }
                }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        name = name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sort();
        persistAcrossRuns();
        return true;
    }

    public void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            synchronized (this) {
                for (Entry e : entries) lines.add(e.score + "\t" + e.survivalTime + "\t" + e.name);
            }
            Files.write(store, lines, UTF8);
        } catch (IOException ignored) { }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.survivalTime);
        return result;
    }

    /** Records the human player's actual final score and elapsed milliseconds. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }
}