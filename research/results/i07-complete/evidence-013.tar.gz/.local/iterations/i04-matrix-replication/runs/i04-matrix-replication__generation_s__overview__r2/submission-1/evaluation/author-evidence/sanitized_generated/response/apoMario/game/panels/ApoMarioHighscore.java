package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, score-descending highscore table. Times are elapsed milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }
        playerName = cleanName(playerName);
        names.add(playerName);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int i = names.size() - 1;
            names.remove(i); scores.remove(i); times.remove(i);
        }
        return write();
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() { write(); }

    /** Records the authoritative player-one result after level scoring has completed. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        String name = p.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(p.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void renderBoard(Graphics2D g, int width, int height) {
        g.setColor(new Color(255,255,255,245));
        g.fillRoundRect(20, 15, width - 40, height - 30, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(20, 15, width - 40, height - 30, 18, 18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", 35, 43);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        int y = 65;
        int n = Math.min(names.size(), 10);
        for (int i = 0; i < n; i++) {
            int ms = times.get(i).intValue();
            String t = String.format("%02d:%02d", ms / 60000, (ms / 1000) % 60);
            g.drawString((i + 1) + ". " + names.get(i), 38, y);
            g.drawString(String.valueOf(scores.get(i)), width / 2, y);
            g.drawString(t, width - 95, y);
            y += 18;
        }
        if (n == 0) g.drawString("No runs recorded", 38, y);
        g.drawString("H / Escape: back", 35, height - 27);
    }

    private String cleanName(String value) {
        String s = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return s.length() == 0 ? "Player" : (s.length() > 32 ? s.substring(0, 32) : s);
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                String name = new String(java.util.Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                names.add(cleanName(name)); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(Math.max(0,time)));
            }
            sort();
            while (names.size() > MAX_ENTRIES) { int i=names.size()-1; names.remove(i); scores.remove(i); times.remove(i); }
        } catch (Exception ignored) { names.clear(); scores.clear(); times.clear(); }
    }

    private boolean write() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (int i=0; i<names.size(); i++) {
                String encoded = java.util.Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8));
                lines.add(scores.get(i) + "\t" + times.get(i) + "\t" + encoded);
            }
            Files.write(store, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            return true;
        } catch (IOException ex) { return false; }
    }
}