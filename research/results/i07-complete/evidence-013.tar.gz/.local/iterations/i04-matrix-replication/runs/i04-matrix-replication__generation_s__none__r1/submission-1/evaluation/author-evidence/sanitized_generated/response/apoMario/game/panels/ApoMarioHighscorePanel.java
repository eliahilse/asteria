package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscorePanel {
    private ApoMarioHighscorePanel() { }

    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 35, 52);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        int rows = Math.min(names.size(), 10);
        for (int i = 0; i < rows; i++) {
            int millis = times.get(i);
            int seconds = millis / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 45, 82 + i * 17);
            g.drawString(String.valueOf(points.get(i)), 190, 82 + i * 17);
            g.drawString(time, 255, 82 + i * 17);
        }
        if (rows == 0) g.drawString("No runs recorded", 45, 90);
        g.drawString("Press H or Escape to return", 45, ApoMarioConstants.GAME_HEIGHT - 28);
    }
}