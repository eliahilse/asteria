package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded high-score table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Record> records = new ArrayList<Record>();

    private static final class Record {
        final String name; final int score; final int time;
        Record(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name.length() == 0) name = "Player";
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        records.add(new Record(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) { chosen = player; break; }
        }
        if (chosen == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && player.getAi() == null) { chosen = player; break; }
            }
        }
        if (chosen != null) storeRun(chosen.getPoints(), level.getPassedTime(), nameOf(chosen));
    }

    private String nameOf(ApoMarioPlayer player) {
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        return name;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Record r : records) result.add(r.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Record r : records) result.add(r.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Record r : records) result.add(r.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add("APO_MARIO_HIGHSCORE_1");
            for (Record r : records) lines.add(r.score + "\t" + r.time + "\t" + escape(r.name));
            Files.write(temp, lines, Charset.forName("UTF-8"), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) { /* persistence must not stop the game */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, Charset.forName("UTF-8"));
            if (lines.size() == 0 || !"APO_MARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && records.size() < MAX_RECORDS; i++) {
                String[] p = lines.get(i).split("\\t", 3); if (p.length != 3) continue;
                int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                if (score < 0 || time < 0 || p[2].length() > MAX_NAME) continue;
                records.add(new Record(normalize(unescape(p[2])), score, time));
            }
            sortAndTrim();
        } catch (Exception ex) { records.clear(); }
    }
    private void sortAndTrim() {
        Collections.sort(records, new Comparator<Record>() { public int compare(Record a, Record b) { return b.score - a.score; } });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
    }
    private static String normalize(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i); if (c >= 32 && c != '\t' && c != '\r' && c != '\n') b.append(c);
        }
        return b.toString().trim();
    }
    private static String escape(String s) { return s.replace("\\", "\\\\").replace("\t", " "); }
    private static String unescape(String s) { return s.replace("\\\\", "\\"); }

    public synchronized void render(Graphics2D g) {
        int x = ApoMarioConstants.GAME_WIDTH / 8, y = 25;
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(x, 12, ApoMarioConstants.GAME_WIDTH * 3 / 4, ApoMarioConstants.GAME_HEIGHT - 24, 20, 20);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", x + 20, y + 20);
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < records.size() && i < 12; i++) {
            Record r = records.get(i); int yy = y + 55 + i * 15;
            g.drawString((i + 1) + ". " + r.name, x + 20, yy);
            g.drawString(String.valueOf(r.score), x + 180, yy);
            g.drawString(formatTime(r.time), x + 250, yy);
        }
        if (records.isEmpty()) g.drawString("No runs recorded", x + 20, y + 60);
        g.drawString("Press H or Escape to return", x + 20, ApoMarioConstants.GAME_HEIGHT - 35);
    }
    private static String formatTime(int millis) { long seconds = Math.max(0L, millis) / 1000L; return (seconds / 60L) + ":" + String.format("%02d", seconds % 60L); }
}