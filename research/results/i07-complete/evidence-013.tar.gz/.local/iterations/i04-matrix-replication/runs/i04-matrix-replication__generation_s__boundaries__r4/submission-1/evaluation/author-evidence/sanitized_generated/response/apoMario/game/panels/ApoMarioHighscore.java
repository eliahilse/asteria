package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final ArrayList<Record> records = new ArrayList<Record>();

    private static final class Record {
        final int score;
        final int time;
        final String name;
        Record(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        records.add(new Record(score, survivalTime, name));
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return result;
    }

    public synchronized void persistAcrossRuns() { persist(); }

    /** Records the human participant's authoritative score and elapsed time. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || (player.getAi() != null)) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 245));
        g.fillRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 20, 20);
        g.drawString("HIGHSCORES", width / 2 - 45, height / 8 + 5);
        int y = height / 8 + 30;
        for (int i = 0; i < records.size() && i < 12; i++) {
            Record r = records.get(i);
            g.drawString((i + 1) + ". " + r.name, width / 5, y);
            g.drawString(String.valueOf(r.score), width / 2, y);
            g.drawString(formatTime(r.time), width * 3 / 5, y);
            y += 16;
        }
        g.drawString("Press H or ESC to return", width / 2 - 75, height - height / 10);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }
    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c) && c != '\t' && c != '|') b.append(c);
        }
        return b.toString().trim();
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line; int count = 0;
            while ((line = r.readLine()) != null && count++ < MAX_RECORDS) {
                String[] p = line.split("\\|", -1);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    String name = cleanName(p[2]);
                    if (score >= 0 && time >= 0 && name.length() > 0) records.add(new Record(score, time, name));
                } catch (NumberFormatException ignored) { }
            }
            Collections.sort(records, new Comparator<Record>() {
                public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
            });
        } catch (IOException ignored) { }
    }
    private synchronized boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter w = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                for (Record r : records) w.write(r.score + "|" + r.time + "|" + r.name + "\n");
            }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) { return false; }
    }
}