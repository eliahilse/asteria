package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-descending highscore table. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(names);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(scores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(survivalTimes);
    }

    /** Records the authoritative first human/player result after score adjustments. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer selected = level.getPlayers().get(0);
        if (selected == null) {
            return;
        }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) {
            return;
        }
        try {
            Path parent = store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    writer.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(Integer.toString(scores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(survivalTimes.get(i).intValue()));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
            try {
                Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A read-only store must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) {
            return;
        }
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", -1);
                    if (parts.length != 3) {
                        continue;
                    }
                    try {
                        String name = new String(Base64.getDecoder().decode(parts[0]), StandardCharsets.UTF_8);
                        names.add(cleanName(name));
                        scores.add(Integer.valueOf(parts[1]));
                        survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(parts[2]))));
                    } catch (RuntimeException ex) {
                        // Ignore malformed records and keep the remaining table usable.
                    }
                }
            } finally {
                reader.close();
            }
        } catch (IOException ex) {
            // Missing or inaccessible data is treated as an empty table.
        }
        sort();
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) {
            order.add(Integer.valueOf(i));
        }
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        List<String> newNames = new ArrayList<String>();
        List<Integer> newScores = new ArrayList<Integer>();
        List<Integer> newTimes = new ArrayList<Integer>();
        for (Integer index : order) {
            newNames.add(names.get(index.intValue()));
            newScores.add(scores.get(index.intValue()));
            newTimes.add(survivalTimes.get(index.intValue()));
        }
        names.clear(); names.addAll(newNames);
        scores.clear(); scores.addAll(newScores);
        survivalTimes.clear(); survivalTimes.addAll(newTimes);
    }

    private String cleanName(String value) {
        if (value == null) {
            return "Player";
        }
        String result = value.replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) {
            return "Player";
        }
        return result.length() > 40 ? result.substring(0, 40) : result;
    }
}