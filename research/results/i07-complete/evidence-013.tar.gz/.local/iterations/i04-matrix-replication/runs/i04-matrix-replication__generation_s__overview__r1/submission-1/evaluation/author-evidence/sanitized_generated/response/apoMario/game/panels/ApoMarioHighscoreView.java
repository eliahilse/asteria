package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore board, int width) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, 20, width * 3 / 4, 200, 15, 15);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, 20, width * 3 / 4, 200, 15, 15);
        g.drawString("HIGHSCORES (ESC to return)", width / 4, 48);
        List<String> n = board.getPlayersNames();
        List<Integer> s = board.getPlayersScores();
        List<Integer> t = board.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 8; i++) {
            int seconds = t.get(i).intValue() / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
            g.drawString((i + 1) + ". " + n.get(i), width / 6, 75 + i * 18);
            g.drawString(String.valueOf(s.get(i)), width / 2, 75 + i * 18);
            g.drawString(time, width * 2 / 3, 75 + i * 18);
        }
    }
}