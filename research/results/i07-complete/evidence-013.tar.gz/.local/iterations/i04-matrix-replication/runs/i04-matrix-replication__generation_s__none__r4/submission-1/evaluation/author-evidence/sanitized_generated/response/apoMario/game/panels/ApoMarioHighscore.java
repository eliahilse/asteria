package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, score-ordered results from completed runs. */
public class ApoMarioHighscore {
    private static final String SEPARATOR = "\t";
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;
        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        name = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ');
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.survivalTime);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write(SEPARATOR);
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write(SEPARATOR);
                    writer.write(run.name);
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
        } catch (IOException ignored) {
            // A read-only installation must not stop the game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(SEPARATOR, 3);
                    if (parts.length == 3) {
                        try { runs.add(new Run(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), parts[2])); }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
    }
}