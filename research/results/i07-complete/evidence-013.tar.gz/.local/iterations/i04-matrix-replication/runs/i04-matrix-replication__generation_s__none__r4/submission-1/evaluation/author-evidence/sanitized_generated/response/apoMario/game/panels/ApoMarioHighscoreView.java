package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small renderer for the menu's highscore screen. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(24, 18, ApoMarioConstants.GAME_WIDTH - 48, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 34, 48);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        int count = Math.min(10, names.size());
        for (int i = 0; i < count; i++) {
            int seconds = Math.max(0, times.get(i)) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 42, 76 + i * 16);
            g.drawString(Integer.toString(scores.get(i)), 190, 76 + i * 16);
            g.drawString(time, 250, 76 + i * 16);
        }
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("H / ESC: back to menu", 42, ApoMarioConstants.GAME_HEIGHT - 22);
    }
}