package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, score-ordered highscore table. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 10;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name;
        int score;
        int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            java.nio.file.Path parent = store.toAbsolutePath().getParent();
            if (parent != null) java.nio.file.Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Entry e : entries) {
                lines.add(Integer.toString(e.score) + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " "));
            }
            java.nio.file.Files.write(store, lines, java.nio.charset.Charset.forName("UTF-8"));
        } catch (Exception ignored) { }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible() && p.getAi() == null) { chosen = p; break; }
        }
        if (chosen == null && !level.getPlayers().isEmpty()) chosen = level.getPlayers().get(0);
        if (chosen == null) return;
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }

    private synchronized void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score < a.score ? -1 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private void load() {
        if (store == null || !java.nio.file.Files.exists(store)) return;
        try {
            for (String line : java.nio.file.Files.readAllLines(store, java.nio.charset.Charset.forName("UTF-8"))) {
                String[] p = line.split("\\t", 3);
                if (p.length == 3) entries.add(new Entry(p[2], Integer.parseInt(p[0]), Integer.parseInt(p[1])));
            }
            sortAndTrim();
        } catch (Exception ignored) { }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 20, 20);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 65, height / 8 + 12);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int y = height / 5;
        for (int i = 0; i < entries.size(); i++, y += 20) {
            Entry e = entries.get(i);
            int seconds = e.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + e.name, width / 6, y);
            g.drawString(Integer.toString(e.score), width / 2, y);
            g.drawString(time, width * 2 / 3, y);
        }
        g.drawString("Press H or ESC to return", width / 2 - 85, height * 9 / 10);
    }
}