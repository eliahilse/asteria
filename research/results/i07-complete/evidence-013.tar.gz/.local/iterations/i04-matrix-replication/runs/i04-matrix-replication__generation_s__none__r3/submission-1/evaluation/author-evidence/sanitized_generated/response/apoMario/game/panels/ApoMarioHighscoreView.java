package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

/** Marker view type for integrations that want to identify the menu board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
}