package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.Collections;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        int time = Math.max(0, survivalTime);

        this.playersNames.add(name);
        this.playersScores.add(score);
        this.survivalTimes.add(time);
        this.sort();
        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                if (selected == null || player.getPoints() > selected.getPoints()) {
                    selected = player;
                }
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }
        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        this.storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            ArrayList<String> lines = new ArrayList<String>();
            for (int i = 0; i < this.playersNames.size(); i++) {
                String encodedName = Base64.getEncoder().encodeToString(
                        this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
                lines.add(this.playersScores.get(i) + "\t"
                        + this.survivalTimes.get(i) + "\t"
                        + encodedName);
            }

            Files.write(this.store, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to persist highscore", ex);
        }
    }

    public synchronized String formatSurvivalTime(int survivalTime) {
        long totalSeconds = Math.max(0, survivalTime) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private synchronized void load() {
        if (!Files.exists(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            for (String line : lines) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int time = Integer.parseInt(values[1]);
                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);

                    this.playersScores.add(score);
                    this.survivalTimes.add(Math.max(0, time));
                    this.playersNames.add(normalizeName(name));
                } catch (IllegalArgumentException ex) {
                    this.playersNames.clear();
                    this.playersScores.clear();
                    this.survivalTimes.clear();
                    return;
                }
            }
            this.sort();
            while (this.playersNames.size() > MAX_ENTRIES) {
                int last = this.playersNames.size() - 1;
                this.playersNames.remove(last);
                this.playersScores.remove(last);
                this.survivalTimes.remove(last);
            }
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indexes = new ArrayList<Integer>();
        for (int i = 0; i < this.playersNames.size(); i++) {
            indexes.add(i);
        }

        Collections.sort(indexes, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreCompare = Integer.compare(
                        playersScores.get(second), playersScores.get(first));
                if (scoreCompare != 0) {
                    return scoreCompare;
                }
                return Integer.compare(
                        survivalTimes.get(first), survivalTimes.get(second));
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : indexes) {
            names.add(this.playersNames.get(index));
            scores.add(this.playersScores.get(index));
            times.add(this.survivalTimes.get(index));
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        this.playersNames.addAll(names);
        this.playersScores.addAll(scores);
        this.survivalTimes.addAll(times);
    }

    private static String normalizeName(String playerName) {
        if (playerName == null) {
            return "Player";
        }

        String name = playerName.trim();
        if (name.length() == 0) {
            return "Player";
        }
        if (name.length() > 64) {
            return name.substring(0, 64);
        }
        return name;
    }
}