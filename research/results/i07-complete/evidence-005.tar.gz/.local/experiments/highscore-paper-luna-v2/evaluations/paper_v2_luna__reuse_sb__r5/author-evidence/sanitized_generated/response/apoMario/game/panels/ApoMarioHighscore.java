package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }

        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        if (name.length() > 64) {
            name = name.substring(0, 64);
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();

        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        return this.write();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        this.write();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null) {
                    if (selected == null || player.getPoints() > selected.getPoints()) {
                        selected = player;
                    }
                }
            }
        }

        if (selected == null) {
            return;
        }

        int elapsed = level.getStartTime() - level.getTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        this.storeRun(selected.getPoints(), elapsed, name);
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        graphics.drawString("Highscore", 20, 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int y = 58;
        for (int i = 0; i < this.playersNames.size(); i++) {
            String line = (i + 1) + ". " + this.playersNames.get(i)
                    + "  " + this.playersScores.get(i)
                    + "  " + formatTime(this.survivalTimes.get(i));
            graphics.drawString(line, 20, y);
            y += 22;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public static String formatTime(int milliseconds) {
        long totalSeconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
    }

    private synchronized void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(this.store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int time = Integer.parseInt(values[1]);
                    String name = values[2];
                    if (name.length() == 0) {
                        name = "Player";
                    }
                    this.playersScores.add(Integer.valueOf(score));
                    this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
                    this.playersNames.add(name);
                } catch (NumberFormatException ignored) {
                }
            }
            this.sort();
        } catch (IOException ignored) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private synchronized boolean write() {
        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            try (BufferedWriter writer = Files.newBufferedWriter(
                    this.store,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {

                for (int i = 0; i < this.playersNames.size(); i++) {
                    writer.write(Integer.toString(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(this.survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(this.playersNames.get(i).replace('\t', ' '));
                    writer.newLine();
                }
            }
            return true;
        } catch (IOException ignored) {
            return false;
        }
    }

    private synchronized void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        Collections.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int score = Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());
                if (score != 0) {
                    return score;
                }

                return Integer.compare(
                        survivalTimes.get(first.intValue()).intValue(),
                        survivalTimes.get(second.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            sortedNames.add(this.playersNames.get(i));
            sortedScores.add(this.playersScores.get(i));
            sortedTimes.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }
}