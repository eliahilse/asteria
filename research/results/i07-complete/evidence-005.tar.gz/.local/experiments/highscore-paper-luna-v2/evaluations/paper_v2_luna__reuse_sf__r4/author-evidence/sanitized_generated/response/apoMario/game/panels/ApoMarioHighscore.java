package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final Comparator<Run> SCORE_ORDER = new Comparator<Run>() {
        @Override
        public int compare(Run first, Run second) {
            return Integer.compare(second.score, first.score);
        }
    };

    private final Path store;
    private final ArrayList<Run> runs;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.runs = new ArrayList<Run>();
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        this.runs.add(new Run(score, survivalTime, name));
        Collections.sort(this.runs, SCORE_ORDER);
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.name);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.score);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(this.runs.size());
        for (Run run : this.runs) {
            result.add(run.survivalTime);
        }
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = this.store.getParent();
        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                for (Run run : this.runs) {
                    String encodedName = Base64.getEncoder().encodeToString(
                            run.name.getBytes(StandardCharsets.UTF_8));
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(encodedName);
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException exception) {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) {
            try {
                Files.deleteIfExists(this.store.resolveSibling(
                        this.store.getFileName().toString() + ".tmp"));
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                if (selected == null || player.getPoints() > selected.getPoints()) {
                    selected = player;
                }
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }
        if (selected == null) {
            return;
        }

        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }

        storeRun(selected.getPoints(), Math.max(0, level.getPassedTime()), name);
        persistAcrossRuns();
    }

    private synchronized void load() {
        if (!Files.isRegularFile(this.store)) {
            return;
        }

        ArrayList<Run> loaded = new ArrayList<Run>();
        try {
            BufferedReader reader = Files.newBufferedReader(
                    this.store,
                    StandardCharsets.UTF_8);

            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] values = line.split("\t", -1);
                    if (values.length != 3) {
                        continue;
                    }

                    int score = Integer.parseInt(values[0]);
                    int survivalTime = Integer.parseInt(values[1]);
                    String name = new String(
                            Base64.getDecoder().decode(values[2]),
                            StandardCharsets.UTF_8);

                    if (name.length() == 0) {
                        name = "Player";
                    }
                    loaded.add(new Run(score, survivalTime, name));
                }
            } finally {
                reader.close();
            }

            Collections.sort(loaded, SCORE_ORDER);
            this.runs.clear();
            this.runs.addAll(loaded);
        } catch (IOException exception) {
            this.runs.clear();
        } catch (RuntimeException exception) {
            this.runs.clear();
        }
    }

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;

        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }
}