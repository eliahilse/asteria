package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.Collections;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APOMARIO_HIGHSCORE_1";
    private static final int DEFAULT_SURVIVAL_TIME = 0;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            ArrayList<String> lines = new ArrayList<String>();
            lines.add(HEADER);

            for (int i = 0; i < this.playersNames.size(); i++) {
                String encodedName = Base64.getEncoder().encodeToString(
                        this.playersNames.get(i).getBytes(StandardCharsets.UTF_8));
                lines.add(this.playersScores.get(i) + "\t"
                        + this.survivalTimes.get(i) + "\t"
                        + encodedName);
            }

            Files.write(this.store, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
        } catch (IOException ex) {
            // Persistence failures do not invalidate the in-memory board.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selectedPlayer = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) {
                selectedPlayer = player;
                break;
            }
        }

        if (selectedPlayer == null) {
            selectedPlayer = level.getPlayers().get(0);
        }
        if (selectedPlayer == null) {
            return;
        }

        int survivalTime = level.getStartTime() - level.getTime();
        if (survivalTime < 0) {
            survivalTime = DEFAULT_SURVIVAL_TIME;
        }

        String playerName = selectedPlayer.getTeamName();
        if ((playerName == null || playerName.trim().length() == 0)
                && selectedPlayer.getAi() != null) {
            playerName = selectedPlayer.getAi().getTeamName();
        }

        this.storeRun(selectedPlayer.getPoints(), survivalTime, playerName);
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        Font oldFont = graphics.getFont();
        Color oldColor = graphics.getColor();

        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        graphics.drawString("Highscore", 20, 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        int y = 55;
        for (int i = 0; i < this.playersNames.size(); i++) {
            String line = (i + 1) + ". " + this.playersNames.get(i)
                    + "  " + this.playersScores.get(i)
                    + "  " + formatSurvivalTime(this.survivalTimes.get(i));
            graphics.drawString(line, 20, y);
            y += 20;
        }

        graphics.setFont(oldFont);
        graphics.setColor(oldColor);
    }

    public synchronized String formatSurvivalTime(int time) {
        long totalSeconds = Math.max(0L, time) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", Long.valueOf(minutes), Long.valueOf(seconds));
    }

    private void load() {
        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !HEADER.equals(lines.get(0))) {
                return;
            }

            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                String[] values = line.split("\t", -1);
                if (values.length != 3) {
                    continue;
                }

                int score = Integer.parseInt(values[0]);
                int survivalTime = Integer.parseInt(values[1]);
                String name = new String(
                        Base64.getDecoder().decode(values[2]),
                        StandardCharsets.UTF_8);

                if (name.trim().length() == 0) {
                    name = "Player";
                }

                this.playersScores.add(Integer.valueOf(score));
                this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
                this.playersNames.add(name);
            }

            this.sort();
        } catch (Exception ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        order.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        playersScores.get(second.intValue()),
                        playersScores.get(first.intValue()));
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            sortedNames.add(this.playersNames.get(i));
            sortedScores.add(this.playersScores.get(i));
            sortedTimes.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }

    private String normalizeName(String name) {
        if (name == null) {
            return "";
        }
        return name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
    }
}