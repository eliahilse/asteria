package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        this.sort();
        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(this.playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(this.survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            ArrayList<String> lines = new ArrayList<String>();
            for (int i = 0; i < this.playersNames.size(); i++) {
                String name = this.playersNames.get(i).replace('\t', ' ').replace('\r', ' ').replace('\n', ' ');
                lines.add(this.playersScores.get(i) + "\t" + this.survivalTimes.get(i) + "\t" + name);
            }

            Files.write(this.store, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
        } catch (IOException ignored) {
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }

        int elapsed = level.getStartTime() - level.getTime();
        if (elapsed < 0) {
            elapsed = 0;
        }

        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = player.getAuthor();
        }

        this.storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized void render(Graphics2D graphics) {
        if (graphics == null) {
            return;
        }

        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, 320, 240);
        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        graphics.drawString("Highscore", 105, 30);

        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        graphics.drawString("#", 20, 55);
        graphics.drawString("Name", 45, 55);
        graphics.drawString("Points", 190, 55);
        graphics.drawString("Time", 255, 55);

        int row = 75;
        for (int i = 0; i < this.playersNames.size() && i < 10; i++) {
            graphics.drawString(String.valueOf(i + 1), 20, row);
            graphics.drawString(this.playersNames.get(i), 45, row);
            graphics.drawString(String.valueOf(this.playersScores.get(i)), 190, row);
            graphics.drawString(formatTime(this.survivalTimes.get(i).intValue()), 255, row);
            row += 17;
        }
    }

    public static String formatTime(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }

    private void load() {
        if (this.store == null || !Files.exists(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            for (String line : lines) {
                String[] values = line.split("\t", 3);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int time = Integer.parseInt(values[1]);
                    String name = normalizeName(values[2]);
                    if (name.length() > 0) {
                        this.playersScores.add(Integer.valueOf(score));
                        this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
                        this.playersNames.add(name);
                    }
                } catch (NumberFormatException ignored) {
                }
            }
            this.sort();
        } catch (IOException ignored) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indexes = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            indexes.add(Integer.valueOf(i));
        }

        Collections.sort(indexes, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreCompare = Integer.compare(
                        ApoMarioHighscore.this.playersScores.get(second.intValue()).intValue(),
                        ApoMarioHighscore.this.playersScores.get(first.intValue()).intValue());
                if (scoreCompare != 0) {
                    return scoreCompare;
                }
                return Integer.compare(
                        ApoMarioHighscore.this.survivalTimes.get(first.intValue()).intValue(),
                        ApoMarioHighscore.this.survivalTimes.get(second.intValue()).intValue());
            }
        });

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        for (Integer index : indexes) {
            names.add(this.playersNames.get(index.intValue()));
            scores.add(this.playersScores.get(index.intValue()));
            times.add(this.survivalTimes.get(index.intValue()));
        }

        this.playersNames.clear();
        this.playersNames.addAll(names);
        this.playersScores.clear();
        this.playersScores.addAll(scores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(times);
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return "";
        }
        return name.trim();
    }
}