package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {

    private static final String HEADER = "APO_MARIO_HIGHSCORE_1";
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }

        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(survivalTime));
        this.sort();
        while (this.playersNames.size() > MAX_ENTRIES) {
            int last = this.playersNames.size() - 1;
            this.playersNames.remove(last);
            this.playersScores.remove(last);
            this.survivalTimes.remove(last);
        }

        this.persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(this.playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(this.playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(this.survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path temporary = this.store.resolveSibling(this.store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(
                    temporary,
                    StandardCharsets.UTF_8);

            try {
                writer.write(HEADER);
                writer.newLine();

                for (int i = 0; i < this.playersNames.size(); i++) {
                    writer.write(Base64.getEncoder().encodeToString(
                            this.playersNames.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.write('\t');
                    writer.write(String.valueOf(this.playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(String.valueOf(this.survivalTimes.get(i).intValue()));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }

            try {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                Files.move(temporary, this.store,
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try {
                Files.deleteIfExists(this.store.resolveSibling(
                        this.store.getFileName().toString() + ".tmp"));
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;

        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            return;
        }

        int elapsedMilliseconds;
        try {
            elapsedMilliseconds = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsedMilliseconds = level.getStartTime() - level.getTime();
        }

        if (elapsedMilliseconds < 0) {
            elapsedMilliseconds = 0;
        }

        int survivalTime = elapsedMilliseconds / 1000;
        String playerName = selected.getTeamName();

        if (playerName == null || playerName.trim().length() == 0) {
            playerName = selected.getAuthor();
        }
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }

        this.storeRun(selected.getPoints(), survivalTime, playerName);
    }

    private synchronized void load() {
        if (!Files.exists(this.store)) {
            return;
        }

        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        ArrayList<Integer> times = new ArrayList<Integer>();

        try {
            BufferedReader reader = Files.newBufferedReader(
                    this.store,
                    StandardCharsets.UTF_8);

            try {
                String header = reader.readLine();
                if (!HEADER.equals(header)) {
                    return;
                }

                String line;
                while ((line = reader.readLine()) != null) {
                    String[] values = line.split("\\t", -1);
                    if (values.length != 3) {
                        continue;
                    }

                    String name = new String(
                            Base64.getDecoder().decode(values[0]),
                            StandardCharsets.UTF_8);

                    int score = Integer.parseInt(values[1]);
                    int time = Integer.parseInt(values[2]);

                    if (name.trim().length() == 0 || score < 0 || time < 0) {
                        continue;
                    }

                    names.add(name);
                    scores.add(Integer.valueOf(score));
                    times.add(Integer.valueOf(time));
                }
            } finally {
                reader.close();
            }

            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
            this.playersNames.addAll(names);
            this.playersScores.addAll(scores);
            this.survivalTimes.addAll(times);
            this.sort();
        } catch (IOException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        } catch (IllegalArgumentException ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indexes = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            indexes.add(Integer.valueOf(i));
        }

        Collections.sort(indexes, new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                int scoreComparison = Integer.compare(
                        playersScores.get(second.intValue()).intValue(),
                        playersScores.get(first.intValue()).intValue());

                if (scoreComparison != 0) {
                    return scoreComparison;
                }

                return Integer.compare(
                        survivalTimes.get(first.intValue()).intValue(),
                        survivalTimes.get(second.intValue()).intValue());
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : indexes) {
            int value = index.intValue();
            sortedNames.add(this.playersNames.get(value));
            sortedScores.add(this.playersScores.get(value));
            sortedTimes.add(this.survivalTimes.get(value));
        }

        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.addAll(sortedTimes);
    }
}