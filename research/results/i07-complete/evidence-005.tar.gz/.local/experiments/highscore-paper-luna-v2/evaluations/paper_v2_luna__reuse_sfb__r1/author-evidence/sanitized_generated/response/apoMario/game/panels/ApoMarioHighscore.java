package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.swing.JPanel;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends JPanel {

    private static final long serialVersionUID = 1L;

    private static final String DEFAULT_PLAYER_NAME = "Player";

    private final Path store;
    private final ArrayList<String> playersNames;
    private final ArrayList<Integer> playersScores;
    private final ArrayList<Integer> survivalTimes;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        this.playersNames = new ArrayList<String>();
        this.playersScores = new ArrayList<Integer>();
        this.survivalTimes = new ArrayList<Integer>();
        this.load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }

        this.playersNames.add(name);
        this.playersScores.add(Integer.valueOf(score));
        this.survivalTimes.add(Integer.valueOf(survivalTime));
        this.sort();
        this.persistAcrossRuns();
        this.repaint();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(this.playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(this.playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(this.survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (this.store == null) {
            return;
        }

        try {
            Path parent = this.store.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            ArrayList<String> lines = new ArrayList<String>();
            for (int i = 0; i < this.playersNames.size(); i++) {
                String name = this.playersNames.get(i)
                        .replace('\t', ' ')
                        .replace('\r', ' ')
                        .replace('\n', ' ');
                lines.add(this.playersScores.get(i) + "\t"
                        + this.survivalTimes.get(i) + "\t"
                        + name);
            }

            Files.write(this.store, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
        } catch (Exception ex) {
            // A failed write must not stop the game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }

        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) {
                continue;
            }
            if (selected == null || player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }

        if (selected == null) {
            selected = level.getPlayers().get(0);
        }
        if (selected == null) {
            return;
        }

        int elapsed;
        try {
            elapsed = level.getPassedTime();
        } catch (RuntimeException ex) {
            elapsed = Math.max(0, level.getStartTime() - level.getTime());
        }

        this.storeRun(selected.getPoints(), elapsed, selected.getTeamName());
    }

    public synchronized String getFormattedSurvivalTime(int index) {
        if (index < 0 || index >= this.survivalTimes.size()) {
            return "00:00";
        }
        return formatTime(this.survivalTimes.get(index).intValue());
    }

    public synchronized void refreshScores() {
        this.load();
        this.repaint();
    }

    @Override
    protected synchronized void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);

        Graphics2D g = (Graphics2D) graphics.create();
        try {
            int width = this.getWidth();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, width, this.getHeight());

            g.setColor(Color.BLACK);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
            g.drawString("Highscore", 20, 32);

            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            g.drawString("#", 20, 60);
            g.drawString("Name", 55, 60);
            g.drawString("Score", Math.max(170, width - 180), 60);
            g.drawString("Time", Math.max(260, width - 90), 60);

            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            int y = 84;
            for (int i = 0; i < this.playersNames.size(); i++) {
                g.drawString(String.valueOf(i + 1), 20, y);
                g.drawString(this.playersNames.get(i), 55, y);
                g.drawString(String.valueOf(this.playersScores.get(i)),
                        Math.max(170, width - 180), y);
                g.drawString(formatTime(this.survivalTimes.get(i).intValue()),
                        Math.max(260, width - 90), y);
                y += 22;
                if (y > this.getHeight() - 10) {
                    break;
                }
            }
        } finally {
            g.dispose();
        }
    }

    private synchronized void load() {
        this.playersNames.clear();
        this.playersScores.clear();
        this.survivalTimes.clear();

        if (this.store == null || !Files.isRegularFile(this.store)) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(this.store, StandardCharsets.UTF_8);
            for (String line : lines) {
                String[] values = line.split("\t", 3);
                if (values.length != 3) {
                    continue;
                }

                try {
                    int score = Integer.parseInt(values[0]);
                    int time = Integer.parseInt(values[1]);
                    this.playersScores.add(Integer.valueOf(Math.max(0, score)));
                    this.survivalTimes.add(Integer.valueOf(Math.max(0, time)));
                    this.playersNames.add(normalizeName(values[2]));
                } catch (NumberFormatException ex) {
                    // Ignore malformed records and retain valid records.
                }
            }
            this.sort();
        } catch (Exception ex) {
            this.playersNames.clear();
            this.playersScores.clear();
            this.survivalTimes.clear();
        }
    }

    private synchronized void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < this.playersScores.size(); i++) {
            order.add(Integer.valueOf(i));
        }

        order.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer first, Integer second) {
                return Integer.compare(
                        playersScores.get(second.intValue()),
                        playersScores.get(first.intValue()));
            }
        });

        ArrayList<String> sortedNames = new ArrayList<String>();
        ArrayList<Integer> sortedScores = new ArrayList<Integer>();
        ArrayList<Integer> sortedTimes = new ArrayList<Integer>();

        for (Integer index : order) {
            int i = index.intValue();
            sortedNames.add(this.playersNames.get(i));
            sortedScores.add(this.playersScores.get(i));
            sortedTimes.add(this.survivalTimes.get(i));
        }

        this.playersNames.clear();
        this.playersNames.addAll(sortedNames);
        this.playersScores.clear();
        this.playersScores.addAll(sortedScores);
        this.survivalTimes.clear();
        this.survivalTimes.addAll(sortedTimes);
    }

    private static String normalizeName(String name) {
        if (name == null) {
            return DEFAULT_PLAYER_NAME;
        }

        String normalized = name.trim();
        if (normalized.length() == 0) {
            return DEFAULT_PLAYER_NAME;
        }
        return normalized;
    }

    private static String formatTime(int milliseconds) {
        int totalSeconds = Math.max(0, milliseconds) / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", Integer.valueOf(minutes), Integer.valueOf(seconds));
    }
}