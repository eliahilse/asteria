package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Local, durable highscore table for ApoMario. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 1000;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name == null || survivalTime < 0) {
            return false;
        }
        runs.add(new Run(score, survivalTime, name));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
            }
        });
        if (runs.size() > MAX_RECORDS) {
            runs.remove(runs.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            try {
                out.writeInt(MAGIC);
                out.writeInt(VERSION);
                out.writeInt(runs.size());
                for (Run run : runs) {
                    out.writeInt(run.score);
                    out.writeInt(run.time);
                    out.writeUTF(run.name);
                }
            } finally {
                out.close();
            }
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A failed save must not interrupt the running game.
        }
    }

    private synchronized void load() {
        if (!Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE_SIZE) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            List<Run> loaded = new ArrayList<Run>();
            try {
                if (in.readInt() != MAGIC || in.readInt() != VERSION) return;
                int count = in.readInt();
                if (count < 0 || count > MAX_RECORDS) return;
                for (int i = 0; i < count; i++) {
                    int score = in.readInt();
                    int time = in.readInt();
                    String name = in.readUTF();
                    if (time < 0 || normalizeName(name) == null) return;
                    loaded.add(new Run(score, time, normalizeName(name)));
                }
            } finally {
                in.close();
            }
            runs.clear();
            runs.addAll(loaded);
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
            });
        } catch (IOException ex) {
            // Ignore corrupt or incomplete stores.
        }
    }

    private static String normalizeName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME) return null;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return null;
        }
        return name;
    }
}