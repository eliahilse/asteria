package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 64;

    private static final class Run {
        private final int score;
        private final int time;
        private final String name;
        private Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name == null || survivalTime < 0) {
            return false;
        }
        runs.add(new Run(score, survivalTime, name));
        sort();
        while (runs.size() > MAX_RECORDS) {
            runs.remove(runs.size() - 1);
        }
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream output = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            output.writeInt(MAGIC);
            output.writeInt(VERSION);
            output.writeInt(runs.size());
            for (Run run : runs) {
                output.writeInt(run.score);
                output.writeInt(run.time);
                output.writeUTF(run.name);
            }
            output.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 1024) return;
            DataInputStream input = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (input.readInt() != MAGIC || input.readInt() != VERSION) {
                input.close();
                return;
            }
            int count = input.readInt();
            if (count < 0 || count > MAX_RECORDS) {
                input.close();
                return;
            }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = input.readInt();
                int time = input.readInt();
                String name = normalize(input.readUTF());
                if (name == null || time < 0) {
                    input.close();
                    return;
                }
                loaded.add(new Run(score, time, name));
            }
            input.close();
            runs.clear();
            runs.addAll(loaded);
            sort();
        } catch (IOException ex) {
            // Keep the valid in-memory board empty when the file is malformed.
        }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                return first.score == second.score ? 0 : (first.score < second.score ? 1 : -1);
            }
        });
    }

    private static String normalize(String value) {
        if (value == null) return null;
        String result = value.trim();
        if (result.length() == 0 || result.length() > MAX_NAME_LENGTH) return null;
        for (int i = 0; i < result.length(); i++) {
            if (Character.isISOControl(result.charAt(i))) return null;
        }
        return result;
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(20, 20, width - 40, height - 40, 15, 15);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 18));
        g.drawString("HIGHSCORES", width / 2 - 60, 50);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run run = runs.get(i);
            int y = 78 + i * 14;
            g.drawString(String.valueOf(i + 1), 35, y);
            g.drawString(run.name, 65, y);
            g.drawString(String.valueOf(run.score), width - 115, y);
            g.drawString(formatTime(run.time), width - 65, y);
        }
        g.drawString("ESC: back", 30, height - 30);
    }

    private static String formatTime(int milliseconds) {
        long seconds = milliseconds / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}