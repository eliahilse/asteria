package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, local highscore table for ApoMario. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name.replace('\t', ' ').replace('\n', ' '));
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int n = names.size() - 1;
            names.remove(n); scores.remove(n); survivalTimes.remove(n);
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the best real player in the completed run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && (best == null || p.getPoints() > best.getPoints())) best = p;
        }
        if (best != null) {
            String name = best.getTeamName();
            if (name == null || name.trim().length() == 0) name = "Player";
            storeRun(best.getPoints(), level.getPassedTime(), name);
        }
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(Integer.toString(scores.get(i))); out.write('\t');
                    out.write(Integer.toString(survivalTimes.get(i))); out.write('\t');
                    out.write(names.get(i)); out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        try { scores.add(Integer.valueOf(p[0])); survivalTimes.add(Integer.valueOf(p[1])); names.add(p[2]); }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { in.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
        }});
        ArrayList<String> n = new ArrayList<String>(); ArrayList<Integer> s = new ArrayList<Integer>(); ArrayList<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20, 15, width-40, height-30, 20, 20);
        g.setColor(Color.BLACK); g.drawRoundRect(20, 15, width-40, height-30, 20, 20);
        g.setFont(new Font("Dialog", Font.BOLD, 20)); g.drawString("HIGHSCORES", width/2-65, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        for (int i=0; i<names.size() && i<10; i++) {
            int y=75+i*18; int ms=survivalTimes.get(i).intValue(); int sec=ms/1000;
            g.drawString((i+1)+". "+names.get(i), 40, y);
            g.drawString(Integer.toString(scores.get(i)), width/2, y);
            g.drawString(String.format("%02d:%02d", sec/60, sec%60), width-90, y);
        }
        g.drawString("ESC / H: back", 40, height-25);
    }
}