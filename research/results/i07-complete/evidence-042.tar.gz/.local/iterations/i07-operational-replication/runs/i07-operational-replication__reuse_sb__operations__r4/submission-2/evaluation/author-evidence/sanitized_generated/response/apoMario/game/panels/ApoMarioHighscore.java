package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final int score;
        private final int time;
        private final String name;
        private Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(score, survivalTime, name));
        sort();
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            out.writeInt(VERSION);
            out.writeInt(entries.size());
            for (Entry e : entries) { out.writeInt(e.score); out.writeInt(e.time); out.writeUTF(e.name); }
            out.close();
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { }
    }

    private String normalize(String name) {
        if (name == null) return null;
        name = name.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return null;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return null;
        return name;
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); }
        });
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024L * 1024L) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Entry> loaded = new ArrayList<Entry>();
            for (int n = 0; n < count; n++) {
                int score = in.readInt();
                int time = in.readInt();
                String name = normalize(in.readUTF());
                if (name == null || time < 0) { in.close(); return; }
                loaded.add(new Entry(score, time, name));
            }
            in.close();
            entries.addAll(loaded);
            sort();
        } catch (IOException ex) { }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245, 235));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 65, 30);
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        for (int n = 0; n < entries.size() && n < 12; n++) {
            Entry e = entries.get(n);
            int y = 55 + n * 14;
            g.drawString(String.valueOf(n + 1), 20, y);
            g.drawString(e.name, 50, y);
            g.drawString(String.valueOf(e.score), width / 2, y);
            g.drawString(formatTime(e.time), width - 60, y);
        }
        g.drawString("ESC/H: back", 10, height - 10);
    }

    private static String formatTime(int millis) {
        int seconds = millis / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }
}