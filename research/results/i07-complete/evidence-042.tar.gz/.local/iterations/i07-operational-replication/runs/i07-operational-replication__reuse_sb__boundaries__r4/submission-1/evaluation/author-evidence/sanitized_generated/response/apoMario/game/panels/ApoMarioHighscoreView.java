package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Dedicated lightweight highscore view used by the main menu. */
public class ApoMarioHighscoreView {
    private final ApoMarioPanel game;
    public ApoMarioHighscoreView(ApoMarioPanel game) { this.game = game; }
    public void render(Graphics2D g, ApoMarioHighscore board) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 95, 40);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        List<String> names = board.getPlayersNames();
        List<Integer> scores = board.getPlayersScores();
        List<Integer> times = board.getSurvivalTimes();
        int count = Math.min(10, names.size());
        for (int i = 0; i < count; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", (seconds / 60) % 100, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 35, 75 + i * 15);
            g.drawString(Integer.toString(scores.get(i)), 205, 75 + i * 15);
            g.drawString(time, 255, 75 + i * 15);
        }
        g.drawString("ESC / H: back", 100, 225);
    }
}