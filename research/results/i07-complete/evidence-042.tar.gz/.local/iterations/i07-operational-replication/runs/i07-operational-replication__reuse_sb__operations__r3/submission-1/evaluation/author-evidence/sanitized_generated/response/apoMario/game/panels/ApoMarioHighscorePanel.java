package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** Rendering helper used by the menu's dedicated highscore view. */
public final class ApoMarioHighscorePanel {
    private ApoMarioHighscorePanel() { }

    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 10, 28);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 55 + i * 18;
            g.drawString((i + 1) + ". " + names.get(i), 15, y);
            g.drawString(String.valueOf(points.get(i)), 190, y);
            g.drawString(formatTime(times.get(i)), 250, y);
        }
        g.drawString("ESC: back", 10, ApoMarioConstants.GAME_HEIGHT - 10);
    }

    private static String formatTime(int milliseconds) {
        long totalSeconds = Math.max(0L, milliseconds) / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%02d:%02d", minutes, seconds);
    }
}