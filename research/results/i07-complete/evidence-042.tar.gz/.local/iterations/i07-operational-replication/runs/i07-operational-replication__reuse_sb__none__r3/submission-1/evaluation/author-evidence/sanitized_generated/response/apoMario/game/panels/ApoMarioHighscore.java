package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent local highscore table for completed Mario runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<String> playersNames = new ArrayList<String>();
    private final ArrayList<Integer> playersScores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }
        playersNames.add(playerName.trim());
        playersScores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(survivalTime));
        sort();
        while (playersNames.size() > MAX_ENTRIES) {
            playersNames.remove(playersNames.size() - 1);
            playersScores.remove(playersScores.size() - 1);
            survivalTimes.remove(survivalTimes.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the best real player score from the level which just ended. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (best == null || player.getPoints() > best.getPoints())) {
                best = player;
            }
        }
        if (best == null) {
            best = level.getPlayers().get(0);
        }
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        storeRun(best.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(playersScores);
    }

    /** Survival time is retained in milliseconds; formatting belongs to the view. */
    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < playersNames.size(); i++) {
                    writer.write(Integer.toString(playersScores.get(i)));
                    writer.write('\t');
                    writer.write(Integer.toString(survivalTimes.get(i)));
                    writer.write('\t');
                    writer.write(playersNames.get(i).replace('\t', ' '));
                    writer.newLine();
                }
            } finally { writer.close(); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        playersScores.add(Integer.valueOf(p[0]));
                        playersNames.add(p[2]);
                        survivalTimes.add(Integer.valueOf(p[1]));
                    }
                }
            } finally { reader.close(); }
            sort();
        } catch (Exception ignored) {
            playersNames.clear(); playersScores.clear(); survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> indexes = new ArrayList<Integer>();
        for (int i = 0; i < playersScores.size(); i++) indexes.add(Integer.valueOf(i));
        Collections.sort(indexes, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return playersScores.get(b.intValue()).compareTo(playersScores.get(a.intValue()));
            }
        });
        ArrayList<String> n = new ArrayList<String>();
        ArrayList<Integer> s = new ArrayList<Integer>();
        ArrayList<Integer> t = new ArrayList<Integer>();
        for (Integer i : indexes) { n.add(playersNames.get(i)); s.add(playersScores.get(i)); t.add(survivalTimes.get(i)); }
        playersNames.clear(); playersNames.addAll(n);
        playersScores.clear(); playersScores.addAll(s);
        survivalTimes.clear(); survivalTimes.addAll(t);
    }

    /** Small renderer used by the menu's dedicated highscore view. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(20, 15, width - 40, height - 30, 15, 15);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 18));
        g.drawString("HIGHSCORES", 30, 40);
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        int y = 62;
        for (int i = 0; i < playersNames.size() && i < 12; i++) {
            int millis = survivalTimes.get(i).intValue();
            int seconds = millis / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
            g.drawString((i + 1) + ". " + playersNames.get(i), 35, y);
            g.drawString(Integer.toString(playersScores.get(i)), width / 2, y);
            g.drawString(time, width - 75, y);
            y += 15;
        }
        g.drawString("ESC: back", 30, height - 25);
    }
}