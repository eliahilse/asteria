package apoMario.game.panels;

import apoMario.ApoMarioConstants;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent local highscore table for completed Mario runs. */
public class ApoMarioHighscore extends ApoMarioModel {
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(store)));
            out.writeInt(names.size());
            for (int i = 0; i < names.size(); i++) {
                out.writeUTF(names.get(i));
                out.writeInt(scores.get(i).intValue());
                out.writeInt(survivalTimes.get(i).intValue());
            }
            out.close();
        } catch (IOException ignored) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible()) { chosen = p; break; }
        }
        String name = chosen.getTeamName();
        if ((name == null || name.trim().length() == 0) && chosen.getAi() != null) name = chosen.getAi().getTeamName();
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int count = in.readInt();
            if (count < 0 || count > 100000) throw new IOException("invalid highscore");
            for (int i = 0; i < count; i++) {
                names.add(in.readUTF()); scores.add(Integer.valueOf(in.readInt())); survivalTimes.add(Integer.valueOf(in.readInt()));
            }
            in.close(); sort();
        } catch (EOFException ignored) { names.clear(); scores.clear(); survivalTimes.clear(); }
        catch (IOException ignored) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b).compareTo(scores.get(a)); } });
        ArrayList<String> n = new ArrayList<String>(); ArrayList<Integer> s = new ArrayList<Integer>(); ArrayList<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    public void init() { }
    public void keyButtonReleased(int button, char character) { }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function)) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, apoMario.ApoMarioConstants.GAME_WIDTH, apoMario.ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 20)); g.drawString("HIGHSCORES", 95, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        List<String> n = getPlayersNames(); List<Integer> s = getPlayersScores(); List<Integer> t = getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 10; i++) {
            int ms = t.get(i).intValue(); int sec = ms / 1000; String time = String.format("%02d:%02d", Integer.valueOf(sec / 60), Integer.valueOf(sec % 60));
            g.drawString((i + 1) + ". " + n.get(i), 35, 65 + i * 17); g.drawString(String.valueOf(s.get(i)), 210, 65 + i * 17); g.drawString(time, 275, 65 + i * 17);
        }
        g.drawString("ESC - back", 110, apoMario.ApoMarioConstants.GAME_HEIGHT - 12);
    }
}