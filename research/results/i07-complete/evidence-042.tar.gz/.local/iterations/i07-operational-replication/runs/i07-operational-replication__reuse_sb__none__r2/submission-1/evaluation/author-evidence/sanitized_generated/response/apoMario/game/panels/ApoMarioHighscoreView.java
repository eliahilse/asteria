package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioMenu;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small menu view used by ApoMarioMenu to display persisted scores. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore table) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 15, 15);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 15, 15);
        g.setFont(new Font("Dialog", Font.BOLD, 18));
        g.drawString("HIGHSCORES", 105, 48);
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        g.drawString("ESC / H: back", 25, ApoMarioConstants.GAME_HEIGHT - 25);
        List<String> n = table.getPlayersNames();
        List<Integer> s = table.getPlayersScores();
        List<Integer> t = table.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 10; i++) {
            int y = 75 + i * 15;
            g.drawString(String.valueOf(i + 1), 45, y);
            g.drawString(n.get(i), 75, y);
            g.drawString(String.valueOf(s.get(i)), 205, y);
            int ms = Math.max(0, t.get(i));
            g.drawString(String.format("%02d:%02d", (ms / 60000), (ms / 1000) % 60), 270, y);
        }
    }
}