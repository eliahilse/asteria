package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends ApoMarioModel {
    private static final int MAGIC = 0x4D415249;
    private static final int MAX_RECORDS = 1000;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private ApoMarioPanel panel;

    private static final class Entry {
        private final String name;
        private final int score;
        private final int time;
        private Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public ApoMarioHighscore(ApoMarioPanel panel, Path store) {
        this(store);
        this.panel = panel;
    }

    private static final Comparator<Entry> SCORE_ORDER = new Comparator<Entry>() {
        public int compare(Entry a, Entry b) {
            if (a.score < b.score) return 1;
            if (a.score > b.score) return -1;
            return 0;
        }
    };

    private String cleanName(String value) {
        if (value == null) return null;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) result.append(c);
        }
        String name = result.toString().trim();
        return name.length() == 0 ? null : name;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0 || entries.size() >= MAX_RECORDS) return false;
        entries.add(new Entry(name, score, survivalTime));
        Collections.sort(entries, SCORE_ORDER);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return result;
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        if (safeSize() > 1024L * 1024L) return;
        List<Entry> loaded = new ArrayList<Entry>();
        try {
            DataInputStream input = new DataInputStream(Files.newInputStream(store));
            int magic = input.readInt();
            int count = input.readInt();
            if (magic != MAGIC || count < 0 || count > MAX_RECORDS) {
                input.close();
                return;
            }
            for (int i = 0; i < count; i++) {
                String name = cleanName(input.readUTF());
                int score = input.readInt();
                int time = input.readInt();
                if (name == null || time < 0) {
                    input.close();
                    return;
                }
                loaded.add(new Entry(name, score, time));
            }
            input.close();
            Collections.sort(loaded, SCORE_ORDER);
            synchronized (this) {
                entries.clear();
                entries.addAll(loaded);
            }
        } catch (IOException ex) {
            // Leave the current board unchanged when the file is malformed.
        }
    }

    private long safeSize() {
        try { return Files.size(store); }
        catch (IOException ex) { return Long.MAX_VALUE; }
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream output = new DataOutputStream(Files.newOutputStream(temporary));
            output.writeInt(MAGIC);
            output.writeInt(entries.size());
            for (Entry entry : entries) {
                output.writeUTF(entry.name);
                output.writeInt(entry.score);
                output.writeInt(entry.time);
            }
            output.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = Math.max(0, level.getPassedTime());
        storeRun(player.getPoints(), elapsed, name);
    }

    public void init() { }

    public void keyButtonReleased(int button, char character) {
        if (button == KeyEvent.VK_ESCAPE || button == KeyEvent.VK_B) {
            if (panel != null) panel.setMenu();
        }
    }

    public void mouseButtonFunction(String function) {
        if ("backHighscore".equals(function) && panel != null) panel.setMenu();
    }

    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }

    public void render(Graphics2D g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 20, 30);
        List<String> names = getPlayersNames();
        List<Integer> scores = getPlayersScores();
        List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int y = 55 + i * 15;
            int seconds = times.get(i) / 1000;
            String clock = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 20, y);
            g.drawString(String.valueOf(scores.get(i)), 190, y);
            g.drawString(clock, 250, y);
        }
        g.drawString("ESC/B: back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
}