package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Renderer for the menu highscore board. */
public final class ApoMarioHighscorePanel {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscorePanel(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g) {
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(35, 20, ApoMarioConstants.GAME_WIDTH - 70, ApoMarioConstants.GAME_HEIGHT - 40, 16, 16);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", ApoMarioConstants.GAME_WIDTH / 2 - 55, 52);
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < names.size() && i < 12; i++) {
            int y = 78 + i * 14;
            g.drawString((i + 1) + ". " + names.get(i), 55, y);
            g.drawString(Integer.toString(scores.get(i)), 190, y);
            g.drawString(formatTime(times.get(i)), 245, y);
        }
        if (names.isEmpty()) g.drawString("No runs recorded", 85, 95);
        g.drawString("Press H or Escape to return", 72, ApoMarioConstants.GAME_HEIGHT - 28);
    }
    private String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds / 1000L);
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }
}