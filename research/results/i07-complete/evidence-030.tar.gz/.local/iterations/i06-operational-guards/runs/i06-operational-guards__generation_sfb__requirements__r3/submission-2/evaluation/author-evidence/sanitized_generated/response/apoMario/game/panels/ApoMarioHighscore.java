package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival durations are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private boolean runRecorded;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || survivalTime < 0 || playerName.length() == 0 || playerName.length() > MAX_NAME_LENGTH) {
            return false;
        }
        for (int i = 0; i < playerName.length(); i++) {
            if (Character.isISOControl(playerName.charAt(i))) return false;
        }
        entries.add(new Entry(score, survivalTime, playerName));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(Integer.valueOf(e.score));
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(Integer.valueOf(e.time));
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) {
                    writer.write(Integer.toString(e.score)); writer.write('\t');
                    writer.write(Integer.toString(e.time)); writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A missing/unwritable score file must not stop the game.
        }
    }

    /** Records the first terminal result for this live level, after final scoring. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || this.runRecorded) return;
        this.runRecorded = true;
        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty() || players.get(0) == null) return;
        ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null && entries.size() < MAX_ENTRIES) {
                    String[] parts = line.split("\\t", -1);
                    if (parts.length != 3) continue;
                    try {
                        int score = Integer.parseInt(parts[0]);
                        int time = Integer.parseInt(parts[1]);
                        if (time < 0) continue;
                        String name = new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8);
                        if (name.length() > 0 && name.length() <= MAX_NAME_LENGTH) entries.add(new Entry(score, time, name));
                    } catch (RuntimeException ex) { /* ignore malformed records */ }
                }
            } finally { reader.close(); }
            sortAndTrim();
        } catch (IOException ex) { /* treat unavailable storage as empty */ }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
}