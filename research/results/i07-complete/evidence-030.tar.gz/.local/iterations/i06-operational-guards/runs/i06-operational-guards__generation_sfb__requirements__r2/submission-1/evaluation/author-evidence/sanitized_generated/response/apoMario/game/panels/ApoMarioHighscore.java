package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-descending run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 80;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH || survivalTime < 0) return false;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return false;
        }
        entries.add(new Entry(score, survivalTime, name));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) {
                    writer.write(Integer.toString(e.score)); writer.write('\t');
                    writer.write(Integer.toString(e.time)); writer.write('\t');
                    writer.write(e.name.replace("\\", "\\\\").replace("\t", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A read-only or unavailable store must not stop the game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || !player.isBVisible()) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = reader.readLine()) != null && count++ < MAX_ENTRIES) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        if (time >= 0 && p[2].length() > 0 && p[2].length() <= MAX_NAME_LENGTH)
                            entries.add(new Entry(score, time, p[2]));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { reader.close(); }
            Collections.sort(entries, new Comparator<Entry>() {
                public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
            });
        } catch (IOException ex) { /* missing or corrupt stores are treated as empty */ }
    }

    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
}