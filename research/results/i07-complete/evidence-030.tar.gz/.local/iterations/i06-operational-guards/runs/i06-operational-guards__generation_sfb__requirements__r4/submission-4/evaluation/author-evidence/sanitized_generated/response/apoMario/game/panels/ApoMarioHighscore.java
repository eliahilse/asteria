package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_BYTES = 128;

    private static final class Run {
        String name;
        int score;
        int time;
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private final Map<ApoMarioLevel, Boolean> recorded = new IdentityHashMap<ApoMarioLevel, Boolean>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) {
            return false;
        }
        Run run = new Run();
        run.score = score;
        run.time = survivalTime;
        run.name = name;
        runs.add(run);
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    /** Starts a fresh run for a level object that is being reused. */
    public synchronized void beginRun(ApoMarioLevel level) {
        if (level != null) recorded.remove(level);
    }

    /** Records the first live player exactly once for this finished level instance. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recorded.containsKey(level) || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        recorded.put(level, Boolean.TRUE);
        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)));
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(runs.size());
            for (Run run : runs) {
                byte[] bytes = run.name.getBytes(StandardCharsets.UTF_8);
                out.writeInt(run.score);
                out.writeInt(run.time);
                out.writeInt(bytes.length);
                out.write(bytes);
            }
            out.close();
            try {
                Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A read-only or unavailable store must not stop the game.
        }
    }

    private String cleanName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_BYTES) return null;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c < 32 || c == 127) result.append('?'); else result.append(c);
        }
        return result.toString();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
            }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                Run run = new Run();
                run.score = in.readInt();
                run.time = in.readInt();
                int length = in.readInt();
                if (length < 1 || length > MAX_NAME_BYTES) { in.close(); runs.clear(); return; }
                byte[] bytes = new byte[length];
                in.readFully(bytes);
                run.name = cleanName(new String(bytes, StandardCharsets.UTF_8));
                if (run.name == null || run.time < 0) { in.close(); runs.clear(); return; }
                runs.add(run);
            }
            in.close();
            sortAndTrim();
        } catch (IOException ex) {
            runs.clear();
        }
    }

    /** Small rendering helper used by the live menu view. */
    public synchronized void render(Graphics2D g, int x, int y, int rowHeight) {
        List<String> names = getPlayersNames();
        List<Integer> scores = getPlayersScores();
        List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), x, y + i * rowHeight);
            g.drawString(String.valueOf(scores.get(i)), x + 170, y + i * rowHeight);
            g.drawString(time, x + 260, y + i * rowHeight);
        }
    }
}