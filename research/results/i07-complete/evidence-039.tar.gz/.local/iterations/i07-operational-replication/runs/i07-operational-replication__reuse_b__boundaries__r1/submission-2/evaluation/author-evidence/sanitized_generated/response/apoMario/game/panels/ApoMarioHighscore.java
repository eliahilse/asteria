package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed, local highscore board. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 80;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private boolean loaded;
    private boolean recorded;

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store");
        this.store = store;
        load();
    }

    private static String cleanName(String name) {
        if (name == null) return "Player";
        String s = name.trim();
        if (s.length() == 0) return "Player";
        if (s.length() > MAX_NAME) s = s.substring(0, MAX_NAME);
        return s.replace('\n', ' ').replace('\r', ' ');
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, cleanName(playerName)));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (recorded || level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || !player.isBVisible()) return;
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
        recorded = true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    private synchronized void load() {
        if (loaded) return;
        loaded = true;
        if (!Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE) return;
        } catch (IOException ex) {
            return;
        }
        List<Run> read = new ArrayList<Run>();
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line;
            while ((line = in.readLine()) != null) {
                if (read.size() >= MAX_RECORDS) break;
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                int score = Integer.parseInt(p[0]);
                int time = Integer.parseInt(p[1]);
                if (score < 0 || time < 0 || p[2].length() == 0 || p[2].length() > MAX_NAME) continue;
                read.add(new Run(score, time, cleanName(p[2])));
            }
            in.close();
            runs.clear(); runs.addAll(read); sortAndTrim();
        } catch (Exception ignored) { /* malformed stores never partially replace the board */ }
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            for (Run r : runs) out.write(r.score + "\t" + r.time + "\t" + r.name + "\n");
            out.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) { try { Files.deleteIfExists(tmp); } catch (IOException ignored2) { } }
    }

    /** Small rendering helper used by the menu's dedicated highscore view. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 30, 42);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < runs.size() && i < 15; i++) {
            Run r = runs.get(i); int y = 75 + i * 25;
            g.drawString(String.valueOf(i + 1), 35, y);
            g.drawString(r.name, 75, y);
            g.drawString(String.valueOf(r.score), 300, y);
            long seconds = ((long)r.time) / 1000L;
            g.drawString(String.format("%02d:%02d", seconds / 60L, seconds % 60L), 410, y);
        }
        g.drawString("ESC/H: back", 30, height - 20);
    }
}