package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, bounded and failure-safe highscore board. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private static final long MAX_FILE = 1024L * 1024L;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score, time; final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return Collections.unmodifiableList(result);
    }

    /** Reads the authoritative final player state after terminal scoring. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        if (p != null) storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), p.getTeamName());
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (Run r : runs) { out.write(Integer.toString(r.score)); out.write('\t'); out.write(Integer.toString(r.time)); out.write('\t'); out.write(r.name); out.newLine(); }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed save never damages the in-memory board. */ }
    }

    private synchronized void load() {
        if (store == null) return;
        try {
            if (!Files.isRegularFile(store) || Files.size(store) > MAX_FILE) return;
            List<Run> read = new ArrayList<Run>();
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; while ((line = in.readLine()) != null && read.size() < MAX_RECORDS) {
                    String[] a = line.split("\\t", 3);
                    if (a.length != 3) continue;
                    try { int score = Integer.parseInt(a[0]); int time = Integer.parseInt(a[1]); String name = cleanName(a[2]);
                        if (name != null && time >= 0) read.add(new Run(score, time, name));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            runs.clear(); runs.addAll(read); sortAndTrim();
        } catch (IOException ex) { runs.clear(); }
    }
    private static String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim(); if (s.length() == 0 || s.length() > MAX_NAME) return null;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return null;
        return s;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    /** Renders the dedicated menu view; conversion to mm:ss is presentation-only. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245,245,220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24)); g.drawString("HIGHSCORES", 30, 40);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < runs.size(); i++) { Run r = runs.get(i); long sec = r.time / 1000L; String t = String.format("%02d:%02d", sec / 60L, sec % 60L); g.drawString((i + 1) + ". " + r.name, 35, 75 + i * 22); g.drawString(Integer.toString(r.score), width / 2, 75 + i * 22); g.drawString(t, width - 100, 75 + i * 22); }
        g.drawString("ESC: back", 30, height - 20);
    }
}