package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Lightweight menu view for the persistent highscore data. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore scores, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 18, 18);
        g.drawString("HIGHSCORES", width / 2 - 45, height / 8);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        int rows = Math.min(names.size(), 12);
        for (int i = 0; i < rows; i++) {
            int y = height / 6 + i * 18;
            int seconds = Math.max(0, times.get(i)) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), width / 6, y);
            g.drawString(String.valueOf(points.get(i)), width / 2, y);
            g.drawString(time, width * 2 / 3, y);
        }
        g.drawString("H/ESC: back", width / 2 - 35, height * 11 / 12);
    }
}