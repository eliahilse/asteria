package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 80;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final int score;
        final int time;
        final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sortAndLimit();
        return true;
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
        persistAcrossRuns();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Entry e : entries) {
                lines.add(e.score + "\t" + e.time + "\t" + Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) { }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 24, 40);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        g.drawString("Name", 35, 72); g.drawString("Score", width - 220, 72); g.drawString("Time", width - 100, 72);
        for (int i = 0; i < entries.size() && i < 15; i++) {
            Entry e = entries.get(i); int y = 100 + i * 25;
            g.drawString((i + 1) + ". " + e.name, 35, y);
            g.drawString(String.valueOf(e.score), width - 220, y);
            g.drawString(formatTime(e.time), width - 100, y);
        }
        g.drawString("ESC: back", 35, height - 20);
    }

    public static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, (long) milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    private String cleanName(String value) {
        if (value == null) return "";
        String result = value.trim().replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
        return result.length() > MAX_NAME_LENGTH ? result.substring(0, MAX_NAME_LENGTH) : result;
    }
    private synchronized void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) {
            int result = Integer.compare(b.score, a.score);
            return result != 0 ? result : Integer.compare(a.time, b.time);
        }});
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_SIZE) return;
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.size() > MAX_RECORDS) return;
            List<Entry> loaded = new ArrayList<Entry>();
            for (String line : lines) {
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3) return;
                int score = Integer.parseInt(fields[0]);
                int time = Integer.parseInt(fields[1]);
                if (time < 0) return;
                String name = new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8);
                if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return;
                loaded.add(new Entry(score, time, cleanName(name)));
            }
            entries.addAll(loaded);
            sortAndLimit();
        } catch (Exception ex) { entries.clear(); }
    }
}