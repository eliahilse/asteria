package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered results for completed runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the first live player after the level has applied its final score. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Run r : runs) lines.add(r.score + "\t" + r.time + "\t" + Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)));
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed save must not stop the game. */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            int count = 0;
            for (String line : lines) {
                if (count++ >= MAX_ENTRIES || line.length() > 512) break;
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    String name = normalizeName(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                    if (name != null && time >= 0) runs.add(new Run(score, time, name));
                } catch (RuntimeException ex) { /* ignore malformed records */ }
            }
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
            });
            while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
        } catch (IOException ex) { /* missing or unreadable stores start empty */ }
    }

    private static String normalizeName(String value) {
        if (value == null) return null;
        String s = value.replaceAll("[\\r\\n\\t]", " ").trim();
        if (s.length() == 0) return null;
        return s.length() > MAX_NAME_LENGTH ? s.substring(0, MAX_NAME_LENGTH) : s;
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, 190, 12, 12);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, 190, 12, 12);
        g.drawString("HIGHSCORES", x + 12, y + 22);
        for (int i = 0; i < runs.size() && i < 8; i++) {
            Run r = runs.get(i);
            int seconds = r.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + r.name, x + 12, y + 45 + i * 18);
            g.drawString(String.valueOf(r.score), x + width - 100, y + 45 + i * 18);
            g.drawString(time, x + width - 52, y + 45 + i * 18);
        }
    }
}