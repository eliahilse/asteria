package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local, file-backed highscore board. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0) return false;
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first human player's final score after terminal scoring. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    String encoded = Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8));
                    out.write(Integer.toString(run.score)); out.write('\t');
                    out.write(Integer.toString(run.time)); out.write('\t');
                    out.write(encoded); out.newLine();
                }
            } finally { out.close(); }
            try {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A failed write must not make the running game fail.
        }
    }

    private synchronized void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            List<Run> loaded = new ArrayList<Run>();
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null && loaded.size() < MAX_RECORDS) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3) continue;
                    int score = Integer.parseInt(fields[0]);
                    int time = Integer.parseInt(fields[1]);
                    if (score < 0 || time < 0) continue;
                    String name = new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8);
                    name = cleanName(name);
                    if (name.length() > 0) loaded.add(new Run(score, time, name));
                }
            } finally { in.close(); }
            runs.clear(); runs.addAll(loaded); sortAndTrim();
        } catch (Exception ex) {
            runs.clear();
        }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\t' && c != '\n' && c != '\r') result.append(c);
        }
        return result.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                if (a.score != b.score) return a.score > b.score ? -1 : 1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 18));
        g.drawString("Name", 45, 85); g.drawString("Score", width - 210, 85); g.drawString("Time", width - 90, 85);
        int y = 115;
        for (Run run : runs) {
            if (y > height - 20) break;
            g.drawString(run.name, 45, y);
            g.drawString(Integer.toString(run.score), width - 210, y);
            long seconds = ((long) run.time) / 1000L;
            long minutes = seconds / 60L;
            g.drawString(String.format("%02d:%02d", minutes, seconds % 60L), width - 90, y);
            y += 27;
        }
        g.drawString("Press ESC to return", 30, height - 20);
    }
}