package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private final Map<ApoMarioLevel, String> recordedLevels = new IdentityHashMap<ApoMarioLevel, String>();

    private static final class Run {
        String name; int score; int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null) return;
        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty()) return;
        ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int score = player.getPoints();
        int time = Math.max(0, level.getPassedTime());
        String key = score + "\\n" + time + "\\n" + name;
        if (key.equals(recordedLevels.get(level))) return;
        if (storeRun(score, time, name)) {
            recordedLevels.put(level, key);
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Run r : runs) out.write(escape(r.name) + "\t" + r.score + "\t" + r.time + "\n");
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* highscore must not stop the game */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = in.readLine()) != null && count++ < MAX_ENTRIES) {
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[1]); int time = Integer.parseInt(p[2]);
                        String name = normalizeName(unescape(p[0]));
                        if (name != null && time >= 0) runs.add(new Run(name, score, time));
                    } catch (RuntimeException ignored) { }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ignored) { }
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
    private static String normalizeName(String value) {
        if (value == null) return null;
        String s = value.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
        if (s.length() == 0 || s.length() > MAX_NAME_LENGTH) return null;
        return s;
    }
    private static String escape(String s) { return s.replace("\\", "\\\\").replace("\t", "\\t"); }
    private static String unescape(String s) { return s.replace("\\t", "\t").replace("\\\\", "\\"); }
}