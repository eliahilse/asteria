package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private final Set<ApoMarioLevel> recordedLevels = Collections.newSetFromMap(new IdentityHashMap<ApoMarioLevel, Boolean>());

    private static final class Entry {
        final int score;
        final int time;
        final String name;
        Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || survivalTime < 0) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return false;
        }
        entries.add(new Entry(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first live player's final score, name, and elapsed milliseconds once. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level) || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) recordedLevels.add(level);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Entry e : entries) {
                lines.add(e.score + "\t" + e.time + "\t" + Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // Persistence failure must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            for (int i = 0; i < lines.size() && entries.size() < MAX_ENTRIES; i++) {
                String[] parts = lines.get(i).split("\\t", -1);
                if (parts.length != 3) continue;
                try {
                    int score = Integer.parseInt(parts[0]);
                    int time = Integer.parseInt(parts[1]);
                    String name = new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8).trim();
                    if (time >= 0 && name.length() > 0 && name.length() <= MAX_NAME_LENGTH) {
                        entries.add(new Entry(score, time, name));
                    }
                } catch (RuntimeException ex) {
                    // Ignore malformed records.
                }
            }
            sortAndTrim();
        } catch (IOException ex) {
            // Missing or unreadable stores are treated as empty.
        }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry left, Entry right) {
                return left.score < right.score ? 1 : (left.score == right.score ? 0 : -1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
}