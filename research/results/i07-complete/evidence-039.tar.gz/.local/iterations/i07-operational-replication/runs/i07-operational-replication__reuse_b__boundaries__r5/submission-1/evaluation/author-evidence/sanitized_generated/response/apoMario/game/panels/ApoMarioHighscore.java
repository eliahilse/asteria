package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, file-backed highscore board and its small menu view. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private static final int MAX_FILE_BYTES = 1024 * 1024;

    private static final class Entry {
        final int score;
        final int time;
        final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        entries.add(new Entry(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the final score after ApoMarioLevel has applied terminal bonuses. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        storeRun(player.getPoints(), level.getPassedTime(), player.getTeamName());
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Entry e : entries) {
                String encoded = Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8));
                lines.add(e.score + "\t" + e.time + "\t" + encoded);
            }
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            try {
                Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            // A failed save must not interrupt the game.
        }
    }

    private synchronized void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_BYTES) return;
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            List<Entry> loaded = new ArrayList<Entry>();
            for (String line : lines) {
                if (loaded.size() >= MAX_RECORDS || line.length() > 512) break;
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                int score = Integer.parseInt(p[0]);
                int time = Integer.parseInt(p[1]);
                if (score < 0 || time < 0) continue;
                String name = new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                name = cleanName(name);
                if (name.length() == 0) continue;
                loaded.add(new Entry(score, time, name));
            }
            entries.clear();
            entries.addAll(loaded);
            sortAndTrim();
        } catch (Exception ex) {
            entries.clear();
        }
    }

    private String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                if (a.score != b.score) return a.score > b.score ? -1 : 1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("Highscores", 30, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        g.drawString("Name", 65, 80); g.drawString("Points", 300, 80); g.drawString("Time", 420, 80);
        for (int i = 0; i < entries.size() && i < 15; i++) {
            Entry e = entries.get(i); int y = 108 + i * 24;
            g.drawString((i + 1) + ". " + e.name, 35, y);
            g.drawString(String.valueOf(e.score), 300, y);
            long seconds = e.time / 1000L;
            g.drawString(String.format("%02d:%02d", seconds / 60L, seconds % 60L), 420, y);
        }
        g.drawString("Press Escape to return", 30, ApoMarioConstants.GAME_HEIGHT - 20);
    }
}