package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModelMenu;
import org.apogames.entity.ApoAnimation;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run results and their menu view. */
public class ApoMarioHighscore extends ApoMarioModelMenu {
    private static final int MAGIC = 0x41504F48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();
    private boolean bRecorded;
    private int recordedScore;
    private int recordedTime;
    private String recordedName;

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME || survivalTime < 0) return false;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return false;
        }
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(Integer.valueOf(e.score));
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(Integer.valueOf(e.time));
        return Collections.unmodifiableList(result);
    }

    /** Records the first human/player result when this level reaches its terminal state. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int score = player.getPoints();
        int survivalTime = Math.max(0, level.getPassedTime());
        if (bRecorded && recordedScore == score && recordedTime == survivalTime && recordedName.equals(name)) return;
        if (storeRun(score, survivalTime, name)) {
            bRecorded = true;
            recordedScore = score;
            recordedTime = survivalTime;
            recordedName = name;
        }
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(entries.size());
            for (Entry e : entries) { out.writeUTF(e.name); out.writeInt(e.score); out.writeInt(e.time); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A read-only store must not stop the game. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = in.readUTF(); int score = in.readInt(); int time = in.readInt();
                if (name.length() > 0 && name.length() <= MAX_NAME && time >= 0) entries.add(new Entry(name, score, time));
            }
            in.close(); sortAndTrim();
        } catch (IOException | RuntimeException ex) { entries.clear(); }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }

    @Override public void init() { }
    @Override public void makeBackground() { setIBackground(null); }
    @Override public void makeBackgroundAnimation() { setBackgroundAnimation(new ArrayList<org.apogames.entity.ApoAnimation>()); }
    @Override public void makeRunner() { setRunner(null); }
    @Override public void makeSearch() { setSearch(null); }
    @Override public void keyButtonReleased(int button, char character) { if (button == java.awt.event.KeyEvent.VK_ESCAPE) getGame().setMenu(); }
    @Override public void mouseButtonFunction(String function) { if ("backHighscore".equals(function) && getGame() != null) getGame().setMenu(); }
    @Override public void excecuteFunction() { }
    @Override public void mouseButtonReleased(int x, int y) { }
    @Override public boolean mouseMoved(int x, int y) { return false; }
    @Override public boolean mouseDragged(int x, int y) { return false; }
    @Override public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    @Override public void think(int delta) { }
    @Override public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 20, 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = getPlayersNames(); List<Integer> scores = getPlayersScores(); List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int y = 65 + i * 18;
            g.drawString((i + 1) + ". " + names.get(i), 20, y);
            g.drawString(String.valueOf(scores.get(i)), 190, y);
            g.drawString(formatTime(times.get(i)), 260, y);
        }
        g.drawString("ESC - back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
}