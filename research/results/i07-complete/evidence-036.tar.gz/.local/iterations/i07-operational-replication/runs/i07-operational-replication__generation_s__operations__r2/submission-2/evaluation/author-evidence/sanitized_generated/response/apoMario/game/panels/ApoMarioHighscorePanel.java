package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** Dedicated renderer for the persistent highscore board. */
public class ApoMarioHighscorePanel {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscorePanel(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(28, 18, ApoMarioConstants.GAME_WIDTH-56, ApoMarioConstants.GAME_HEIGHT-36, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(28, 18, ApoMarioConstants.GAME_WIDTH-56, ApoMarioConstants.GAME_HEIGHT-36, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 72, 52);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> n=highscore.getPlayersNames();
        List<Integer> s=highscore.getPlayersScores();
        List<Integer> t=highscore.getSurvivalTimes();
        for (int i=0; i<n.size() && i<9; i++) { int y=82+i*19; int sec=t.get(i)/1000; String tm=(sec/60)+":"+String.format("%02d", sec%60); g.drawString((i+1)+". "+n.get(i), 48, y); g.drawString(Integer.toString(s.get(i)), 205, y); g.drawString(tm, 258, y); }
        if (n.isEmpty()) g.drawString("No runs recorded yet", 72, 95);
        g.drawString("H / ESC: back", 72, ApoMarioConstants.GAME_HEIGHT-28);
    }
}