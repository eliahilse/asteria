package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final String SEPARATOR = "\t";
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final String name;
        private final int score;
        private final int time;
        private Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    private synchronized void load() {
        entries.clear();
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split(SEPARATOR, -1);
                if (p.length >= 3) entries.add(new Entry(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2])));
            }
            sort();
        } catch (Exception ignored) { entries.clear(); }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Unknown" : playerName.trim();
        if (name.length() == 0) name = "Unknown";
        name = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ');
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible()) { selected = player; break; }
        }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Entry e : entries) lines.add(e.name + SEPARATOR + e.score + SEPARATOR + e.time);
            Files.write(store, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (Exception ignored) { }
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, height, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 20, 20);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", x + 20, y + 30);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int row = y + 55;
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i);
            long seconds = e.time / 1000L;
            g.drawString((i + 1) + ". " + e.name, x + 20, row);
            g.drawString(String.valueOf(e.score), x + width - 125, row);
            g.drawString(String.format("%02d:%02d", seconds / 60L, seconds % 60L), x + width - 65, row);
            row += 20;
        }
        if (entries.isEmpty()) g.drawString("No completed runs yet", x + 20, row);
        g.drawString("Press H or Escape to return", x + 20, y + height - 15);
    }
}