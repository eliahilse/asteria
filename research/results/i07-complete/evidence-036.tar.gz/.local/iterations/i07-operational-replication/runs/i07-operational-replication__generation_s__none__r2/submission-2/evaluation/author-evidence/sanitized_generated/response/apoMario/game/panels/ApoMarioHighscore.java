package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;

/** Persistent highscore table for completed runs. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final String VERSION = "APOMARIO_HIGHSCORE_1";
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final int score;
        private final int time;
        private final String name;
        private Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        if (name.length() > 40) {
            name = name.substring(0, 40);
        }
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sort();
        return persistInternal();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persistInternal();
    }

    /** Records one completed live level using its actual score, name and elapsed time. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level != null) {
            level.recordRunEnd(this);
        }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.size() == 0 || !VERSION.equals(lines.get(0))) return;
            for (int i = 1; i < lines.size(); i++) {
                String[] parts = lines.get(i).split("\\t", -1);
                if (parts.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8);
                    entries.add(new Entry(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), name));
                } catch (IllegalArgumentException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private boolean persistInternal() {
        if (store == null) return false;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            lines.add(VERSION);
            for (Entry entry : entries) {
                lines.add(entry.score + "\t" + entry.time + "\t" +
                        Base64.getEncoder().encodeToString(entry.name.getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(store, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            return true;
        } catch (IOException ignored) {
            return false;
        }
    }

    /** Renders the board; conversion to mm:ss deliberately happens only here. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(20, 15, width - 40, height - 30, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(20, 15, width - 40, height - 30, 20, 20);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
        g.drawString("HIGHSCORES", 35, 48);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int y = 78;
        int max = Math.min(entries.size(), 12);
        for (int i = 0; i < max; i++) {
            Entry e = entries.get(i);
            int seconds = e.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + e.name, 40, y);
            g.drawString(String.valueOf(e.score), width / 2, y);
            g.drawString(time, width - 100, y);
            y += 22;
        }
        if (max == 0) g.drawString("No completed runs yet.", 40, y);
        g.drawString("Press H or Escape to return", 35, height - 35);
    }
}