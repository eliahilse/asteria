package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, deliberately simple highscore table. Durations are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        String name; int score; int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0) return false;
        String name = normalize(playerName);
        if (name.length() == 0) name = "Player";
        runs.add(new Run(name, score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                out.write("APO_MARIO_HIGHSCORE_1"); out.newLine();
                for (Run r : runs) {
                    out.write(Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)));
                    out.write('\t'); out.write(Integer.toString(r.score));
                    out.write('\t'); out.write(Integer.toString(r.time)); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) {
            // A failed write must not interrupt the game or destroy the old snapshot.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g) {
        int size = ApoMarioConstants.SIZE;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(20 * size, 15 * size, ApoMarioConstants.GAME_WIDTH - 40 * size,
                ApoMarioConstants.GAME_HEIGHT - 30 * size, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(20 * size, 15 * size, ApoMarioConstants.GAME_WIDTH - 40 * size,
                ApoMarioConstants.GAME_HEIGHT - 30 * size, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 35 * size, 38 * size);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        int y = 58 * size;
        for (int i = 0; i < runs.size() && i < 10; i++) {
            Run r = runs.get(i);
            g.drawString((i + 1) + ". " + r.name, 35 * size, y);
            g.drawString(Integer.toString(r.score), 175 * size, y);
            g.drawString(formatTime(r.time), 230 * size, y);
            y += 16 * size;
        }
        g.drawString("ESC: back", 35 * size, ApoMarioConstants.GAME_HEIGHT - 20 * size);
    }

    private static String formatTime(int millis) {
        long seconds = millis / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }

    private static String normalize(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    private void sortAndLimit() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 1024) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE_1".equals(in.readLine())) return;
                String line; int count = 0;
                while ((line = in.readLine()) != null && count++ < MAX_ENTRIES) {
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3) continue;
                    String name = normalize(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8));
                    int score = Integer.parseInt(p[1]); int time = Integer.parseInt(p[2]);
                    if (name.length() > 0 && time >= 0) runs.add(new Run(name, score, time));
                }
            } finally { in.close(); }
            sortAndLimit();
        } catch (Exception e) { runs.clear(); }
    }
}