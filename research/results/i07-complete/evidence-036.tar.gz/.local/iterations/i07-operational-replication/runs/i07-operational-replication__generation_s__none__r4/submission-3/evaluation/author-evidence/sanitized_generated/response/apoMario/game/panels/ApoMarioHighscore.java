package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModelMenu;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.game.ApoMarioPanel;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends ApoMarioModelMenu {
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();
    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }
    public ApoMarioHighscore(Path store) { super(null); this.store = store; load(); }
    public ApoMarioHighscore(ApoMarioPanel game, Path store) { super(game); this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        entries.add(new Entry(name, score, Math.max(0, survivalTime))); sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { ArrayList<String> r = new ArrayList<String>(); for (Entry e: entries) r.add(e.name); return r; }
    public synchronized List<Integer> getPlayersScores() { ArrayList<Integer> r = new ArrayList<Integer>(); for (Entry e: entries) r.add(e.score); return r; }
    public synchronized List<Integer> getSurvivalTimes() { ArrayList<Integer> r = new ArrayList<Integer>(); for (Entry e: entries) r.add(e.time); return r; }
    private void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } }); }
    private void load() {
        if (store == null || !Files.exists(store)) return;
        try { BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8); String line;
            while ((line = r.readLine()) != null) { String[] p = line.split("\\t", -1); if (p.length == 3) try { entries.add(new Entry(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]))); } catch (NumberFormatException ignored) {} }
            r.close(); sort();
        } catch (IOException ignored) {}
    }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try { Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent); BufferedWriter w = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            for (Entry e: entries) { w.write(e.name.replace('\t', ' ') + "\t" + e.score + "\t" + e.time); w.newLine(); } w.close();
        } catch (IOException ignored) {}
    }
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0); String name = p.getTeamName(); if (name == null || name.trim().length() == 0) name = p.getAuthor();
        storeRun(p.getPoints(), level.getPassedTime(), name);
    }
    public void init() {}
    public void makeBackground() {}
    public void makeBackgroundAnimation() {}
    public void makeRunner() {}
    public void makeSearch() {}
    public void keyButtonReleased(int b, char c) {}
    public void mouseButtonFunction(String f) {}
    public void mouseButtonReleased(int x, int y) {}
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean right) { return false; }
    public void think(int delta) {}
    public void releasedEnter() {}
    public void excecuteFunction() {}
    public synchronized void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT); g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 20, 35); g.setFont(ApoMarioConstants.FONT_MENU); int y = 65;
        for (int i = 0; i < entries.size() && i < 10; i++) { Entry e = entries.get(i); int seconds = e.time / 1000; g.drawString((i + 1) + ". " + e.name, 20, y); g.drawString(String.valueOf(e.score), 190, y); g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 260, y); y += 18; }
        if (entries.isEmpty()) g.drawString("No runs recorded", 20, y);
    }
}