package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name;
        final int score;
        final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private static String cleanName(String value) {
        if (value == null) return "Player";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < 24; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) result.append(c);
        }
        String name = result.toString().trim();
        return name.length() == 0 ? "Player" : name;
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.isRegularFile(store) || Files.size(store) > 1048576L) return;
            List<String> lines = Files.readAllLines(store, UTF8);
            for (String line : lines) {
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3 || fields[0].length() > 128) continue;
                try {
                    String name = cleanName(new String(java.util.Base64.getDecoder().decode(fields[0]), "UTF-8"));
                    int score = Integer.parseInt(fields[1]);
                    int time = Integer.parseInt(fields[2]);
                    if (score >= 0 && time >= 0) entries.add(new Entry(name, score, time));
                } catch (Exception ignored) { }
            }
            sort();
        } catch (Exception ignored) { }
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0) return false;
        entries.add(new Entry(cleanName(playerName), score, survivalTime));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = null;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Entry entry : entries) {
                String encoded = java.util.Base64.getEncoder().encodeToString(entry.name.getBytes("UTF-8"));
                lines.add(encoded + "\t" + entry.score + "\t" + entry.time);
            }
            Files.write(temporary, lines, UTF8);
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception unsupportedAtomicMove) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ignored) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (Exception ignoredAgain) { }
        }
    }

    private final java.util.Set<ApoMarioLevel> recordedLevels = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<ApoMarioLevel, Boolean>());

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level) || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) recordedLevels.add(level);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(18, 18, width - 36, height - 36, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(18, 18, width - 36, height - 36, 20, 20);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        g.drawString("HIGHSCORES", 35, 52);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        for (int i = 0; i < entries.size() && i < 12; i++) {
            Entry entry = entries.get(i);
            int seconds = entry.time / 1000;
            String time = (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60);
            int y = 82 + i * 22;
            g.drawString((i + 1) + ". " + entry.name, 42, y);
            g.drawString(String.valueOf(entry.score), width / 2, y);
            g.drawString(time, width - 100, y);
        }
        g.drawString("Press H or Escape to return", 35, height - 30);
    }
}