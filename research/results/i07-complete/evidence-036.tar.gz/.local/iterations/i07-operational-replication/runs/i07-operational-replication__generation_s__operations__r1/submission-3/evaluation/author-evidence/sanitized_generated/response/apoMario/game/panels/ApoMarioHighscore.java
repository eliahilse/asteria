package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final String HEADER = "APOMARIO-HIGHSCORE-1";
    private static final int MAX_ENTRIES = 1000;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private ApoMarioLevel recordedLevel;
    private int recordedScore;
    private int recordedTime;
    private String recordedName;
    private boolean hasRecordedState;

    private static final class Entry {
        private final String name;
        private final int score;
        private final int time;
        private Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = normalize(player.getTeamName());
        if (name == null) name = "Human";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        int score = player.getPoints();
        if (hasRecordedState && level == recordedLevel && score == recordedScore && elapsed == recordedTime && name.equals(recordedName)) return;
        if (storeRun(score, elapsed, name)) {
            recordedLevel = level;
            recordedScore = score;
            recordedTime = elapsed;
            recordedName = name;
            hasRecordedState = true;
        }
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                writer.write(HEADER);
                writer.newLine();
                for (Entry entry : entries) {
                    writer.write(escape(entry.name));
                    writer.write("\t");
                    writer.write(Integer.toString(entry.score));
                    writer.write("\t");
                    writer.write(Integer.toString(entry.time));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException exception) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException exception) { }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 1024) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!HEADER.equals(reader.readLine())) return;
                String line;
                while (entries.size() < MAX_ENTRIES && (line = reader.readLine()) != null) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3) continue;
                    try {
                        String name = normalize(unescape(fields[0]));
                        int score = Integer.parseInt(fields[1]);
                        int time = Integer.parseInt(fields[2]);
                        if (name != null && time >= 0) entries.add(new Entry(name, score, time));
                    } catch (IllegalArgumentException exception) { }
                }
            } finally { reader.close(); }
            sortAndLimit();
        } catch (IOException exception) { }
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r");
    }

    private static String unescape(String value) {
        return value.replace("\\t", "\t").replace("\\n", "\n").replace("\\r", "\r").replace("\\\\", "\\");
    }

    private static String normalize(String value) {
        if (value == null) return null;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = value.charAt(i);
            if (!Character.isISOControl(character)) result.append(character);
        }
        String normalized = result.toString().trim();
        return normalized.length() == 0 ? null : normalized;
    }

    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) { return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    public synchronized void render(Graphics2D graphics) {
        graphics.setColor(new Color(245, 245, 255));
        graphics.fillRect(0, 0, 320, 240);
        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        graphics.drawString("HIGHSCORES", 92, 30);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        graphics.drawString("PLAYER", 20, 55);
        graphics.drawString("POINTS", 165, 55);
        graphics.drawString("TIME", 245, 55);
        int y = 73;
        for (Entry entry : entries) {
            if (y > 225) break;
            graphics.drawString(entry.name, 20, y);
            graphics.drawString(Integer.toString(entry.score), 165, y);
            int seconds = entry.time / 1000;
            graphics.drawString(String.format("%d:%02d", seconds / 60, seconds % 60), 245, y);
            y += 16;
        }
        graphics.drawString("H: back", 20, 235);
    }

    public static Path defaultStore() {
        return Paths.get(System.getProperty("user.home"), ".apoMario-highscores.dat");
    }
}