package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated renderer for the menu highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 95, 55);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        int count = Math.min(names.size(), 10);
        for (int i = 0; i < count; i++) {
            int seconds = Math.max(0, times.get(i) / 1000);
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 50, 85 + i * 18);
            g.drawString(String.valueOf(points.get(i)), 200, 85 + i * 18);
            g.drawString(time, 255, 85 + i * 18);
        }
        g.drawString("Press H or ESC to return", 65, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}