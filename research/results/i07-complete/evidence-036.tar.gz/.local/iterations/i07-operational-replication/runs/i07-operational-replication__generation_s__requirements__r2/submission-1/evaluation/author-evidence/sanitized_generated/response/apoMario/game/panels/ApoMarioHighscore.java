package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded highscore table. Survival times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first live player, using the level's authoritative final values. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            for (Entry e : entries) lines.add(e.score + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " "));
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* Scores remain available for this run. */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            int count = 0;
            for (String line : lines) {
                if (count++ >= MAX_ENTRIES) break;
                String[] p = line.split("\\t", 3);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                    String name = cleanName(p[2]);
                    if (name != null && time >= 0) entries.add(new Entry(name, score, time));
                } catch (NumberFormatException ex) { /* ignore malformed records */ }
            }
            sortAndTrim();
        } catch (IOException ex) { /* missing or unreadable stores start empty */ }
    }
    private static String cleanName(String name) {
        if (name == null) return null;
        name = name.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ').trim();
        if (name.length() == 0) return null;
        return name.length() > MAX_NAME ? name.substring(0, MAX_NAME) : name;
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    /** Small dedicated view used by the main menu. */
    public void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 255, 235)); g.fillRect(10, 10, width - 20, height - 20);
        g.setColor(Color.BLACK); g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", width / 2 - 65, 38);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        List<String> names = getPlayersNames(); List<Integer> scores = getPlayersScores(); List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int millis = times.get(i); int seconds = millis / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 35, 65 + i * 16);
            g.drawString(String.valueOf(scores.get(i)), width / 2, 65 + i * 16);
            g.drawString(time, width - 75, 65 + i * 16);
        }
        g.drawString("Press H or Escape to return", 35, height - 25);
    }
}