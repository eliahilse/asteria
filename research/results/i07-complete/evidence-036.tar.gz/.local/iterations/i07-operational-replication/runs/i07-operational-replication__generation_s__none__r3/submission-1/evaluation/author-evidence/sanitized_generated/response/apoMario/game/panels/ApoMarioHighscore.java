package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered results for completed runs. */
public class ApoMarioHighscore {
    private static final String HEADER = "APO_MARIO_HIGHSCORE_1";
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final int score;
        private final int time;
        private final String name;
        private Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Unknown" : playerName.trim();
        if (name.length() == 0) {
            name = "Unknown";
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }
        entries.add(new Entry(score, survivalTime, name));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            lines.add(HEADER);
            for (Entry entry : entries) {
                lines.add(entry.score + "\t" + entry.time + "\t" +
                        Base64.getEncoder().encodeToString(entry.name.getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(store, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (IOException ignored) {
            // A highscore must never stop the game when its file is unavailable.
        }
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            for (int i = 1; i < lines.size(); i++) {
                String[] parts = lines.get(i).split("\\t", 3);
                if (parts.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8);
                    entries.add(new Entry(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), name));
                } catch (IllegalArgumentException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
    }

    /** Convenience hook used by the live level lifecycle. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }
}