package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Dedicated menu view for the persistent score table. */
public class ApoMarioHighscorePanel extends ApoMarioModel {
    private final ApoMarioHighscore scores;
    public ApoMarioHighscorePanel(ApoMarioPanel game, ApoMarioHighscore scores) { super(game); this.scores = scores; }
    public void init() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE || button == KeyEvent.VK_H) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function)) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 30, 40);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> n = scores.getPlayersNames(); List<Integer> p = scores.getPlayersScores(); List<Integer> t = scores.getSurvivalTimes();
        int y = 75;
        for (int i = 0; i < n.size() && i < 12; i++, y += 18) {
            int seconds = t.get(i) / 1000; String time = (seconds / 60) + ":" + String.format("%02d", seconds % 60);
            g.drawString((i + 1) + ". " + n.get(i), 30, y); g.drawString(String.valueOf(p.get(i)), 210, y); g.drawString(time, 260, y);
        }
        g.drawString("ESC: back", 30, ApoMarioConstants.GAME_HEIGHT - 15);
    }
}