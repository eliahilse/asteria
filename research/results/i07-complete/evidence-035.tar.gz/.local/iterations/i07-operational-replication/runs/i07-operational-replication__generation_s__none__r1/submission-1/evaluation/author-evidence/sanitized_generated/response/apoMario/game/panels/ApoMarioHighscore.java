package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final class Run {
        String name; int score; int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try (BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length >= 3) {
                    try { runs.add(new Run(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]))); }
                    catch (NumberFormatException ignored) { }
                }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        name = name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
        runs.add(new Run(name, score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    /** Records the best real player score in the completed level. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && (best == null || p.getPoints() > best.getPoints())) best = p;
        }
        if (best == null) return;
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(best.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter w = Files.newBufferedWriter(store, StandardCharsets.UTF_8)) {
                for (Run run : runs) w.write(run.name + "\t" + run.score + "\t" + run.time + "\n");
            }
        } catch (IOException ignored) { }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> out = new ArrayList<String>(); for (Run r : runs) out.add(r.name); return out;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> out = new ArrayList<Integer>(); for (Run r : runs) out.add(r.score); return out;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> out = new ArrayList<Integer>(); for (Run r : runs) out.add(r.time); return out;
    }
}