package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded high-score table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String clean(String value) {
        if (value == null) return "Player";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? "Player" : s;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0) survivalTime = 0;
        entries.add(new Entry(clean(playerName), score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || player.getAi() != null) return;
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score == a.score ? a.name.compareTo(b.name) : (b.score < a.score ? -1 : 1); }
        });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null && entries.size() < MAX_RECORDS) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    if (time >= 0 && p[2].length() <= MAX_NAME) entries.add(new Entry(clean(p[2]), score, time));
                } catch (NumberFormatException ignored) { }
            }
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter w = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                for (Entry e : entries) w.write(e.score + "\t" + e.time + "\t" + e.name.replace("\t", " ") + "\n");
            }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) { }
    }

    public synchronized List<String> getPlayersNames() { List<String> r = new ArrayList<String>(); for (Entry e : entries) r.add(e.name); return r; }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.score); return r; }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.time); return r; }
}