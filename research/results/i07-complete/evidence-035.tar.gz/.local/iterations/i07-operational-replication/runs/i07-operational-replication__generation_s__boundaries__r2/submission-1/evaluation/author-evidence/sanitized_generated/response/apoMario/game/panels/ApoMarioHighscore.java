package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent highscore data and its small, self-contained menu view. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String cleanName(String name) {
        if (name == null) return "Player";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < name.length() && b.length() < MAX_NAME; i++) {
            char c = name.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        String result = b.toString().trim();
        return result.length() == 0 ? "Player" : result;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, cleanName(playerName)));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return result;
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, Charset.forName("UTF-8"));
            for (String line : lines) {
                if (runs.size() >= MAX_RECORDS || !line.startsWith("v1\t")) continue;
                String[] p = line.split("\\t", -1);
                if (p.length != 4) continue;
                try {
                    int score = Integer.parseInt(p[1]);
                    int time = Integer.parseInt(p[2]);
                    if (time >= 0) runs.add(new Run(score, time, cleanName(p[3])));
                } catch (NumberFormatException ignored) { }
            }
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
            });
        } catch (Exception ignored) { }
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            for (Run r : runs) lines.add("v1\t" + r.score + "\t" + r.time + "\t" + r.name.replace("\t", " "));
            Files.write(tmp, lines, Charset.forName("UTF-8"));
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    /** Captures the authoritative human player's score and elapsed level time. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || player.getAi() != null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }

    /** Renders the board; storage remains in milliseconds and is formatted only here. */
    public synchronized void render(Graphics2D g) {
        int w = ApoMarioConstants.GAME_WIDTH - 36 * ApoMarioConstants.SIZE;
        int h = ApoMarioConstants.GAME_HEIGHT - 30 * ApoMarioConstants.SIZE;
        int x = (ApoMarioConstants.GAME_WIDTH - w) / 2;
        int y = (ApoMarioConstants.GAME_HEIGHT - h) / 2;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, w, h, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, w, h, 18, 18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18 * ApoMarioConstants.SIZE));
        g.drawString("HIGHSCORES", x + 18, y + 28 * ApoMarioConstants.SIZE);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        int row = y + 52 * ApoMarioConstants.SIZE;
        for (int i = 0; i < runs.size() && i < 10; i++) {
            Run r = runs.get(i);
            g.drawString((i + 1) + ". " + r.name, x + 18, row);
            g.drawString(String.valueOf(r.score), x + w - 105, row);
            g.drawString(formatTime(r.time), x + w - 55, row);
            row += 15 * ApoMarioConstants.SIZE;
        }
        if (runs.isEmpty()) g.drawString("No runs recorded", x + 18, row);
        g.setFont(ApoMarioConstants.FONT_FPS);
        g.drawString("Press H or Escape to return", x + 18, y + h - 12);
    }
}