package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = clean(playerName);
        if (name.length() == 0 || survivalTime < 0) return false;
        entries.add(new Entry(score, survivalTime, name)); sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { List<String> r = new ArrayList<String>(); for (Entry e: entries) r.add(e.name); return r; }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r = new ArrayList<Integer>(); for (Entry e: entries) r.add(e.score); return r; }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r = new ArrayList<Integer>(); for (Entry e: entries) r.add(e.time); return r; }
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isHighscoreRecorded() || level.getPlayers() == null) return;
        ApoMarioPlayer p = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) if (candidate != null && candidate.getAi() == null) { p = candidate; break; }
        if (p == null && !level.getPlayers().isEmpty()) p = level.getPlayers().get(0);
        if (p != null && storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), p.getTeamName())) level.setHighscoreRecorded(true);
    }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path tmp = Paths.get(store.toString() + ".tmp");
            List<String> lines = new ArrayList<String>(); lines.add("APOMARIO_HIGHSCORE_1");
            for (Entry e: entries) lines.add(e.score+"\t"+e.time+"\t"+java.util.Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Files.write(tmp, lines, StandardCharsets.UTF_8); Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception ignored) { }
    }
    private void load() {
        try {
            if (store == null || !Files.isRegularFile(store)) return;
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            for (int i=1; i<lines.size() && entries.size()<MAX; i++) { String[] f=lines.get(i).split("\\t",-1); if(f.length!=3) continue;
                try { int s=Integer.parseInt(f[0]), t=Integer.parseInt(f[1]); String n=clean(new String(java.util.Base64.getDecoder().decode(f[2]),StandardCharsets.UTF_8)); if(n.length()>0&&t>=0) entries.add(new Entry(s,t,n)); } catch(Exception ignored) { }
            } sort();
        } catch (Exception ignored) { }
    }
    private synchronized void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score==b.score?0:(a.score>b.score?-1:1); } }); while(entries.size()>MAX) entries.remove(entries.size()-1); }
    private static String clean(String s) { if(s==null)return "Player"; StringBuilder b=new StringBuilder(); for(int i=0;i<s.length()&&b.length()<64;i++) if(!Character.isISOControl(s.charAt(i))) b.append(s.charAt(i)); return b.toString().trim(); }
    public synchronized void render(Graphics2D g, int x, int y, int w, int h) {
        g.setColor(new Color(255,255,255,240)); g.fillRoundRect(x,y,w,h,20,20); g.setColor(Color.BLACK); g.drawRoundRect(x,y,w,h,20,20); g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,18)); g.drawString("HIGHSCORES",x+20,y+30); g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,13));
        for(int i=0;i<entries.size()&&i<12;i++){ Entry e=entries.get(i); int yy=y+55+i*19; g.drawString((i+1)+". "+e.name,x+20,yy); g.drawString(String.valueOf(e.score),x+w-130,yy); long sec=Math.max(0,e.time)/1000L; g.drawString((sec/60)+":"+(sec%60<10?"0":"")+(sec%60),x+w-65,yy); }
    }
}