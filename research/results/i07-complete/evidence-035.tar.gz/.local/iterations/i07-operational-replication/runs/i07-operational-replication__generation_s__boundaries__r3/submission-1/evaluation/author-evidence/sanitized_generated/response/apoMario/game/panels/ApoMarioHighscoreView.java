package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated renderer used by the main menu for the persistent score board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        int w = ApoMarioConstants.GAME_WIDTH - 30 * ApoMarioConstants.SIZE;
        int h = ApoMarioConstants.GAME_HEIGHT - 30 * ApoMarioConstants.SIZE;
        int x = (ApoMarioConstants.GAME_WIDTH - w) / 2;
        int y = (ApoMarioConstants.GAME_HEIGHT - h) / 2;
        g.setColor(new Color(255, 255, 255, 240)); g.fillRoundRect(x, y, w, h, 20, 20);
        g.setColor(Color.BLACK); g.drawRoundRect(x, y, w, h, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", x + 20, y + 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        int limit = Math.min(10, names.size());
        for (int i = 0; i < limit; i++) {
            int ms = times.get(i);
            int seconds = ms / 1000;
            String time = (seconds / 60) + ":" + String.format("%02d", seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), x + 25, y + 70 + i * 18);
            g.drawString(Integer.toString(points.get(i)), x + w - 105, y + 70 + i * 18);
            g.drawString(time, x + w - 55, y + 70 + i * 18);
        }
        g.drawString("ESC / H: back", x + 20, y + h - 15);
    }
}