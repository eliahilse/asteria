package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** The menu's dedicated highscore board view. */
public class ApoMarioHighscoreView {
    private final ApoMarioPanel game;
    public ApoMarioHighscoreView(ApoMarioPanel game) { this.game = game; }
    public void render(Graphics2D g) {
        ApoMarioHighscore h = game.getHighscore();
        List<String> names = h.getPlayersNames();
        List<Integer> scores = h.getPlayersScores();
        List<Integer> times = h.getSurvivalTimes();
        int x = ApoMarioConstants.GAME_WIDTH / 8;
        int y = ApoMarioConstants.GAME_HEIGHT / 8;
        g.setColor(new Color(255,255,255,235));
        g.fillRoundRect(x, y, ApoMarioConstants.GAME_WIDTH * 3 / 4, ApoMarioConstants.GAME_HEIGHT * 3 / 4, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", x + 20, y + 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < names.size() && i < 10; i++) {
            int ms = times.get(i);
            String time = String.format("%02d:%02d", ms / 60000, (ms / 1000) % 60);
            g.drawString((i + 1) + ". " + names.get(i), x + 25, y + 75 + i * 20);
            g.drawString(String.valueOf(scores.get(i)), x + 260, y + 75 + i * 20);
            g.drawString(time, x + 350, y + 75 + i * 20);
        }
        g.drawString("H / ESC: back", x + 20, y + ApoMarioConstants.GAME_HEIGHT * 3 / 4 - 15);
    }
}