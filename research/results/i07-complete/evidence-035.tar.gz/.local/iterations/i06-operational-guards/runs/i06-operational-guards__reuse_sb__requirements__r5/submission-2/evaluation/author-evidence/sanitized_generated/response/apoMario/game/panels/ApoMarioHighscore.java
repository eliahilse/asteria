package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private static final int MAX_FILE_SIZE = 128 * 1024;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim()); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(survivalTime));
        sortAndTrim(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) lines.add(scores.get(i) + "\t" + times.get(i) + "\t" + names.get(i));
            Files.write(temp, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(temp, store, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (Exception e) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception e) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName(); if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(Math.max(0, player.getPoints()), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245, 235)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 18)); g.drawString("HIGHSCORES", width / 2 - 55, 28);
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        for (int i = 0; i < names.size() && i < 10; i++) { int y = 52 + i * 17; g.drawString(String.valueOf(i + 1), 20, y); g.drawString(names.get(i), 48, y); g.drawString(String.valueOf(scores.get(i)), width - 105, y); g.drawString(formatTime(times.get(i)), width - 55, y); }
    }
    private boolean validName(String name) {
        if (name == null) return false; String s = name.trim(); if (s.length() == 0 || s.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false; return true;
    }
    private void sortAndTrim() {
        List<Integer> order = new ArrayList<Integer>(); for (int i = 0; i < scores.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b).compareTo(scores.get(a)); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (int i = 0; i < order.size() && i < MAX_ENTRIES; i++) { int j = order.get(i); n.add(names.get(j)); s.add(scores.get(j)); t.add(times.get(j)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_SIZE) return;
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", 3); if (p.length != 3) continue;
                try { int s = Integer.parseInt(p[0]); int t = Integer.parseInt(p[1]); if (s >= 0 && t >= 0 && validName(p[2])) { names.add(p[2].trim()); scores.add(s); times.add(t); } } catch (Exception e) { }
                if (names.size() >= MAX_ENTRIES) break;
            }
            sortAndTrim();
        } catch (Exception e) { names.clear(); scores.clear(); times.clear(); }
    }
    private String formatTime(int millis) { long seconds = millis / 1000L; return String.format("%02d:%02d", seconds / 60L, seconds % 60L); }
}