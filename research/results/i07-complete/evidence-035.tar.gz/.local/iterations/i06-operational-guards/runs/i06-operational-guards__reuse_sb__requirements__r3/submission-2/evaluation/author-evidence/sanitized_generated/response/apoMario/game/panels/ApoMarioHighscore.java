package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** File-backed, bounded highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private static final int MAX_FILE_LINES = MAX_ENTRIES * 2 + 1;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private boolean recordedLevel;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    /** Starts a fresh gameplay run; terminal recording remains idempotent within it. */
    public synchronized void beginRun() {
        recordedLevel = false;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        entries.add(new Entry(score, survivalTime, playerName.trim()));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    /** Records the final, already-scored player state exactly once for this level run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (recordedLevel || level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible() && (best == null || p.getPoints() > best.getPoints())) best = p;
        }
        if (best == null) {
            for (ApoMarioPlayer p : level.getPlayers()) if (p != null && (best == null || p.getPoints() > best.getPoints())) best = p;
        }
        if (best != null) {
            String name = best.getTeamName();
            if (!validName(name)) name = "Player";
            recordedLevel = true;
            storeRun(best.getPoints(), Math.max(0, level.getPassedTime()), name);
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> r = new ArrayList<String>(); for (Entry e : entries) r.add(e.name); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.score); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.time); return Collections.unmodifiableList(r);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                w.write("APO_MARIO_HIGHSCORE_1"); w.newLine();
                for (Entry e : entries) { w.write(Integer.toString(e.score)); w.write('\t'); w.write(Integer.toString(e.time)); w.write('\t'); w.write(e.name); w.newLine(); }
            } finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* persistence must not stop the game */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line = r.readLine(); if (!"APO_MARIO_HIGHSCORE_1".equals(line)) return;
                int count = 0;
                while (count++ < MAX_FILE_LINES && (line = r.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try { int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]); if (score >= 0 && time >= 0 && validName(p[2])) entries.add(new Entry(score, time, p[2].trim())); } catch (NumberFormatException ex) { }
                }
            } finally { r.close(); }
            Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
            while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        } catch (IOException ex) { entries.clear(); }
    }
    private static boolean validName(String s) {
        if (s == null || s.trim().length() == 0 || s.trim().length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }
    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
}