package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, file-backed highscore board. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024L * 1024L;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String n, int s, int t) { name = n; score = s; time = t; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        entries.add(new Entry(name, score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) out.write(e.score + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " "));
                out.newLine();
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* a highscore must never stop the game */ }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        if (chosen == null) return;
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(255,255,255,235));
        g.fillRoundRect(20, 18, ApoMarioConstants.GAME_WIDTH - 40, ApoMarioConstants.GAME_HEIGHT - 36, 15, 15);
        g.setColor(Color.BLACK); g.drawRoundRect(20, 18, ApoMarioConstants.GAME_WIDTH - 40, ApoMarioConstants.GAME_HEIGHT - 36, 15, 15);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 88, 52);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        for (int i=0; i<entries.size() && i<10; i++) {
            Entry e = entries.get(i); int y = 78 + i * 15;
            g.drawString((i+1)+". "+e.name, 35, y);
            g.drawString(String.valueOf(e.score), 205, y);
            long seconds = ((long)e.time) / 1000L;
            long minutes = seconds / 60L; long secs = seconds % 60L;
            g.drawString(String.format("%02d:%02d", minutes, secs), 260, y);
        }
        g.setFont(ApoMarioConstants.FONT_MENU); g.drawString("ESC / H: back", 92, ApoMarioConstants.GAME_HEIGHT - 25);
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            ArrayList<Entry> loaded = new ArrayList<Entry>();
            try {
                String line; while ((line = in.readLine()) != null && loaded.size() < MAX_RECORDS) {
                    String[] p = line.split("\\t", 3); if (p.length != 3) continue;
                    try { int score=Integer.parseInt(p[0]); int time=Integer.parseInt(p[1]); String n=cleanName(p[2]);
                        if (n.length()>0 && time>=0) loaded.add(new Entry(n,score,time));
                    } catch (NumberFormatException ex) { }
                }
            } finally { in.close(); }
            entries.clear(); entries.addAll(loaded); sortAndLimit();
        } catch (IOException ex) { entries.clear(); }
    }
    private static String cleanName(String value) {
        if (value == null) return "";
        String s = value.replace('\\', ' ').replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s;
    }
    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size()-1);
    }
}