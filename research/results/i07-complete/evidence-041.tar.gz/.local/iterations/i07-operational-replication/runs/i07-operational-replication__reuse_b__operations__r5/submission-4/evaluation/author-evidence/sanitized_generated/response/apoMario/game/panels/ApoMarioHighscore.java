package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.level.ApoMarioLevel;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int MAX_ENTRIES = 1000;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(score, survivalTime, name));
        sort();
        if (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }
    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return Collections.unmodifiableList(result);
    }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(temp));
            out.writeInt(MAGIC); out.writeInt(entries.size());
            for (Entry e : entries) { out.writeInt(e.score); out.writeInt(e.time); out.writeUTF(e.name); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { }
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1048576) return;
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != MAGIC) { in.close(); return; }
            int count = in.readInt(); if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            List<Entry> loaded = new ArrayList<Entry>();
            for (int i = 0; i < count; i++) { int score = in.readInt(); int time = in.readInt(); String name = normalize(in.readUTF()); if (name == null || time < 0) { in.close(); return; } loaded.add(new Entry(score, time, name)); }
            in.close(); entries.addAll(loaded); sort();
        } catch (IOException ex) { entries.clear(); }
    }
    private static String normalize(String value) {
        if (value == null) return null; String result = value.trim();
        if (result.length() == 0 || result.length() > MAX_NAME_LENGTH) return null;
        for (int i = 0; i < result.length(); i++) if (Character.isISOControl(result.charAt(i))) return null;
        return result;
    }
    public void recordRunEnd(apoMario.level.ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    private void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); } }); }
}