package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, bounded and failure-safe highscore table. Times are milliseconds. */
public final class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_BYTES = 128;
    private static final long MAX_FILE_BYTES = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final int score, time;
        final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store");
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null) return false;
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                out.write("APO_MARIO_HIGHSCORE_1"); out.newLine();
                for (Entry e : entries) {
                    out.write(Integer.toString(e.score)); out.write('\t');
                    out.write(Integer.toString(e.time)); out.write('\t');
                    out.write(Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
                    out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { try { Files.deleteIfExists(tmp); } catch (IOException ignored) { } }
    }

    /** Records the final score after ApoMarioLevel has applied terminal scoring. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible() && (chosen == null || p.getPoints() > chosen.getPoints())) chosen = p;
        }
        if (chosen == null && !level.getPlayers().isEmpty()) chosen = level.getPlayers().get(0);
        if (chosen != null) {
            String name = chosen.getTeamName();
            if (name == null || name.trim().length() == 0) name = "Player";
            storeRun(chosen.getPoints(), level.getPassedTime(), name);
        }
    }

    private String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim().replace('\t', ' ').replace('\r', ' ').replace('\n', ' ');
        if (s.length() == 0) return null;
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        if (b.length > MAX_NAME_BYTES) s = new String(b, 0, MAX_NAME_BYTES, StandardCharsets.UTF_8);
        return s;
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) {
            int c = Integer.compare(b.score, a.score); return c != 0 ? c : Integer.compare(a.time, b.time);
        }});
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }
    private synchronized void load() {
        if (!Files.isRegularFile(store)) return;
        if (store.toFile().length() > MAX_FILE_BYTES) return;
        List<Entry> read = new ArrayList<Entry>();
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE_1".equals(in.readLine())) return;
                String line;
                while ((line = in.readLine()) != null) {
                    if (read.size() >= MAX_RECORDS) return;
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3) return;
                    int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]);
                    if (time < 0) return;
                    String name = cleanName(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                    if (name == null) return;
                    read.add(new Entry(score, time, name));
                }
            } finally { in.close(); }
            entries.clear(); entries.addAll(read); sortAndTrim();
        } catch (Exception ignored) { }
    }
}