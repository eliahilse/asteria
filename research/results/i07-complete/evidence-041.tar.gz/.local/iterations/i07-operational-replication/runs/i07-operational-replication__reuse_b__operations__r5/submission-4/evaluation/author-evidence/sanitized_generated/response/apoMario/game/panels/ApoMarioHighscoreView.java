package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore highscore, int width, int height) {
        g.setColor(new Color(245,245,220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28)); g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> names = highscore.getPlayersNames(); List<Integer> scores = highscore.getPlayersScores(); List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 20; i++) { int y = 95 + i * 24; int seconds = times.get(i) / 1000;
            g.drawString(String.valueOf(i + 1), 55, y); g.drawString(names.get(i), 100, y); g.drawString(String.valueOf(scores.get(i)), width / 2, y); g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 105, y);
        }
        g.drawString("H / Escape: back", 20, height - 20);
    }
}