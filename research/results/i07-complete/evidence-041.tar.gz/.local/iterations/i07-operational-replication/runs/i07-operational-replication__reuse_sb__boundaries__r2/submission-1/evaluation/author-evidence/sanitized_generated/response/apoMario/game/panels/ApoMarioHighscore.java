package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Local, file-backed highscore board. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;
    private static final int MAX_NAME_BYTES = 80;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store");
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path absolute = store.toAbsolutePath();
        Path parent = absolute.getParent();
        try {
            if (parent != null) Files.createDirectories(parent);
            Path temp = Files.createTempFile(parent == null ? absolute.getParent() : parent,
                    absolute.getFileName().toString(), ".tmp");
            try {
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
                out.writeInt(MAGIC);
                out.writeInt(VERSION);
                out.writeInt(runs.size());
                for (Run run : runs) {
                    out.writeInt(run.score);
                    out.writeInt(run.time);
                    byte[] bytes = run.name.getBytes(StandardCharsets.UTF_8);
                    out.writeInt(bytes.length);
                    out.write(bytes);
                }
                out.close();
                try {
                    Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException ex) {
                    Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(temp);
            }
        } catch (IOException ex) {
            // A failed write must not damage the in-memory board.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        storeRun(player.getPoints(), level.getPassedTime(), player.getTeamName());
    }

    private void load() {
        synchronized (this) {
            if (!Files.exists(store)) return;
            try {
                if (Files.size(store) > MAX_FILE_SIZE) return;
                DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
                int magic = in.readInt();
                int version = in.readInt();
                int count = in.readInt();
                List<Run> loaded = new ArrayList<Run>();
                if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
                for (int i = 0; i < count; i++) {
                    int score = in.readInt();
                    int time = in.readInt();
                    int length = in.readInt();
                    if (length < 0 || length > MAX_NAME_BYTES) throw new IOException("name");
                    byte[] bytes = new byte[length];
                    in.readFully(bytes);
                    String name = cleanName(new String(bytes, StandardCharsets.UTF_8));
                    if (name.length() == 0) name = "Player";
                    loaded.add(new Run(score, Math.max(0, time), name));
                }
                in.close();
                runs.clear();
                runs.addAll(loaded);
                sortAndTrim();
            } catch (IOException ex) {
                // Ignore malformed or truncated stores; never partially apply them.
            }
        }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) result.append(c);
            if (result.length() >= MAX_NAME_BYTES) break;
        }
        return result.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                return a.score == b.score ? 0 : (a.score > b.score ? -1 : 1);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
}