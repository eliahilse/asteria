package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Local, bounded highscore store. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        entries.add(new Entry(playerName.trim(), score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first human player's finalized result, once called by the live run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || !player.isBVisible()) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path tmp = null;
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            tmp = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) {
                    out.write(Integer.toString(e.score));
                    out.write('\t');
                    out.write(Integer.toString(e.time));
                    out.write('\t');
                    out.write(e.name);
                    out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, absolute, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* persistence must never stop a run */ }
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store.toAbsolutePath(), StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while (count < MAX_ENTRIES && (line = in.readLine()) != null) {
                    count++;
                    String[] p = line.split("\\t", 3); if (p.length != 3) continue;
                    try { int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]); if (score >= 0 && time >= 0 && validName(p[2])) entries.add(new Entry(p[2].trim(), score, time)); } catch (NumberFormatException ex) { }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ex) { entries.clear(); }
    }

    /** Small renderer used by the menu's dedicated highscore view. */
    public synchronized void render(Graphics2D g, int x, int y, int rowHeight) {
        g.drawString("HIGHSCORES", x, y);
        for (int i = 0; i < entries.size() && i < 12; i++) {
            Entry e = entries.get(i); int seconds = e.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + e.name + "  " + e.score + "  " + time, x, y + (i + 1) * rowHeight);
        }
    }
}