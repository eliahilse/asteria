package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim()); scores.add(Integer.valueOf(score)); survivalTimes.add(Integer.valueOf(survivalTime));
        sortAndLimit(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path parent = store.toAbsolutePath().getParent(); Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, "apomario-highscore", ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                out.write("APOMARIO-HIGHSCORE-1"); out.newLine();
                for (int i = 0; i < scores.size(); i++) { out.write(scores.get(i).toString()); out.write('\t'); out.write(survivalTimes.get(i).toString()); out.write('\t'); out.write(names.get(i)); out.newLine(); }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { } }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName(); if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245,245,220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24)); g.drawString("HIGHSCORES", 20, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < scores.size() && i < 15; i++) {
            int seconds = survivalTimes.get(i).intValue() / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            int y = 70 + i * 25; g.drawString((i + 1) + ". " + names.get(i), 25, y); g.drawString(String.valueOf(scores.get(i)), width / 2, y); g.drawString(time, width - 90, y);
        }
        g.drawString("ESC / H: back", 20, height - 15);
    }

    private boolean validName(String name) {
        if (name == null || name.trim().length() == 0 || name.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return false;
        return true;
    }
    private void sortAndLimit() {
        List<Integer> order = new ArrayList<Integer>(); for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b.intValue()).intValue() < scores.get(a.intValue()).intValue() ? -1 : (scores.get(b.intValue()).intValue() == scores.get(a.intValue()).intValue() ? 0 : 1); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (int i = 0; i < order.size() && i < MAX_ENTRIES; i++) { int x = order.get(i).intValue(); n.add(names.get(x)); s.add(scores.get(x)); t.add(survivalTimes.get(x)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APOMARIO-HIGHSCORE-1".equals(in.readLine())) return;
                String line; int count = 0;
                while (count++ < MAX_ENTRIES && (line = in.readLine()) != null) {
                    String[] fields = line.split("\\t", 3); if (fields.length != 3) continue;
                    try { int score = Integer.parseInt(fields[0]); int time = Integer.parseInt(fields[1]); if (score >= 0 && time >= 0 && validName(fields[2])) { scores.add(Integer.valueOf(score)); survivalTimes.add(Integer.valueOf(time)); names.add(fields[2]); } } catch (RuntimeException ignored) { }
                }
            } finally { in.close(); }
            sortAndLimit();
        } catch (IOException ignored) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }
}