package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu's highscore screen. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore board, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(20, 20, width - 40, height - 40, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(20, 20, width - 40, height - 40, 18, 18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 65, 55);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        List<String> names = board.getPlayersNames();
        List<Integer> scores = board.getPlayersScores();
        List<Integer> times = board.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 82 + i * 15;
            g.drawString(String.valueOf(i + 1), 38, y);
            g.drawString(names.get(i), 65, y);
            g.drawString(String.valueOf(scores.get(i)), width - 125, y);
            long seconds = Math.max(0L, times.get(i).longValue()) / 1000L;
            long minutes = seconds / 60L;
            g.drawString(String.format("%02d:%02d", minutes, seconds % 60L), width - 70, y);
        }
        g.drawString("H or ESC: back", 35, height - 32);
    }
}