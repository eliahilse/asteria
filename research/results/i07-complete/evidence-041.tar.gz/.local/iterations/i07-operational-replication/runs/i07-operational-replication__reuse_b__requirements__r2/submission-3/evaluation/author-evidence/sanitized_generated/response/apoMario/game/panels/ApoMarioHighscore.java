package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private static final long MAX_FILE_SIZE = 65536L;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim()); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(survivalTime)); sortAndTrim(); persistAcrossRuns(); return true;
    }
    private boolean validName(String value) {
        if (value == null) return false; String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return false;
        return true;
    }
    private void sortAndTrim() {
        List<Integer> order = new ArrayList<Integer>(); for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b).compareTo(scores.get(a)); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (int j = 0; j < order.size() && j < MAX_ENTRIES; j++) { int i = order.get(j).intValue(); n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try { for (int i = 0; i < names.size(); i++) { w.write(scores.get(i).toString()); w.write('\t'); w.write(times.get(i).toString()); w.write('\t'); w.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8))); w.newLine(); } } finally { w.close(); }
            Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) { }
    }
    private void load() {
        if (store == null) return;
        try {
            if (!Files.isRegularFile(store) || Files.size(store) > MAX_FILE_SIZE) return;
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try { String line; while (names.size() < MAX_ENTRIES && (line = r.readLine()) != null) { String[] p = line.split("\\t", -1); if (p.length != 3) continue; try { int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]); String name = new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8); if (score >= 0 && time >= 0 && validName(name)) { names.add(name); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(time)); } } catch (RuntimeException ex) { } } } finally { r.close(); }
            sortAndTrim();
        } catch (IOException ex) { names.clear(); scores.clear(); times.clear(); }
    }
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0); String name = player.getTeamName(); if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height); g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28)); g.drawString("Highscore", 30, 45); g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < names.size() && i < 15; i++) { int y = 80 + i * 25; int seconds = times.get(i).intValue() / 1000; g.drawString((i + 1) + "  " + names.get(i) + "  " + scores.get(i) + "  " + String.format("%02d:%02d", seconds / 60, seconds % 60), 35, y); }
        g.drawString("ESC: back", 30, height - 20);
    }
}