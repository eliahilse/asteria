package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;
public final class ApoMarioHighscoreView {
 private ApoMarioHighscoreView(){}
 public static void render(Graphics2D g,ApoMarioHighscore h,int width){
  g.setColor(new Color(255,255,255,240));g.fillRoundRect(30,20,width-60,440,20,20);g.setColor(Color.BLACK);g.drawRoundRect(30,20,width-60,440,20,20);g.setFont(new Font("Dialog",Font.BOLD,24));g.drawString("HIGHSCORES",width/2-75,58);g.setFont(new Font("Dialog",Font.PLAIN,16));List<String> n=h.getPlayersNames();List<Integer>s=h.getPlayersScores();List<Integer>t=h.getSurvivalTimes();int rows=Math.min(15,n.size());for(int i=0;i<rows;i++){String name=n.get(i);if(name.length()>22)name=name.substring(0,22);int sec=t.get(i)/1000;g.drawString((i+1)+". "+name,55,95+i*22);g.drawString(String.valueOf(s.get(i)),width-180,95+i*22);g.drawString(String.format("%02d:%02d",sec/60,sec%60),width-105,95+i*22);}if(rows==0)g.drawString("No runs recorded yet",width/2-70,110);g.drawString("H / Escape: back to menu",55,435);
 }
}