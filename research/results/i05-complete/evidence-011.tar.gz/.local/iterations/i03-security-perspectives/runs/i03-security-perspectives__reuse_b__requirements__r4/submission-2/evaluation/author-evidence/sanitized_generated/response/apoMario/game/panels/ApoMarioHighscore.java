package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES=1000, MAX_NAME=32;
    private final Path store;
    private final List<Run> runs=new ArrayList<Run>();
    private static final class Run { String name; int score,time; long order; Run(String n,int s,int t,long o){name=n;score=s;time=t;order=o;} }
    public ApoMarioHighscore(Path store){this.store=store;load();}
    public synchronized boolean storeRun(int score,int survivalTime,String playerName){
        if(score<0||survivalTime<0||playerName==null||playerName.trim().length()==0||playerName.length()>MAX_NAME)return false;
        for(int i=0;i<playerName.length();i++)if(Character.isISOControl(playerName.charAt(i))||Character.isSurrogate(playerName.charAt(i)))return false;
        runs.add(new Run(playerName.trim(),score,survivalTime,System.nanoTime())); sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames(){List<String> r=new ArrayList<String>();for(Run x:runs)r.add(x.name);return Collections.unmodifiableList(r);}
    public synchronized List<Integer> getPlayersScores(){List<Integer> r=new ArrayList<Integer>();for(Run x:runs)r.add(x.score);return Collections.unmodifiableList(r);}
    public synchronized List<Integer> getSurvivalTimes(){List<Integer> r=new ArrayList<Integer>();for(Run x:runs)r.add(x.time);return Collections.unmodifiableList(r);}
    public synchronized void recordRunEnd(ApoMarioLevel level){
        if(level==null||level.getPlayers()==null||level.getPlayers().isEmpty())return;
        ApoMarioPlayer p=level.getPlayers().get(0); if(p==null)return;
        String n=p.getTeamName(); if(n==null||n.trim().length()==0)n="Player";
        storeRun(p.getPoints(),Math.max(0,level.getPassedTime()),n);
    }
    public synchronized void persistAcrossRuns(){
        if(store==null)return;
        try{Path parent=store.toAbsolutePath().getParent();if(parent!=null)Files.createDirectories(parent);Path tmp=store.resolveSibling(store.getFileName().toString()+".tmp");List<String> l=new ArrayList<String>();l.add("APO_MARIO_HIGHSCORE 1");for(Run r:runs)l.add(r.score+"\t"+r.time+"\t"+r.name);Files.write(tmp,l,StandardCharsets.UTF_8);try{Files.move(tmp,store,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,store,StandardCopyOption.REPLACE_EXISTING);}}catch(IOException e){}
    }
    private synchronized void load(){
        if(store==null||!Files.isRegularFile(store))return;try{List<String> l=Files.readAllLines(store,StandardCharsets.UTF_8);if(l.size()<1||l.size()>MAX_ENTRIES+1||!"APO_MARIO_HIGHSCORE 1".equals(l.get(0)))return;List<Run> v=new ArrayList<Run>();for(int i=1;i<l.size();i++){String[] a=l.get(i).split("\\t",3);if(a.length!=3)return;int s=Integer.parseInt(a[0]),t=Integer.parseInt(a[1]);if(s<0||t<0||a[2].trim().length()==0||a[2].length()>MAX_NAME)return;for(int j=0;j<a[2].length();j++)if(Character.isISOControl(a[2].charAt(j))||Character.isSurrogate(a[2].charAt(j)))return;v.add(new Run(a[2].trim(),s,t,i));}runs.clear();runs.addAll(v);sort();}catch(Exception e){}
    }
    private void sort(){Collections.sort(runs,new Comparator<Run>(){public int compare(Run a,Run b){int c=b.score-a.score;if(c!=0)return c;return a.order<b.order?-1:a.order==b.order?0:1;}});while(runs.size()>MAX_ENTRIES)runs.remove(runs.size()-1);}
}