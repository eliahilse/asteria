package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local high-score table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 1000;
    private static final int MAX_NAME = 40;
    private static final String HEADER = "APO_MARIO_HIGHSCORE 1";

    private static final class Run {
        final String name; final int score; final int time; final long order;
        Run(String name, int score, int time, long order) { this.name=name; this.score=score; this.time=time; this.order=order; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private long sequence;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || playerName == null || playerName.trim().length() == 0
                || playerName.length() > MAX_NAME) return false;
        for (int i=0; i<playerName.length(); i++) {
            char c=playerName.charAt(i);
            if (Character.isISOControl(c) || Character.isSurrogate(c)) return false;
        }
        runs.add(new Run(playerName.trim(), score, survivalTime, sequence++));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> r=new ArrayList<String>(); for (Run x:runs) r.add(x.name); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> r=new ArrayList<Integer>(); for (Run x:runs) r.add(x.score); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> r=new ArrayList<Integer>(); for (Run x:runs) r.add(x.time); return Collections.unmodifiableList(r);
    }

    /** Writes a complete snapshot, leaving the previous file intact on failure. */
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent=store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp=store.resolveSibling(store.getFileName().toString()+".tmp");
            BufferedWriter w=Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                w.write(HEADER); w.newLine();
                for (Run x:runs) { w.write(Integer.toString(x.score)); w.write('\t'); w.write(Integer.toString(x.time)); w.write('\t'); w.write(x.name); w.newLine(); }
            } finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { /* scores remain valid in memory */ }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p=level.getPlayers().get(0);
        String name=p.getTeamName();
        if (name == null || name.trim().length() == 0) name="Player";
        storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(new Font("Dialog", Font.BOLD, 14));
        int rows=Math.min(18, runs.size());
        for (int i=0;i<rows;i++) {
            Run x=runs.get(i); int y=75+i*24;
            g.drawString((i+1)+".", 35, y);
            g.drawString(x.name.length()>24 ? x.name.substring(0,24) : x.name, 75, y);
            g.drawString(Integer.toString(x.score), 300, y);
            g.drawString(formatTime(x.time), 410, y);
        }
        if (rows == 0) g.drawString("No runs recorded", 75, 85);
        g.drawString("Press ESC to return", 30, ApoMarioConstants.GAME_HEIGHT-20);
    }

    public static String formatTime(int millis) {
        long seconds=Math.max(0, millis)/1000L;
        return String.format("%02d:%02d", seconds/60L, seconds%60L);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r=Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!HEADER.equals(r.readLine())) return;
                String line; int count=0;
                while ((line=r.readLine()) != null && count++ < MAX_ENTRIES) {
                    int a=line.indexOf('\t'), b=a<0 ? -1 : line.indexOf('\t',a+1);
                    if (a<=0 || b<=a+1 || b+1>=line.length()) continue;
                    try { int score=Integer.parseInt(line.substring(0,a)); int time=Integer.parseInt(line.substring(a+1,b));
                        String name=line.substring(b+1); if (score>=0 && time>=0 && name.length()>0 && name.length()<=MAX_NAME) runs.add(new Run(name,score,time,sequence++));
                    } catch (NumberFormatException e) { }
                }
            } finally { r.close(); }
            sortAndTrim();
        } catch (IOException e) { runs.clear(); }
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { int c=Integer.compare(b.score,a.score); return c!=0?c:Long.compare(a.order,b.order); } });
        while (runs.size()>MAX_ENTRIES) runs.remove(runs.size()-1);
    }
}