package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 32;
    private static final int MAX_TIME = 7 * 24 * 60 * 60 * 1000;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private long sequence;

    private static final class Entry {
        final String name; final int score; final int time; final long order;
        Entry(String n, int s, int t, long o) { name=n; score=s; time=t; order=o; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (!valid(score, survivalTime, playerName)) return false;
        entries.add(new Entry(playerName.trim(), score, survivalTime, sequence++));
        sort();
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = null;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                writer.write("APOMARIO_HIGHSCORE 1"); writer.newLine();
                for (Entry e : entries) {
                    writer.write(e.score + "\t" + e.time + "\t" + Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { } }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) persistAcrossRuns();
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245,245,220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.drawString("HIGHSCORES", width / 2 - 50, 35);
        int rows = Math.min(entries.size(), Math.max(0, (height - 70) / 24));
        for (int i=0; i<rows; i++) {
            Entry e=entries.get(i); int y=70+i*24; int seconds=e.time/1000;
            g.drawString((i+1)+".", 25, y); g.drawString(e.name, 65, y);
            g.drawString(Integer.toString(e.score), width-170, y);
            g.drawString(String.format("%02d:%02d", seconds/60, seconds%60), width-85, y);
        }
        g.drawString("ESC: back", 20, height-15);
    }

    private boolean valid(int score, int time, String name) {
        if (score < 0 || time < 0 || time > MAX_TIME || name == null) return false;
        String value=name.trim(); if (value.length()==0 || value.length()>MAX_NAME) return false;
        for (int i=0;i<value.length();i++) if (Character.isISOControl(value.charAt(i))) return false;
        return true;
    }
    private void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { if (a.score != b.score) return b.score-a.score; return a.order < b.order ? -1 : (a.order == b.order ? 0 : 1); } }); }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        List<Entry> loaded=new ArrayList<Entry>();
        try {
            BufferedReader reader=Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APOMARIO_HIGHSCORE 1".equals(reader.readLine())) return;
                String line; int count=0;
                while ((line=reader.readLine()) != null && count++ < MAX_ENTRIES) {
                    String[] parts=line.split("\\t", -1); if (parts.length != 3) continue;
                    try { int score=Integer.parseInt(parts[0]); int time=Integer.parseInt(parts[1]); String name=new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8); if (valid(score,time,name)) loaded.add(new Entry(name,score,time,sequence++)); } catch (RuntimeException ignored) { }
                }
            } finally { reader.close(); }
        } catch (IOException ignored) { return; }
        entries.clear(); entries.addAll(loaded); sort();
    }
}