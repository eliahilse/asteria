package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, points-ordered highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 20;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name;
        int score;
        int time;
        Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Records the first (human) player when a real level run ends. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try { entries.add(new Entry(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]))); }
                catch (NumberFormatException ignored) { }
            }
            Collections.sort(entries, new Comparator<Entry>() {
                public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
            });
            while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8)) {
                for (Entry e : entries) {
                    writer.write(e.name.replace('\t', ' '));
                    writer.write('\t'); writer.write(Integer.toString(e.score));
                    writer.write('\t'); writer.write(Integer.toString(e.time));
                    writer.newLine();
                }
            }
            return true;
        } catch (IOException ignored) { return false; }
    }
}