package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** Dedicated menu view for the persistent highscore table. */
public final class ApoMarioHighscorePanel {
    private final ApoMarioHighscore scores;
    public ApoMarioHighscorePanel(ApoMarioHighscore scores) { this.scores = scores; }
    public void render(Graphics2D g) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 18, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 30, 45);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        int y = 70;
        for (int i = 0; i < names.size() && i < 12; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 38, y);
            g.drawString(String.valueOf(points.get(i)), 205, y);
            g.drawString(time, 265, y); y += 14;
        }
        g.drawString("H or ESC: back", 38, ApoMarioConstants.GAME_HEIGHT - 18);
    }
}