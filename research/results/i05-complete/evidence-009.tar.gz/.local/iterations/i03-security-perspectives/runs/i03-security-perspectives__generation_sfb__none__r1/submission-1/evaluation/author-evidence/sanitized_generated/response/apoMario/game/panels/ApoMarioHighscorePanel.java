package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated renderer for the persistent highscore board. */
public final class ApoMarioHighscorePanel {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscorePanel(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g) {
        g.setColor(new Color(255, 255, 255, 220));
        g.fillRoundRect(35, 25, ApoMarioConstants.GAME_WIDTH - 70, ApoMarioConstants.GAME_HEIGHT - 50, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(35, 25, ApoMarioConstants.GAME_WIDTH - 70, ApoMarioConstants.GAME_HEIGHT - 50, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 85, 58);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            int y = 85 + i * 18;
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 55, y);
            g.drawString(Integer.toString(scores.get(i)), 205, y);
            g.drawString(time, 260, y);
        }
        g.drawString("ESC / H: back", 55, ApoMarioConstants.GAME_HEIGHT - 35);
    }
}