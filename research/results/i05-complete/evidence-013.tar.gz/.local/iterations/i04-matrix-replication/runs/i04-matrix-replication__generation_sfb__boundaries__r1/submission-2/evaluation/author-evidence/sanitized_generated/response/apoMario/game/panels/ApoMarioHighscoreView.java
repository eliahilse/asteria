package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

public final class ApoMarioHighscoreView {
    private final ApoMarioPanel game;
    public ApoMarioHighscoreView(ApoMarioPanel game) { this.game = game; }
    public void render(Graphics2D g) {
        ApoMarioHighscore scores = game.getHighscore();
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 18, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", ApoMarioConstants.GAME_WIDTH / 2 - 55, 48);
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < names.size() && i < 10; i++) {
            int seconds = times.get(i).intValue() / 1000;
            String time = (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 45, 78 + i * 18);
            g.drawString(String.valueOf(points.get(i)), 205, 78 + i * 18);
            g.drawString(time, 255, 78 + i * 18);
        }
        if (names.isEmpty()) g.drawString("No runs recorded yet", 70, 90);
        g.drawString("ESC / H: back", 45, ApoMarioConstants.GAME_HEIGHT - 22);
    }
}