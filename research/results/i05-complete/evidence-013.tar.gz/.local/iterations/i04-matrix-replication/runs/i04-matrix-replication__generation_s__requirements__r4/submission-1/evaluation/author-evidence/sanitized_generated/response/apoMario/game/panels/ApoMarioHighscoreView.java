package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer for the highscore board shown from the main menu. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore scores, int width) {
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, 18, width * 3 / 4, 204, 16, 16);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, 18, width * 3 / 4, 204, 16, 16);
        g.drawString("HIGHSCORES  (H or ESC to return)", width / 4, 45);
        for (int i = 0; i < names.size() && i < 8; i++) {
            int millis = times.get(i);
            int seconds = millis / 1000;
            String time = String.format("%d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), width / 5, 70 + i * 18);
            g.drawString(String.valueOf(points.get(i)), width / 2, 70 + i * 18);
            g.drawString(time, width * 3 / 5, 70 + i * 18);
        }
        if (names.isEmpty()) g.drawString("No runs recorded yet.", width / 3, 85);
    }
}