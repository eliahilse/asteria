package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent highscore table. Survival times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", 3);
                if (p.length == 3) {
                    try { runs.add(new Run(Integer.parseInt(p[0]), Integer.parseInt(p[1]), p[2])); }
                    catch (NumberFormatException ignored) { }
                }
            }
            reader.close();
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            for (Run run : runs) {
                writer.write(run.score + "\t" + run.time + "\t" + run.name.replace('\t', ' '));
                writer.newLine();
            }
            writer.close();
            return true;
        } catch (IOException ignored) { return false; }
    }
}