package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small rendering helper used by the menu's dedicated highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores, int x, int y) {
        g.setColor(Color.BLACK);
        g.drawString("HIGHSCORES", x, y);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 10; i++) {
            int seconds = times.get(i).intValue() / 1000;
            String time = (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i) + "  " + points.get(i) + "  " + time, x, y + 18 * (i + 1));
        }
    }
}