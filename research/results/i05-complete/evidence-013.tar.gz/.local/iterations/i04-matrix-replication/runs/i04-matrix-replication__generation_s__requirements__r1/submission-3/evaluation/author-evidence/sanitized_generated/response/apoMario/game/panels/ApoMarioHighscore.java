package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_BYTES = 96;
    private static class Run { String name; int score; int time; Run(String n,int s,int t){name=n;score=s;time=t;} }
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) { this.store=store; load(); }
    public synchronized boolean storeRun(int score,int survivalTime,String playerName) {
        String name=clean(playerName);
        if(name==null || survivalTime<0) return false;
        runs.add(new Run(name,score,survivalTime)); sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames(){ List<String> r=new ArrayList<String>(); for(Run x:runs)r.add(x.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores(){ List<Integer> r=new ArrayList<Integer>(); for(Run x:runs)r.add(x.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes(){ List<Integer> r=new ArrayList<Integer>(); for(Run x:runs)r.add(x.time); return Collections.unmodifiableList(r); }
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if(level==null || level.getPlayers()==null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p=level.getPlayers().get(0);
        if(p==null || !p.isBVisible()) return;
        String name=p.getTeamName(); if(name==null || name.trim().length()==0) name="Player";
        storeRun(p.getPoints(),Math.max(0,level.getPassedTime()),name);
    }
    public synchronized void persistAcrossRuns() {
        if(store==null)return;
        try {
            Path parent=store.toAbsolutePath().getParent(); if(parent!=null)Files.createDirectories(parent);
            Path tmp=store.resolveSibling(store.getFileName().toString()+".tmp");
            DataOutputStream out=new DataOutputStream(Files.newOutputStream(tmp)); out.writeInt(MAGIC);out.writeInt(VERSION);out.writeInt(runs.size());
            for(Run x:runs){byte[] b=x.name.getBytes(StandardCharsets.UTF_8);out.writeInt(x.score);out.writeInt(x.time);out.writeInt(b.length);out.write(b);} out.close();
            try{Files.move(tmp,store,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(IOException e){Files.move(tmp,store,StandardCopyOption.REPLACE_EXISTING);}
        }catch(IOException e){}
    }
    private void load(){
        if(store==null || !Files.isRegularFile(store))return;
        try{DataInputStream in=new DataInputStream(Files.newInputStream(store));if(in.readInt()!=MAGIC||in.readInt()!=VERSION){in.close();return;}int n=in.readInt();if(n<0||n>MAX_ENTRIES){in.close();return;}for(int i=0;i<n;i++){int s=in.readInt(),t=in.readInt(),l=in.readInt();if(l<1||l>MAX_NAME_BYTES)break;byte[] b=new byte[l];in.readFully(b);String name=clean(new String(b,StandardCharsets.UTF_8));if(name!=null&&t>=0)runs.add(new Run(name,s,t));}in.close();sort();}catch(EOFException e){}catch(IOException e){}
    }
    private static String clean(String s){if(s==null)return null;s=s.trim();if(s.length()==0||s.length()>48||s.getBytes(StandardCharsets.UTF_8).length>MAX_NAME_BYTES)return null;for(int i=0;i<s.length();i++)if(Character.isISOControl(s.charAt(i)))return null;return s;}
    private void sort(){Collections.sort(runs,new Comparator<Run>(){public int compare(Run a,Run b){return a.score==b.score?0:(a.score>b.score?-1:1);}});while(runs.size()>MAX_ENTRIES)runs.remove(runs.size()-1);}
}