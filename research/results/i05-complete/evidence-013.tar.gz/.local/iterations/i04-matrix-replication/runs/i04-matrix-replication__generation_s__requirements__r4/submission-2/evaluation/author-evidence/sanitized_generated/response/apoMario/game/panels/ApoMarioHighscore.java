package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered results from completed runs. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private final Set<ApoMarioLevel> recordedLevels =
            Collections.newSetFromMap(new IdentityHashMap<ApoMarioLevel, Boolean>());

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name == null || survivalTime < 0) {
            return false;
        }
        runs.add(new Run(score, survivalTime, name));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                return a.score == b.score ? 0 : (a.score > b.score ? -1 : 1);
            }
        });
        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    /** Starts a new run for a level instance. */
    public synchronized void clearRun(ApoMarioLevel level) {
        if (level != null) recordedLevels.remove(level);
    }

    /** Records the first real player after the level has applied its final score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level) || level.isBReplay()
                || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || !player.isBVisible() && player.getPoints() == 0) {
            return;
        }
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        int time = level.getPassedTime();
        if (time < 0) {
            time = 0;
        }
        recordedLevels.add(level);
        storeRun(player.getPoints(), time, name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    /** Survival times are milliseconds; formatting belongs to the view. */
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Run run : runs) {
                lines.add(run.score + "\t" + run.time + "\t"
                        + Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A read-only store must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            for (String line : lines) {
                if (runs.size() >= MAX_ENTRIES) break;
                String[] parts = line.split("\\t", -1);
                if (parts.length != 3) continue;
                try {
                    int score = Integer.parseInt(parts[0]);
                    int time = Integer.parseInt(parts[1]);
                    if (time < 0) continue;
                    String name = normalizeName(new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8));
                    if (name != null) runs.add(new Run(score, time, name));
                } catch (RuntimeException ex) {
                    // Ignore malformed records.
                }
            }
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score > b.score ? -1 : 1); }
            });
        } catch (IOException ex) {
            // Missing or malformed storage is treated as an empty board.
        }
    }

    private static String normalizeName(String value) {
        if (value == null) return null;
        String name = value.replaceAll("[\\p{Cntrl}]", "").trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return null;
        return name;
    }
}