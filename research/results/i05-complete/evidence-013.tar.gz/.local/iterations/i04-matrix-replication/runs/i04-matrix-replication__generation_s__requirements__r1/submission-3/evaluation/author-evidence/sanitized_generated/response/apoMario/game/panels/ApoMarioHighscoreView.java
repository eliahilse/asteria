package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255,255,255,235));
        g.fillRoundRect(18,18,ApoMarioConstants.GAME_WIDTH-36,ApoMarioConstants.GAME_HEIGHT-36,18,18);
        g.setColor(Color.BLACK); g.drawRoundRect(18,18,ApoMarioConstants.GAME_WIDTH-36,ApoMarioConstants.GAME_HEIGHT-36,18,18);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES",30,48);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> n=scores.getPlayersNames(); List<Integer> p=scores.getPlayersScores(); List<Integer> t=scores.getSurvivalTimes();
        for(int i=0;i<n.size()&&i<10;i++){int sec=t.get(i)/1000;g.drawString((i+1)+". "+n.get(i),35,78+i*18);g.drawString(String.valueOf(p.get(i)),205,78+i*18);g.drawString(String.format("%02d:%02d",sec/60,sec%60),260,78+i*18);}
        if(n.isEmpty())g.drawString("No runs recorded",35,82);
        g.drawString("H / Escape: back",35,ApoMarioConstants.GAME_HEIGHT-28);
    }
}