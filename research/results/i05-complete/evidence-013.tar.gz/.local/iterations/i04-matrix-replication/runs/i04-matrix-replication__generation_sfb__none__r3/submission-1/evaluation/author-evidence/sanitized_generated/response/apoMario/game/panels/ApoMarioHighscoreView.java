package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores, int width) {
        g.setColor(Color.WHITE);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 18));
        g.drawString("HIGHSCORES", width / 2 - 65, 35);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 12));
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 35, 65 + i * 16);
            g.drawString(String.valueOf(points.get(i)), width / 2, 65 + i * 16);
            g.drawString(time, width - 65, 65 + i * 16);
        }
        g.drawString("Press H or Escape to return", 35, 225);
    }
}