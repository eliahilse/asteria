package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated renderer for the menu highscore board. */
public class ApoMarioHighscoreView {
    public void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 45, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 45, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 70, 55);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        if (names.isEmpty()) g.drawString("No runs recorded yet", 70, 90);
        for (int i = 0; i < names.size() && i < 12; i++) {
            int y = 88 + i * 16;
            g.drawString((i + 1) + ".", 45, y);
            g.drawString(names.get(i), 70, y);
            g.drawString(String.valueOf(points.get(i)), 205, y);
            g.drawString(formatTime(times.get(i)), 260, y);
        }
        g.setFont(ApoMarioConstants.FONT_FPS);
        g.drawString("H/Esc: back", 70, ApoMarioConstants.GAME_HEIGHT - 35);
    }

    private String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }
}