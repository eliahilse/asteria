package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscoreView {
    private final ApoMarioPanel game;
    public ApoMarioHighscoreView(ApoMarioPanel game) { this.game = game; }
    public void render(Graphics2D g) {
        List<String> names = game.getHighscore().getPlayersNames();
        List<Integer> scores = game.getHighscore().getPlayersScores();
        List<Integer> times = game.getHighscore().getSurvivalTimes();
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 18, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(25, 18, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setFont(ApoMarioConstants.FONT_MENU); g.drawString("HIGHSCORES", 95, 45);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        int y = 70;
        for (int i = 0; i < names.size() && i < 10; i++) {
            int seconds = Math.max(0, times.get(i) / 1000);
            String elapsed = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 45, y);
            g.drawString(Integer.toString(scores.get(i)), 190, y);
            g.drawString(elapsed, 250, y); y += 16;
        }
        if (names.isEmpty()) g.drawString("No runs recorded", 75, 80);
        g.setFont(ApoMarioConstants.FONT_FPS); g.drawString("Press H or ESC to return", 85, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}