package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, score-ordered run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final String SEPARATOR = "\t";
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final String name;
        private final int score;
        private final int survivalTime;
        private Entry(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || playerName.trim().length() == 0) {
            return false;
        }
        String name = playerName.trim().replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
        if (survivalTime < 0) {
            survivalTime = 0;
        }
        entries.add(new Entry(name, score, survivalTime));
        sort();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.survivalTime);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE);
            try {
                for (Entry entry : entries) {
                    writer.write(entry.name);
                    writer.write(SEPARATOR);
                    writer.write(Integer.toString(entry.score));
                    writer.write(SEPARATOR);
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
        } catch (IOException ex) {
            // A highscore must never stop the game when its backing store is unavailable.
        }
    }

    private synchronized void load() {
        if (!Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(SEPARATOR, -1);
                    if (parts.length != 3) continue;
                    try {
                        if (parts[0].trim().length() > 0) {
                            entries.add(new Entry(parts[0], Integer.parseInt(parts[1]), Integer.parseInt(parts[2])));
                        }
                    } catch (NumberFormatException ex) {
                        // Ignore damaged records and keep the remaining board usable.
                    }
                }
            } finally {
                reader.close();
            }
            sort();
        } catch (IOException ex) {
            // Treat an unreadable store as an empty board.
        }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
    }

    /** Records the primary player's completed run using the live level values. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
        persistAcrossRuns();
    }
}