package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** Dedicated renderer for the menu highscore page. */
public class ApoMarioHighscoreView {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g) {
        g.setColor(new Color(255,255,255,225));
        g.fillRoundRect(30, 18, ApoMarioConstants.GAME_WIDTH - 60, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 42, 48);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        int rows = Math.min(names.size(), 10);
        for (int i=0; i<rows; i++) {
            int y = 75 + i * 16;
            int ms = Math.max(0, times.get(i));
            int sec = ms / 1000;
            String time = (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60);
            g.drawString((i+1)+". "+names.get(i), 48, y);
            g.drawString(Integer.toString(scores.get(i)), 190, y);
            g.drawString(time, 255, y);
        }
        if (rows == 0) g.drawString("No runs recorded yet", 48, 80);
        g.drawString("Press ESC to return", 48, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}