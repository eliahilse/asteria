package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.drawString("HIGHSCORES (H to return)", width / 4, height / 7);
        List<String> n = scores.getPlayersNames();
        List<Integer> p = scores.getPlayersScores();
        List<Integer> t = scores.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 12; i++) {
            int seconds = t.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + n.get(i), width / 5, height / 5 + i * 18);
            g.drawString(Integer.toString(p.get(i)), width * 3 / 5, height / 5 + i * 18);
            g.drawString(time, width * 7 / 10, height / 5 + i * 18);
        }
    }
}