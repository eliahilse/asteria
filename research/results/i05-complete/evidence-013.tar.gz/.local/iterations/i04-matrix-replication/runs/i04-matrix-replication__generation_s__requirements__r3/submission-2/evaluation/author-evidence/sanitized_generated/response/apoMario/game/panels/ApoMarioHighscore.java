package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name;
        int score;
        int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || survivalTime < 0) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(Integer.valueOf(e.score));
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(Integer.valueOf(e.time));
        return Collections.unmodifiableList(result);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) { selected = player; break; }
        }
        if (selected == null) return;
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        storeRun(selected.getPoints(), elapsed < 0 ? 0 : elapsed, name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = null;
        try {
            Path absolute = store.toAbsolutePath();
            if (absolute.getParent() != null) Files.createDirectories(absolute.getParent());
            temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(temporary));
            out.writeInt(MAGIC);
            out.writeInt(entries.size());
            for (Entry e : entries) { out.writeUTF(e.name); out.writeInt(e.score); out.writeInt(e.time); }
            out.close();
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != MAGIC) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = in.readUTF();
                int score = in.readInt();
                int time = in.readInt();
                if (name.length() > 0 && name.length() <= MAX_NAME_LENGTH && time >= 0) entries.add(new Entry(name, score, time));
            }
            in.close();
            sortAndTrim();
        } catch (IOException ex) { entries.clear(); }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) { return first.score == second.score ? 0 : (first.score < second.score ? 1 : -1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    public synchronized void render(Graphics2D g) {
        int x = 18 * ApoMarioConstants.SIZE;
        int y = 25 * ApoMarioConstants.SIZE;
        int width = ApoMarioConstants.GAME_WIDTH - 36 * ApoMarioConstants.SIZE;
        int height = ApoMarioConstants.GAME_HEIGHT - 45 * ApoMarioConstants.SIZE;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", x + 15, y + 25);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12 * ApoMarioConstants.SIZE));
        g.drawString("NAME", x + 18, y + 48);
        g.drawString("POINTS", x + width / 2, y + 48);
        g.drawString("TIME", x + width - 70 * ApoMarioConstants.SIZE, y + 48);
        for (int i = 0; i < entries.size() && i < 12; i++) {
            Entry e = entries.get(i);
            int line = y + 68 + i * 18 * ApoMarioConstants.SIZE;
            g.drawString((i + 1) + ". " + e.name, x + 18, line);
            g.drawString(String.valueOf(e.score), x + width / 2, line);
            int seconds = e.time / 1000;
            String time = (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60);
            g.drawString(time, x + width - 70 * ApoMarioConstants.SIZE, line);
        }
        g.drawString("Press H or Escape to return", x + 18, y + height - 12);
    }
}