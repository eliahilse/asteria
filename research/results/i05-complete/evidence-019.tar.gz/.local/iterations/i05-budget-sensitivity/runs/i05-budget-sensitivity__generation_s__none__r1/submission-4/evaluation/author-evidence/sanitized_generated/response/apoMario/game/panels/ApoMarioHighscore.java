package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final class Run {
        private final String name;
        private final int score;
        private final int time;
        private Run(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        runs.add(new Run(name, score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.time));
                    writer.write('\t');
                    writer.write(run.name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' '));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
        } catch (IOException ignored) {
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                return second.score < first.score ? -1 : (second.score > first.score ? 1 : 0);
            }
        });
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] fields = line.split("\\t", 3);
                    if (fields.length != 3) continue;
                    try {
                        runs.add(new Run(fields[2], Integer.parseInt(fields[0]), Integer.parseInt(fields[1])));
                    } catch (NumberFormatException ignored) {
                    }
                }
            } finally {
                reader.close();
            }
            sort();
        } catch (IOException ignored) {
        }
    }
}