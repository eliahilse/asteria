package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table and its menu rendering helper. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504F48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;

    private static final class Run {
        String name;
        int score;
        int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private ApoMarioLevel recordedLevel;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first terminal transition of the supplied live level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level == recordedLevel || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        recordedLevel = level;
        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(Integer.valueOf(run.score));
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(Integer.valueOf(run.time));
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run run : runs) { out.writeUTF(run.name); out.writeInt(run.score); out.writeInt(run.time); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A read-only or unavailable score file must not stop the game.
        }
    }

    public synchronized void render(Graphics2D g) {
        int size = ApoMarioConstants.SIZE;
        int left = 25 * size;
        int top = 25 * size;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(left, top, ApoMarioConstants.GAME_WIDTH - 50 * size, ApoMarioConstants.GAME_HEIGHT - 50 * size, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(left, top, ApoMarioConstants.GAME_WIDTH - 50 * size, ApoMarioConstants.GAME_HEIGHT - 50 * size, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", left + 15 * size, top + 28 * size);
        g.setFont(ApoMarioConstants.FONT_MENU);
        int y = top + 55 * size;
        for (int i = 0; i < runs.size() && i < 10; i++) {
            Run run = runs.get(i);
            g.drawString((i + 1) + ". " + run.name, left + 15 * size, y);
            g.drawString(String.valueOf(run.score), left + 180 * size, y);
            g.drawString(formatTime(run.time), left + 245 * size, y);
            y += 16 * size;
        }
        g.drawString("Press H to return", left + 15 * size, top + ApoMarioConstants.GAME_HEIGHT / size - 35 * size);
    }

    private static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        return String.format("%02d:%02d", Long.valueOf(seconds / 60L), Long.valueOf(seconds % 60L));
    }

    private static String cleanName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME) return null;
        StringBuilder safe = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c >= 32 && c != 127) safe.append(c);
        }
        return safe.length() == 0 ? null : safe.toString();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = cleanName(in.readUTF());
                int score = in.readInt(); int time = in.readInt();
                if (name != null && time >= 0) runs.add(new Run(name, score, time));
            }
            in.close(); sortAndTrim();
        } catch (IOException | RuntimeException ex) {
            runs.clear();
        }
    }
}