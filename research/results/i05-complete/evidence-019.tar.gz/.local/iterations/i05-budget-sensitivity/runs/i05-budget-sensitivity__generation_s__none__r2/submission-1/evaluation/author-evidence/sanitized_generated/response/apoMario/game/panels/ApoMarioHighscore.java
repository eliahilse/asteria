package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Persistent, score-ordered results for completed runs. */
public class ApoMarioHighscore {
    private static final class Run {
        private final int score;
        private final int time;
        private final String name;
        private Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Run run : runs) {
                lines.add(run.score + "\t" + run.time + "\t" +
                        Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(store, lines, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            // A read-only highscore file must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] parts = line.split("\\t", 3);
                if (parts.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8);
                    runs.add(new Run(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), name));
                } catch (IllegalArgumentException ex) {
                    // Ignore a damaged record and retain the remaining board.
                }
            }
            sort();
        } catch (IOException ex) {
            // Treat an unavailable file as an empty board.
        }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
    }
}