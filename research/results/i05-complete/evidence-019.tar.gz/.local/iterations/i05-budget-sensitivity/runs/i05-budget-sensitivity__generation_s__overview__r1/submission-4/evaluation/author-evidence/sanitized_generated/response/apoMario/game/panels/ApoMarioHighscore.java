package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 64) name = name.substring(0, 64);
        names.add(name); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort(); return write();
    }
    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }
    public synchronized void persistAcrossRuns() { write(); }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try { names.add(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8)); scores.add(Integer.valueOf(p[1])); times.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[2])))); } catch (IllegalArgumentException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }
    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer index : order) { int i = index.intValue(); n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
    private boolean write() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter w = Files.newBufferedWriter(store, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
                for (int i = 0; i < names.size(); i++) { w.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8))); w.write('\t'); w.write(String.valueOf(scores.get(i))); w.write('\t'); w.write(String.valueOf(times.get(i))); w.newLine(); }
            }
            return true;
        } catch (IOException ignored) { return false; }
    }
    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(x,y,width,height,18,18); g.setColor(Color.BLACK); g.drawRoundRect(x,y,width,height,18,18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20)); g.drawString("HIGHSCORES", x+20, y+30); g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int row=y+58; int limit=Math.min(10,names.size());
        for (int i=0; i<limit && row<y+height-8; i++) { int sec=times.get(i).intValue()/1000; g.drawString((i+1)+". "+names.get(i),x+20,row); g.drawString(String.valueOf(scores.get(i)),x+width-125,row); g.drawString(String.format("%02d:%02d",Integer.valueOf(sec/60),Integer.valueOf(sec%60)),x+width-65,row); row+=20; }
        if (limit==0) g.drawString("No runs recorded yet.",x+20,row); g.drawString("Press ESC to return",x+20,y+height-12);
    }
}