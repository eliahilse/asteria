package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent high-score table for completed runs. */
public class ApoMarioHighscore {
    private static final class Run {
        String name;
        int score;
        int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        runs.add(new Run(name, score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.time));
                    writer.write('\t');
                    writer.write(run.name.replace("\\", "\\\\").replace("\t", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
        } catch (IOException ignored) { }
    }

    /** Records the first human/player entry at the point at which the level ends. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    /** Draws the board in the same coordinate system as the game's menu. */
    public synchronized void render(Graphics2D g) {
        int width = ApoMarioConstants.GAME_WIDTH - 36 * ApoMarioConstants.SIZE;
        int height = ApoMarioConstants.GAME_HEIGHT - 24 * ApoMarioConstants.SIZE;
        int x = (ApoMarioConstants.GAME_WIDTH - width) / 2;
        int y = (ApoMarioConstants.GAME_HEIGHT - height) / 2;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 18, 18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18 * ApoMarioConstants.SIZE));
        g.drawString("HIGHSCORES", x + 18, y + 28 * ApoMarioConstants.SIZE);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        int row = y + 50 * ApoMarioConstants.SIZE;
        int limit = Math.min(10, runs.size());
        for (int i = 0; i < limit; i++) {
            Run run = runs.get(i);
            g.drawString((i + 1) + ". " + run.name, x + 18, row);
            g.drawString(Integer.toString(run.score), x + width - 125, row);
            g.drawString(formatTime(run.time), x + width - 65, row);
            row += 16 * ApoMarioConstants.SIZE;
        }
        if (limit == 0) g.drawString("No completed runs yet", x + 18, row);
        g.drawString("H / ESC: back", x + 18, y + height - 12);
    }

    private static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); }
        });
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", 3);
                    if (parts.length == 3) {
                        try { runs.add(new Run(parts[2].replace("\\\\", "\\"), Integer.parseInt(parts[0]), Integer.parseInt(parts[1]))); }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { reader.close(); }
        } catch (IOException ignored) { }
        sort();
    }
}