package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        private final String name;
        private final int score;
        private final int time;
        private Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = clean(playerName);
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(name, Math.max(0, score), Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                writer.write("APO_MARIO_HIGHSCORE 1"); writer.newLine();
                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score)); writer.write('\t');
                    writer.write(Integer.toString(entry.time)); writer.write('\t');
                    writer.write(entry.name.replace("\t", " ")); writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException exception) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException exception) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.getAi() == null) { player = candidate; break; }
        }
        if (player != null) storeRun(player.getPoints(), level.getPassedTime(), player.getTeamName());
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE 1".equals(reader.readLine())) return;
                String line; int count = 0;
                while (count++ < MAX_RECORDS && (line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", 3);
                    if (parts.length != 3) continue;
                    try {
                        int score = Integer.parseInt(parts[0]);
                        int time = Integer.parseInt(parts[1]);
                        if (score >= 0 && time >= 0 && parts[2].length() <= MAX_NAME_LENGTH) entries.add(new Entry(clean(parts[2]), score, time));
                    } catch (NumberFormatException exception) { }
                }
            } finally { reader.close(); }
        } catch (IOException exception) { }
        sort();
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) { return first.score == second.score ? 0 : (first.score > second.score ? -1 : 1); }
        });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }

    private static String clean(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) result.append(c);
        }
        return result.toString().trim();
    }
}