package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.file.Path;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore board. */
public class ApoMarioHighscoreView {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(Path store) { this.highscore = new ApoMarioHighscore(store); }
    public ApoMarioHighscore getHighscore() { return highscore; }
    public void render(Graphics2D g, int x, int y, int width) {
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, 150, 12, 12);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, 150, 12, 12);
        g.drawString("HIGHSCORES", x + 12, y + 20);
        for (int i = 0; i < names.size() && i < 6; i++) {
            int seconds = Math.max(0, times.get(i) / 1000);
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), x + 12, y + 42 + i * 17);
            g.drawString(scores.get(i) + "  " + time, x + width - 105, y + 42 + i * 17);
        }
        if (names.isEmpty()) g.drawString("No runs recorded", x + 12, y + 48);
    }
}