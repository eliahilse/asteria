package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-descending run history used by the main menu. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();
    private boolean runRecorded;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int last = names.size() - 1;
            names.remove(last);
            scores.remove(last);
            survivalTimes.remove(last);
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the final (post scoring) result exactly once for this level run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (runRecorded || level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = selected.getAuthor();
        }
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        storeRun(selected.getPoints(), level.getPassedTime(), name);
        runRecorded = true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    /** Writes atomically where the platform permits it; a failed write leaves memory usable. */
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) {
                lines.add(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)) + "\t" + scores.get(i) + "\t" + survivalTimes.get(i));
            }
            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) {
            // Persistence is best effort; a corrupt/unwritable store must not stop the game.
        }
    }

    public synchronized void render(Graphics2D g) {
        int size = ApoMarioConstants.SIZE;
        int x = 25 * size;
        int y = 32 * size;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, 15 * size, ApoMarioConstants.GAME_WIDTH - 50 * size, ApoMarioConstants.GAME_HEIGHT - 30 * size, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, 15 * size, ApoMarioConstants.GAME_WIDTH - 50 * size, ApoMarioConstants.GAME_HEIGHT - 30 * size, 20, 20);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18 * size));
        g.drawString("HIGHSCORES", x + 20 * size, y);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12 * size));
        g.drawString("Name", x + 20 * size, y + 25 * size);
        g.drawString("Points", x + 150 * size, y + 25 * size);
        g.drawString("Time", x + 230 * size, y + 25 * size);
        for (int i = 0; i < names.size() && i < 10; i++) {
            int row = y + (45 + i * 15) * size;
            g.drawString((i + 1) + ". " + names.get(i), x + 20 * size, row);
            g.drawString(String.valueOf(scores.get(i)), x + 150 * size, row);
            int seconds = survivalTimes.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), x + 230 * size, row);
        }
        g.drawString("Press H or Escape to return", x + 20 * size, ApoMarioConstants.GAME_HEIGHT - 22 * size);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                String name = new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8);
                names.add(cleanName(name));
                scores.add(Integer.valueOf(p[1]));
                survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[2]))));
            }
            sort();
            while (names.size() > MAX_ENTRIES) { int i = names.size() - 1; names.remove(i); scores.remove(i); survivalTimes.remove(i); }
        } catch (Exception ex) {
            names.clear(); scores.clear(); survivalTimes.clear();
        }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b) - scores.get(a); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); scores.clear(); survivalTimes.clear(); names.addAll(n); scores.addAll(s); survivalTimes.addAll(t);
    }
    private static String cleanName(String value) {
        if (value == null) return "Player";
        String s = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (s.length() == 0) return "Player";
        return s.length() > 24 ? s.substring(0, 24) : s;
    }
}