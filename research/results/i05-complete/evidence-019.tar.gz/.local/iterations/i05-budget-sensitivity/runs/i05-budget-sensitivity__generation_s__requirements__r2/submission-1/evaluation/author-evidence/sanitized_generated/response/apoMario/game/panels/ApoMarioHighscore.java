package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;

    private static class Run {
        String name; int score; int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();
    private boolean runRecorded;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME || survivalTime < 0) return false;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return false;
        }
        runs.add(new Run(name, score, survivalTime));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(Integer.valueOf(r.score));
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(Integer.valueOf(r.time));
        return Collections.unmodifiableList(result);
    }

    /** Records the live player's final score exactly once for this level run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (runRecorded || level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) runRecorded = true;
    }

    public synchronized void beginRun() { runRecorded = false; }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run r : runs) { out.writeUTF(r.name); out.writeInt(r.score); out.writeInt(r.time); }
            out.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A game must remain playable when storage is unavailable. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = in.readUTF(); int score = in.readInt(); int time = in.readInt();
                if (name.length() > 0 && name.length() <= MAX_NAME && time >= 0) runs.add(new Run(name, score, time));
            }
            in.close();
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
            });
        } catch (IOException ex) { runs.clear(); }
    }

    public synchronized void render(Graphics2D g, int x, int y) {
        g.setColor(Color.BLACK); g.drawString("HIGHSCORES", x, y);
        List<String> names = getPlayersNames(); List<Integer> scores = getPlayersScores(); List<Integer> times = getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int row = y + 22 + i * 17;
            g.drawString((i + 1) + ". " + names.get(i), x, row);
            g.drawString(String.valueOf(scores.get(i)), x + 145, row);
            g.drawString(formatTime(times.get(i).intValue()), x + 215, row);
        }
    }

    public static String formatTime(int milliseconds) {
        long seconds = Math.max(0, milliseconds) / 1000L;
        return String.format("%02d:%02d", Long.valueOf(seconds / 60L), Long.valueOf(seconds % 60L));
    }
}