package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModelMenu;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.game.ApoMarioPanel;
import apoMario.level.ApoMarioLevel;

/** Persistent highscore storage and the small menu view used to display it. */
public class ApoMarioHighscore extends ApoMarioModelMenu {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 48;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();
    private ApoMarioLevel lastRecordedLevel;

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public ApoMarioHighscore(ApoMarioPanel game) {
        super(game);
        this.store = java.nio.file.Paths.get(System.getProperty("user.home", "."), ".apoMario-highscores");
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return Collections.unmodifiableList(result);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level == lastRecordedLevel || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        if (p == null) return;
        String name = p.getTeamName();
        if (name == null || name.trim().length() == 0) name = p.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        if (storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), name)) lastRecordedLevel = level;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            for (Entry e : entries) lines.add(e.score + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " "));
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    private String cleanName(String value) {
        if (value == null) return null;
        String s = value.replaceAll("[\\p{Cntrl}]", " ").trim();
        if (s.length() == 0) return null;
        return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s;
    }
    private synchronized void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            for (String line : lines) {
                if (entries.size() >= MAX_ENTRIES) break;
                String[] p = line.split("\\t", 3); if (p.length != 3) continue;
                int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                if (time < 0) continue;
                String name = cleanName(p[2]); if (name != null) entries.add(new Entry(name, score, time));
            }
            sortAndTrim();
        } catch (Exception ignored) { }
    }

    /* View implementation. The Path constructor is intentionally storage-only. */
    public void init() { }
    public void makeBackground() { }
    public void makeBackgroundAnimation() { }
    public void makeRunner() { }
    public void makeSearch() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE && getGame() != null) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        if (getGame() == null) return;
        g.setColor(new Color(245,245,245,235)); g.fillRect(20, 20, ApoMarioConstants.GAME_WIDTH-40, ApoMarioConstants.GAME_HEIGHT-40);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 35, 55);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> ns=getPlayersNames(); List<Integer> ss=getPlayersScores(); List<Integer> ts=getSurvivalTimes();
        for (int i=0; i<ns.size() && i<10; i++) {
            int y=85+i*18; int seconds=ts.get(i)/1000; String time=(seconds/60)+":"+String.format("%02d", seconds%60);
            g.drawString((i+1)+". "+ns.get(i), 40, y); g.drawString(String.valueOf(ss.get(i)), 205, y); g.drawString(time, 270, y);
        }
        g.drawString("ESC: back", 35, ApoMarioConstants.GAME_HEIGHT-30);
    }
    public void releasedEnter() { }
    public void excecuteFunction() { }
}