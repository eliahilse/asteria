package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        names.add(cleanName(playerName));
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(Integer.toString(scores.get(i).intValue()));
                    out.write('\t');
                    out.write(Integer.toString(survivalTimes.get(i).intValue()));
                    out.write('\t');
                    out.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException e) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { /* retain the in-memory score */ }
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3) continue;
                    try {
                        names.add(cleanName(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8)));
                        scores.add(Integer.valueOf(p[0]));
                        survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[1]))));
                    } catch (RuntimeException e) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sort();
        } catch (IOException e) { /* unavailable stores are empty */ }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(survivalTimes.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    private static String cleanName(String value) {
        if (value == null) return "Player";
        String s = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (s.length() == 0) return "Player";
        return s.length() > 24 ? s.substring(0, 24) : s;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.length() == 0) name = player.getAuthor();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(255, 255, 255, 240));
        g.fillRoundRect(15, 15, ApoMarioConstants.GAME_WIDTH - 30, ApoMarioConstants.GAME_HEIGHT - 30, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20 * ApoMarioConstants.SIZE));
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(ApoMarioConstants.FONT_MENU);
        int y = 72;
        for (int i = 0; i < names.size() && i < 10; i++) {
            g.drawString((i + 1) + ". " + names.get(i), 30, y);
            g.drawString(Integer.toString(scores.get(i).intValue()), 190, y);
            int seconds = Math.max(0, survivalTimes.get(i).intValue()) / 1000;
            g.drawString(String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60)), 255, y);
            y += 18 * ApoMarioConstants.SIZE;
        }
        g.setFont(ApoMarioConstants.FONT_FPS);
        g.drawString("Press H or ESC to return", 30, ApoMarioConstants.GAME_HEIGHT - 20);
    }
}