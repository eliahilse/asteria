package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore scores, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 10, height / 12, width * 8 / 10, height * 10 / 12, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 10, height / 12, width * 8 / 10, height * 10 / 12, 20, 20);
        g.drawString("HIGHSCORES", width / 2 - 45, height / 8 + 10);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        int y = height / 5;
        for (int i = 0; i < names.size() && i < 12; i++) {
            int millis = times.get(i);
            int seconds = millis / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), width / 5, y);
            g.drawString(Integer.toString(points.get(i)), width / 2, y);
            g.drawString(time, width * 3 / 5, y);
            y += g.getFontMetrics().getHeight() + 3;
        }
        g.drawString("Press H or Escape to return", width / 2 - 70, height * 11 / 12);
    }
}