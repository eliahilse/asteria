package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Dedicated renderer for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore scores, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.drawString("HIGHSCORES", width / 2 - 45, height / 10 + 30);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        int y = height / 10 + 60;
        for (int i = 0; i < names.size() && i < 12; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), width / 6, y);
            g.drawString(Integer.toString(points.get(i)), width / 2, y);
            g.drawString(time, width * 2 / 3, y);
            y += 18;
        }
        g.drawString("Press H or ESC to return", width / 2 - 65, height - height / 10 - 10);
    }
}