package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local highscore table. Survival times are elapsed milliseconds. */
public class ApoMarioHighscore {
    private static final class Run {
        String name; int score; int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        runs.add(new Run(name, score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the authoritative, already-finalized score of the run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getPoints() > chosen.getPoints()) chosen = p;
        }
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Run r : runs) {
                lines.add(Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)) + "\t" + r.score + "\t" + r.time);
            }
            Files.write(store, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (IOException ignored) { }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8);
                    runs.add(new Run(cleanName(name), Integer.parseInt(p[1]), Math.max(0, Integer.parseInt(p[2]))));
                } catch (RuntimeException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }
    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }
    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < 24; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }
    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.drawString("HIGHSCORES", x, y);
        int row = y + g.getFontMetrics().getHeight() + 4;
        for (int i = 0; i < runs.size() && i < 10; i++) {
            Run r = runs.get(i);
            int seconds = r.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + r.name + "  " + r.score + "  " + time, x, row);
            row += g.getFontMetrics().getHeight();
        }
    }
}