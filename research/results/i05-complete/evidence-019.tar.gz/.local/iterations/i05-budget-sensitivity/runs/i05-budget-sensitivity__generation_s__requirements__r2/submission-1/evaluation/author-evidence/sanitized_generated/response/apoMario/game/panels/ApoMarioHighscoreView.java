package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

/** Marker type for clients that want to refer to the menu's highscore screen. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
}