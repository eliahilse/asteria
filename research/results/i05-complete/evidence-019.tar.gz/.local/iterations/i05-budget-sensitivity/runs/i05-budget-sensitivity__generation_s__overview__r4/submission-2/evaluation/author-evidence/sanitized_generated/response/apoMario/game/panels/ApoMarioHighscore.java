package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    add(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8), Integer.parseInt(p[0]), Integer.parseInt(p[1]));
                } catch (IllegalArgumentException ignored) { }
            }
        } catch (IOException ignored) { }
        sort();
    }

    private String name(String value) {
        if (value == null) return "Player";
        value = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return value.length() == 0 ? "Player" : value;
    }

    private void add(String player, int score, int time) {
        names.add(name(player)); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(Math.max(0, time)));
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(times.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        add(playerName, score, survivalTime); sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter w = Files.newBufferedWriter(store, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
                for (int i = 0; i < names.size(); i++) {
                    w.write(Integer.toString(scores.get(i))); w.write('\t'); w.write(Integer.toString(times.get(i))); w.write('\t');
                    w.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8))); w.newLine();
                }
            }
        } catch (IOException ignored) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer p : level.getPlayers()) if (p != null && p.isBVisible() && (selected == null || p.getPoints() > selected.getPoints())) selected = p;
        if (selected == null) selected = level.getPlayers().get(0);
        String playerName = selected.getTeamName();
        if (playerName == null || playerName.trim().length() == 0) playerName = selected.getAuthor();
        storeRun(selected.getPoints(), level.getPassedTime(), playerName);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235)); g.fillRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 20, 20);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        String title = "HIGHSCORES"; g.drawString(title, width / 2 - g.getFontMetrics().stringWidth(title) / 2, height / 6);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12 * ApoMarioConstants.SIZE));
        int y = height / 6 + 28 * ApoMarioConstants.SIZE;
        for (int i = 0; i < Math.min(names.size(), 12); i++) {
            int seconds = times.get(i).intValue() / 1000;
            g.drawString((i + 1) + ". " + names.get(i), width / 5, y);
            g.drawString(Integer.toString(scores.get(i).intValue()), width / 2, y);
            g.drawString(String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60)), width * 3 / 5, y);
            y += 18 * ApoMarioConstants.SIZE;
        }
        g.drawString("Press H or ESC to return", width / 2 - 75, height - height / 10);
    }
}