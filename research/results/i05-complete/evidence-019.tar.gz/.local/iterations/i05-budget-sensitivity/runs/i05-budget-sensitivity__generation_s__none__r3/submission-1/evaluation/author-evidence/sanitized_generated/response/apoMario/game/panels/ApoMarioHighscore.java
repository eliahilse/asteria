package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final class Run {
        String name;
        int score;
        int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Unknown" : playerName.trim();
        if (name.length() == 0) name = "Unknown";
        runs.add(new Run(name, score, Math.max(0, survivalTime)));
        sort();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() { persist(); }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\t", -1);
                if (parts.length != 3) continue;
                try {
                    runs.add(new Run(new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8),
                            Integer.parseInt(parts[0]), Integer.parseInt(parts[1])));
                } catch (IllegalArgumentException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8)) {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.time));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }
            return true;
        } catch (IOException ignored) { return false; }
    }

    /** Records the first human player's actual final score and elapsed time. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player.getAi() == null) { selected = player; break; }
        }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = selected.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Human";
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g) {
        int size = ApoMarioConstants.SIZE;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(20 * size, 15 * size, ApoMarioConstants.GAME_WIDTH - 40 * size,
                ApoMarioConstants.GAME_HEIGHT - 30 * size, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 35 * size, 35 * size);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("Name", 35 * size, 55 * size);
        g.drawString("Points", 180 * size, 55 * size);
        g.drawString("Time", 245 * size, 55 * size);
        List<String> names = getPlayersNames();
        List<Integer> scores = getPlayersScores();
        List<Integer> times = getSurvivalTimes();
        int max = Math.min(names.size(), 8);
        for (int i = 0; i < max; i++) {
            int y = (65 + i * 17) * size;
            g.drawString((i + 1) + ". " + names.get(i), 25 * size, y);
            g.drawString(Integer.toString(scores.get(i)), 180 * size, y);
            int seconds = times.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 245 * size, y);
        }
        g.drawString("Press H or Escape to return", 75 * size, ApoMarioConstants.GAME_HEIGHT - 15 * size);
    }
}