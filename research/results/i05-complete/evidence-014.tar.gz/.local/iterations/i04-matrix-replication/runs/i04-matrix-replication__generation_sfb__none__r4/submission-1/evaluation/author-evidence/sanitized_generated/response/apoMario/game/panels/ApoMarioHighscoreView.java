package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore highscore, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.drawString("HIGHSCORES", width / 2 - 45, height / 7);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            int minutes = times.get(i) / 60000;
            int seconds = (times.get(i) / 1000) % 60;
            String time = String.format("%02d:%02d", minutes, seconds);
            g.drawString((i + 1) + ". " + names.get(i), width / 5, height / 5 + i * 18);
            g.drawString(Integer.toString(scores.get(i)), width / 2, height / 5 + i * 18);
            g.drawString(time, width * 3 / 5, height / 5 + i * 18);
        }
        g.drawString("H / ESC: back", width / 2 - 38, height * 9 / 10);
    }
}