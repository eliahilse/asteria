package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-descending highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();
    private final Map<ApoMarioLevel, Boolean> recordedLevels = new WeakHashMap<ApoMarioLevel, Boolean>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        name = name.replace('\n', ' ').replace('\r', ' ').replace('|', ' ');
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        return persistAcrossRuns();
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized boolean persistAcrossRuns() {
        if (store == null) return false;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    writer.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.write("|"); writer.write(String.valueOf(scores.get(i)));
                    writer.write("|"); writer.write(String.valueOf(survivalTimes.get(i))); writer.newLine();
                }
            } finally { writer.close(); }
            Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException ex) { return false; }
    }

    /** Records the best participant in a finished run exactly once per level instance. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.containsKey(level)) return;
        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : players) {
            if (player != null && player.isBVisible() && (best == null || player.getPoints() > best.getPoints())) best = player;
        }
        if (best == null) best = players.get(0);
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = best.getAuthor();
        storeRun(best.getPoints(), level.getPassedTime(), name);
        recordedLevels.put(level, Boolean.TRUE);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] p = line.split("\\|", -1);
                    if (p.length != 3) continue;
                    try {
                        String name = new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8);
                        names.add(name); scores.add(Integer.valueOf(p[1]));
                        survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[2]))));
                    } catch (RuntimeException ignored) { }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
}