package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Rendering helper for the menu highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore score, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235)); g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 18, 18);
        g.drawString("HIGHSCORES", width / 2 - 45, height / 10 + 28);
        List<String> n = score.getPlayersNames(); List<Integer> p = score.getPlayersScores(); List<Integer> t = score.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 12; i++) {
            int seconds = Math.max(0, t.get(i) / 1000); String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + n.get(i), width / 5, height / 5 + i * 17);
            g.drawString(Integer.toString(p.get(i)), width / 2, height / 5 + i * 17);
            g.drawString(time, width * 3 / 5, height / 5 + i * 17);
        }
        if (n.isEmpty()) g.drawString("No completed runs yet", width / 2 - 55, height / 2);
        g.drawString("Press H or Escape to return", width / 2 - 75, height * 9 / 10);
    }
}