package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first human player after the level has awarded its final points. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add("APO_MARIO_HIGHSCORE_1");
            for (Entry e : entries) {
                String encoded = Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encoded + "\t" + e.score + "\t" + e.time);
            }
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) { /* A broken store must not stop the game. */ }
    }

    /** Simple renderer used by the menu's dedicated highscore view. */
    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 18, 18);
        g.drawString("HIGHSCORES", x + 16, y + 28);
        int row = y + 54;
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i);
            g.drawString((i + 1) + ". " + e.name, x + 16, row);
            g.drawString(String.valueOf(e.score), x + width - 100, row);
            g.drawString(formatTime(e.time), x + width -  fifty(), row);
            row += 20;
        }
    }

    private int fifty() { return 50; }
    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis / 1000L);
        return (seconds / 60L) + ":" + String.format("%02d", seconds % 60L);
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.size() == 0 || !"APO_MARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && entries.size() < MAX_RECORDS; i++) {
                String[] p = lines.get(i).split("\\t", -1);
                if (p.length != 3 || p[0].length() > 256) continue;
                try {
                    String name = cleanName(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8));
                    int score = Integer.parseInt(p[1]); int time = Integer.parseInt(p[2]);
                    if (name.length() > 0 && time >= 0) entries.add(new Entry(name, score, time));
                } catch (Exception ex) { /* ignore malformed records */ }
            }
            sortAndTrim();
        } catch (Exception ex) { /* ignore malformed or inaccessible stores */ }
    }
    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }
}