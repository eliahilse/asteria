package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered records for completed runs. */
public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final ArrayList<Record> records = new ArrayList<Record>();

    private static final class Record {
        final int score;
        final int time;
        final String name;
        Record(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name.length() == 0) name = "Player";
        records.add(new Record(score, Math.max(0, survivalTime), name));
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score == a.score ? a.name.compareTo(b.name) : (b.score > a.score ? 1 : -1); }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
        return persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> out = new ArrayList<String>(); for (Record r : records) out.add(r.name); return out;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> out = new ArrayList<Integer>(); for (Record r : records) out.add(r.score); return out;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> out = new ArrayList<Integer>(); for (Record r : records) out.add(r.time); return out;
    }
    public synchronized void persistAcrossRuns() { persist(); }

    private String normalize(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != '\t' && c != '|') b.append(c);
        }
        return b.toString().trim();
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line; int count = 0;
            while ((line = r.readLine()) != null && count++ < MAX_RECORDS) {
                String[] p = line.split("\\|", 3);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                    String name = normalize(p[2]);
                    if (name.length() > 0 && time >= 0) records.add(new Record(score, time, name));
                } catch (RuntimeException ignored) { }
            }
            Collections.sort(records, new Comparator<Record>() { public int compare(Record a, Record b) { return b.score - a.score; } });
            while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
        } catch (IOException ignored) { }
    }
    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter w = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                w.write("# ApoMario highscore " + VERSION); w.newLine();
                for (Record r : records) { w.write(Integer.toString(r.score)); w.write('|'); w.write(Integer.toString(r.time)); w.write('|'); w.write(r.name); w.newLine(); }
            }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ignored) { return false; }
    }
}