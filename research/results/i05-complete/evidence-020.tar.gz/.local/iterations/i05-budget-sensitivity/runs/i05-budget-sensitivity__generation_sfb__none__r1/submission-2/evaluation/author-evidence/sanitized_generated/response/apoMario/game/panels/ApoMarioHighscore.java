package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent high-score table. Times are retained in milliseconds. */
public class ApoMarioHighscore {
    private static final class Entry {
        private final String name;
        private final int score;
        private final int time;
        private Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] values = line.split("\\t", -1);
                if (values.length != 3) continue;
                try {
                    entries.add(new Entry(values[0], Integer.parseInt(values[1]), Integer.parseInt(values[2])));
                } catch (NumberFormatException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(name.replace('\t', ' '), score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Entry entry : entries) {
                lines.add(entry.name + "\t" + entry.score + "\t" + entry.time);
            }
            Files.write(store, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException ignored) { }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    /** Renders a compact menu board; milliseconds become mm:ss only here. */
    public synchronized void render(Graphics2D graphics, int x, int y, int width, int height) {
        graphics.setColor(new Color(255, 255, 255, 225));
        graphics.fillRoundRect(x, y, width, height, 12, 12);
        graphics.setColor(Color.BLACK);
        graphics.drawRoundRect(x, y, width, height, 12, 12);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        graphics.drawString("HIGHSCORES", x + 10, y + 18);
        graphics.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
        int row = y + 36;
        for (int i = 0; i < entries.size() && i < 8; i++) {
            Entry entry = entries.get(i);
            int seconds = entry.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            graphics.drawString((i + 1) + ". " + entry.name, x + 8, row);
            graphics.drawString(String.valueOf(entry.score), x + width - 82, row);
            graphics.drawString(time, x + width - 42, row);
            row += 15;
        }
    }
}