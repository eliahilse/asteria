package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Record> records = new ArrayList<Record>();

    private static final class Record {
        final String name; final int score; final int time;
        Record(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name.length() == 0) name = "Player";
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        records.add(new Record(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first human player using authoritative level state. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        storeRun(player.getPoints(), level.getPassedTime(), player.getTeamName());
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Record r : records) result.add(r.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Record r : records) result.add(r.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Record r : records) result.add(r.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                out.write("APOMARIO_HIGHSCORE_1"); out.newLine();
                for (Record r : records) { out.write(Integer.toString(r.score)); out.write('\t'); out.write(Integer.toString(r.time)); out.write('\t'); out.write(r.name); out.newLine(); }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* a highscore must never stop the game */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line = in.readLine();
                if (!"APOMARIO_HIGHSCORE_1".equals(line)) return;
                int count = 0;
                while (count < MAX_RECORDS && (line = in.readLine()) != null) {
                    if (line.length() > 256) continue;
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                        if (score < 0 || time < 0) continue;
                        String name = normalize(p[2]); if (name.length() == 0) continue;
                        records.add(new Record(name, score, time)); count++;
                    } catch (NumberFormatException ex) { /* ignore malformed input */ }
                }
            } finally { in.close(); }
        } catch (IOException ex) { /* missing or unreadable data is an empty table */ }
        sortAndTrim();
    }
    private void sortAndTrim() {
        Collections.sort(records, new Comparator<Record>() { public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
    }
    private static String normalize(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i); if (c >= 32 && c != '\t' && c != '\r' && c != '\n') b.append(c);
        }
        return b.toString().trim();
    }
}