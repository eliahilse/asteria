package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** Small dedicated renderer used by the menu for the persistent table. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore table) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 20, 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = table.getPlayersNames(); List<Integer> scores = table.getPlayersScores(); List<Integer> times = table.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int seconds = times.get(i) / 1000; int minutes = seconds / 60; int sec = seconds % 60;
            String t = minutes + ":" + (sec < 10 ? "0" : "") + sec;
            g.drawString((i + 1) + ". " + names.get(i), 25, 65 + i * 18);
            g.drawString(Integer.toString(scores.get(i)), 185, 65 + i * 18);
            g.drawString(t, 250, 65 + i * 18);
        }
        g.drawString("H / Escape: back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
}