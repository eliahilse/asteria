package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run records and their menu view. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Record> records = new ArrayList<Record>();

    private static final class Record {
        String name; int score; int time;
        Record(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        records.add(new Record(name, score, Math.max(0, survivalTime)));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the authoritative first player's finished run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            lines.add("APO_MARIO_HIGHSCORE_1");
            for (Record r : records) {
                String encoded = Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8));
                lines.add(encoded + "\t" + r.score + "\t" + r.time);
            }
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) { /* A highscore must never stop the game. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.isEmpty() || !"APO_MARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && records.size() < MAX_RECORDS; i++) {
                String[] p = lines.get(i).split("\\t", -1);
                if (p.length != 3 || p[0].length() > 128) continue;
                try {
                    String name = cleanName(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8));
                    int score = Integer.parseInt(p[1]);
                    int time = Integer.parseInt(p[2]);
                    if (name.length() > 0 && time >= 0) records.add(new Record(name, score, time));
                } catch (Exception ex) { /* ignore malformed persisted records */ }
            }
            sortAndTrim();
        } catch (Exception ex) { /* ignore unreadable stores */ }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(java.awt.Color.WHITE); g.fillRoundRect(x, y, width, height, 16, 16);
        g.setColor(java.awt.Color.BLACK); g.drawRoundRect(x, y, width, height, 16, 16);
        g.drawString("HIGHSCORES", x + 12, y + 24);
        int row = y + 48;
        for (int i = 0; i < records.size() && row < y + height - 8; i++) {
            Record r = records.get(i);
            int totalSeconds = r.time / 1000;
            String time = (totalSeconds / 60) + ":" + String.format("%02d", totalSeconds % 60);
            g.drawString((i + 1) + ". " + r.name, x + 12, row);
            g.drawString(String.valueOf(r.score), x + width / 2, row);
            g.drawString(time, x + width - 52, row);
            row += 18;
        }
        if (records.isEmpty()) g.drawString("No runs recorded", x + 12, row);
    }
}