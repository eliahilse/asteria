package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            for (Entry e : entries) {
                String encoded = java.util.Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8));
                lines.add(e.score + "\t" + e.time + "\t" + encoded);
            }
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    /** Records the first human/live player's final score exactly once per run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void renderBoard(Graphics2D g) {
        int x = 20, y = 35;
        g.setColor(new Color(255,255,255,235));
        g.fillRoundRect(10, 10, ApoMarioConstants.GAME_WIDTH - 20, ApoMarioConstants.GAME_HEIGHT - 20, 20, 20);
        g.setColor(Color.BLACK); g.drawRoundRect(10, 10, ApoMarioConstants.GAME_WIDTH - 20, ApoMarioConstants.GAME_HEIGHT - 20, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", x, y);
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i);
            int row = y + 25 + i * (g.getFontMetrics().getHeight() + 3);
            g.drawString((i + 1) + ". " + e.name, x, row);
            g.drawString(String.valueOf(e.score), x + 175, row);
            g.drawString(formatTime(e.time), x + 245, row);
        }
        g.drawString("H / ESC: back", x, ApoMarioConstants.GAME_HEIGHT - 20);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return String.format(java.util.Locale.ROOT, "%02d:%02d", seconds / 60L, seconds % 60L);
    }
    private static String cleanName(String value) {
        if (value == null) return null;
        String s = value.replaceAll("[\\p{Cntrl}]", "").trim();
        if (s.length() == 0 || s.length() > MAX_NAME_LENGTH) return null;
        return s;
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            for (int i = 0; i < lines.size() && i < MAX_ENTRIES; i++) {
                String[] p = lines.get(i).split("\\t", -1);
                if (p.length != 3) continue;
                int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]);
                if (score < 0 || time < 0) continue;
                String name = cleanName(new String(java.util.Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                if (name != null) entries.add(new Entry(name, score, time));
            }
            sortAndTrim();
        } catch (Exception ignored) { entries.clear(); }
    }
}