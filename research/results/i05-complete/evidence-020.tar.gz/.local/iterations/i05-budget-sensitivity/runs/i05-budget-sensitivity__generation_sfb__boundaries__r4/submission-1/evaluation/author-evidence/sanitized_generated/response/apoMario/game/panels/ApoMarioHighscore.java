package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 80;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final int score;
        final int time;
        final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        entries.add(new Entry(score, survivalTime, name));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    /** Records the authoritative human-player result of a completed level. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible() && p.getAi() == null) { selected = p; break; }
        }
        if (selected == null) {
            for (ApoMarioPlayer p : level.getPlayers()) if (p != null && p.isBVisible()) { selected = p; break; }
        }
        if (selected == null) return;
        storeRun(selected.getPoints(), Math.max(0, level.getPassedTime()), selected.getTeamName());
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                out.write("APO_MARIO_HIGHSCORE_1"); out.newLine();
                for (Entry e : entries) {
                    out.write(Integer.toString(e.score)); out.write('\t');
                    out.write(Integer.toString(e.time)); out.write('\t');
                    out.write(Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
                    out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed highscore save must not stop the game. */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line = in.readLine();
                if (!"APO_MARIO_HIGHSCORE_1".equals(line)) return;
                while (entries.size() < MAX_RECORDS && (line = in.readLine()) != null) {
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        if (time < 0) continue;
                        String name = normalize(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                        if (name.length() > 0) entries.add(new Entry(score, time, name));
                    } catch (RuntimeException ex) { /* malformed persisted record */ }
                }
            } finally { in.close(); }
            Collections.sort(entries, new Comparator<Entry>() {
                public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
            });
        } catch (IOException ex) { /* absent or unreadable stores are treated as empty */ }
    }

    private static String normalize(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 255, 235));
        g.fillRoundRect(12, 12, width - 24, height - 24, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(12, 12, width - 24, height - 24, 18, 18);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 22));
        g.drawString("HIGHSCORES", 25, 42);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 14));
        int y = 70;
        for (int i = 0; i < entries.size() && y < height - 18; i++, y += 22) {
            Entry e = entries.get(i);
            int seconds = e.time / 1000;
            String time = (seconds / 60) + ":" + String.format("%02d", seconds % 60);
            g.drawString((i + 1) + ". " + e.name, 28, y);
            g.drawString(Integer.toString(e.score), width / 2, y);
            g.drawString(time, width - 75, y);
        }
        if (entries.isEmpty()) g.drawString("No runs recorded yet.", 28, y);
        g.drawString("Press H or Escape to return", 25, height - 24);
    }
}