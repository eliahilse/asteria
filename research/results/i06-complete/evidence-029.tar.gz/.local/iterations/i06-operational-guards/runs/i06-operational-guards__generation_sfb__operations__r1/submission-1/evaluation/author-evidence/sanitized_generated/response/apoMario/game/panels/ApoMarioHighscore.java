package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore store. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 32;
    private static final long MAX_FILE = 128 * 1024;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final String name; final int score; final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sortAndTrim();
        if (!write()) { runs.remove(findLast(name, score, survivalTime)); return false; }
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return result;
    }

    /** Records the authoritative human player's finished score exactly once per caller transition. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null) {
                String name = player.getTeamName();
                if (name == null || name.trim().length() == 0) name = "Player";
                int elapsed = level.getPassedTime();
                if (elapsed < 0) elapsed = 0;
                storeRun(player.getPoints(), elapsed, name);
                return;
            }
        }
    }

    public synchronized void persistAcrossRuns() { write(); }

    private int findLast(String name, int score, int time) {
        for (int i = runs.size() - 1; i >= 0; i--) if (runs.get(i).name.equals(name) && runs.get(i).score == score && runs.get(i).time == time) return i;
        return runs.size() - 1;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { int c = Integer.compare(b.score, a.score); return c != 0 ? c : a.name.compareTo(b.name); } });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
    private String cleanName(String value) {
        if (value == null) return null;
        String s = value.replaceAll("[\\p{Cntrl}]", " ").trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        return s;
    }
    private void load() {
        try {
            if (store == null || !Files.exists(store) || Files.size(store) > MAX_FILE) return;
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", -1); if (p.length != 3 || runs.size() >= MAX_RECORDS) continue;
                try { String n = cleanName(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8)); int s = Integer.parseInt(p[1]); int t = Integer.parseInt(p[2]); if (n != null && t >= 0) runs.add(new Run(n, s, t)); } catch (RuntimeException ignored) { }
            }
            sortAndTrim();
        } catch (IOException ignored) { }
    }
    private boolean write() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path tmp = Files.createTempFile(parent, "highscore", ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Run r : runs) lines.add(Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)) + "\t" + r.score + "\t" + r.time);
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) { return false; }
    }
}