package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 32;
    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String cleanName(String name) {
        if (name == null) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < name.length() && b.length() < MAX_NAME; i++) {
            char c = name.charAt(i);
            if (c >= 32 && c != 127 && c != '|') b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? null : s;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        return persist();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                int c = (a.score == b.score) ? 0 : (a.score > b.score ? -1 : 1);
                if (c != 0) return c;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return result;
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            if (Files.size(store) > 65536) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line;
            while ((line = reader.readLine()) != null && runs.size() < MAX_RECORDS) {
                String[] p = line.split("\\|", -1);
                if (p.length != 3 || p[2].length() > MAX_NAME) continue;
                try {
                    String name = cleanName(p[2]);
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    if (name != null && time >= 0) runs.add(new Run(score, time, name));
                } catch (RuntimeException ignored) { }
            }
            reader.close();
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        if (store == null) return false;
        Path parent = store.toAbsolutePath().getParent();
        Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            for (Run r : runs) writer.write(r.score + "|" + r.time + "|" + r.name + "\n");
            writer.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
            return false;
        }
    }

    public synchronized void persistAcrossRuns() { persist(); }

    /** Records the authoritative human player's completed run exactly as supplied by the level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) { selected = player; break; }
        }
        if (selected == null) return;
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0 || "Human".equalsIgnoreCase(name)) name = "Player";
        storeRun(selected.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 225));
        g.fillRoundRect(x, y, width, height, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 20, 20);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        g.drawString("HIGHSCORES", x + 15, y + 25);
        int row = 22;
        for (int i = 0; i < runs.size() && i < (height - 45) / row; i++) {
            Run r = runs.get(i);
            int seconds = r.time / 1000;
            String t = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + r.name, x + 15, y + 48 + i * row);
            g.drawString(String.valueOf(r.score), x + width - 105, y + 48 + i * row);
            g.drawString(t, x + width - 55, y + 48 + i * row);
        }
        if (runs.isEmpty()) g.drawString("No runs recorded", x + 15, y + 55);
    }
}