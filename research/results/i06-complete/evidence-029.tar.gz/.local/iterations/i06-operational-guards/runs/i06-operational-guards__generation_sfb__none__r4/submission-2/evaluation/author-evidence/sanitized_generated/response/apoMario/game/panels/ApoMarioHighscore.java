package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final class Run {
        final String name;
        final int score;
        final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private void load() {
        runs.clear();
        if (store == null || !Files.exists(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try { runs.add(new Run(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]))); }
                catch (NumberFormatException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score == a.score ? 0 : (b.score > a.score ? 1 : -1); }
        });
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Unknown" : playerName.trim();
        if (name.length() == 0) name = "Unknown";
        name = name.replace('\t', ' ').replace('\n', ' ');
        runs.add(new Run(name, score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8)) {
                for (Run r : runs) writer.write(r.name + "\t" + r.score + "\t" + r.time + "\n");
            }
        } catch (IOException ignored) { }
    }

    /** Records every active player at the instant the live level ends. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        int time = level.getPassedTime();
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player == null || !player.isBVisible()) continue;
            String name = player.getTeamName();
            if (name == null || name.trim().length() == 0) name = "Human";
            storeRun(player.getPoints(), time, name);
            return;
        }
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235)); g.fillRoundRect(x, y, width, height, 16, 16);
        g.setColor(Color.BLACK); g.drawRoundRect(x, y, width, height, 16, 16);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20)); g.drawString("HIGHSCORES", x + 20, y +  thirty(height));
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int row = y + 55;
        int count = Math.min(runs.size(), 10);
        for (int i = 0; i < count; i++) {
            Run r = runs.get(i);
            int seconds = r.time / 1000;
            String t = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ".", x + 20, row);
            g.drawString(r.name, x + 55, row);
            g.drawString(String.valueOf(r.score), x + width - 125, row);
            g.drawString(t, x + width - 65, row); row += 22;
        }
        if (count == 0) g.drawString("No runs recorded yet", x + 20, row);
        g.drawString("Press H or ESC to return", x + 20, y + height - 15);
    }

    private int thirty(int height) { return height > 30 ? 30 : height - 5; }
}