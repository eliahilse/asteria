package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private final Map<ApoMarioLevel, Boolean> recordedLevels = new WeakHashMap<ApoMarioLevel, Boolean>();

    private static final class Entry {
        private final int score;
        private final int time;
        private final String name;
        private Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name == null || survivalTime < 0) {
            return false;
        }
        entries.add(new Entry(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the first terminal result observed for this live level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.containsKey(level)) return;
        List<ApoMarioPlayer> players = level.getPlayers();
        if (players == null || players.isEmpty() || players.get(0) == null) return;
        ApoMarioPlayer player = players.get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        if (storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name)) {
            recordedLevels.put(level, Boolean.TRUE);
        }
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score)); writer.write('\t');
                    writer.write(Integer.toString(entry.time)); writer.write('\t');
                    writer.write(entry.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " ").replace("\r", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A failed save must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null && entries.size() < MAX_ENTRIES) {
                    String[] parts = line.split("\\t", 3);
                    if (parts.length != 3) continue;
                    try {
                        int score = Integer.parseInt(parts[0]);
                        int time = Integer.parseInt(parts[1]);
                        String name = normalizeName(parts[2]);
                        if (name != null && time >= 0) entries.add(new Entry(score, time, name));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { reader.close(); }
            sortAndTrim();
        } catch (IOException ex) { /* missing or unreadable stores are empty */ }
    }

    private String normalizeName(String name) {
        if (name == null) return null;
        String value = name.trim();
        if (value.length() == 0 || value.length() > MAX_NAME_LENGTH) return null;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (Character.isISOControl(c)) return null;
        }
        return value;
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    /** Small renderer used by the menu's dedicated highscore view. */
    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.drawString("HIGHSCORES", x, y);
        int row = y + 22;
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i);
            int seconds = e.time / 1000;
            String time = String.format("%d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + e.name + "  " + e.score + "  " + time, x, row);
            row += 18;
        }
    }
}