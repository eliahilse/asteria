package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 50;
    private static final int MAX_NAME = 32;
    private static final long MAX_FILE_SIZE = 128 * 1024L;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        private final String name;
        private final int score;
        private final int time;
        private Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    private String cleanName(String value) {
        if (value == null) return null;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != '\r' && c != '\n' && c != '\t') result.append(c);
        }
        String name = result.toString().trim();
        return name.length() == 0 ? null : name;
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                if (a.score != b.score) return b.score < a.score ? -1 : 1;
                return a.name.compareTo(b.name);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sortRuns();
        return write();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() { write(); }

    private boolean write() {
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = Files.createTempFile(parent, absolute.getFileName().toString(), ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Run run : runs) {
                lines.add(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)) + "\t" + run.score + "\t" + run.time);
            }
            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (Exception ex) { return false; }
    }

    private void load() {
        try {
            Path absolute = store.toAbsolutePath();
            if (!Files.exists(absolute) || Files.size(absolute) > MAX_FILE_SIZE) return;
            for (String line : Files.readAllLines(absolute, StandardCharsets.UTF_8)) {
                if (runs.size() >= MAX_RECORDS || line.length() > 512) break;
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3) continue;
                try {
                    String name = cleanName(new String(Base64.getDecoder().decode(fields[0]), StandardCharsets.UTF_8));
                    int score = Integer.parseInt(fields[1]);
                    int time = Integer.parseInt(fields[2]);
                    if (name != null && time >= 0) runs.add(new Run(name, score, time));
                } catch (Exception ignored) { }
            }
            sortRuns();
        } catch (Exception ignored) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.isBAnalysis() || level.getPlayers() == null) return;
        ApoMarioPlayer player = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.getAi() == null && candidate.isBVisible()) { player = candidate; break; }
        }
        if (player == null) return;
        String name = cleanName(player.getTeamName());
        if (name == null || "Human".equalsIgnoreCase(name)) name = "Player";
        int elapsed;
        try { elapsed = Math.max(0, level.getPassedTime()); }
        catch (Exception ex) { elapsed = Math.max(0, level.getStartTime() - level.getTime()); }
        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", x, y);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        List<String> names = getPlayersNames();
        List<Integer> scores = getPlayersScores();
        List<Integer> times = getSurvivalTimes();
        if (names.isEmpty()) { g.drawString("No runs recorded", x, y + 25); return; }
        for (int i = 0; i < names.size() && i < 12; i++) {
            int milliseconds = times.get(i);
            String time = String.format("%02d:%02d", milliseconds / 60000, (milliseconds / 1000) % 60);
            int rowY = y + 25 + i * 18;
            g.drawString((i + 1) + ". " + names.get(i), x, rowY);
            g.drawString(String.valueOf(scores.get(i)), x + width / 2, rowY);
            g.drawString(time, x + width - 55, rowY);
        }
    }
}