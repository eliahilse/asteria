package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public final class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final long MAX_FILE_SIZE = 65536L;
    private static final int MAX_NAME_LENGTH = 32;
    private static final class Run {
        final int score, time; final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    private String cleanName(String value) {
        if (value == null) return null;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\r' && c != '\n' && c != '\t') result.append(c);
        }
        String name = result.toString().trim();
        return name.length() == 0 ? null : name;
    }

    private void load() {
        try {
            if (store == null || !Files.exists(store) || Files.size(store) > MAX_FILE_SIZE) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while (runs.size() < MAX_RECORDS && (line = reader.readLine()) != null) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3 || fields[2].length() > 256) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        String name = cleanName(new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8));
                        if (time >= 0 && name != null) runs.add(new Run(score, time, name));
                    } catch (IllegalArgumentException ignored) { }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run left, Run right) {
                int result = Integer.compare(right.score, left.score);
                if (result == 0) result = Integer.compare(left.time, right.time);
                if (result == 0) result = left.name.compareTo(right.name);
                return result;
            }
        });
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (store == null || name == null || survivalTime < 0) return false;
        List<Run> old = new ArrayList<Run>(runs);
        runs.add(new Run(score, survivalTime, name)); sort();
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        if (!write()) { runs.clear(); runs.addAll(old); return false; }
        return true;
    }

    private boolean write() {
        Path temporary = null;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score)); writer.write('\t');
                    writer.write(Integer.toString(run.time)); writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
            return false;
        }
    }

    public synchronized void persistAcrossRuns() { write(); }
    public synchronized List<String> getPlayersNames() { List<String> r = new ArrayList<String>(); for (Run x : runs) r.add(x.name); return r; }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.score); return r; }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.time); return r; }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null) { selected = player; break; }
        }
        if (selected == null) return;
        String name = cleanName(selected.getTeamName());
        if (name == null) name = "Player";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(selected.getPoints(), elapsed, name);
    }
}