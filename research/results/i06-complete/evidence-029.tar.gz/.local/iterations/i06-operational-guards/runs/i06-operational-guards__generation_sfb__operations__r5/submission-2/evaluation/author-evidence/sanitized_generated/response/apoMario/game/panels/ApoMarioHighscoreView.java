package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

public final class ApoMarioHighscoreView {
    private final ApoMarioHighscore scores;
    public ApoMarioHighscoreView(ApoMarioHighscore scores) { this.scores = scores; }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(20, 15, ApoMarioConstants.GAME_WIDTH - 40, ApoMarioConstants.GAME_HEIGHT - 30);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 30, 45);
        List<String> names = scores.getPlayersNames();
        List<Integer> points = scores.getPlayersScores();
        List<Integer> times = scores.getSurvivalTimes();
        g.setFont(ApoMarioConstants.FONT_MENU);
        if (names.isEmpty()) { g.drawString("No runs recorded yet", 35, 80); return; }
        int count = Math.min(names.size(), 12);
        for (int i = 0; i < count; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 35, 75 + i * 17);
            g.drawString(Integer.toString(points.get(i)), 210, 75 + i * 17);
            g.drawString(time, 270, 75 + i * 17);
        }
    }
}