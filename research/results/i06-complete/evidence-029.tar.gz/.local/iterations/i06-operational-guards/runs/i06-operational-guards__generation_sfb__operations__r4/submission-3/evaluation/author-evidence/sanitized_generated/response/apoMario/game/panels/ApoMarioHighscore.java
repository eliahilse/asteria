package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private static final long MAX_FILE_SIZE = 256L * 1024L;

    private static final class Run {
        private final int score;
        private final int time;
        private final String name;
        private Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private static String cleanName(String value) {
        if (value == null) return null;
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < value.length() && builder.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\t') builder.append(c);
        }
        String result = builder.toString().trim();
        return result.length() == 0 ? null : result;
    }

    private static boolean valid(int score, int time, String name) {
        return name != null && name.length() <= MAX_NAME_LENGTH && time >= 0;
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                if (first.score != second.score) return first.score < second.score ? 1 : -1;
                return first.name.compareToIgnoreCase(second.name);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            if (Files.size(store) > MAX_FILE_SIZE) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line;
            while (runs.size() < MAX_RECORDS && (line = reader.readLine()) != null) {
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3) continue;
                try {
                    int score = Integer.parseInt(fields[0]);
                    int time = Integer.parseInt(fields[1]);
                    String name = cleanName(fields[2]);
                    if (valid(score, time, name)) runs.add(new Run(score, time, name));
                } catch (NumberFormatException ignored) { }
            }
            reader.close();
            sortRuns();
        } catch (IOException ignored) { }
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (!valid(score, survivalTime, name)) return false;
        runs.add(new Run(score, survivalTime, name));
        sortRuns();
        return persist();
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    private boolean persist() {
        if (store == null) return false;
        Path temporary = null;
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            temporary = Files.createTempFile(parent, absolute.getFileName().toString(), ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            for (Run run : runs) {
                writer.write(Integer.toString(run.score));
                writer.write('\t');
                writer.write(Integer.toString(run.time));
                writer.write('\t');
                writer.write(run.name);
                writer.newLine();
            }
            writer.close();
            Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException ignored) {
            if (temporary != null) {
                try { Files.deleteIfExists(temporary); } catch (IOException ignoredAgain) { }
            }
            return false;
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null) {
                String name = cleanName(player.getTeamName());
                if (name == null) name = "Player";
                storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
                return;
            }
        }
    }
}