package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        private final String name;
        private final int score;
        private final int survivalTime;
        private Run(String name, int score, int survivalTime) {
            this.name = name;
            this.score = score;
            this.survivalTime = survivalTime;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = sanitizeName(playerName);
        if (name == null || survivalTime < 0) {
            return false;
        }
        runs.add(new Run(name, score, survivalTime));
        sortRuns();
        persistAcrossRuns();
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) {
            return;
        }
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(player.getPoints(), elapsed, player.getTeamName());
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.survivalTime);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(run.name);
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // Persistence failure must not stop the game.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while (runs.size() < MAX_ENTRIES && (line = reader.readLine()) != null) {
                    if (line.length() > 256) continue;
                    String[] fields = line.split("\\t", 3);
                    if (fields.length != 3) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        String name = sanitizeName(fields[2]);
                        if (name != null && time >= 0) runs.add(new Run(name, score, time));
                    } catch (NumberFormatException ex) {
                        // Ignore malformed records.
                    }
                }
            } finally {
                reader.close();
            }
            sortRuns();
        } catch (IOException ex) {
            // Treat an absent or unreadable file as an empty board.
        }
    }

    private String sanitizeName(String value) {
        if (value == null) return null;
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < value.length() && builder.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) builder.append(c);
        }
        String name = builder.toString().trim();
        return name.length() == 0 ? "Player" : name;
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
}