package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, points-descending run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 20;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name;
        final int score;
        final int time;
        Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) {
                    writer.write(Integer.toString(e.score));
                    writer.write("\t");
                    writer.write(Integer.toString(e.time));
                    writer.write("\t");
                    writer.write(e.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
        } catch (IOException ignored) { }
    }

    /** Records the first live player, using the level's real score and elapsed time. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.drawString("HIGHSCORES", x, y);
        int line = g.getFontMetrics().getHeight();
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            g.drawString((i + 1) + ". " + e.name, x, y + (i + 1) * line);
            g.drawString(Integer.toString(e.score), x + width / 2, y + (i + 1) * line);
            g.drawString(formatTime(e.time), x + width - 55, y + (i + 1) * line);
        }
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) entries.add(new Entry(p[2], Integer.parseInt(p[0]), Integer.parseInt(p[1])));
                }
            } finally { reader.close(); }
            sortAndTrim();
        } catch (Exception ignored) { entries.clear(); }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
}