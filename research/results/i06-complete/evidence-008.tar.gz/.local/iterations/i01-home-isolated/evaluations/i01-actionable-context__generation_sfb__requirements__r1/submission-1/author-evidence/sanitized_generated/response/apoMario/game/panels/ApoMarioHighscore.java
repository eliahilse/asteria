package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-sorted highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final String name; final int score; final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first (human) player's actual terminal score exactly once per level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), player.getTeamName());
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (Run r : runs) out.write(Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)) + "\t" + r.score + "\t" + r.time + "\n");
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A highscore failure must not stop the game. */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while (count++ < MAX_ENTRIES && (line = in.readLine()) != null) {
                    String[] p = line.split("\\t", -1); if (p.length != 3) continue;
                    try {
                        String name = cleanName(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8));
                        int score = Integer.parseInt(p[1]); int time = Integer.parseInt(p[2]);
                        if (name != null && time >= 0) runs.add(new Run(name, score, time));
                    } catch (IllegalArgumentException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ex) { /* missing or inaccessible data means an empty table */ }
    }
    private String cleanName(String value) {
        if (value == null) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i); if (!Character.isISOControl(c)) b.append(c);
        }
        String result = b.toString().trim(); return result.length() == 0 ? null : result;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
}