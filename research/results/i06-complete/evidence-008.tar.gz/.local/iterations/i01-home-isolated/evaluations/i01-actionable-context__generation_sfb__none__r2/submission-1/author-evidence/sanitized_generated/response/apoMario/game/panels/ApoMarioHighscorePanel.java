package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated renderer for the persistent highscore board. */
public class ApoMarioHighscorePanel {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscorePanel(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g) {
        g.setColor(new Color(255, 255, 255, 230));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 80, 55);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 12; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 45, 85 + i * 18);
            g.drawString(Integer.toString(scores.get(i)), 205, 85 + i * 18);
            g.drawString(time, 255, 85 + i * 18);
        }
        g.drawString("H / ESC: back", 45, ApoMarioConstants.GAME_HEIGHT - 18);
    }
}