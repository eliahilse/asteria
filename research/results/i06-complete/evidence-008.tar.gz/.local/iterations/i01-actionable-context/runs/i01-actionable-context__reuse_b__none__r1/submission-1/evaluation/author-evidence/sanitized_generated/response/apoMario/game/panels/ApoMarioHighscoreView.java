package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Renderer used by the menu for the dedicated highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore table, int width, int height) {
        g.setColor(new Color(245, 245, 220));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 50);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> n = table.getPlayersNames();
        List<Integer> s = table.getPlayersScores();
        List<Integer> t = table.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 15; i++) {
            int seconds = t.get(i).intValue() / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
            g.drawString(String.format("%2d. %-20s %7d   %s", Integer.valueOf(i + 1), n.get(i), s.get(i), time), 55, 90 + i * 25);
        }
        if (n.isEmpty()) g.drawString("No runs recorded yet.", width / 2 - 75, 100);
        g.drawString("Press ESC to return", 20, height - 20);
    }
}