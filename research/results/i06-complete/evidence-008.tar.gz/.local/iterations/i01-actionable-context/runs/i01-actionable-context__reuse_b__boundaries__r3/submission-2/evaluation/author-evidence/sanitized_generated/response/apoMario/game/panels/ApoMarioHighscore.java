package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, locally stored highscore table for ApoMario. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<String> playersNames = new ArrayList<String>();
    private final List<Integer> playersScores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();
    private static final int MAX_ENTRIES = 100;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        playersScores.add(score);
        survivalTimes.add(Math.max(0, survivalTime));
        playersNames.add(name);
        sort();
        while (playersScores.size() > MAX_ENTRIES) {
            int last = playersScores.size() - 1;
            playersScores.remove(last);
            survivalTimes.remove(last);
            playersNames.remove(last);
        }
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(playersNames));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(playersScores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < playersScores.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return Integer.compare(playersScores.get(b), playersScores.get(a));
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(playersNames.get(i)); s.add(playersScores.get(i)); t.add(survivalTimes.get(i)); }
        playersNames.clear(); playersNames.addAll(n);
        playersScores.clear(); playersScores.addAll(s);
        survivalTimes.clear(); survivalTimes.addAll(t);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    playersScores.add(Integer.valueOf(p[0]));
                    survivalTimes.add(Integer.valueOf(p[1]));
                    playersNames.add(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                } catch (IllegalArgumentException ex) { /* ignore damaged entries */ }
            }
            sort();
        } catch (IOException ex) { /* a missing/unreadable table is an empty table */ }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter w = Files.newBufferedWriter(store, StandardCharsets.UTF_8)) {
                for (int i = 0; i < playersScores.size(); i++) {
                    w.write(String.valueOf(playersScores.get(i)));
                    w.write('\t'); w.write(String.valueOf(survivalTimes.get(i))); w.write('\t');
                    w.write(Base64.getEncoder().encodeToString(playersNames.get(i).getBytes(StandardCharsets.UTF_8)));
                    w.newLine();
                }
            }
            return true;
        } catch (IOException ex) { return false; }
    }

    /** Records the first human/player result after the level has calculated its final score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 255));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        if (playersNames.isEmpty()) { g.drawString("No runs recorded yet.", 40, 90); return; }
        for (int i = 0; i < playersNames.size() && i < 15; i++) {
            int y = 80 + i * 25;
            int ms = survivalTimes.get(i);
            String time = String.format("%02d:%02d", ms / 60000, (ms / 1000) % 60);
            g.drawString(String.format("%2d. %-20s %7d   %s", i + 1, playersNames.get(i), playersScores.get(i), time), 35, y);
        }
        g.drawString("ESC / H: back", 35, height - 20);
    }
}