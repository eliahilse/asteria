package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, local highscore table for completed Mario runs. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<String> playersNames = new ArrayList<String>();
    private final List<Integer> playersScores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 40) name = name.substring(0, 40);
        playersNames.add(name.replace('\t', ' '));
        playersScores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(playersNames);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(playersScores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            try {
                for (int i = 0; i < playersScores.size(); i++) {
                    writer.write(Integer.toString(playersScores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(playersNames.get(i).replace('\n', ' ').replace('\r', ' '));
                    writer.newLine();
                }
            } finally { writer.close(); }
        } catch (IOException ignored) { }
    }

    /** Records the first human player's final, real score and elapsed run time. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        try {
                            playersScores.add(Integer.valueOf(p[0]));
                            survivalTimes.add(Integer.valueOf(p[1]));
                            playersNames.add(p[2]);
                        } catch (NumberFormatException ignored) { }
                    }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < playersScores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return playersScores.get(b.intValue()).compareTo(playersScores.get(a.intValue()));
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(playersNames.get(i)); s.add(playersScores.get(i)); t.add(survivalTimes.get(i)); }
        playersNames.clear(); playersNames.addAll(n);
        playersScores.clear(); playersScores.addAll(s);
        survivalTimes.clear(); survivalTimes.addAll(t);
    }

    /** Menu rendering; milliseconds are converted to mm:ss only here. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 25, width - 50, height - 50, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 25, width - 50, height - 50, 18, 18);
        g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.drawString("HIGHSCORES", 45, 60);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int max = Math.min(playersScores.size(), 12);
        for (int i = 0; i < max; i++) {
            int y = 90 + i * 25;
            long seconds = Math.max(0, survivalTimes.get(i).intValue()) / 1000L;
            String time = String.format("%02d:%02d", Long.valueOf(seconds / 60L), Long.valueOf(seconds % 60L));
            g.drawString((i + 1) + ". " + playersNames.get(i), 50, y);
            g.drawString(Integer.toString(playersScores.get(i)), width / 2, y);
            g.drawString(time, width - 120, y);
        }
        if (max == 0) g.drawString("No runs recorded yet.", 50, 95);
        g.drawString("ESC / H: back", 45, height - 45);
    }
}