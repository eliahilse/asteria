package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Graphics2D;

/** Small dedicated menu view for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g, int width, int height) { highscore.render(g, width, height); }
}