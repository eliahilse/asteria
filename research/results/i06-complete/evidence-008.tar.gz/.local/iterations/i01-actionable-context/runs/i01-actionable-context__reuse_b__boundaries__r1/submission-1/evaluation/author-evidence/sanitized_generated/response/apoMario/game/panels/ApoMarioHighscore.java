package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent local highscore table. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sort();
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                synchronized (this) {
                    for (Entry e : entries) {
                        out.write(Integer.toString(e.score)); out.write('\t');
                        out.write(Integer.toString(e.time)); out.write('\t');
                        out.write(e.name.replace('\t', ' ')); out.newLine();
                    }
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    /** Records the authoritative score and elapsed time at the end of a run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed;
        try { elapsed = level.getPassedTime(); } catch (RuntimeException ex) { elapsed = 0; }
        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 85, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        g.drawString("Rank", 50, 95); g.drawString("Player", 120, 95);
        g.drawString("Points", width - 190, 95); g.drawString("Time", width - 90, 95);
        for (int i = 0; i < entries.size() && i < 15; i++) {
            Entry e = entries.get(i); int y = 125 + i * 25;
            g.drawString(Integer.toString(i + 1), 55, y);
            g.drawString(e.name, 120, y);
            g.drawString(Integer.toString(e.score), width - 190, y);
            int seconds = e.time / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 90, y);
        }
        g.drawString("Press Escape to return", 50, height - 25);
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) entries.add(new Entry(Integer.parseInt(p[0]), Integer.parseInt(p[1]), p[2]));
                }
            } finally { in.close(); }
            sort();
        } catch (Exception ignored) { entries.clear(); }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
}