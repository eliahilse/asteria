package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, deliberately network-free highscore table. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        if (names.size() > MAX_ENTRIES) {
            names.subList(MAX_ENTRIES, names.size()).clear();
            scores.subList(MAX_ENTRIES, scores.size()).clear();
            survivalTimes.subList(MAX_ENTRIES, survivalTimes.size()).clear();
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the authoritative post-completion score of the best visible player. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && !player.isBDie()) { chosen = player; break; }
        }
        if (chosen == null && !level.getPlayers().isEmpty()) chosen = level.getPlayers().get(0);
        if (chosen == null) return;
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    out.write('\t'); out.write(String.valueOf(scores.get(i))); out.write('\t');
                    out.write(String.valueOf(survivalTimes.get(i))); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* a failed write must not damage the in-memory table */ }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245,245,245)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.drawString("HIGHSCORES", width / 2 - 70, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        for (int i = 0; i < names.size() && i < 12; i++) {
            int y = 65 + i * 22;
            g.drawString((i + 1) + ".", 20, y);
            g.drawString(names.get(i), 50, y);
            g.drawString(String.valueOf(scores.get(i)), width - 125, y);
            g.drawString(formatTime(survivalTimes.get(i).intValue()), width - 65, y);
        }
        g.drawString("ESC: back", 20, height - 15);
    }

    public static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        String result = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) result = "Player";
        return result.length() > 32 ? result.substring(0, 32) : result;
    }
    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); } });
        ArrayList<String> n = new ArrayList<String>(); ArrayList<Integer> s = new ArrayList<Integer>(); ArrayList<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(survivalTimes.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8); String line;
            while ((line = in.readLine()) != null && names.size() < MAX_ENTRIES) {
                try { String[] p = line.split("\\t", -1); if (p.length != 3) continue;
                    names.add(cleanName(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8)));
                    scores.add(Integer.valueOf(p[1])); survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[2]))));
                } catch (RuntimeException ignored) { }
            }
            in.close(); sort();
        } catch (IOException ignored) { }
    }
}