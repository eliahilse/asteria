package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Rendering-only highscore board used by the Mario menu. */
public class ApoMarioHighscoreView {
    public void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(new Color(245, 245, 255, 235));
        g.fillRoundRect(18, 18, ApoMarioConstants.GAME_WIDTH - 36, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(18, 18, ApoMarioConstants.GAME_WIDTH - 36, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", ApoMarioConstants.GAME_WIDTH / 2 - 55, 48);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("#", 35, 75); g.drawString("PLAYER", 65, 75); g.drawString("POINTS", 205, 75); g.drawString("TIME", 275, 75);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 98 + i * 14;
            g.drawString(Integer.toString(i + 1), 35, y);
            g.drawString(names.get(i), 65, y);
            g.drawString(Integer.toString(scores.get(i)), 205, y);
            g.drawString(formatTime(times.get(i).intValue()), 275, y);
        }
        g.setFont(new Font("Dialog", Font.PLAIN, 10));
        g.drawString("Press ESC to return", 35, ApoMarioConstants.GAME_HEIGHT - 30);
    }

    private String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
    }
}