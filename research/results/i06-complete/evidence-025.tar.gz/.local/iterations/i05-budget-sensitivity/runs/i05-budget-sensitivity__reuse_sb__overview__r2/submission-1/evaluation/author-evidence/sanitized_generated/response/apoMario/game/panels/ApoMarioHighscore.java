package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** A small, local, path-backed highscore table. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            survivalTimes.remove(survivalTimes.size() - 1);
        }
        return true;
    }

    /** Records the authoritative, post-scoring result of a completed level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        storeRun(selected.getPoints(), level.getPassedTime(), name);
        persistAcrossRuns();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(names));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(scores));
    }

    /** Survival times are milliseconds; formatting is deliberately a view concern. */
    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;
        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }
            temporary = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    writer.write(Integer.toString(scores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) {
                try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
            }
        }
    }

    private synchronized void load() {
        if (!Files.isRegularFile(store)) {
            return;
        }
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null && names.size() < MAX_ENTRIES) {
                    String[] parts = line.split("\\t", -1);
                    if (parts.length != 3) continue;
                    try {
                        int score = Integer.parseInt(parts[0]);
                        int time = Integer.parseInt(parts[1]);
                        String name = cleanName(new String(Base64.getDecoder().decode(parts[2]), StandardCharsets.UTF_8));
                        names.add(name); scores.add(Integer.valueOf(score)); survivalTimes.add(Integer.valueOf(Math.max(0, time)));
                    } catch (RuntimeException ignored) { }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(survivalTimes.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    private static String cleanName(String name) {
        if (name == null) return "Player";
        String value = name.replace('\r', ' ').replace('\n', ' ').trim();
        if (value.length() == 0) return "Player";
        return value.length() > 32 ? value.substring(0, 32) : value;
    }
}