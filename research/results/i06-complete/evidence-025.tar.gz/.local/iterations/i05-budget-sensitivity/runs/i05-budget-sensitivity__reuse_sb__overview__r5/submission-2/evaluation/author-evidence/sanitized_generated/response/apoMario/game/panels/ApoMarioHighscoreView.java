package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioModelMenu;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscoreView extends ApoMarioModelMenu {
    public static final String FUNCTION_BACK = "highscoreBack";
    private ApoMarioHighscore highscore;

    public ApoMarioHighscoreView(ApoMarioPanel game) { super(game); }
    public void init() { super.init(); highscore = getGame().getHighscore(); }
    public void makeBackground() { }
    public void makeBackgroundAnimation() { }
    public void makeRunner() { }
    public void makeSearch() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if (FUNCTION_BACK.equals(function)) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void excecuteFunction() { }

    public void render(Graphics2D g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 95, 35);
        if (highscore == null) return;
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 65 + i * 17;
            g.drawString((i + 1) + ".", 35, y);
            g.drawString(names.get(i), 60, y);
            g.drawString(String.valueOf(scores.get(i)), 190, y);
            g.drawString(formatTime(times.get(i)), 250, y);
        }
        g.drawString("ESC: back", 35, ApoMarioConstants.GAME_HEIGHT - 15);
    }

    private String formatTime(int milliseconds) {
        long seconds = Math.max(0, milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}