package apoMario.game.panels;

import apoMario.game.ApoMarioPanel;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

/** Compatibility name for code that wants to refer to the dedicated board view. */
public class ApoMarioHighscoreView extends ApoMarioHighscore {
    public ApoMarioHighscoreView(apoMario.game.ApoMarioPanel game) { super(game); }
}