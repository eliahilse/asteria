package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

/** Small menu view used for displaying the persisted table. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore table) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 18, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 105, 48);
        List<String> n = table.getPlayersNames();
        List<Integer> s = table.getPlayersScores();
        List<Integer> t = table.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 10; i++) {
            int y = 72 + i * 16;
            int ms = t.get(i).intValue();
            String time = String.format("%02d:%02d", (ms / 60000), (ms / 1000) % 60);
            g.drawString((i + 1) + ".", 42, y);
            g.drawString(n.get(i), 65, y);
            g.drawString(String.valueOf(s.get(i)), 205, y);
            g.drawString(time, 255, y);
        }
        g.setFont(ApoMarioConstants.FONT_FPS);
        g.drawString("ESC / H: back", 110, ApoMarioConstants.GAME_HEIGHT - 15);
    }
}