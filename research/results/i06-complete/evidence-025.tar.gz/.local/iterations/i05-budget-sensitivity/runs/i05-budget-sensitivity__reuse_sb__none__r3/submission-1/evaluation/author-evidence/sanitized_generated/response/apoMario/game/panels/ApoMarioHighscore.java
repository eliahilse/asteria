package apoMario.game.panels;

import apoMario.game.ApoMarioPanel;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent highscore storage and the small menu view used by ApoMario. */
public class ApoMarioHighscore extends ApoMarioModel {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public ApoMarioHighscore(apoMario.game.ApoMarioPanel game) {
        super(game);
        this.store = game.getHighscorePath();
        load();
    }

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score < a.score ? -1 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try { for (Entry e : entries) out.write(e.score + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " ") + "\n"); }
            finally { out.close(); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        entries.clear();
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) entries.add(new Entry(p[2], Integer.parseInt(p[0]), Integer.parseInt(p[1])));
                }
            } finally { in.close(); }
            Collections.sort(entries, new Comparator<Entry>() {
                public int compare(Entry a, Entry b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score < a.score ? -1 : 1); }
            });
        } catch (Exception ignored) { entries.clear(); }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private static String drawTime(int millis) {
        int seconds = Math.max(0, millis) / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    /* View implementation. The storage-only constructor remains useful to tools and tests. */
    public void init() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE && getGame() != null) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function) && getGame() != null) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 20, 35);
        List<String> n = getPlayersNames(); List<Integer> s = getPlayersScores(); List<Integer> t = getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 12; i++) {
            int y = 65 + i * 15;
            g.drawString((i + 1) + ".", 20, y); g.drawString(n.get(i), 45, y);
            g.drawString(String.valueOf(s.get(i)), 190, y); g.drawString(drawTime(t.get(i)), 260, y);
        }
        g.drawString("ESC: back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
    public ApoMarioPanel getGame() { return (ApoMarioPanel)super.getGame(); }
}