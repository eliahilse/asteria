package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, offline highscore table. Times are always stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            survivalTimes.remove(survivalTimes.size() - 1);
        }
        return persistAcrossRuns();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(names));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(scores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    /** Writes the complete table and returns whether it was durable enough to replace the store. */
    public synchronized boolean persistAcrossRuns() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    writer.write(Integer.toString(scores.get(i).intValue()));
                    writer.write('\t');
                    writer.write(Integer.toString(survivalTimes.get(i).intValue()));
                    writer.write('\t');
                    writer.write(names.get(i).replace('\t', ' '));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    /** Records the first player, whose points are the authoritative single-player run score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        storeRun(player.getPoints(), level.getPassedTime(), player.getTeamName());
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245, 235));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.drawString("HIGHSCORES", width / 2 - 65, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        g.drawString("Rank", 20, 62);
        g.drawString("Points", 75, 62);
        g.drawString("Player", 145, 62);
        g.drawString("Time", width - 75, 62);
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 87 + i * 22;
            g.drawString(Integer.toString(i + 1), 25, y);
            g.drawString(Integer.toString(scores.get(i).intValue()), 75, y);
            g.drawString(names.get(i), 145, y);
            g.drawString(formatTime(survivalTimes.get(i).intValue()), width - 75, y);
        }
        g.drawString("Press H or Escape to return", 20, height - 12);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null && names.size() < MAX_ENTRIES) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        scores.add(Integer.valueOf(p[0]));
                        survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[1]))));
                        names.add(cleanName(p[2]));
                    } catch (NumberFormatException ignored) { }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        ArrayList<String> n = new ArrayList<String>();
        ArrayList<Integer> s = new ArrayList<Integer>();
        ArrayList<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    private static String cleanName(String value) {
        if (value == null) return "Player";
        String s = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (s.length() == 0) s = "Player";
        return s.length() >  thirty() ? s.substring(0, thirty()) : s;
    }
    private static int thirty() { return 30; }

    public static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return String.format("%02d:%02d", Long.valueOf(seconds / 60L), Long.valueOf(seconds % 60L));
    }
}