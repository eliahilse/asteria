package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, bounded high-score table. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_BYTES = 80;
    private static final long MAX_FILE_BYTES = 1024L * 1024L;

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        int time = Math.max(0, survivalTime);
        runs.add(new Run(score, time, name));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                int c = Integer.compare(b.score, a.score);
                return c != 0 ? c : Integer.compare(a.time, b.time);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path absolute = store.toAbsolutePath();
        Path parent = absolute.getParent();
        Path temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
        try {
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run r : runs) {
                byte[] name = r.name.getBytes(StandardCharsets.UTF_8);
                out.writeInt(r.score); out.writeInt(r.time); out.writeInt(name.length); out.write(name);
            }
            out.close();
            try { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
        persistAcrossRuns();
    }

    private void load() {
        if (store == null) return;
        try {
            Path p = store.toAbsolutePath();
            if (!Files.exists(p) || Files.size(p) > MAX_FILE_BYTES) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(p)));
            int magic = in.readInt(), version = in.readInt(), count = in.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt(), time = in.readInt(), length = in.readInt();
                if (length < 0 || length > MAX_NAME_BYTES) throw new IOException("invalid name");
                byte[] data = new byte[length]; in.readFully(data);
                String name = cleanName(new String(data, StandardCharsets.UTF_8));
                if (name.length() == 0) throw new IOException("invalid name");
                loaded.add(new Run(score, Math.max(0, time), name));
            }
            in.close();
            runs.addAll(loaded);
            Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return Integer.compare(b.score, a.score); } });
        } catch (IOException | RuntimeException ex) { runs.clear(); }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < 40; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", 20, 40);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < runs.size(); i++) {
            Run r = runs.get(i); int y = 70 + i * 22;
            if (y > height - 10) break;
            long seconds = r.time / 1000L; long minutes = seconds / 60L;
            g.drawString((i + 1) + ". " + r.name, 25, y);
            g.drawString(String.valueOf(r.score), width / 2, y);
            g.drawString(String.format("%02d:%02d", minutes, seconds % 60L), width * 3 / 4, y);
        }
        g.drawString("ESC / H: back", 20, height - 15);
    }
}