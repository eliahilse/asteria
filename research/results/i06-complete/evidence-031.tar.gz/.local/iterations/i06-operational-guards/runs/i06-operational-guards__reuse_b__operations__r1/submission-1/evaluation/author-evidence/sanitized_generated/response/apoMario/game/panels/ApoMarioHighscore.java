package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, local highscore table. Durations are always milliseconds. */
public final class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = validName(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        return persist();
    }

    public void persistAcrossRuns() { persist(); }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the first human player's final score and elapsed level time. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || !player.isBVisible() && player.getPoints() < 0) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    private String validName(String value) {
        if (value == null) return null;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < 32 || c == 127 || c == '\t' || c == '\n' || c == '\r' || c == '|') return null;
        }
        return s;
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score > b.score ? -1 : 1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    private synchronized void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            List<Run> loaded = new ArrayList<Run>();
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line;
            while ((line = reader.readLine()) != null && loaded.size() < MAX_RECORDS) {
                String[] p = line.split("\\|", -1);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    String name = validName(p[2]);
                    if (score >= 0 && time >= 0 && name != null) loaded.add(new Run(score, time, name));
                } catch (NumberFormatException ignored) { }
            }
            reader.close();
            runs.clear(); runs.addAll(loaded); sortAndTrim();
        } catch (IOException ignored) { }
    }

    private synchronized boolean persist() {
        if (store == null) return false;
        Path parent = store.toAbsolutePath().getParent();
        Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            for (Run r : runs) { writer.write(Integer.toString(r.score)); writer.write('|'); writer.write(Integer.toString(r.time)); writer.write('|'); writer.write(r.name); writer.newLine(); }
            writer.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
            return false;
        }
    }
}