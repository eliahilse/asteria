package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store");
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = validName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sort();
        if (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        if (storeRun(player.getPoints(), level.getPassedTime(), name)) persistAcrossRuns();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        Path target = store.toAbsolutePath();
        Path parent = target.getParent();
        Path temp = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temp = Files.createTempFile(parent, target.getFileName().toString(), ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run run : runs) { out.writeInt(run.score); out.writeInt(run.time); out.writeUTF(run.name); }
            out.close();
            try { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING); }
            temp = null;
        } catch (IOException ex) {
            if (temp != null) try { Files.deleteIfExists(temp); } catch (IOException ignored) { }
        }
    }

    private String validName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME) return null;
        for (int i = 0; i < name.length(); i++) if (name.charAt(i) < 32 || name.charAt(i) == 127) return null;
        return name;
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                if (a.score != b.score) return a.score < b.score ? 1 : -1;
                return a.name.compareTo(b.name);
            }
        });
    }

    private synchronized void load() {
        if (!Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt();
                int time = in.readInt();
                String name = validName(in.readUTF());
                if (name == null || time < 0) { in.close(); return; }
                loaded.add(new Run(score, time, name));
            }
            in.close(); runs.clear(); runs.addAll(loaded); sort();
        } catch (IOException ex) { }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("Highscores", width / 2 - 70, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run run = runs.get(i); long seconds = run.time / 1000L;
            String duration = String.format("%02d:%02d", seconds / 60L, seconds % 60L);
            int y = 80 + i * 25;
            g.drawString((i + 1) + ". " + run.name, 45, y);
            g.drawString(String.valueOf(run.score), width / 2, y);
            g.drawString(duration, width - 100, y);
        }
        g.drawString("H: close", 15, height - 15);
    }
}