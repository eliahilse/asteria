package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Rendering helper for the menu's dedicated highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore board, int width) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, 1000);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 17));
        List<String> names = board.getPlayersNames(); List<Integer> scores = board.getPlayersScores(); List<Integer> times = board.getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            int y = 95 + i * 25;
            int seconds = times.get(i) / 1000; int minutes = seconds / 60;
            g.drawString((i + 1) + ".", 40, y);
            g.drawString(names.get(i), 75, y);
            g.drawString(String.valueOf(scores.get(i)), 300, y);
            g.drawString(String.format("%02d:%02d", minutes, seconds % 60), 400, y);
        }
        g.drawString("Press ESC to return", 40, 95 + Math.max(names.size(), 1) * 25 + 25);
    }
}