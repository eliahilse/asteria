package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, file-backed highscore board. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x414D4853;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store");
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (runs.size() >= MAX_RECORDS) {
            sortRuns();
            if (score < runs.get(runs.size() - 1).score) return false;
            runs.remove(runs.size() - 1);
        }
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sortRuns();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public void persistAcrossRuns() {
        List<Run> snapshot;
        synchronized (this) { snapshot = new ArrayList<Run>(runs); }
        Path absolute = store.toAbsolutePath();
        Path parent = absolute.getParent();
        try {
            if (parent != null) Files.createDirectories(parent);
            Path temp = Files.createTempFile(parent, absolute.getFileName().toString(), ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(snapshot.size());
            for (Run run : snapshot) { out.writeInt(run.score); out.writeInt(run.time); out.writeUTF(run.name); }
            out.close();
            try { Files.move(temp, absolute, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ex) { Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A failed save must not damage the in-memory board or the old file.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private synchronized void load() {
        runs.clear();
        if (!Files.exists(store) || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt(); int time = in.readInt(); String name = in.readUTF();
                if (name.length() > MAX_NAME || time < 0) { in.close(); return; }
                loaded.add(new Run(score, time, cleanName(name)));
            }
            in.close();
            runs.addAll(loaded); sortRuns();
        } catch (IOException ex) { runs.clear(); }
    }

    private String cleanName(String name) {
        if (name == null) return "";
        String value = name.trim();
        if (value.length() > MAX_NAME) value = value.substring(0, MAX_NAME);
        return value;
    }

    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                if (a.score != b.score) return a.score < b.score ? 1 : -1;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        g.drawString("Name", 70, 95); g.drawString("Points", 290, 95); g.drawString("Time", 410, 95);
        for (int i = 0; i < runs.size() && i < 20; i++) {
            Run r = runs.get(i); int y = 125 + i * 24;
            g.drawString((i + 1) + ". " + r.name, 35, y);
            g.drawString(String.valueOf(r.score), 290, y);
            g.drawString(formatTime(r.time), 410, y);
        }
        g.drawString("Press Escape or H to return", 35, height - 25);
    }

    private String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        long minutes = seconds / 60L;
        return String.format("%02d:%02d", minutes, seconds % 60L);
    }
}