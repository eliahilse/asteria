package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local high-score table for Mario runs. */
public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(store));
            try {
                out.writeInt(VERSION);
                out.writeInt(names.size());
                for (int i = 0; i < names.size(); i++) {
                    out.writeUTF(names.get(i));
                    out.writeInt(scores.get(i).intValue());
                    out.writeInt(times.get(i).intValue());
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        names.clear(); scores.clear(); times.clear();
        if (store == null || !Files.exists(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            try {
                if (in.readInt() != VERSION) return;
                int count = in.readInt();
                if (count < 0 || count > 100000) return;
                for (int i = 0; i < count; i++) {
                    names.add(in.readUTF()); scores.add(Integer.valueOf(in.readInt())); times.add(Integer.valueOf(in.readInt()));
                }
                sort();
            } finally { in.close(); }
        } catch (IOException | RuntimeException ignored) { names.clear(); scores.clear(); times.clear(); }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(times.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    /** Records the first human player when the live level reaches its end state. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    /** Small renderer used by the menu's dedicated high-score view. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("HIGHSCORES", width / 2 - 85, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int y = 80;
        for (int i = 0; i < names.size() && i < 15; i++) {
            int ms = times.get(i).intValue(); int sec = ms / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(sec / 60), Integer.valueOf(sec % 60));
            g.drawString((i + 1) + ". " + names.get(i), 45, y);
            g.drawString(String.valueOf(scores.get(i)), width / 2, y);
            g.drawString(time, width - 105, y); y += 24;
        }
        g.drawString("H / ESC: back", 45, height - 25);
    }
}