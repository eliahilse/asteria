package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name.replace('\t', ' ').replace('\n', ' '));
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        if (names.size() > 100) { names.remove(100); scores.remove(100); times.remove(100); }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(scores.get(i) + "\t" + times.get(i) + "\t" + names.get(i));
                    out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) { scores.add(Integer.valueOf(p[0])); times.add(Integer.valueOf(p[1])); names.add(p[2]); }
                }
            } finally { in.close(); }
            sort();
        } catch (Exception ignored) { names.clear(); scores.clear(); times.clear(); }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b).compareTo(scores.get(a)); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    public synchronized void render(Graphics2D g, int x, int y, int rowHeight) {
        g.drawString("HIGHSCORES", x, y);
        for (int i = 0; i < names.size(); i++) {
            long sec = times.get(i).intValue() / 1000L;
            g.drawString((i + 1) + ". " + names.get(i) + "  " + scores.get(i) + "  " + String.format("%02d:%02d", Long.valueOf(sec / 60), Long.valueOf(sec % 60)), x, y + (i + 1) * rowHeight);
        }
    }
}