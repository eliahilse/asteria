package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModelMenu;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;
import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 40) name = name.substring(0, 40);
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sort();
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) {
                    out.write(Integer.toString(e.score)); out.newLine();
                    out.write(Integer.toString(e.time)); out.newLine();
                    out.write(e.name.replace('\n', ' ')); out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String score;
                while ((score = in.readLine()) != null) {
                    String time = in.readLine();
                    String name = in.readLine();
                    if (time == null || name == null) break;
                    try { entries.add(new Entry(Integer.parseInt(score), Integer.parseInt(time), name)); }
                    catch (NumberFormatException ignored) { }
                }
            } finally { in.close(); }
            sort();
        } catch (IOException ignored) { }
    }
    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || player.getAi() != null) return;
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public static final class View extends ApoMarioModelMenu {
        private final ApoMarioHighscore scores;
        public View(ApoMarioPanel game, ApoMarioHighscore scores) { super(game); this.scores = scores; }
        public void init() { super.init(); }
        public void makeBackground() { }
        public void makeBackgroundAnimation() { }
        public void makeRunner() { }
        public void makeSearch() { }
        public void render(Graphics2D g) {
            g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
            g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU); g.drawString("HIGHSCORES", 30, 45);
            g.setFont(new Font("Dialog", Font.PLAIN, 16));
            List<String> names = scores.getPlayersNames(); List<Integer> points = scores.getPlayersScores(); List<Integer> times = scores.getSurvivalTimes();
            for (int i = 0; i < names.size() && i < 15; i++) {
                int y = 80 + i * 25; int seconds = times.get(i) / 1000;
                g.drawString((i + 1) + ". " + names.get(i), 40, y);
                g.drawString(String.valueOf(points.get(i)), 300, y);
                g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 420, y);
            }
            g.drawString("ESC - back", 30, ApoMarioConstants.GAME_HEIGHT - 20);
        }
        public void keyButtonReleased(int key, char c) { if (key == KeyEvent.VK_ESCAPE) getGame().setMenu(); }
        public void mouseButtonFunction(String function) { if ("back".equals(function)) getGame().setMenu(); }
        public void excecuteFunction() { }
        public void mouseButtonReleased(int x, int y) { }
        public boolean mouseDragged(int x, int y) { return false; }
        public boolean mouseMoved(int x, int y) { return false; }
        public boolean mousePressed(int x, int y, boolean right) { return false; }
        public void think(int delta) { }
    }
}