package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private ApoMarioLevel lastLevel;
    private int lastScore;
    private int lastTime;
    private String lastName;
    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = clean(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() {
        List<String> r = new ArrayList<String>(); for (Entry e : entries) r.add(e.name);
        return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.score);
        return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.time);
        return Collections.unmodifiableList(r);
    }
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null) return;
        List<ApoMarioPlayer> ps = level.getPlayers();
        if (ps == null || ps.isEmpty()) return;
        ApoMarioPlayer p = ps.get(0);
        int score = p.getPoints();
        int time = Math.max(0, level.getPassedTime());
        String name = p.getTeamName();
        if (name == null || name.trim().length() == 0) name = p.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        name = clean(name);
        if (name == null) name = "Player";
        if (level == lastLevel && score == lastScore && time == lastTime && name.equals(lastName)) return;
        lastLevel = level;
        lastScore = score;
        lastTime = time;
        lastName = name;
        storeRun(score, time, name);
    }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try { for (Entry e : entries) { w.write(e.score + "\t" + e.time + "\t" + Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8))); w.newLine(); } }
            finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { }
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8); String line; int count = 0;
            try { while ((line = r.readLine()) != null && count++ < MAX_ENTRIES) { String[] p = line.split("\\t", -1); if (p.length != 3) continue; try { int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]); if (time < 0 || p[2].length() > 512) continue; String name = clean(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8)); if (name != null) entries.add(new Entry(name, score, time)); } catch (RuntimeException ex) { } } }
            finally { r.close(); } sort();
        } catch (IOException ex) { }
    }
    private String clean(String value) { if (value == null) return null; String s = value.trim(); if (s.length() == 0 || s.length() > MAX_NAME_LENGTH) return null; StringBuilder b = new StringBuilder(); for (int i=0;i<s.length();i++) if (!Character.isISOControl(s.charAt(i))) b.append(s.charAt(i)); return b.length() == 0 ? null : b.toString(); }
    private void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); } }); while (entries.size() > MAX_ENTRIES) entries.remove(entries.size()-1); }
}