package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final List<Record> records = new ArrayList<Record>();

    private static final class Record {
        private final int score;
        private final int time;
        private final String name;
        private Record(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        records.add(new Record(score, Math.max(0, survivalTime), name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        for (ApoMarioPlayer candidate : level.getPlayers()) {
            if (candidate != null && candidate.getAi() == null) {
                player = candidate;
                break;
            }
        }
        if (player != null) storeRun(player.getPoints(), level.getPassedTime(), player.getTeamName());
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Record record : records) result.add(record.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record record : records) result.add(record.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record record : records) result.add(record.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                writer.write("APO_MARIO_HIGHSCORE_1");
                writer.newLine();
                for (Record record : records) {
                    writer.write(Integer.toString(record.score));
                    writer.write('\t');
                    writer.write(Integer.toString(record.time));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(record.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
            try {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // Persistence failure must not terminate a game.
        }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE_1".equals(reader.readLine())) return;
                String line;
                int count = 0;
                while (count < MAX_RECORDS && (line = reader.readLine()) != null) {
                    count++;
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3 || fields[2].length() > 256) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        String name = cleanName(new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8));
                        if (name.length() > 0 && time >= 0) records.add(new Record(score, time, name));
                    } catch (RuntimeException ex) {
                        // Ignore malformed persisted records.
                    }
                }
            } finally {
                reader.close();
            }
            sortAndTrim();
        } catch (IOException ex) {
            // Treat an unreadable store as empty.
        }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char character = value.charAt(i);
            if (!Character.isISOControl(character)) result.append(character);
        }
        return result.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record first, Record second) {
                return first.score == second.score ? 0 : (first.score > second.score ? -1 : 1);
            }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
    }
}