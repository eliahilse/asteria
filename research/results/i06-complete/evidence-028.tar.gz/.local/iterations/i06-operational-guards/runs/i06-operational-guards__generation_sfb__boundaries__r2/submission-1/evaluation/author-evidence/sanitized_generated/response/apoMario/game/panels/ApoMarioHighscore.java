package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history and its small menu view. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Record> records = new ArrayList<Record>();

    private static final class Record {
        final int score;
        final int time;
        final String name;
        Record(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) {
            name = "Player";
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }
        records.add(new Record(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    /** Capture the authoritative player score and elapsed level time exactly once per call. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        storeRun(player.getPoints(), level.getPassedTime(), player.getTeamName());
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                writer.write("APO_MARIO_HIGHSCORE_1");
                writer.newLine();
                for (Record r : records) {
                    writer.write(Integer.toString(r.score));
                    writer.write('\t');
                    writer.write(Integer.toString(r.time));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            // A failed score file must never stop the game.
        }
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 230));
        g.fillRoundRect(x, y, width, height, 14, 14);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 14, 14);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        g.drawString("HIGHSCORES", x + 12, y + 25);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        int row = y + 47;
        int count = Math.min(records.size(), 10);
        for (int i = 0; i < count; i++) {
            Record r = records.get(i);
            g.drawString((i + 1) + ". " + r.name, x + 12, row);
            g.drawString(Integer.toString(r.score), x + width - 105, row);
            g.drawString(formatTime(r.time), x + width - 55, row);
            row += 17;
        }
        if (count == 0) g.drawString("No runs recorded", x + 12, row);
        g.drawString("H / ESC: back", x + 12, y + height - 10);
    }

    private static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE_1".equals(reader.readLine())) return;
                String line;
                while (records.size() < MAX_RECORDS && (line = reader.readLine()) != null) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3 || fields[2].length() > 256) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        if (time < 0) continue;
                        String name = cleanName(new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8));
                        if (name.length() > 0) records.add(new Record(score, time, name));
                    } catch (RuntimeException ex) {
                        // Ignore malformed persisted records.
                    }
                }
            } finally {
                reader.close();
            }
            sortAndTrim();
        } catch (IOException ex) {
            // Start with an empty board if the file is unavailable.
        }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) result.append(c);
        }
        return result.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
    }
}