package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 48;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            ArrayList<String> lines = new ArrayList<String>();
            for (Entry e : entries) lines.add(e.score + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " "));
            Files.write(tmp, lines, Charset.forName("UTF-8"));
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed;
        try { elapsed = Math.max(0, level.getPassedTime()); }
        catch (Exception ex) { elapsed = 0; }
        storeRun(player.getPoints(), elapsed, name);
    }

    private String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim().replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
        if (s.length() == 0) return null;
        return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s;
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) {
            return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
        }});
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, Charset.forName("UTF-8"));
            for (int i = 0; i < lines.size() && entries.size() < MAX_ENTRIES; i++) {
                String[] p = lines.get(i).split("\\t", 3);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                    String name = cleanName(p[2]);
                    if (name != null && time >= 0) entries.add(new Entry(name, score, time));
                } catch (RuntimeException ignored) { }
            }
            sortAndTrim();
        } catch (Exception ignored) { }
    }

    public synchronized void render(Graphics2D g) {
        int w = ApoMarioConstants.GAME_WIDTH, h = ApoMarioConstants.GAME_HEIGHT;
        g.setColor(new Color(255,255,255,245)); g.fillRoundRect(12, 12, w - 24, h - 24, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(12, 12, w - 24, h - 24, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 28, 45);
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < entries.size() && i < 12; i++) {
            Entry e = entries.get(i); int y = 70 + i * 14;
            g.drawString((i + 1) + ". " + e.name, 28, y);
            g.drawString(String.valueOf(e.score), w - 135, y);
            int seconds = e.time / 1000; String t = (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60);
            g.drawString(t, w - 65, y);
        }
        g.setFont(ApoMarioConstants.FONT_FPS); g.drawString("Press H or ESC to return", 28, h - 24);
    }
}