package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded high-score table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < Integer.MIN_VALUE || survivalTime < 0) return false;
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first player, which is the authoritative human-run score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add("APO_MARIO_HIGHSCORE_1");
            for (Entry e : entries) lines.add(e.score + "\t" + e.time + "\t" + Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
            Files.write(temp, lines, StandardCharsets.UTF_8);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.size() > MAX_RECORDS + 1 || lines.isEmpty() || !"APO_MARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && entries.size() < MAX_RECORDS; i++) {
                String[] p = lines.get(i).split("\\t", -1); if (p.length != 3 || p[2].length() > 256) continue;
                try {
                    int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]);
                    if (time < 0) continue;
                    String name = cleanName(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                    if (name.length() > 0) entries.add(new Entry(name, score, time));
                } catch (Exception ignored) { }
            }
            sortAndTrim();
        } catch (Exception ignored) { }
    }
    private String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i); if (c >= 32 && c != 127 && c != '\t' && c != '\r' && c != '\n') b.append(c);
        }
        return b.toString().trim();
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.drawString("HIGHSCORES", 20, 30);
        g.drawString("NAME", 25, 55); g.drawString("POINTS", width / 2, 55); g.drawString("TIME", width - 75, 55);
        int y = 78;
        for (Entry e : entries) {
            if (y > height - 8) break;
            g.drawString(e.name, 25, y); g.drawString(String.valueOf(e.score), width / 2, y); g.drawString(formatTime(e.time), width - 75, y); y += 20;
        }
        if (entries.isEmpty()) g.drawString("No runs recorded", 25, y);
    }
    private String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", seconds % 60L);
    }
}