package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

public final class ApoMarioHighscorePanel {
    private ApoMarioHighscorePanel() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 35, 52);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        if (names.isEmpty()) {
            g.drawString("No runs recorded", 45, 90);
        } else {
            for (int i = 0; i < names.size() && i < 12; i++) {
                int seconds = times.get(i) / 1000;
                String time = (seconds / 60) + ":" + String.format("%02d", seconds % 60);
                g.drawString((i + 1) + ". " + names.get(i), 45, 82 + i * 15);
                g.drawString(Integer.toString(scores.get(i)), 210, 82 + i * 15);
                g.drawString(time, 260, 82 + i * 15);
            }
        }
        g.drawString("H/ESC: back", 45, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}