package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small dedicated renderer used by the main menu for the highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        int w = ApoMarioConstants.GAME_WIDTH - 40 * ApoMarioConstants.SIZE;
        int h = ApoMarioConstants.GAME_HEIGHT - 40 * ApoMarioConstants.SIZE;
        int x = (ApoMarioConstants.GAME_WIDTH - w) / 2;
        int y = (ApoMarioConstants.GAME_HEIGHT - h) / 2;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, w, h, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, w, h, 20, 20);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", x + 20, y + 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        int limit = Math.min(10, names.size());
        for (int i = 0; i < limit; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), x + 25, y + 65 + i * 18);
            g.drawString(String.valueOf(scores.get(i)), x + w - 110, y + 65 + i * 18);
            g.drawString(time, x + w - 55, y + 65 + i * 18);
        }
        g.drawString("Press H or Escape to return", x + 25, y + h - 15);
    }
}