package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name;
        int score;
        int time;
        Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }
        playerName = playerName.trim();
        if (score < 0) {
            score = 0;
        }
        if (survivalTime < 0) {
            survivalTime = 0;
        }
        entries.add(new Entry(playerName, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the highest scoring active player in the finished level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (selected == null || player.getPoints() > selected.getPoints())) {
                selected = player;
            }
        }
        if (selected == null) {
            selected = level.getPlayers().get(0);
        }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) {
                    writer.write(Integer.toString(e.score));
                    writer.write('\t');
                    writer.write(Integer.toString(e.time));
                    writer.write('\t');
                    writer.write(e.name.replace("\\", "\\\\").replace("\t", " "));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
        } catch (IOException ignored) {
            // A read-only home must not stop the game.
        }
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        try { entries.add(new Entry(p[2], Integer.parseInt(p[0]), Integer.parseInt(p[1]))); }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { reader.close(); }
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score < a.score ? -1 : 1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 18, 18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", x + 18, y + 28);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        int row = y + 52;
        int count = Math.min(entries.size(), 9);
        for (int i = 0; i < count; i++) {
            Entry e = entries.get(i);
            int seconds = e.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + e.name, x + 18, row);
            g.drawString(Integer.toString(e.score), x + width - 105, row);
            g.drawString(time, x + width - 55, row);
            row += 21;
        }
        if (entries.isEmpty()) g.drawString("No runs recorded yet", x + 18, row);
    }
}