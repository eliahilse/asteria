package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

/** Named view type for integrations that want a dedicated menu highscore view. */
public class ApoMarioHighscoreView extends ApoMarioHighscore {
    public ApoMarioHighscoreView(java.nio.file.Path store) { super(store); }
}