package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        private final int score;
        private final int survivalTime;
        private final String name;
        private Run(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store must not be null");
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sortAndTrim();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.survivalTime);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null) {
                selected = player;
                break;
            }
        }
        if (selected != null) {
            storeRun(selected.getPoints(), level.getPassedTime(), selected.getTeamName());
        }
    }

    private String cleanName(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) result.append(c);
        }
        return result.toString().trim();
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    private void load() {
        if (!Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while (runs.size() < MAX_RECORDS && (line = reader.readLine()) != null) {
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3) continue;
                try {
                    int score = Integer.parseInt(fields[0]);
                    int time = Integer.parseInt(fields[1]);
                    String name = cleanName(fields[2]);
                    if (time >= 0 && name.length() > 0) runs.add(new Run(score, time, name));
                } catch (NumberFormatException ignored) { }
            }
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.survivalTime));
                    writer.write('\t');
                    writer.write(run.name);
                    writer.newLine();
                }
            }
            try {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }
}