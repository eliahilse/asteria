package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded high-score table and its small menu view. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 80;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME || survivalTime < 0) return false;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return false;
        }
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Run r : runs) lines.add(r.score + "\t" + r.time + "\t" + Base64.getEncoder().encodeToString(r.name.getBytes(Charset.forName("UTF-8"))));
            Files.write(tmp, lines, Charset.forName("UTF-8"));
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { /* A game must remain playable if storage is unavailable. */ }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, Charset.forName("UTF-8"));
            int count = 0;
            for (String line : lines) {
                if (count++ >= MAX_ENTRIES || line.length() > 512) break;
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    byte[] bytes = Base64.getDecoder().decode(p[2]);
                    String name = new String(bytes, Charset.forName("UTF-8"));
                    if (name.trim().length() > 0 && name.length() <= MAX_NAME && time >= 0) runs.add(new Run(score, time, name));
                } catch (RuntimeException e) { /* ignore malformed records */ }
            }
            sortAndTrim();
        } catch (IOException e) { /* missing/corrupt storage is treated as empty */ }
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 10, height / 12, width * 4 / 5, height * 5 / 6, 18, 18);
        g.drawString("HIGHSCORES", width / 2 - 45, height / 8 + 8);
        int y = height / 5;
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run r = runs.get(i);
            long seconds = r.time / 1000L;
            String t = String.format("%02d:%02d", seconds / 60L, seconds % 60L);
            g.drawString((i + 1) + ". " + r.name, width / 6, y);
            g.drawString(String.valueOf(r.score), width / 2, y);
            g.drawString(t, width * 2 / 3, y);
            y += 18;
        }
        g.drawString("Press H or Escape to return", width / 3, height * 9 / 10);
    }
}