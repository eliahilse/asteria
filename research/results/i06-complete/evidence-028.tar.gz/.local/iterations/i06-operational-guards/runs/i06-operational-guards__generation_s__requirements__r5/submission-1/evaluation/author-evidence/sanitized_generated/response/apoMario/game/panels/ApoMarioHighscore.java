package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded highscore table and its menu view. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 48;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the first live player after the level has applied its final score bonus. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = player.getAuthor();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(entries.size());
            for (Entry e : entries) { out.writeUTF(e.name); out.writeInt(e.score); out.writeInt(e.time); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A missing/unwritable score file must not stop the game. */ }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 240)); g.fillRoundRect(18, 15, width - 36, height - 30, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(18, 15, width - 36, height - 30, 18, 18);
        g.drawString("HIGHSCORES (press H to return)", 35, 42);
        int y = 70;
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i); g.drawString((i + 1) + ". " + e.name, 38, y);
            g.drawString(String.valueOf(e.score), width / 2, y);
            g.drawString(formatTime(e.time), width - 105, y); y += 20;
        }
        if (entries.isEmpty()) g.drawString("No runs recorded yet.", 38, y);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return String.format("%02d:%02d", Long.valueOf(seconds / 60L), Long.valueOf(seconds % 60L));
    }
    private static String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim(); if (s.length() == 0 || s.length() > MAX_NAME) return null;
        StringBuilder b = new StringBuilder(); for (int i = 0; i < s.length(); i++) if (!Character.isISOControl(s.charAt(i))) b.append(s.charAt(i));
        return b.length() == 0 ? null : b.toString();
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); } });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt(); if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) { String n = cleanName(in.readUTF()); int s = in.readInt(); int t = in.readInt(); if (n != null && t >= 0) entries.add(new Entry(n, s, t)); }
            in.close(); sortAndTrim();
        } catch (IOException ex) { entries.clear(); }
    }
}