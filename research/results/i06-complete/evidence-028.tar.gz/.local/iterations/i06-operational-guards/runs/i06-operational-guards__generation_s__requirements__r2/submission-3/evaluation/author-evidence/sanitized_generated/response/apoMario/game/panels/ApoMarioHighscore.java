package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();
    private static final class Run {
        final String name; final int score; final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0 || playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > 32) return false;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return false;
        runs.add(new Run(name, score, survivalTime)); sortRuns(); persistAcrossRuns(); return true;
    }
    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
    public synchronized List<String> getPlayersNames() { ArrayList<String> r = new ArrayList<String>(); for (Run x:runs) r.add(x.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores() { ArrayList<Integer> r = new ArrayList<Integer>(); for (Run x:runs) r.add(x.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes() { ArrayList<Integer> r = new ArrayList<Integer>(); for (Run x:runs) r.add(x.time); return Collections.unmodifiableList(r); }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            if (store.toAbsolutePath().getParent() != null) Files.createDirectories(store.toAbsolutePath().getParent());
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(tmp)); out.writeInt(MAGIC); out.writeInt(runs.size());
            for (Run x:runs) { byte[] n = x.name.getBytes(StandardCharsets.UTF_8); out.writeInt(x.score); out.writeInt(x.time); out.writeShort(n.length); out.write(n); }
            out.close(); Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) { try { Files.deleteIfExists(tmp); } catch (IOException ignored) { } }
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != MAGIC) { in.close(); return; }
            int count = in.readInt(); if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i=0;i<count;i++) { int score=in.readInt(); int time=in.readInt(); int len=in.readUnsignedShort(); if (len > 96 || time < 0) { in.close(); return; } byte[] b=new byte[len]; in.readFully(b); String n=new String(b,StandardCharsets.UTF_8).trim(); if (n.length()==0 || n.length()>32) { in.close(); return; } runs.add(new Run(n,score,time)); }
            in.close(); sortRuns();
        } catch (IOException e) { runs.clear(); }
    }
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0); String n = p.getTeamName();
        if (n == null || n.trim().length() == 0) n = p.getAuthor(); if (n == null || n.trim().length() == 0) n = "Player";
        storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), n);
    }
    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20,15,ApoMarioConstants.GAME_WIDTH-40,ApoMarioConstants.GAME_HEIGHT-30,20,20);
        g.setColor(Color.BLACK); g.drawRoundRect(20,15,ApoMarioConstants.GAME_WIDTH-40,ApoMarioConstants.GAME_HEIGHT-30,20,20); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES",35,48); g.setFont(ApoMarioConstants.FONT_MENU);
        int y=78; for (int i=0;i<runs.size() && i<12;i++) { Run x=runs.get(i); g.drawString((i+1)+". "+x.name,38,y); g.drawString(String.valueOf(x.score),190,y); g.drawString(formatTime(x.time),255,y); y += 22; } g.drawString("ESC: back",35,ApoMarioConstants.GAME_HEIGHT-25);
    }
    private static String formatTime(int ms) { long s=Math.max(0,ms)/1000; return String.format("%02d:%02d",s/60,s%60); }
}