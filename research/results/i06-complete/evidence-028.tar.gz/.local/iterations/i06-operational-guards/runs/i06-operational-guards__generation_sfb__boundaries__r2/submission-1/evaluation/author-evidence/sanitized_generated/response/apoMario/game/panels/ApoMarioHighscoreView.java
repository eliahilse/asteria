package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

/** Named view type for menu integrations that need a dedicated highscore panel. */
public class ApoMarioHighscoreView extends ApoMarioHighscore {
    public ApoMarioHighscoreView(java.nio.file.Path store) {
        super(store);
    }
}