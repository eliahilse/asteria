package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;

public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore scores) {
        g.setColor(Color.WHITE); g.fillRoundRect(22, 18, ApoMarioConstants.GAME_WIDTH - 44, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK); g.drawRoundRect(22, 18, ApoMarioConstants.GAME_WIDTH - 44, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 95, 48); g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> n=scores.getPlayersNames(); List<Integer> p=scores.getPlayersScores(); List<Integer> t=scores.getSurvivalTimes();
        if (n.isEmpty()) g.drawString("No runs recorded yet", 70, 90);
        for (int i=0;i<n.size() && i<10;i++) { long sec=Math.max(0,t.get(i)/1000L); String tm=String.format("%02d:%02d",sec/60L,sec%60L); int y=78+i*18; g.drawString((i+1)+". "+n.get(i),42,y); g.drawString(Integer.toString(p.get(i)),190,y); g.drawString(tm,250,y); }
        g.drawString("ESC - back",42,ApoMarioConstants.GAME_HEIGHT-25);
    }
}