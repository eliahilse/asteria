package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small menu view used to display the persisted highscore table. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(20, 18, ApoMarioConstants.GAME_WIDTH - 40, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(20, 18, ApoMarioConstants.GAME_WIDTH - 40, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 30, 45);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        int count = Math.min(10, names.size());
        for (int i = 0; i < count; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 35, 72 + i * 16);
            g.drawString(scores.get(i) + "  " + time, ApoMarioConstants.GAME_WIDTH - 105, 72 + i * 16);
        }
        if (count == 0) g.drawString("No runs recorded", 35, 75);
        g.drawString("Press H or ESC to return", 35, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}