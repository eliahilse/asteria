package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-descending run history. */
public class ApoMarioHighscore {
    private static final String SEPARATOR = "\t";
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name;
        final int score;
        final int time;
        Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (survivalTime < 0) {
            survivalTime = 0;
        }
        String name = cleanName(playerName);
        entries.add(new Entry(name, score, survivalTime));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return result;
    }

    /** Records the authoritative final player score and elapsed level time. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try {
                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score));
                    writer.write(SEPARATOR);
                    writer.write(Integer.toString(entry.time));
                    writer.write(SEPARATOR);
                    writer.write(entry.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " ").replace("\r", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temp, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ex) { Files.move(temp, store); }
        } catch (IOException ex) {
            // A failed save must not make the running game fail.
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(SEPARATOR, 3);
                    if (parts.length == 3) {
                        try { entries.add(new Entry(cleanName(parts[2]), Integer.parseInt(parts[0]), Math.max(0, Integer.parseInt(parts[1])))); }
                        catch (NumberFormatException ignored) { }
                    }
                }
            } finally { reader.close(); }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
    }

    private static String cleanName(String name) {
        if (name == null) return "Player";
        String result = name.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) return "Player";
        return result.length() > 32 ? result.substring(0, 32) : result;
    }
}