package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated highscore board rendered from the persistent highscore model. */
public class ApoMarioHighscorePanel {
    private final ApoMarioHighscore highscore;

    public ApoMarioHighscorePanel(ApoMarioHighscore highscore) {
        this.highscore = highscore;
    }

    public void render(Graphics2D g) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(30, 20, ApoMarioConstants.GAME_WIDTH - 60, ApoMarioConstants.GAME_HEIGHT - 40, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(30, 20, ApoMarioConstants.GAME_WIDTH - 60, ApoMarioConstants.GAME_HEIGHT - 40, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 48, 52);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            int minutes = times.get(i) / 60000;
            int seconds = (times.get(i) / 1000) % 60;
            g.drawString((i + 1) + ". " + names.get(i), 48, 80 + i * 18);
            g.drawString(scores.get(i) + " pts  " + String.format("%02d:%02d", minutes, seconds), 205, 80 + i * 18);
        }
        if (names.isEmpty()) g.drawString("No runs recorded yet", 70, 100);
        g.drawString("Press H or ESC to return", 65, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}