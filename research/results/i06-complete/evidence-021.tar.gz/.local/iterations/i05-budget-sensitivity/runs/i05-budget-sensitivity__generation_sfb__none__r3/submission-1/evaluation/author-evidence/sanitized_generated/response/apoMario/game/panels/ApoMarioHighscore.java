package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent highscore table. Survival times are always milliseconds. */
public class ApoMarioHighscore {
    private static final class Run {
        String name;
        int score;
        int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private void load() {
        synchronized (runs) {
            runs.clear();
            if (store == null || !Files.exists(store)) return;
            try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] p = line.split("\\t", -1);
                    if (p.length < 3) continue;
                    try {
                        runs.add(new Run(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2])));
                    } catch (NumberFormatException ignored) { }
                }
                sort();
            } catch (IOException ignored) { }
        }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    public boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Anonymous" : playerName.trim();
        if (name.length() == 0) name = "Anonymous";
        name = name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
        synchronized (runs) {
            runs.add(new Run(name, score, Math.max(0, survivalTime)));
            sort();
        }
        persistAcrossRuns();
        return true;
    }

    public List<String> getPlayersNames() {
        synchronized (runs) { List<String> r = new ArrayList<String>(); for (Run x : runs) r.add(x.name); return r; }
    }
    public List<Integer> getPlayersScores() {
        synchronized (runs) { List<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.score); return r; }
    }
    public List<Integer> getSurvivalTimes() {
        synchronized (runs) { List<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.time); return r; }
    }

    public void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8)) {
                synchronized (runs) {
                    for (Run x : runs) writer.write(x.name + "\t" + x.score + "\t" + x.time + "\n");
                }
            }
        } catch (IOException ignored) { }
    }

    /** Records the first active player's real score, name and elapsed level time. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible()) { selected = p; break; }
        }
        if (selected != null) storeRun(selected.getPoints(), level.getPassedTime(), selected.getTeamName());
    }

    public void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 225));
        g.fillRoundRect(x, y, width, height, 16, 16);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 16, 16);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", x + 20, y + 30);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        List<String> n = getPlayersNames(); List<Integer> s = getPlayersScores(); List<Integer> t = getSurvivalTimes();
        int limit = Math.min(10, n.size());
        for (int i = 0; i < limit; i++) {
            int seconds = t.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + n.get(i), x + 20, y + 55 + i * 18);
            g.drawString(String.valueOf(s.get(i)), x + width - 105, y + 55 + i * 18);
            g.drawString(time, x + width - 55, y + 55 + i * 18);
        }
    }
}