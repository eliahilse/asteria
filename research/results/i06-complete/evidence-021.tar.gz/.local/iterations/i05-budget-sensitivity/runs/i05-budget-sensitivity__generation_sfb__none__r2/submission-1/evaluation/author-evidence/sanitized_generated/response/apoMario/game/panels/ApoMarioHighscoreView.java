package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 12, 12);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 12, 12);
        g.drawString("HIGHSCORES", width / 2 - g.getFontMetrics().stringWidth("HIGHSCORES") / 2, height / 10 + 25);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        int rows = Math.min(names.size(), 10);
        for (int i = 0; i < rows; i++) {
            int seconds = times.get(i) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), width / 8 + 15, height / 10 + 55 + i * 18);
            g.drawString(Integer.toString(scores.get(i)), width / 2, height / 10 + 55 + i * 18);
            g.drawString(time, width * 5 / 8, height / 10 + 55 + i * 18);
        }
        g.drawString("H / ESC: back", width / 8 + 15, height * 9 / 10 - 8);
    }
}