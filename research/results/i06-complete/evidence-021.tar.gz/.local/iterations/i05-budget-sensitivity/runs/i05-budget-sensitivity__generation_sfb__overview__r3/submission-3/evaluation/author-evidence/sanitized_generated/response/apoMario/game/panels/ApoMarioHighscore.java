package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-descending highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();
    private final Set<ApoMarioLevel> recordedLevels = Collections.newSetFromMap(new IdentityHashMap<ApoMarioLevel, Boolean>());

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Anonymous";
        }
        playerName = clean(playerName);
        if (survivalTime < 0) {
            survivalTime = 0;
        }
        names.add(playerName);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(survivalTime));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(names);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(scores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(times);
    }

    /** Writes a complete, UTF-8, replaceable snapshot of the current table. */
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) {
                lines.add(Base64.getEncoder().encodeToString(names.get(i).getBytes(Charset.forName("UTF-8")))
                    + "\t" + scores.get(i) + "\t" + times.get(i));
            }
            Files.write(store, lines, Charset.forName("UTF-8"), StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (Exception ignored) {
            // A read-only store must not stop the game.
        }
    }

    /** Allows the same level object to represent a fresh run after restart/new level. */
    public synchronized void resetRun(ApoMarioLevel level) {
        if (level != null) {
            recordedLevels.remove(level);
        }
    }

    /** Records the final participant score exactly once for this level instance. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level) || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (selected == null || player.getPoints() > selected.getPoints())) {
                selected = player;
            }
        }
        if (selected == null && !level.getPlayers().isEmpty()) selected = level.getPlayers().get(0);
        if (selected == null) return;
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        storeRun(selected.getPoints(), level.getPassedTime(), name);
        recordedLevels.add(level);
    }

    /** Renders the menu's dedicated highscore view; milliseconds become mm:ss here only. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 255, 235));
        g.fillRoundRect(15, 15, width - 30, height - 30, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(15, 15, width - 30, height - 30, 18, 18);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        int rows = Math.min(names.size(), Math.max(1, (height - 65) / 22));
        for (int i = 0; i < rows; i++) {
            int y = 68 + i * 22;
            int millis = times.get(i).intValue();
            int seconds = millis / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
            g.drawString((i + 1) + ". " + names.get(i), 32, y);
            g.drawString(String.valueOf(scores.get(i)), width / 2, y);
            g.drawString(time, width - 75, y);
        }
        if (rows == 0) g.drawString("No runs recorded yet.", 32, 75);
        g.drawString("Press H or Escape to return", 30, height - 28);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, Charset.forName("UTF-8"))) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(p[0]), Charset.forName("UTF-8"));
                    names.add(clean(name));
                    scores.add(Integer.valueOf(p[1]));
                    times.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[2]))));
                } catch (Exception ignored) { }
            }
            sort();
        } catch (Exception ignored) { }
    }

    private String clean(String value) {
        String result = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return result.length() == 0 ? "Anonymous" : result.substring(0, Math.min(32, result.length()));
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(times.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
}