package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-descending run history. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final String SEPARATOR = "\t";
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(names);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(scores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(times);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(Integer.toString(scores.get(i)));
                    out.write(SEPARATOR);
                    out.write(Integer.toString(times.get(i)));
                    out.write(SEPARATOR);
                    out.write(names.get(i).replace("\t", " ").replace("\r", " ").replace("\n", " "));
                    out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ex) { Files.copy(tmp, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING); Files.deleteIfExists(tmp); }
        } catch (IOException ex) {
            // A failed write must not make the running game fail.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (selected == null || player.getPoints() > selected.getPoints())) selected = player;
        }
        if (selected == null) selected = level.getPlayers().get(0);
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split(SEPARATOR, 3);
                    if (p.length != 3) continue;
                    try { scores.add(Integer.valueOf(p[0])); times.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[1])))); names.add(cleanName(p[2])); }
                    catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sort();
        } catch (IOException ex) { /* absent or unreadable stores start empty */ }
    }

    private String cleanName(String value) {
        if (value == null || value.trim().length() == 0) return "Player";
        String s = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return s.length() == 0 ? "Player" : (s.length() > 32 ? s.substring(0, 32) : s);
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b).compareTo(scores.get(a)); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
}