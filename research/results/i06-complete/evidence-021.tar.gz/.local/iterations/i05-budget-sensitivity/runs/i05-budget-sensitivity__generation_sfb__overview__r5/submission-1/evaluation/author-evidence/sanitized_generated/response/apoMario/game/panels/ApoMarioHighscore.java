package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run results. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private boolean recorded;

    private static final class Entry {
        final int score;
        final int time;
        final String name;
        Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (Entry e : entries) {
                String encoded = Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8));
                lines.add(e.score + "\t" + e.time + "\t" + encoded);
            }
            Files.write(store, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (Exception ignored) {
            // A read-only score file must not stop the game.
        }
    }

    /** Records the best participating player once, after the level has finished scoring. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (recorded || level == null || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (chosen == null || player.getPoints() > chosen.getPoints())) {
                chosen = player;
            }
        }
        if (chosen == null) {
            for (ApoMarioPlayer player : level.getPlayers()) {
                if (player != null && (chosen == null || player.getPoints() > chosen.getPoints())) chosen = player;
            }
        }
        if (chosen != null) {
            recorded = true;
            storeRun(chosen.getPoints(), level.getPassedTime(), chosen.getTeamName());
        }
    }

    /** Allows the next newly-created run to be recorded. */
    public synchronized void beginRun() {
        recorded = false;
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                    entries.add(new Entry(Integer.parseInt(p[0]), Math.max(0, Integer.parseInt(p[1])), cleanName(name)));
                } catch (Exception ignored) { }
            }
            sortAndTrim();
        } catch (Exception ignored) { }
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private static String cleanName(String value) {
        if (value == null) return "Player";
        String name = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (name.length() == 0) name = "Player";
        return name.length() > 32 ? name.substring(0, 32) : name;
    }

    /** Small rendering helper used by the menu view. */
    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(Color.BLACK);
        g.drawString("HIGHSCORES", x, y);
        int row = y + 22;
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i);
            int seconds = e.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + e.name + "  " + e.score + "  " + time, x, row);
            row += 18;
        }
    }
}