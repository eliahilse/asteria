package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent highscore table. Survival times are stored in milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();
    private final Map<ApoMarioLevel, String> recordedRuns = new HashMap<ApoMarioLevel, String>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        names.add(cleanName(playerName));
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(names));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(scores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes));
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (selected == null || player.getPoints() > selected.getPoints())) selected = player;
        }
        if (selected == null && !level.getPlayers().isEmpty()) selected = level.getPlayers().get(0);
        if (selected == null) return;
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        int elapsed = level.getPassedTime();
        String runKey = selected.getPoints() + "|" + elapsed + "|" + name;
        String previous = recordedRuns.get(level);
        if (runKey.equals(previous)) return;
        storeRun(selected.getPoints(), elapsed, name);
        recordedRuns.put(level, runKey);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path absolute = store.toAbsolutePath();
            if (absolute.getParent() != null) Files.createDirectories(absolute.getParent());
            Path temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) {
                String encoded = Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8));
                lines.add(encoded + "\t" + scores.get(i) + "\t" + survivalTimes.get(i));
            }
            Files.write(temporary, lines, StandardCharsets.UTF_8);
            try {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception ex) {
                Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            // Persistence failure must not stop gameplay.
        }
    }

    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, height, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, height, 18, 18);
        g.drawString("HIGHSCORES", x + 12, y + 22);
        int row = y + 45;
        for (int i = 0; i < names.size() && i < 8; i++) {
            int milliseconds = survivalTimes.get(i).intValue();
            String time = String.format("%02d:%02d", Integer.valueOf(milliseconds / 60000), Integer.valueOf((milliseconds / 1000) % 60));
            g.drawString((i + 1) + ". " + names.get(i), x + 10, row);
            g.drawString(String.valueOf(scores.get(i)), x + width - 105, row);
            g.drawString(time, x + width - 55, row);
            row += 18;
        }
        if (names.isEmpty()) g.drawString("No runs recorded", x + 12, row);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] parts = line.split("\\t", -1);
                if (parts.length != 3) continue;
                names.add(cleanName(new String(Base64.getDecoder().decode(parts[0]), StandardCharsets.UTF_8)));
                scores.add(Integer.valueOf(parts[1]));
                survivalTimes.add(Integer.valueOf(Math.max(0, Integer.parseInt(parts[2]))));
            }
            sort();
        } catch (Exception ex) {
            names.clear();
            scores.clear();
            survivalTimes.clear();
        }
    }

    private String cleanName(String value) {
        if (value == null) return "Human";
        String result = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) return "Human";
        return result.length() > 24 ? result.substring(0, 24) : result;
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer left, Integer right) {
                return scores.get(right.intValue()).compareTo(scores.get(left.intValue()));
            }
        });
        List<String> sortedNames = new ArrayList<String>();
        List<Integer> sortedScores = new ArrayList<Integer>();
        List<Integer> sortedTimes = new ArrayList<Integer>();
        for (Integer index : order) {
            sortedNames.add(names.get(index.intValue()));
            sortedScores.add(scores.get(index.intValue()));
            sortedTimes.add(survivalTimes.get(index.intValue()));
        }
        names.clear(); names.addAll(sortedNames);
        scores.clear(); scores.addAll(sortedScores);
        survivalTimes.clear(); survivalTimes.addAll(sortedTimes);
    }
}