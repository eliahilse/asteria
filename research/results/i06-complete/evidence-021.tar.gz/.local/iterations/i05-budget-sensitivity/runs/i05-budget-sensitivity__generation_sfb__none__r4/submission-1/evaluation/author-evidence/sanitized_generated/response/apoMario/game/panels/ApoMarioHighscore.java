package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-sorted run history. Survival times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final class Run {
        private final int score;
        private final int time;
        private final String name;
        private Run(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) {
            name = "Player";
        }
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.time));
                    writer.write('\t');
                    writer.write(run.name.replace('\t', ' ').replace('\n', ' '));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
        } catch (IOException ignored) {
            // A damaged or read-only score file must not stop the game.
        }
    }

    /** Records the real player one result at the moment the level ends. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", 3);
                    if (parts.length == 3) {
                        try {
                            runs.add(new Run(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), parts[2]));
                        } catch (NumberFormatException ignored) { }
                    }
                }
            } finally {
                reader.close();
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
    }

    /** Renders the dedicated menu board. Milliseconds are formatted only here. */
    public synchronized void render(Graphics2D g, int x, int y, int width, int height) {
        g.setColor(new java.awt.Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, height, 16, 16);
        g.setColor(java.awt.Color.BLACK);
        g.drawRoundRect(x, y, width, height, 16, 16);
        g.drawString("HIGHSCORES", x + 12, y + 24);
        int row = y + 45;
        int max = Math.min(runs.size(), 10);
        for (int i = 0; i < max; i++) {
            Run run = runs.get(i);
            int seconds = run.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + run.name, x + 12, row);
            g.drawString(Integer.toString(run.score), x + width - 105, row);
            g.drawString(time, x + width - 55, row);
            row += 18;
        }
        if (max == 0) g.drawString("No runs recorded", x + 12, row);
        g.drawString("Press H or Escape to return", x + 12, y + height - 12);
    }
}