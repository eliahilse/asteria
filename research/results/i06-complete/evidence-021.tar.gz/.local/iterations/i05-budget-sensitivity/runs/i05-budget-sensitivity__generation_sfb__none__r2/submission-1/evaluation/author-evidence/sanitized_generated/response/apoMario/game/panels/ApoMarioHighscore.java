package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, score-ordered run history. Times are kept in milliseconds. */
public class ApoMarioHighscore {
    private static final class Run {
        private final String name;
        private final int score;
        private final int time;
        private Run(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Unknown" : playerName.trim();
        if (name.length() == 0) {
            name = "Unknown";
        }
        runs.add(new Run(name, score, Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score));
                    writer.write('\t');
                    writer.write(Integer.toString(run.time));
                    writer.write('\t');
                    writer.write(run.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " "));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
        } catch (IOException ignored) {
            // A score must never interrupt the game when storage is unavailable.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (selected == null || player.getPoints() > selected.getPoints())) {
                selected = player;
            }
        }
        if (selected == null) selected = level.getPlayers().get(0);
        String name = selected.getTeamName();
        if ((name == null || name.trim().length() == 0) && selected.getAi() != null) {
            name = selected.getAi().getTeamName();
        }
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\t", 3);
                    if (parts.length == 3) {
                        try {
                            runs.add(new Run(parts[2], Integer.parseInt(parts[0]), Integer.parseInt(parts[1])));
                        } catch (NumberFormatException ignored) { }
                    }
                }
            } finally {
                reader.close();
            }
            sort();
        } catch (IOException ignored) { }
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
    }
}