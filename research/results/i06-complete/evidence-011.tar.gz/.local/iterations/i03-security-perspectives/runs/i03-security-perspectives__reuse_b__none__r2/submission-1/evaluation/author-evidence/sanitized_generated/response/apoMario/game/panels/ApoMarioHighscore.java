package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;

/** Persistent local highscore table. Survival times are kept in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int n = names.size() - 1;
            names.remove(n); scores.remove(n); survivalTimes.remove(n);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(Integer.toString(scores.get(i)));
                    out.write('\t'); out.write(Integer.toString(survivalTimes.get(i)));
                    out.write('\t'); out.write(names.get(i).replace("\\", "\\\\").replace("\t", " "));
                    out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    /** Records the first human player's actual result at the end of a run. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        if (level.isBReplay()) return;
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    /** Draws the board; time is converted to mm:ss only at this rendering boundary. */
    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(new Color(255,255,255,235));
        g.fillRoundRect(x, y, width, 390, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, 390, 18, 18);
        g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.drawString("HIGHSCORES", x + 24, y + 34);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int rows = Math.min(names.size(), 12);
        for (int i = 0; i < rows; i++) {
            int seconds = survivalTimes.get(i) / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
            g.drawString((i + 1) + ".", x + 22, y + 65 + i * 25);
            g.drawString(names.get(i), x + 58, y + 65 + i * 25);
            g.drawString(Integer.toString(scores.get(i)), x + width - 145, y + 65 + i * 25);
            g.drawString(time, x + width - 75, y + 65 + i * 25);
        }
        if (rows == 0) g.drawString("No runs recorded", x + 24, y + 72);
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        scores.add(Integer.valueOf(p[0])); survivalTimes.add(Integer.valueOf(p[1]));
                        names.add(p[2].replace("\\\\", "\\"));
                    }
                }
            } finally { in.close(); }
            sort();
        } catch (Exception ignored) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(survivalTimes.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
}