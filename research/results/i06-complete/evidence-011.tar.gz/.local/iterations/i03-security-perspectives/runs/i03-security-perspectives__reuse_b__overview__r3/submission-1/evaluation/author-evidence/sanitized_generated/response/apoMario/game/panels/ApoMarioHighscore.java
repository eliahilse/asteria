package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local highscore table. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 1000;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name;
        final int score;
        final int time;
        Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 40) name = name.substring(0, 40);
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sort();
        if (entries.size() > MAX_ENTRIES) entries.subList(MAX_ENTRIES, entries.size()).clear();
        return persist();
    }

    /** Records the authoritative post-scoring result of a live level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.getAi() == null && player.isBVisible()) { chosen = player; break; }
        }
        if (chosen == null) chosen = level.getPlayers().get(0);
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed;
        try { elapsed = level.getPassedTime(); } catch (RuntimeException ex) { elapsed = 0; }
        storeRun(chosen.getPoints(), elapsed, name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() { persist(); }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try { entries.add(new Entry(p[0], Integer.parseInt(p[1]), Math.max(0, Integer.parseInt(p[2])))); }
                catch (NumberFormatException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8)) {
                for (Entry e : entries) writer.write(e.name.replace('\t', ' ') + "\t" + e.score + "\t" + e.time + "\n");
            }
            return true;
        } catch (IOException ex) { return false; }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    /** Small renderer used by the menu's dedicated highscore mode. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 30,  forty(height));
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int y = forty(height) + 35;
        for (int i = 0; i < entries.size() && i < 20; i++) {
            Entry e = entries.get(i);
            g.drawString((i + 1) + ". " + e.name, 40, y);
            g.drawString(String.valueOf(e.score), width / 2, y);
            g.drawString(formatTime(e.time), width - 100, y);
            y += 24;
        }
        g.drawString("ESC: back", 30, height - 20);
    }
    private int forty(int height) { return Math.min(45, Math.max(25, height / 8)); }
    private String formatTime(int millis) {
        long seconds = Math.max(0, millis) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}