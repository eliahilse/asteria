package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Dedicated highscore board renderer used by the menu. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore score, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> names = score.getPlayersNames(); List<Integer> points = score.getPlayersScores(); List<Integer> times = score.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 20; i++) {
            int seconds = times.get(i) / 1000;
            String name = names.get(i); if (name.length() > 24) name = name.substring(0, 24);
            int y = 80 + i * 24;
            g.drawString(String.valueOf(i + 1), 35, y); g.drawString(name, 75, y);
            g.drawString(String.valueOf(points.get(i)), 330, y);
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 430, y);
        }
        g.drawString("Press H or ESC to return", 30, height - 25);
    }
}