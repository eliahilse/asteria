package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;
import apoMario.game.panels.ApoMarioModel;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.List;
import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;
public class ApoMarioHighscorePanel extends ApoMarioModel {
 private final ApoMarioHighscore scores;
 public ApoMarioHighscorePanel(ApoMarioPanel p,ApoMarioHighscore s){super(p);scores=s;}
 public void init(){}
 public void think(int d){}
 public void keyButtonReleased(int k,char c){if(k==KeyEvent.VK_ESCAPE||k==KeyEvent.VK_H)getGame().setMenu();}
 public void mouseButtonFunction(String f){if("back".equals(f))getGame().setMenu();}
 public void mouseButtonReleased(int x,int y){}
 public boolean mouseMoved(int x,int y){return false;}
 public boolean mousePressed(int x,int y,boolean b){return false;}
 public boolean mouseDragged(int x,int y){return false;}
 public void render(Graphics2D g){g.setColor(Color.WHITE);g.fillRect(0,0,ApoMarioConstants.GAME_WIDTH,ApoMarioConstants.GAME_HEIGHT);g.setColor(Color.BLACK);g.setFont(ApoMarioConstants.FONT_MENU);g.drawString("HIGHSCORES",30,45);List<String> n=scores.getPlayersNames();List<Integer> s=scores.getPlayersScores();List<Integer> t=scores.getSurvivalTimes();for(int i=0;i<n.size()&&i<20;i++){int y=85+i*25;g.drawString((i+1)+".",35,y);g.drawString(n.get(i),75,y);g.drawString(String.valueOf(s.get(i)),300,y);g.drawString(fmt(t.get(i)),420,y);}}
 private String fmt(int m){long x=Math.max(0,m)/1000L;return String.format("%02d:%02d",x/60,x%60);}
}