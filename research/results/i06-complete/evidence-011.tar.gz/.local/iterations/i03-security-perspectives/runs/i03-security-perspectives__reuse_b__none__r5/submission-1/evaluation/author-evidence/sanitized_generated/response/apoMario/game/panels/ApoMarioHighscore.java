package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, local highscore table. Survival times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < scores.size(); i++) {
                    out.write(Integer.toString(scores.get(i)));
                    out.write('\t');
                    out.write(Integer.toString(survivalTimes.get(i)));
                    out.write('\t');
                    out.write(names.get(i).replace('\t', ' ').replace('\n', ' '));
                    out.newLine();
                }
            } finally { out.close(); }
        } catch (IOException ignored) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player != null) storeRun(player.getPoints(), level.getPassedTime(), player.getPlayer());
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) {
                        try {
                            scores.add(Integer.valueOf(p[0]));
                            survivalTimes.add(Integer.valueOf(p[1]));
                            names.add(p[2]);
                        } catch (NumberFormatException ignored) { }
                    }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private void sortAndTrim() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        ArrayList<String> n = new ArrayList<String>();
        ArrayList<Integer> s = new ArrayList<Integer>();
        ArrayList<Integer> t = new ArrayList<Integer>();
        for (int j = 0; j < order.size() && j < MAX_ENTRIES; j++) {
            int i = order.get(j).intValue(); n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i));
        }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
}