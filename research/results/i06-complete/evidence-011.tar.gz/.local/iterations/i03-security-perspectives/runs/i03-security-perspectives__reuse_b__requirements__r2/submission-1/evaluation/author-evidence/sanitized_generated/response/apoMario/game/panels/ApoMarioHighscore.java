package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Local, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 1000;
    private static final int MAX_NAME = 32;
    private static final String HEADER = "APO-MARIO-HIGHSCORE-1";
    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final String name; final int score; final int time; final long order;
        Run(String name, int score, int time, long order) { this.name=name; this.score=score; this.time=time; this.order=order; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store == null ? Paths.get(System.getProperty("user.home", "."), ".apomario-highscore") : store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || playerName == null || playerName.length() == 0 || playerName.length() > MAX_NAME) return false;
        for (int i=0; i<playerName.length(); i++) {
            char c=playerName.charAt(i);
            if (Character.isISOControl(c) || Character.isSurrogate(c)) return false;
        }
        String name=playerName.trim();
        if (name.length()==0) return false;
        runs.add(new Run(name, score, survivalTime, System.nanoTime()));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> r=new ArrayList<String>(); for(Run x:runs) r.add(x.name); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> r=new ArrayList<Integer>(); for(Run x:runs) r.add(x.score); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> r=new ArrayList<Integer>(); for(Run x:runs) r.add(x.time); return Collections.unmodifiableList(r);
    }

    public synchronized void persistAcrossRuns() {
        Path parent=store.toAbsolutePath().getParent();
        if (parent == null) parent=Paths.get(".").toAbsolutePath();
        try {
            Files.createDirectories(parent);
            Path tmp=Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter w=Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                w.write(HEADER); w.newLine();
                for(Run x:runs) { w.write(Integer.toString(x.score)); w.write('\t'); w.write(Integer.toString(x.time)); w.write('\t'); w.write(Base64.getEncoder().encodeToString(x.name.getBytes(StandardCharsets.UTF_8))); w.newLine(); }
            } finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* retain the valid in-memory table */ }
    }

    private synchronized void load() {
        if (!Files.isRegularFile(store)) return;
        ArrayList<Run> loaded=new ArrayList<Run>();
        try {
            BufferedReader r=Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!HEADER.equals(r.readLine())) return;
                String line; int n=0;
                while((line=r.readLine())!=null && n++<MAX_ENTRIES) {
                    String[] p=line.split("\\t",-1); if(p.length!=3) continue;
                    int score=Integer.parseInt(p[0]), time=Integer.parseInt(p[1]);
                    String name=new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                    if(score>=0 && time>=0 && name.length()>0 && name.length()<=MAX_NAME) loaded.add(new Run(name,score,time,n));
                }
            } finally { r.close(); }
            runs.clear(); runs.addAll(loaded); sortAndTrim();
        } catch (Exception ex) { /* malformed stores are ignored atomically */ }
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { int c=Integer.compare(b.score,a.score); return c!=0?c:Long.compare(a.order,b.order); }});
        while(runs.size()>MAX_ENTRIES) runs.remove(runs.size()-1);
    }
    private static String time(int ms) { long sec=ms/1000L; return String.format("%02d:%02d", sec/60L, sec%60L); }

    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(245,245,245)); g.fillRect(0,0,ApoMarioConstants.GAME_WIDTH,ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 30, 45); g.setFont(new Font("Dialog",Font.PLAIN,16));
        int y=78, rows=Math.min(20,runs.size());
        for(int i=0;i<rows;i++) { Run x=runs.get(i); g.drawString((i+1)+". "+x.name,30,y); g.drawString(Integer.toString(x.score),300,y); g.drawString(time(x.time),410,y); y+=24; }
        if(rows==0) g.drawString("No runs recorded yet.",30,y);
        g.drawString("Press H or Escape to return",30,ApoMarioConstants.GAME_HEIGHT-20);
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if(level==null || level.getPlayers()==null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p=level.getPlayers().get(0); if(p==null) return;
        String name=p.getTeamName(); if(name==null || name.trim().length()==0) name="Player";
        storeRun(Math.max(0,p.getPoints()), Math.max(0,level.getPassedTime()), name);
    }
}