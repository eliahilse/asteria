package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, local highscore table. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }
        names.add(playerName.trim());
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        return persistAcrossRunsInternal();
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() { persistAcrossRunsInternal(); }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String score;
            while ((score = reader.readLine()) != null) {
                String time = reader.readLine();
                String name = reader.readLine();
                if (time == null || name == null) break;
                try {
                    scores.add(Integer.valueOf(score));
                    survivalTimes.add(Integer.valueOf(time));
                    names.add(name);
                } catch (NumberFormatException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private boolean persistAcrossRunsInternal() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            try (BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                for (int i = 0; i < scores.size(); i++) {
                    writer.write(String.valueOf(scores.get(i))); writer.newLine();
                    writer.write(String.valueOf(survivalTimes.get(i))); writer.newLine();
                    writer.write(names.get(i).replace('\n', ' ').replace('\r', ' ')); writer.newLine();
                }
            }
            return true;
        } catch (IOException ignored) { return false; }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }
        });
        ArrayList<String> n = new ArrayList<String>();
        ArrayList<Integer> s = new ArrayList<Integer>();
        ArrayList<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    /** Records the first human player when a live run reaches its end. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }
}