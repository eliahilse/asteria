package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Small rendering helper used by the menu for the dedicated highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore score, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("HIGHSCORES", width / 2 - 85, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> names = score.getPlayersNames(); List<Integer> points = score.getPlayersScores();
        List<Integer> times = score.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 15; i++) {
            int seconds = Math.max(0, times.get(i) / 1000);
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            int y = 90 + i * 25;
            g.drawString(Integer.toString(i + 1), 45, y);
            g.drawString(names.get(i), 85, y);
            g.drawString(Integer.toString(points.get(i)), width - 190, y);
            g.drawString(time, width - 95, y);
        }
        g.drawString("Press ESC to return", 45, height - 25);
    }
}