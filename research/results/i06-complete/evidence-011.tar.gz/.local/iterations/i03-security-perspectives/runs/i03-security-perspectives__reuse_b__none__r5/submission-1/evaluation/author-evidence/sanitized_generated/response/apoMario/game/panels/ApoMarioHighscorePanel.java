package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small renderer used by the menu for the local highscore view. */
public final class ApoMarioHighscorePanel {
    private ApoMarioHighscorePanel() { }
    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", ApoMarioConstants.GAME_WIDTH / 2 - 70, 55);
        List<String> n = highscore.getPlayersNames();
        List<Integer> s = highscore.getPlayersScores();
        List<Integer> t = highscore.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 15; i++) {
            int ms = Math.max(0, t.get(i).intValue());
            int sec = ms / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(sec / 60), Integer.valueOf(sec % 60));
            g.drawString((i + 1) + ". " + n.get(i), 90, 95 + i * 25);
            g.drawString(String.valueOf(s.get(i)), 330, 95 + i * 25);
            g.drawString(time, 440, 95 + i * 25);
        }
        g.drawString("ESC - back", 20, ApoMarioConstants.GAME_HEIGHT - 20);
    }
}