package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
 private static final int MAX=100, MAX_NAME=40;
 private final Path store;
 private final List<Entry> entries=new ArrayList<Entry>();
 private static class Entry { int score,time; String name; Entry(int s,int t,String n){score=s;time=t;name=n;} }
 public ApoMarioHighscore(Path store){this.store=store; load();}
 public synchronized boolean storeRun(int score,int survivalTime,String playerName){String n=name(playerName);if(n==null||score<0||survivalTime<0)return false;entries.add(new Entry(score,survivalTime,n));sort();persistAcrossRuns();return true;}
 public synchronized List<String> getPlayersNames(){List<String> r=new ArrayList<String>();for(Entry e:entries)r.add(e.name);return Collections.unmodifiableList(r);}
 public synchronized List<Integer> getPlayersScores(){List<Integer> r=new ArrayList<Integer>();for(Entry e:entries)r.add(e.score);return Collections.unmodifiableList(r);}
 public synchronized List<Integer> getSurvivalTimes(){List<Integer> r=new ArrayList<Integer>();for(Entry e:entries)r.add(e.time);return Collections.unmodifiableList(r);}
 public synchronized void persistAcrossRuns(){if(store==null)return;Path tmp=null;try{Path p=store.toAbsolutePath().getParent();if(p!=null)Files.createDirectories(p);tmp=store.resolveSibling(store.getFileName()+".tmp");BufferedWriter w=Files.newBufferedWriter(tmp,StandardCharsets.UTF_8);try{for(Entry e:entries){w.write(e.score+"\t"+e.time+"\t"+e.name);w.newLine();}}finally{w.close();}try{Files.move(tmp,store,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException x){Files.move(tmp,store,StandardCopyOption.REPLACE_EXISTING);}}catch(IOException x){if(tmp!=null)try{Files.deleteIfExists(tmp);}catch(IOException ignored){}}}
 public synchronized void recordRunEnd(ApoMarioLevel level){if(level==null||level.isBReplay()||level.getPlayers()==null)return;for(ApoMarioPlayer p:level.getPlayers())if(p!=null&&p.getAi()==null&&p.isBVisible()){String n=p.getTeamName();storeRun(p.getPoints(),Math.max(0,level.getPassedTime()),n==null?"Player":n);return;}}
 private void load(){if(store==null||!Files.isRegularFile(store))return;try{BufferedReader r=Files.newBufferedReader(store,StandardCharsets.UTF_8);try{String l;int c=0;while((l=r.readLine())!=null&&c++<MAX){String[] a=l.split("\\t",3);if(a.length!=3)continue;try{int s=Integer.parseInt(a[0]),t=Integer.parseInt(a[1]),n=name(a[2]);if(s>=0&&t>=0&&n!=null)entries.add(new Entry(s,t,n));}catch(NumberFormatException ignored){}}}finally{r.close();}sort();}catch(IOException ignored){entries.clear();}}
 private static String name(String n){if(n==null)return null;n=n.trim();if(n.length()==0||n.length()>MAX_NAME)return null;for(int i=0;i<n.length();i++)if(Character.isISOControl(n.charAt(i)))return null;return n;}
 private void sort(){Collections.sort(entries,new Comparator<Entry>(){public int compare(Entry a,Entry b){return b.score-a.score;}});while(entries.size()>MAX)entries.remove(entries.size()-1);}
}