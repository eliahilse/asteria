package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore highscore, int width) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, 5000);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size(); i++) {
            int y = 90 + i * 24;
            if (y > 440) break;
            int seconds = Math.max(0, times.get(i)) / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString(String.valueOf(i + 1), 90, y);
            g.drawString(names.get(i), 140, y);
            g.drawString(String.valueOf(scores.get(i)), 350, y);
            g.drawString(time, 450, y);
        }
        g.drawString("Press ESC or H to return", 30, 470);
    }
}