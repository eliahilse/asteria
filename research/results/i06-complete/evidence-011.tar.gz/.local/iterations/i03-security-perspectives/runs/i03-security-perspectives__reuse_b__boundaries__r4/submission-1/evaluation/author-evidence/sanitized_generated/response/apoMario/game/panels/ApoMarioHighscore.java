package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local and persistent highscore table. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null) return false;
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the finalized human player's score at the level end boundary. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        for (int i = 0; i < level.getPlayers().size(); i++) {
            ApoMarioPlayer player = level.getPlayers().get(i);
            if (player != null && player.getAi() == null) {
                String name = player.getTeamName();
                if (name == null || name.trim().length() == 0) name = "Player " + (i + 1);
                storeRun(player.getPoints(), level.getPassedTime(), name);
                return;
            }
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) out.write(e.score + "\t" + e.time + "\t" + e.name + "\n");
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* a failed save must not stop the game */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = in.readLine()) != null && entries.size() < MAX_ENTRIES) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3 || p[2].length() > MAX_NAME) continue;
                    try {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        String name = cleanName(p[2]);
                        if (name != null && time >= 0) entries.add(new Entry(score, time, name));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ex) { entries.clear(); }
    }
    private String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return null;
        return s;
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) {
            return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
        }});
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }
    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    /** Menu view; formatting is deliberately done only here (milliseconds remain stored). */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 30, 40);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i); int y = 75 + i * 22;
            g.drawString((i + 1) + ". " + e.name, 35, y);
            g.drawString(String.valueOf(e.score), width / 2, y);
            g.drawString(formatTime(e.time), width - 100, y);
        }
        g.drawString("ESC: back", 30, height - 20);
    }
    private String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}