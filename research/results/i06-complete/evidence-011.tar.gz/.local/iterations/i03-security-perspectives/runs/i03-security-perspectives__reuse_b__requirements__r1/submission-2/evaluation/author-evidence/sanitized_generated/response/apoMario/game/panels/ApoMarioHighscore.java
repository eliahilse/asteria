package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent local highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 1000;
    private static final int MAX_NAME = 40;
    private static final int MAX_TIME = 7 * 24 * 60 * 60 * 1000;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score, time; final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
    private static final Comparator<Run> BY_SCORE = new Comparator<Run>() {
        public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
    };

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || survivalTime > MAX_TIME || playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME) return false;
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (Character.isISOControl(c) || Character.isSurrogate(c)) return false;
        }
        runs.add(new Run(score, survivalTime, name));
        Collections.sort(runs, BY_SCORE);
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
        persistAcrossRuns();
        return true;
    }

    /** Records player one after all final score adjustments have been made. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path tmp = null;
        try {
            Path absolute = store.toAbsolutePath();
            Path parent = absolute.getParent();
            if (parent != null) Files.createDirectories(parent);
            tmp = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(tmp));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run r : runs) { out.writeInt(r.score); out.writeInt(r.time); out.writeUTF(r.name); }
            out.close();
            try { Files.move(tmp, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, absolute, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException | RuntimeException e) {
            if (tmp != null) try { Files.deleteIfExists(tmp); } catch (IOException ignored) { }
        }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        List<Run> loaded = new ArrayList<Run>();
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                int score = in.readInt(), time = in.readInt(); String name = in.readUTF();
                if (score < 0 || time < 0 || time > MAX_TIME || name.length() == 0 || name.length() > MAX_NAME) { in.close(); return; }
                for (int j = 0; j < name.length(); j++) if (Character.isISOControl(name.charAt(j)) || Character.isSurrogate(name.charAt(j))) { in.close(); return; }
                loaded.add(new Run(score, time, name));
            }
            in.close(); Collections.sort(loaded, BY_SCORE); runs.addAll(loaded);
        } catch (IOException | RuntimeException e) { }
    }
}