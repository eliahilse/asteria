package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import java.awt.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final String DEFAULT_NAME = "Player";
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final int score;
        final int time;
        final String name;
        Entry(int score, int time, String name) {
            this.score = score;
            this.time = time;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "" : playerName.trim();
        if (name.length() == 0) name = DEFAULT_NAME;
        if (name.length() > 40) name = name.substring(0, 40);
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sortAndTrim();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    private synchronized void load() {
        entries.clear();
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", 3);
                if (p.length != 3) continue;
                try {
                    entries.add(new Entry(Integer.parseInt(p[0]), Math.max(0, Integer.parseInt(p[1])), p[2]));
                } catch (RuntimeException ignored) { }
            }
            sortAndTrim();
        } catch (IOException ignored) { }
    }

    private synchronized boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                for (Entry e : entries) {
                    String safe = e.name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
                    writer.write(Integer.toString(e.score)); writer.write('\t');
                    writer.write(Integer.toString(e.time)); writer.write('\t');
                    writer.write(safe); writer.newLine();
                }
            }
            try {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    public synchronized void render(java.awt.Graphics2D g, int width, int height) {
        g.setColor(java.awt.Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(java.awt.Color.BLACK); g.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 28));
        g.drawString("Highscores", width / 2 - 75, 55);
        g.setFont(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 18));
        for (int i = 0; i < entries.size() && i < 15; i++) {
            Entry e = entries.get(i); int y = 95 + i * 25;
            g.drawString((i + 1) + ".", 45, y);
            g.drawString(e.name, 85, y);
            g.drawString(Integer.toString(e.score), width - 180, y);
            g.drawString(formatTime(e.time), width - 95, y);
        }
        g.drawString("ESC: back", 20, height - 20);
    }
}