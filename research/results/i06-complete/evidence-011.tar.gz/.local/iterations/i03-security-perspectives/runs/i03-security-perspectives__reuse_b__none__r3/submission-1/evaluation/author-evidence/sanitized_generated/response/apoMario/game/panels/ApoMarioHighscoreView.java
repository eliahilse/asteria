package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Small menu view, intentionally independent of image resources. */
public class ApoMarioHighscoreView {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> n = highscore.getPlayersNames(); List<Integer> s = highscore.getPlayersScores();
        List<Integer> t = highscore.getSurvivalTimes();
        if (n.isEmpty()) g.drawString("No runs recorded yet", width / 2 - 75, 100);
        for (int i = 0; i < n.size() && i < 12; i++) {
            int y = 95 + i * 25;
            int millis = Math.max(0, t.get(i));
            String time = String.format("%02d:%02d", millis / 60000, (millis / 1000) % 60);
            g.drawString(String.valueOf(i + 1), 55, y); g.drawString(n.get(i), 95, y);
            g.drawString(String.valueOf(s.get(i)), width - 180, y); g.drawString(time, width - 95, y);
        }
        g.drawString("Press ESC to return", 20, height - 20);
    }
}