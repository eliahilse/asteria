package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.level.ApoMarioLevel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 32;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = validName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void recordRunEnd(apoMario.level.ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path target = store.toAbsolutePath();
        Path parent = target.getParent();
        if (parent == null) return;
        Path temporary = null;
        try {
            Files.createDirectories(parent);
            temporary = Files.createTempFile(parent, target.getFileName().toString(), ".tmp");
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(temporary));
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(runs.size());
            for (Run run : runs) {
                byte[] bytes = run.name.getBytes(StandardCharsets.UTF_8);
                out.writeInt(run.score);
                out.writeInt(run.time);
                out.writeInt(bytes.length);
                out.write(bytes);
            }
            out.flush();
            out.close();
            try {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
            temporary = null;
        } catch (IOException ex) {
            // Persistence failure must not interrupt gameplay.
        } finally {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ex) { }
        }
    }

    private synchronized void load() {
        if (store == null) return;
        Path target = store.toAbsolutePath();
        try {
            if (!Files.exists(target) || Files.size(target) > MAX_FILE_SIZE) return;
            DataInputStream in = new DataInputStream(Files.newInputStream(target));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt();
                int time = in.readInt();
                int length = in.readInt();
                if (length < 1 || length > MAX_NAME * 4) { in.close(); return; }
                byte[] bytes = new byte[length];
                in.readFully(bytes);
                String name = validName(new String(bytes, StandardCharsets.UTF_8));
                if (name == null || time < 0) { in.close(); return; }
                loaded.add(new Run(score, time, name));
            }
            in.close();
            runs.clear();
            runs.addAll(loaded);
            sortAndTrim();
        } catch (IOException ex) {
            // Keep the valid in-memory state, or the safe empty state on startup.
        }
    }

    private String validName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME) return null;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return null;
        return name;
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                if (first.score != second.score) return second.score < first.score ? -1 : 1;
                return first.name.compareTo(second.name);
            }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("HIGHSCORES", 30, 42);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < runs.size() && i < 15; i++) {
            Run run = runs.get(i);
            int seconds = run.time / 1000;
            String formatted = String.format("%02d:%02d", seconds / 60, seconds % 60);
            int y = 75 + i * 25;
            g.drawString(String.valueOf(i + 1), 35, y);
            g.drawString(run.name, 75, y);
            g.drawString(String.valueOf(run.score), 280, y);
            g.drawString(formatted, 390, y);
        }
        g.drawString("ESC: back", 30, height - 20);
    }
}