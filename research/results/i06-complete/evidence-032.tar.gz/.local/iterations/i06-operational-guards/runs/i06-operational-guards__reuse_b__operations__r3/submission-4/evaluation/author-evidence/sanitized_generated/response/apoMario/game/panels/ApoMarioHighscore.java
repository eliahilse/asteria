package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.AtomicMoveNotSupportedException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private static final class Entry { String name; int score; int time; Entry(String n,int s,int t){name=n;score=s;time=t;} }
    public ApoMarioHighscore(Path store) { if (store == null) throw new IllegalArgumentException("store"); this.store=store; load(); }
    public synchronized boolean storeRun(int score,int survivalTime,String playerName) {
        String n=validName(playerName);
        if(n==null || survivalTime<0 || entries.size()>=MAX_ENTRIES) return false;
        entries.add(new Entry(n,score,survivalTime)); sort(); return true;
    }
    public synchronized List<String> getPlayersNames(){ List<String> r=new ArrayList<String>(); for(Entry e:entries)r.add(e.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores(){ List<Integer> r=new ArrayList<Integer>(); for(Entry e:entries)r.add(e.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes(){ List<Integer> r=new ArrayList<Integer>(); for(Entry e:entries)r.add(e.time); return Collections.unmodifiableList(r); }
    public synchronized void persistAcrossRuns(){
        Path absolute=store.toAbsolutePath(), parent=absolute.getParent(), tmp=null;
        try { if(parent!=null)Files.createDirectories(parent); tmp=Files.createTempFile(parent,absolute.getFileName().toString(),".tmp");
            DataOutputStream out=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)));
            out.writeInt(entries.size()); for(Entry e:entries){out.writeUTF(e.name);out.writeInt(e.score);out.writeInt(e.time);} out.close();
            try{Files.move(tmp,absolute,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException ex){Files.move(tmp,absolute,StandardCopyOption.REPLACE_EXISTING);}
        }catch(IOException ex){if(tmp!=null)try{Files.deleteIfExists(tmp);}catch(IOException ignored){}}
    }
    private void load(){
        try{if(!Files.isRegularFile(store)||Files.size(store)>MAX_FILE_SIZE)return; DataInputStream in=new DataInputStream(new BufferedInputStream(Files.newInputStream(store))); int count=in.readInt(); if(count<0||count>MAX_ENTRIES){in.close();return;} List<Entry> loaded=new ArrayList<Entry>();
            for(int i=0;i<count;i++){String n=in.readUTF();int s=in.readInt(),t=in.readInt();if(validName(n)==null||t<0){in.close();return;}loaded.add(new Entry(n,s,t));}in.close();entries.addAll(loaded);sort();
        }catch(IOException ex){entries.clear();}catch(RuntimeException ex){entries.clear();}
    }
    private void sort(){Collections.sort(entries,new Comparator<Entry>(){public int compare(Entry a,Entry b){int c=b.score-a.score;return c!=0?c:a.name.compareTo(b.name);}});}
    private static String validName(String n){if(n==null)return null;n=n.trim();if(n.length()==0||n.length()>MAX_NAME_LENGTH)return null;for(int i=0;i<n.length();i++)if(Character.isISOControl(n.charAt(i)))return null;return n;}
    public static String formatTime(int millis){long sec=Math.max(0,millis)/1000L;return String.format("%02d:%02d",sec/60,sec%60);}
    public synchronized void render(Graphics2D g,int width,int height){g.setColor(Color.WHITE);g.fillRect(0,0,width,height);g.setColor(Color.BLACK);g.setFont(new Font("Dialog",Font.BOLD,24));g.drawString("HIGHSCORES",width/2-75,45);g.setFont(new Font("Dialog",Font.PLAIN,16));for(int i=0;i<entries.size();i++){int y=80+i*22;if(y>height-25)break;Entry e=entries.get(i);g.drawString((i+1)+". "+e.name,30,y);g.drawString(String.valueOf(e.score),width/2,y);g.drawString(formatTime(e.time),width-100,y);}g.drawString("ESC: back",30,height-10);}
    public void recordRunEnd(ApoMarioLevel level){if(level==null||level.getPlayers()==null||level.getPlayers().isEmpty())return;ApoMarioPlayer p=level.getPlayers().get(0);String n=p.getTeamName();if(n==null||n.trim().length()==0)n="Player";if(storeRun(p.getPoints(),Math.max(0,level.getPassedTime()),n))persistAcrossRuns();}
}