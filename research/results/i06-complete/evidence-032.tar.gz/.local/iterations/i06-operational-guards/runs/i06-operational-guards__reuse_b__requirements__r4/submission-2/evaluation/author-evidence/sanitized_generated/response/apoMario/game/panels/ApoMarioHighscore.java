package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed, bounded highscore table. Times are retained in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;

    private static final class Run {
        final String name; final int score; final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalizeName(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        runs.add(new Run(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    /** Records the finished human run after the level has finalized its score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(Math.max(0, player.getPoints()), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run r : runs) { out.writeUTF(r.name); out.writeInt(r.score); out.writeInt(r.time); }
            out.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A read-only score file must not stop the game. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                String name = normalizeName(in.readUTF()); int score = in.readInt(); int time = in.readInt();
                if (name != null && score >= 0 && time >= 0) runs.add(new Run(name, score, time));
            }
            in.close(); sortAndTrim();
        } catch (IOException ex) { runs.clear(); }
    }

    private String normalizeName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME) return null;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return null;
        return name;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
}