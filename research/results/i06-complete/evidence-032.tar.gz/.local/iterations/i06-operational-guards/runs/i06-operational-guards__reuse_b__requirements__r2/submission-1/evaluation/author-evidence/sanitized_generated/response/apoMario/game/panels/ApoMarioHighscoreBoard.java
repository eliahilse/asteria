package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreBoard;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

/** Small reusable renderer for the menu highscore board. */
public final class ApoMarioHighscoreBoard {
    private ApoMarioHighscoreBoard() { }
    public static void render(Graphics2D g, ApoMarioHighscore h, int width) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, 360);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", width / 2 - 75, 38);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        for (int i = 0; i < h.getPlayersNames().size() && i < 12; i++) {
            int y = 70 + i * 23; int ms = h.getSurvivalTimes().get(i); int sec = ms / 1000;
            String time = String.format("%02d:%02d", sec / 60, sec % 60);
            g.drawString((i + 1) + ". " + h.getPlayersNames().get(i), 35, y);
            g.drawString(String.valueOf(h.getPlayersScores().get(i)), 260, y);
            g.drawString(time, 340, y);
        }
        g.drawString("ESC: back", 35, 345);
    }
}