package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** File-backed, bounded high-score table. Times are always milliseconds. */
public final class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Record> records = new ArrayList<Record>();

    private static final class Record {
        final String name; final int score; final int time;
        Record(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        records.add(new Record(playerName.trim(), score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path tmp = null;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (Record r : records) out.write(r.score + "\t" + r.time + "\t" + r.name.replace("\\", "\\\\").replace("\t", " "));
                out.newLine();
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            if (tmp != null) try { Files.deleteIfExists(tmp); } catch (IOException ignored) { }
        }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while (count < MAX_ENTRIES && (line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3 || p[2].length() > MAX_NAME) continue;
                    try {
                        int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                        if (score >= 0 && time >= 0 && validName(p[2])) { records.add(new Record(p[2], score, time)); count++; }
                    } catch (NumberFormatException ignored) { }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ignored) { records.clear(); }
    }
    private static boolean validName(String value) {
        if (value == null) return false;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }
    private void sortAndTrim() {
        Collections.sort(records, new Comparator<Record>() { public int compare(Record a, Record b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (records.size() > MAX_ENTRIES) records.remove(records.size() - 1);
    }
}