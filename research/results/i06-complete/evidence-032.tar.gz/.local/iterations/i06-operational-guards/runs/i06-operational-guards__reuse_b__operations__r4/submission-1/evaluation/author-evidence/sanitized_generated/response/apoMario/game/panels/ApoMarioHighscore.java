package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, local highscore table. Durations are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        runs.add(new Run(score, survivalTime, playerName.trim()));
        sortAndTrim();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> r = new ArrayList<String>(); for (Run x : runs) r.add(x.name); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.score); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.time); return Collections.unmodifiableList(r);
    }

    public synchronized void persistAcrossRuns() { persist(); }

    /** Records the final, authoritative player score after level analysis. */
    public synchronized boolean recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return false;
        ApoMarioPlayer p = level.getPlayers().get(0);
        if (p == null || p.getAi() != null || !p.isBVisible()) return false;
        String name = p.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        return storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void renderBoard(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < runs.size() && i < 15; i++) {
            Run r = runs.get(i); int y = 80 + i * 25;
            g.drawString(String.valueOf(i + 1), 35, y);
            g.drawString(r.name, 75, y);
            g.drawString(String.valueOf(r.score), 300, y);
            int seconds = r.time / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 410, y);
        }
        g.drawString("ESC: back", 30, height - 20);
    }

    private boolean validName(String n) {
        if (n == null || n.trim().length() == 0 || n.length() > MAX_NAME) return false;
        for (int i = 0; i < n.length(); i++) if (Character.isISOControl(n.charAt(i))) return false;
        return true;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); } });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024 * 1024) return;
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8); String s;
            while ((s = r.readLine()) != null && runs.size() < MAX_RECORDS) {
                String[] p = s.split("\\t", -1); if (p.length != 3) continue;
                try { int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]); if (validName(p[2]) && score >= 0 && time >= 0) runs.add(new Run(score, time, p[2])); } catch (NumberFormatException e) { }
            }
            r.close(); sortAndTrim();
        } catch (IOException e) { }
    }
    private boolean persist() {
        if (store == null) return false;
        Path tmp = null;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            tmp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            for (Run r : runs) w.write(r.score + "\t" + r.time + "\t" + r.name + "\n");
            w.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException e) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException e) { if (tmp != null) try { Files.deleteIfExists(tmp); } catch (IOException x) { } return false; }
    }
    private static final class Run { final int score, time; final String name; Run(int s, int t, String n) { score=s; time=t; name=n; } }
}