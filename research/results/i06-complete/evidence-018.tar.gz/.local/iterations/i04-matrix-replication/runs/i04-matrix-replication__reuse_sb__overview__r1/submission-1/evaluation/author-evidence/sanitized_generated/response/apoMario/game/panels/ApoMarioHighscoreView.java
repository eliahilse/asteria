package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioModel;
import java.util.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscoreView extends ApoMarioModel {
    public static final String FUNCTION_BACK = "highscoreBack";
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioPanel game, ApoMarioHighscore highscore) { super(game); this.highscore = highscore; }
    public void init() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if (FUNCTION_BACK.equals(function)) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(new Color(245,245,245)); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 20, 35);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        java.util.List<String> names = highscore.getPlayersNames();
        java.util.List<Integer> scores = highscore.getPlayersScores();
        java.util.List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 65 + i * 17;
            g.drawString((i + 1) + ".", 18, y);
            g.drawString(names.get(i), 45, y);
            g.drawString(String.valueOf(scores.get(i)), 190, y);
            g.drawString(formatTime(times.get(i)), 250, y);
        }
        g.setFont(new Font("Dialog", Font.PLAIN, 11));
        g.drawString("ESC: back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
    private String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }
}