package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Local, durable highscore table. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sort();
        try { persistAcrossRuns(); return true; }
        catch (RuntimeException ex) { entries.remove(find(name, score, Math.max(0, survivalTime))); return false; }
    }

    private int find(String n, int s, int t) {
        for (int i = entries.size() - 1; i >= 0; i--) if (entries.get(i).name.equals(n) && entries.get(i).score == s && entries.get(i).time == t) return i;
        return -1;
    }

    public synchronized List<String> getPlayersNames() { List<String> r = new ArrayList<String>(); for (Entry e: entries) r.add(e.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r = new ArrayList<Integer>(); for (Entry e: entries) r.add(e.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r = new ArrayList<Integer>(); for (Entry e: entries) r.add(e.time); return Collections.unmodifiableList(r); }

    public synchronized void persistAcrossRuns() {
        if (store == null) throw new IllegalStateException("No highscore store");
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { for (Entry e: entries) w.write(e.score + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " ").replace("\r", " ") + "\n"); }
            finally { w.close(); }
            try { Files.move(tmp, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(tmp, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { throw new IllegalStateException("Could not persist highscores", ex); }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = level.getPlayers().get(0);
        if (!selected.isBVisible() && level.getPlayers().size() > 1 && level.getPlayers().get(1).isBVisible()) selected = level.getPlayers().get(1);
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = selected.getAuthor();
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    private String cleanName(String name) {
        if (name == null || name.trim().length() == 0) return "Player";
        String s = name.trim().replace('\t', ' ').replace('\r', ' ').replace('\n', ' ');
        return s.length() > 32 ? s.substring(0, 32) : s;
    }
    private void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } }); }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8); String line;
            while ((line = r.readLine()) != null) { try { String[] p = line.split("\\t", 3); if (p.length == 3) entries.add(new Entry(cleanName(p[2]), Integer.parseInt(p[0]), Math.max(0, Integer.parseInt(p[1])))); } catch (RuntimeException ignored) {} }
            r.close(); sort();
        } catch (IOException ignored) { entries.clear(); }
    }
}