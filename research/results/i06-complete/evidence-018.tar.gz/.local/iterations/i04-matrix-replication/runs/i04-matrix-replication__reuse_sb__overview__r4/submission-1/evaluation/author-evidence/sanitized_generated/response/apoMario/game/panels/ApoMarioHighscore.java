package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, deliberately network-free highscore table and its small menu view. */
public class ApoMarioHighscore {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        if (store == null) {
            throw new IllegalArgumentException("store must not be null");
        }
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(names);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(scores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(times);
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Records the final player state, after ApoMarioLevel has applied end bonuses. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && player.getPoints() > selected.getPoints()) {
                selected = player;
            }
        }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < 24; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\t' && c != '\r' && c != '\n') result.append(c);
        }
        String s = result.toString().trim();
        return s.length() == 0 ? "Player" : s;
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    private void load() {
        if (!Files.isRegularFile(store)) return;
        try {
            for (String line : Files.readAllLines(store, UTF8)) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    String name = new String(Base64.getDecoder().decode(p[2]), UTF8);
                    names.add(cleanName(name)); scores.add(Integer.valueOf(p[0]));
                    times.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[1]))));
                } catch (IllegalArgumentException ex) { /* ignore one corrupt record */ }
            }
            sort();
        } catch (Exception ex) { names.clear(); scores.clear(); times.clear(); }
    }

    private boolean persist() {
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < scores.size(); i++) {
                lines.add(scores.get(i) + "\t" + times.get(i) + "\t" + Base64.getEncoder().encodeToString(names.get(i).getBytes(UTF8)));
            }
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            Files.write(temp, lines, UTF8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (Exception ex) { return false; }
    }

    /** Renders the dedicated menu view; time is converted to mm:ss only here. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
        g.drawString("HIGHSCORES", width / 2 - 65, 35);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        int y = 65;
        for (int i = 0; i < scores.size() && i < 12; i++) {
            int ms = times.get(i).intValue(); int sec = ms / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(sec / 60), Integer.valueOf(sec % 60));
            g.drawString((i + 1) + ".", 25, y); g.drawString(names.get(i), 55, y);
            g.drawString(String.valueOf(scores.get(i)), width / 2, y); g.drawString(time, width - 70, y); y += 20;
        }
        g.drawString("ESC: back", 10, height - 10);
    }
}