package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Local, deliberately network-free highscore store. */
public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 1000;
    private static final int MAX_NAME_LENGTH = 80;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        String name; int score; int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        entries.add(new Entry(name, score, Math.max(0, survivalTime)));
        sort();
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() { persist(); }

    /** Records the best player in the completed run, after completion scoring. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && player.isBVisible() && (selected == null || player.getPoints() > selected.getPoints())) selected = player;
        }
        if (selected == null) selected = level.getPlayers().get(0);
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127) b.append(c);
        }
        String result = b.toString().trim();
        return result.length() == 0 ? "Player" : result;
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)))) {
            if (in.readInt() != VERSION) return;
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES) return;
            for (int i = 0; i < count; i++) {
                String name = in.readUTF();
                int score = in.readInt();
                int time = in.readInt();
                if (name.length() <= MAX_NAME_LENGTH && time >= 0) entries.add(new Entry(cleanName(name), score, time));
            }
            sort();
        } catch (IOException ex) {
            entries.clear();
        }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            out.writeInt(VERSION);
            out.writeInt(entries.size());
            for (Entry e : entries) { out.writeUTF(e.name); out.writeInt(e.score); out.writeInt(e.time); }
            out.close();
            try { Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) { return false; }
    }
}