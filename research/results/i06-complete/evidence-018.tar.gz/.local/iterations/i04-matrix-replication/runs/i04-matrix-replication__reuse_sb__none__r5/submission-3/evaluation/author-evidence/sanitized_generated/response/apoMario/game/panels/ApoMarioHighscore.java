package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String n = playerName == null ? "Player" : playerName.trim();
        if (n.length() == 0) n = "Player";
        names.add(n); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(Math.max(0, survivalTime))); sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path p = store.toAbsolutePath().getParent(); if (p != null) Files.createDirectories(p);
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(store, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE));
            out.writeInt(names.size());
            for (int i=0;i<names.size();i++) { out.writeUTF(names.get(i)); out.writeInt(scores.get(i).intValue()); out.writeInt(times.get(i).intValue()); }
            out.close();
        } catch (IOException ignored) { }
    }
    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store)); int count=in.readInt();
            if (count < 0 || count > 10000) { in.close(); return; }
            for (int i=0;i<count;i++) { names.add(in.readUTF()); scores.add(Integer.valueOf(in.readInt())); times.add(Integer.valueOf(in.readInt())); }
            in.close(); sort();
        } catch (IOException ignored) { names.clear(); scores.clear(); times.clear(); }
    }
    private void sort() {
        List<Integer> order=new ArrayList<Integer>(); for(int i=0;i<names.size();i++) order.add(Integer.valueOf(i));
        Collections.sort(order,new Comparator<Integer>() { public int compare(Integer a,Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }});
        List<String> n=new ArrayList<String>(); List<Integer> s=new ArrayList<Integer>(); List<Integer> t=new ArrayList<Integer>();
        for(Integer i:order){n.add(names.get(i.intValue()));s.add(scores.get(i.intValue()));t.add(times.get(i.intValue()));}
        names.clear();names.addAll(n);scores.clear();scores.addAll(s);times.clear();times.addAll(t);
    }
    public boolean recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return false;
        ApoMarioPlayer p=level.getPlayers().get(0); return storeRun(p.getPoints(), level.getPassedTime(), p.getTeamName());
    }
    public static String formatTime(int millis) { int sec=Math.max(0,millis)/1000; return String.format("%02d:%02d",Integer.valueOf(sec/60),Integer.valueOf(sec%60)); }
}