package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;
public class ApoMarioHighscorePanel {
 private final ApoMarioHighscore highscore;
 public ApoMarioHighscorePanel(ApoMarioHighscore highscore){this.highscore=highscore;}
 public void render(Graphics2D g){
  g.setColor(Color.WHITE);g.fillRect(20,20,ApoMarioConstants.GAME_WIDTH-40,ApoMarioConstants.GAME_HEIGHT-40);g.setColor(Color.BLACK);
  g.setFont(ApoMarioConstants.FONT_CREDITS);g.drawString("HIGHSCORES",90,55);List<String> n=highscore.getPlayersNames();List<Integer>s=highscore.getPlayersScores();List<Integer>t=highscore.getSurvivalTimes();g.setFont(ApoMarioConstants.FONT_STATISTICS);
  for(int i=0;i<n.size()&&i<10;i++){int y=85+i*15;g.drawString(String.valueOf(i+1),35,y);g.drawString(n.get(i),65,y);g.drawString(String.valueOf(s.get(i)),205,y);g.drawString(ApoMarioHighscore.formatTime(t.get(i)),260,y);}g.drawString("ESC: back",110,ApoMarioConstants.GAME_HEIGHT-20);
 }
}