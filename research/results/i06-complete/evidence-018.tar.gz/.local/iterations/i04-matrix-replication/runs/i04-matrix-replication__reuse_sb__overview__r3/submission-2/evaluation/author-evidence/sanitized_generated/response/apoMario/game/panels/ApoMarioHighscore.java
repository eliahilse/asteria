package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        names.add(cleanName(playerName)); scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime))); sort();
        while (names.size() > MAX_ENTRIES) { int i = names.size() - 1; names.remove(i); scores.remove(i); survivalTimes.remove(i); }
        persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        storeRun(player.getPoints(), level.getPassedTime(), name == null ? "Player" : name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(temp));
            out.writeInt(VERSION); out.writeInt(names.size());
            for (int i = 0; i < names.size(); i++) { out.writeUTF(names.get(i)); out.writeInt(scores.get(i)); out.writeInt(survivalTimes.get(i)); }
            out.close();
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt(); if (count < 0 || count > MAX_ENTRIES) { in.close(); return; }
            for (int i = 0; i < count; i++) { names.add(cleanName(in.readUTF())); scores.add(in.readInt()); survivalTimes.add(Math.max(0, in.readInt())); }
            in.close(); sort();
        } catch (IOException ex) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }
    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>(); for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); } });
        ArrayList<String> n = new ArrayList<String>(); ArrayList<Integer> s = new ArrayList<Integer>(); ArrayList<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); scores.clear(); survivalTimes.clear(); names.addAll(n); scores.addAll(s); survivalTimes.addAll(t);
    }
    private static String cleanName(String value) {
        if (value == null) return "Player"; String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        if (s.length() == 0) s = "Player"; return s.length() > 24 ? s.substring(0, 24) : s;
    }
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245, 235)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 22)); g.drawString("HIGHSCORES", width / 2 - 70, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        for (int i = 0; i < names.size() && i < 10; i++) { int y = 65 + i * 18; int seconds = survivalTimes.get(i) / 1000;
            g.drawString(String.valueOf(i + 1), 18, y); g.drawString(names.get(i), 48, y); g.drawString(String.valueOf(scores.get(i)), width - 105, y);
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 55, y); }
        g.drawString("ESC / H: back", 15, height - 12);
    }
}