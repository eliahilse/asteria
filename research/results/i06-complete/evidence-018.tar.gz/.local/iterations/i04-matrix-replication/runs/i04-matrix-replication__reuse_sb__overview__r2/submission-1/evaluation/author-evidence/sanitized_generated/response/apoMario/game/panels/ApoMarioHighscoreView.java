package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;
import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Dedicated menu view for the local Mario highscore table. */
public class ApoMarioHighscoreView {
    private final ApoMarioPanel game;
    public ApoMarioHighscoreView(ApoMarioPanel game) { this.game = game; }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", ApoMarioConstants.GAME_WIDTH / 2 - 65, 35);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        List<String> n = game.getHighscore().getPlayersNames(); List<Integer> s = game.getHighscore().getPlayersScores(); List<Integer> t = game.getHighscore().getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 10; i++) {
            int y = 65 + i * 16; int seconds = t.get(i) / 1000;
            g.drawString((i + 1) + ". " + n.get(i), 25, y);
            g.drawString(String.valueOf(s.get(i)), 185, y);
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 245, y);
        }
        g.drawString("ESC / H: back", 25, ApoMarioConstants.GAME_HEIGHT - 12);
    }
    public boolean handlesKey(int key) { return key == KeyEvent.VK_ESCAPE || key == KeyEvent.VK_H; }
}