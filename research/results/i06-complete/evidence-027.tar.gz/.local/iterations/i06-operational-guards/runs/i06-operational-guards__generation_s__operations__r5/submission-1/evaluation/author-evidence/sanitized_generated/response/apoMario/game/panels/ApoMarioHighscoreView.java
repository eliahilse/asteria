package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Dedicated lightweight menu view for the persistent highscore board. */
public class ApoMarioHighscoreView {
    private final ApoMarioPanel game;
    public ApoMarioHighscoreView(ApoMarioPanel game) { this.game = game; }
    public void render(Graphics2D g) {
        ApoMarioHighscore h = game.getHighscore();
        List<String> n = h.getPlayersNames(); List<Integer> s = h.getPlayersScores(); List<Integer> t = h.getSurvivalTimes();
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20, 20, ApoMarioConstants.GAME_WIDTH-40, ApoMarioConstants.GAME_HEIGHT-40, 20, 20);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 40, 55);
        g.setFont(ApoMarioConstants.FONT_MENU);
        if (n.isEmpty()) { g.drawString("No runs recorded", 45, 90); return; }
        int rows = Math.min(10, n.size());
        for (int i=0; i<rows; i++) {
            int ms = t.get(i); int sec = ms / 1000;
            String time = String.format("%02d:%02d", sec / 60, sec % 60);
            g.drawString((i+1)+". "+n.get(i), 45, 90+i*22);
            g.drawString(Integer.toString(s.get(i)), 210, 90+i*22);
            g.drawString(time, 270, 90+i*22);
        }
        g.drawString("Press H or Escape to return", 45, ApoMarioConstants.GAME_HEIGHT-30);
    }
}