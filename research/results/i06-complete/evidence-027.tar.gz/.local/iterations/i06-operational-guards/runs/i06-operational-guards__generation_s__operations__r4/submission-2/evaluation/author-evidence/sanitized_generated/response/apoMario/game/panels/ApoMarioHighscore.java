package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score;
        final int survivalTime;
        final String name;
        Run(int score, int survivalTime, String name) { this.score = score; this.survivalTime = survivalTime; this.name = name; }
    }

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        return persistFile();
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.survivalTime);
        return Collections.unmodifiableList(result);
    }
    public synchronized void persistAcrossRuns() { persistFile(); }

    private String cleanName(String value) {
        if (value == null) return null;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c) && c != '|') result.append(c);
        }
        String name = result.toString().trim();
        return name.length() == 0 ? "Player" : name;
    }
    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run first, Run second) {
                if (first.score != second.score) return first.score > second.score ? -1 : 1;
                return first.name.compareTo(second.name);
            }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 65536L) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line;
            int count = 0;
            while ((line = reader.readLine()) != null && count++ < MAX_RECORDS) {
                String[] fields = line.split("\\|", -1);
                if (fields.length != 3 || fields[2].length() > MAX_NAME_LENGTH) continue;
                try {
                    int score = Integer.parseInt(fields[0]);
                    int time = Integer.parseInt(fields[1]);
                    String name = cleanName(fields[2]);
                    if (time >= 0 && name != null) runs.add(new Run(score, time, name));
                } catch (NumberFormatException ignored) { }
            }
            reader.close();
            sortAndTrim();
        } catch (IOException ignored) { runs.clear(); }
    }
    private boolean persistFile() {
        if (store == null) return false;
        Path absolute = store.toAbsolutePath();
        Path parent = absolute.getParent();
        Path temporary = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temporary = Files.createTempFile(parent, absolute.getFileName().toString(), ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            for (Run run : runs) {
                writer.write(Integer.toString(run.score));
                writer.write('|');
                writer.write(Integer.toString(run.survivalTime));
                writer.write('|');
                writer.write(run.name);
                writer.newLine();
            }
            writer.close();
            try { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
            return false;
        }
    }
}