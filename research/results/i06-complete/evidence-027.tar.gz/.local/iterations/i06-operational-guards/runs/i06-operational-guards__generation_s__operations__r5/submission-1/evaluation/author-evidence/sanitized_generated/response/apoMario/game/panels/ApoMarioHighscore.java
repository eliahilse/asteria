package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, bounded highscore table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 32;
    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String cleanName(String name) {
        if (name == null) return null;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < name.length() && b.length() < MAX_NAME; i++) {
            char c = name.charAt(i);
            if (c >= 32 && c != '\t' && c != '\r' && c != '\n') b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? null : s;
    }

    private void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? a.name.compareTo(b.name) : (a.score < b.score ? 1 : -1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) return false;
        runs.add(new Run(score, survivalTime, name));
        sort();
        return persist();
    }

    /** Records the first eligible human player in the finished level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null) return;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null) {
                String name = p.getTeamName();
                if (name == null || name.trim().length() == 0) name = "Player";
                int elapsed = level.getPassedTime();
                if (elapsed < 0) elapsed = 0;
                storeRun(p.getPoints(), elapsed, name);
                return;
            }
        }
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> r = new ArrayList<String>(); for (Run x : runs) r.add(x.name); return r;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.score); return r;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> r = new ArrayList<Integer>(); for (Run x : runs) r.add(x.time); return r;
    }
    public synchronized void persistAcrossRuns() { persist(); }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 65536) return;
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            String line; int count = 0;
            while ((line = r.readLine()) != null && count++ < MAX_RECORDS) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    String name = cleanName(p[2]);
                    if (name != null && time >= 0) runs.add(new Run(score, time, name));
                } catch (NumberFormatException ignored) { }
            }
            r.close(); sort();
        } catch (IOException ignored) { runs.clear(); }
    }

    private boolean persist() {
        if (store == null) return false;
        Path parent = store.toAbsolutePath().getParent();
        try {
            if (parent != null) Files.createDirectories(parent);
            Path tmp = Files.createTempFile(parent, store.getFileName().toString(), ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            for (Run x : runs) { w.write(Integer.toString(x.score)); w.write('\t'); w.write(Integer.toString(x.time)); w.write('\t'); w.write(x.name); w.newLine(); }
            w.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException e) { return false; }
    }
}