package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.game.ApoMarioPanel;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) { this.store = store; load(); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        names.add(name.replace('\t', ' '));
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > 100) { int i = names.size() - 1; names.remove(i); scores.remove(i); times.remove(i); }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try { for (int i = 0; i < names.size(); i++) {
                out.write(names.get(i)); out.write('\t'); out.write(String.valueOf(scores.get(i))); out.write('\t');
                out.write(String.valueOf(times.get(i))); out.newLine();
            }} finally { out.close(); }
        } catch (IOException ignored) { }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer p : level.getPlayers()) if (p != null && (best == null || p.getPoints() > best.getPoints())) best = p;
        if (best != null) storeRun(best.getPoints(), level.getPassedTime(), best.getTeamName());
    }

    private void load() {
        if (store == null || !Files.isReadable(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try { String line; while ((line = in.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                if (p.length == 3) { names.add(p[0]); scores.add(Integer.valueOf(p[1])); times.add(Integer.valueOf(p[2])); }
            }} finally { in.close(); }
            sort();
        } catch (Exception e) { names.clear(); scores.clear(); times.clear(); }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b).compareTo(scores.get(a)); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    public static class View extends ApoMarioModel {
        private final ApoMarioHighscore highscore;
        public View(ApoMarioPanel game, ApoMarioHighscore highscore) { super(game); this.highscore = highscore; }
        public void init() { }
        public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE) getGame().setMenu(); }
        public void mouseButtonFunction(String function) { if ("backHighscore".equals(function)) getGame().setMenu(); }
        public void mouseButtonReleased(int x, int y) { }
        public boolean mouseMoved(int x, int y) { return false; }
        public boolean mouseDragged(int x, int y) { return false; }
        public boolean mousePressed(int x, int y, boolean bRight) { return false; }
        public void think(int delta) { }
        public void render(Graphics2D g) {
            g.setColor(new Color(20, 70, 110)); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
            g.setColor(Color.WHITE); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 20, 35);
            g.setFont(ApoMarioConstants.FONT_STATISTICS);
            List<String> n = highscore.getPlayersNames(); List<Integer> s = highscore.getPlayersScores(); List<Integer> t = highscore.getSurvivalTimes();
            for (int i = 0; i < n.size() && i < 12; i++) {
                int y = 65 + i * 14; int ms = t.get(i);
                g.drawString((i + 1) + ". " + n.get(i), 20, y); g.drawString(String.valueOf(s.get(i)), 175, y);
                g.drawString(String.format("%02d:%02d", ms / 60000, (ms / 1000) % 60), 240, y);
            }
            g.drawString("ESC: back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
        }
    }
}