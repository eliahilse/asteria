package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Dedicated menu view for the local highscore board. */
public final class ApoMarioHighscorePanel {
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscorePanel(ApoMarioHighscore highscore) { this.highscore = highscore; }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 90, 35);
        List<String> n = highscore.getPlayersNames(); List<Integer> s = highscore.getPlayersScores(); List<Integer> t = highscore.getSurvivalTimes();
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        for (int i = 0; i < n.size() && i < 10; i++) {
            int ms = t.get(i); long seconds = ms / 1000L; long minutes = seconds / 60L;
            String time = String.format("%02d:%02d", minutes, seconds % 60L);
            g.drawString((i + 1) + ". " + n.get(i), 30, 70 + i * 16);
            g.drawString(String.valueOf(s.get(i)), 190, 70 + i * 16);
            g.drawString(time, 250, 70 + i * 16);
        }
        g.drawString("ESC: back", 30, ApoMarioConstants.GAME_HEIGHT - 15);
    }
}