package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_BYTES = 256;
    private static final long MAX_FILE_BYTES = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = clean(playerName);
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() {
        List<String> r = new ArrayList<String>(); for (Entry e : entries) r.add(e.name); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.score); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.time); return Collections.unmodifiableList(r);
    }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent(); if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(temp, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { for (Entry e : entries) { w.write(Integer.toString(e.score)); w.write('\t'); w.write(Integer.toString(e.time)); w.write('\t'); w.write(Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8))); w.newLine(); } } finally { w.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { }
    }
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0); if (p != null) storeRun(p.getPoints(), level.getPassedTime(), p.getTeamName());
    }
    private void load() {
        if (store == null) return;
        try {
            if (!Files.isRegularFile(store) || Files.size(store) > MAX_FILE_BYTES) return;
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8); List<Entry> loaded = new ArrayList<Entry>();
            try { String line; while (loaded.size() < MAX_RECORDS && (line = r.readLine()) != null) {
                String[] p = line.split("\\t", -1); if (p.length != 3) continue;
                try { int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]); byte[] b = Base64.getDecoder().decode(p[2]); if (b.length == 0 || b.length > MAX_NAME_BYTES || time < 0) continue; String n = clean(new String(b, StandardCharsets.UTF_8)); if (n.length() > 0) loaded.add(new Entry(score, time, n)); } catch (RuntimeException ex) { }
            } } finally { r.close(); }
            entries.addAll(loaded); sort();
        } catch (IOException ex) { }
    }
    private static String clean(String s) { if (s == null) return ""; s = s.replace('\r', ' ').replace('\n', ' ').trim(); return s.length() > 64 ? s.substring(0, 64) : s; }
    private void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score == b.score ? Integer.valueOf(a.time).compareTo(Integer.valueOf(b.time)) : (a.score < b.score ? 1 : -1); } }); while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1); }
    public synchronized void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT); g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 20, 35); g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        for (int i = 0; i < entries.size() && i < 12; i++) { Entry e = entries.get(i); int sec = e.time / 1000; g.drawString((i + 1) + ". " + e.name, 20, 60 + i * 15); g.drawString(Integer.toString(e.score), 210, 60 + i * 15); g.drawString(String.format("%02d:%02d", sec / 60, sec % 60), 270, 60 + i * 15); }
        g.drawString("ESC / H: back", 20, ApoMarioConstants.GAME_HEIGHT - 10);
    }
}