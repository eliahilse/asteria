package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local highscore table. Times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 40) name = name.substring(0, 40);
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sort();
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the best real player in the completed run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = null;
        for (ApoMarioPlayer player : level.getPlayers()) {
            if (player != null && (best == null || player.getPoints() > best.getPoints())) best = player;
        }
        if (best == null) return;
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(best.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(store, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) {
                    writer.write(Integer.toString(e.score)); writer.write('\t');
                    writer.write(Integer.toString(e.time)); writer.write('\t');
                    writer.write(e.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
        } catch (IOException ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length == 3) entries.add(new Entry(Integer.parseInt(p[0]), Integer.parseInt(p[1]), p[2]));
                }
            } finally { reader.close(); }
            sort();
        } catch (Exception ignored) { entries.clear(); }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
}