package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(new Color(255, 255, 255, 230));
        g.fillRoundRect(28, 20, ApoMarioConstants.GAME_WIDTH - 56, ApoMarioConstants.GAME_HEIGHT - 40, 15, 15);
        g.setColor(Color.BLACK);
        g.drawRoundRect(28, 20, ApoMarioConstants.GAME_WIDTH - 56, ApoMarioConstants.GAME_HEIGHT - 40, 15, 15);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
        g.drawString("HIGHSCORES", 92, 52);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        g.drawString("#", 45, 80);
        g.drawString("PLAYER", 75, 80);
        g.drawString("POINTS", 205, 80);
        g.drawString("TIME", 270, 80);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 105 + i * 15;
            g.drawString(Integer.toString(i + 1), 45, y);
            g.drawString(names.get(i), 75, y);
            g.drawString(Integer.toString(scores.get(i)), 205, y);
            int seconds = times.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 270, y);
        }
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("ESC: back", 105, ApoMarioConstants.GAME_HEIGHT - 28);
    }
}