package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore board, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.drawString("HIGHSCORES", width / 2 - 65, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 13));
        List<String> n = board.getPlayersNames(); List<Integer> s = board.getPlayersScores(); List<Integer> t = board.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 10; i++) {
            int y = 62 + i * 16; int seconds = t.get(i) / 1000;
            g.drawString(String.valueOf(i + 1), 25, y); g.drawString(n.get(i), 55, y); g.drawString(String.valueOf(s.get(i)), 190, y);
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 250, y);
        }
        g.drawString("Press H or Escape to return", 25, Math.max(80, height - 15));
    }
}