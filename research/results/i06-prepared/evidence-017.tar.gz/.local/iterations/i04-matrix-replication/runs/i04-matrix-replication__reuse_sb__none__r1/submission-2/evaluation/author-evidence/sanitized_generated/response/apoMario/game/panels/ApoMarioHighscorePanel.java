package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscorePanel extends ApoMarioHighscore.View {
    public ApoMarioHighscorePanel(ApoMarioPanel game, ApoMarioHighscore highscore) { super(game, highscore); }
}