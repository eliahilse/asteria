package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

import apoMario.ApoMarioConstants;

/** Small renderer used by the menu for the persistent highscore board. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }

    public static void render(Graphics2D g, ApoMarioHighscore highscore) {
        g.setColor(new Color(255, 255, 255, 225));
        g.fillRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 16, 16);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 20, ApoMarioConstants.GAME_WIDTH - 50, ApoMarioConstants.GAME_HEIGHT - 40, 16, 16);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", ApoMarioConstants.GAME_WIDTH / 2 - 55, 52);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        g.drawString("#", 45, 78); g.drawString("PLAYER", 75, 78); g.drawString("POINTS", 190, 78); g.drawString("TIME", 270, 78);
        List<String> names = highscore.getPlayersNames();
        List<Integer> scores = highscore.getPlayersScores();
        List<Integer> times = highscore.getSurvivalTimes();
        for (int i = 0; i < names.size() && i < 10; i++) {
            int y = 102 + i * 18;
            g.drawString(Integer.toString(i + 1), 45, y);
            g.drawString(names.get(i), 75, y);
            g.drawString(Integer.toString(scores.get(i)), 190, y);
            int seconds = times.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60)), 270, y);
        }
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        g.drawString("ESC / H: back", 45, ApoMarioConstants.GAME_HEIGHT - 28);
    }
}