package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent high-score table. Survival times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 50;
    private static final int MAX_NAME = 32;
    private final Path store;
    private final List<Record> records = new ArrayList<Record>();

    private static final class Record {
        final int score;
        final int time;
        final String name;
        Record(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) return false;
        if (survivalTime < 0) survivalTime = 0;
        records.add(new Record(score, survivalTime, name));
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score > a.score ? 1 : -1); }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return result;
    }

    /** Records the authoritative human player's score and elapsed level time. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || level.isBReplay()) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            lines.add("APOMARIO_HIGHSCORE_1");
            for (Record r : records) lines.add(r.score + "\t" + r.time + "\t" + r.name.replace("\t", " "));
            Files.write(temp, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            List<String> lines = Files.readAllLines(store, StandardCharsets.UTF_8);
            if (lines.size() == 0 || !"APOMARIO_HIGHSCORE_1".equals(lines.get(0))) return;
            for (int i = 1; i < lines.size() && records.size() < MAX_RECORDS; i++) {
                String[] p = lines.get(i).split("\\t", 3);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    if (time < 0 || cleanName(p[2]).length() == 0) continue;
                    records.add(new Record(score, time, cleanName(p[2])));
                } catch (NumberFormatException ignored) { }
            }
            Collections.sort(records, new Comparator<Record>() {
                public int compare(Record a, Record b) { return b.score == a.score ? a.name.compareToIgnoreCase(b.name) : (b.score > a.score ? 1 : -1); }
            });
        } catch (Exception ignored) { }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    /** Draws the dedicated menu view; times are converted to mm:ss only here. */
    public synchronized void render(Graphics2D g) {
        int size = ApoMarioConstants.SIZE;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(25 * size, 15 * size, ApoMarioConstants.GAME_WIDTH - 50 * size, ApoMarioConstants.GAME_HEIGHT - 30 * size, 20, 20);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 95 * size, 38 * size);
        g.setFont(ApoMarioConstants.FONT_MENU);
        int y = 58 * size;
        for (int i = 0; i < records.size() && i < 10; i++) {
            Record r = records.get(i);
            g.drawString((i + 1) + ". " + r.name, 45 * size, y);
            g.drawString(String.valueOf(r.score), 190 * size, y);
            g.drawString(formatTime(r.time), 245 * size, y);
            y += 14 * size;
        }
        if (records.isEmpty()) g.drawString("No runs recorded", 90 * size, y);
        g.drawString("Press ESC to return", 90 * size, ApoMarioConstants.GAME_HEIGHT - 18 * size);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }
}