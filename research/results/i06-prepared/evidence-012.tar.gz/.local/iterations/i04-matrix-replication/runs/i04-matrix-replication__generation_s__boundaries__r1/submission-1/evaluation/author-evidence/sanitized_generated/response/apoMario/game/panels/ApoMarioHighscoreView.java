package apoMario.game.panels;

import apoMario.game.ApoMarioPanel;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

/** Named view type for clients that want to refer to the board as a view. */
public class ApoMarioHighscoreView extends ApoMarioHighscore {
    public ApoMarioHighscoreView(java.nio.file.Path store) { super(store); }
    public ApoMarioHighscoreView(apoMario.game.ApoMarioPanel game, java.nio.file.Path store) { super(game, store); }
}