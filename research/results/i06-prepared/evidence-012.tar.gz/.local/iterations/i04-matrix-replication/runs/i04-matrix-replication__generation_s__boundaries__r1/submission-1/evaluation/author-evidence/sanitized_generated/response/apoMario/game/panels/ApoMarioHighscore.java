package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.game.ApoMarioPanel;
import apoMario.level.ApoMarioLevel;

/** Persistent highscore storage and the menu view for the scores. */
public class ApoMarioHighscore extends ApoMarioModel {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();
    private ApoMarioPanel game;

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public ApoMarioHighscore(ApoMarioPanel game, Path store) {
        super(game);
        this.game = game;
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(survivalTime));
        sort();
        while (names.size() > MAX_RECORDS) {
            int n = names.size() - 1;
            names.remove(n); scores.remove(n); times.remove(n);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                out.write("APOMARIO_HIGHSCORE_1"); out.newLine();
                for (int i = 0; i < names.size(); i++) {
                    out.write(Integer.toString(scores.get(i).intValue())); out.write('\t');
                    out.write(Integer.toString(times.get(i).intValue())); out.write('\t');
                    out.write(names.get(i).replace('\t', ' ')); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed score save must not stop the game. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line = in.readLine();
                if (!"APOMARIO_HIGHSCORE_1".equals(line)) return;
                while (names.size() < MAX_RECORDS && (line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        String name = cleanName(p[2]);
                        if (score >= 0 && time >= 0 && name.length() > 0) {
                            names.add(name); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(time));
                        }
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
        } catch (IOException ex) { /* missing or unreadable storage is an empty board */ }
        sort();
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        return b.toString().trim();
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).intValue() - scores.get(a.intValue()).intValue();
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i.intValue())); s.add(scores.get(i.intValue())); t.add(times.get(i.intValue())); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    private static String formatTime(int millis) {
        long seconds = Math.max(0L, (long)millis) / 1000L;
        return (seconds / 60L) + ":" + String.format("%02d", Long.valueOf(seconds % 60L));
    }

    public void init() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE && game != null) game.setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function) && game != null) game.setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(new Color(250, 250, 250, 235));
        g.fillRect(20, 15, ApoMarioConstants.GAME_WIDTH - 40, ApoMarioConstants.GAME_HEIGHT - 30);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 35, 48);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        List<String> n = getPlayersNames(); List<Integer> s = getPlayersScores(); List<Integer> t = getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 12; i++) {
            int y = 78 + i * 14;
            g.drawString((i + 1) + ". " + n.get(i), 40, y);
            g.drawString(Integer.toString(s.get(i).intValue()), 190, y);
            g.drawString(formatTime(t.get(i).intValue()), 270, y);
        }
        g.drawString("ESC - back", 35, ApoMarioConstants.GAME_HEIGHT - 25);
    }
}