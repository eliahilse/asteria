package apoMario.game.panels;

import apoMario.game.ApoMarioPanel;
import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** File-backed, bounded highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 32;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(times); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < scores.size(); i++) {
                    out.write(scores.get(i).toString()); out.write('\t');
                    out.write(times.get(i).toString()); out.write('\t');
                    out.write(names.get(i)); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A read-only score file must never stop the game.
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getComponent() instanceof apoMario.game.ApoMarioPanel && ((apoMario.game.ApoMarioPanel)level.getComponent()).isBSimulate()) return;
        if (level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while (count++ < MAX_ENTRIES && (line = in.readLine()) != null) {
                    if (line.length() > 256) continue;
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]);
                        int time = Integer.parseInt(p[1]);
                        if (score >= 0 && time >= 0 && cleanName(p[2]) != null) {
                            scores.add(score); times.add(time); names.add(cleanName(p[2]));
                        }
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ex) { names.clear(); scores.clear(); times.clear(); }
    }

    private String cleanName(String value) {
        if (value == null) return null;
        String s = value.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return null;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return null;
        return s;
    }

    private void sortAndTrim() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b) - scores.get(a); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (int j = 0; j < order.size() && j < MAX_ENTRIES; j++) { int i = order.get(j); n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
}