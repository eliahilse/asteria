package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** File-backed highscore table. Survival times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private static final long MAX_FILE_BYTES = 1024L * 1024L;

    private static final class Run {
        final String name;
        final int score;
        final int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return false;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return false;
        }
        runs.add(new Run(name, score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score)); writer.write('\t');
                    writer.write(Integer.toString(run.time)); writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(run.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A read-only score file must never stop the game.
        }
    }

    /** Records the first, human run player after the level has finalized its score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(Math.max(0, player.getPoints()), Math.max(0, level.getPassedTime()), name);
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_BYTES) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while (runs.size() < MAX_ENTRIES && (line = reader.readLine()) != null) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        String name = new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8);
                        if (score >= 0 && time >= 0 && name.length() > 0 && name.length() <= MAX_NAME_LENGTH) {
                            boolean safe = true;
                            for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) safe = false;
                            if (safe) runs.add(new Run(name, score, time));
                        }
                    } catch (IllegalArgumentException ex) { /* ignore malformed records */ }
                }
            } finally { reader.close(); }
            sortAndLimit();
        } catch (IOException ex) { runs.clear(); }
    }

    private void sortAndLimit() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); }
        });
        while (runs.size() > MAX_ENTRIES) runs.remove(runs.size() - 1);
    }
}