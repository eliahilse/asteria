package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;

/** Lightweight dedicated renderer used by the menu for the local table. */
public final class ApoMarioHighscorePanel {
    private ApoMarioHighscorePanel() { }
    public static void render(Graphics2D g, ApoMarioHighscore table, int width) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, 1000);
        g.setColor(Color.BLACK);
        g.drawString("HIGHSCORES", 30, 45);
        List<String> n = table.getPlayersNames(); List<Integer> s = table.getPlayersScores(); List<Integer> t = table.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 20; i++) {
            int ms = t.get(i).intValue(); int sec = ms / 1000;
            String time = String.format("%02d:%02d", Integer.valueOf(sec / 60), Integer.valueOf(sec % 60));
            g.drawString((i + 1) + ". " + n.get(i), 40, 80 + i * 24);
            g.drawString(String.valueOf(s.get(i)), 300, 80 + i * 24);
            g.drawString(time, 430, 80 + i * 24);
        }
        g.drawString("ESC/H: back", 30, 570);
    }
}