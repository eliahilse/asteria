package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.Charset;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local, file-backed highscore board. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    /** Persists the complete, already sorted board using a failure-safe replacement. */
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (Run r : runs) lines.add(r.score + "\t" + r.time + "\t" + r.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " ").replace("\r", " "));
            Files.write(temp, lines, Charset.forName("UTF-8"), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
            try {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            // A failed save must not make the running game fail.
        }
    }

    /** Records the first (human) player after the level has applied terminal scoring. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 245, 235));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK);
        g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
        g.drawString("HIGHSCORES", width / 2 - 65, 35);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        g.drawString("Rank", 20, 62); g.drawString("Name", 70, 62); g.drawString("Score", width - 105, 62); g.drawString("Time", width - 55, 62);
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run r = runs.get(i); int y = 82 + i * 14;
            g.drawString(String.valueOf(i + 1), 25, y);
            g.drawString(r.name, 70, y);
            g.drawString(String.valueOf(r.score), width - 105, y);
            g.drawString(formatTime(r.time), width - 55, y);
        }
        g.drawString("ESC: back", 20, height - 12);
    }

    public static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, (long) milliseconds) / 1000L;
        long minutes = seconds / 60L;
        return String.format("%02d:%02d", minutes, seconds % 60L);
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            List<String> lines = Files.readAllLines(store, Charset.forName("UTF-8"));
            List<Run> loaded = new ArrayList<Run>();
            for (String line : lines) {
                if (loaded.size() >= MAX_RECORDS) break;
                String[] p = line.split("\\t", 3);
                if (p.length != 3) continue;
                try {
                    int score = Integer.parseInt(p[0]);
                    int time = Integer.parseInt(p[1]);
                    if (time < 0 || p[2].length() > MAX_NAME) continue;
                    loaded.add(new Run(score, time, cleanName(p[2])));
                } catch (NumberFormatException ex) { }
            }
            runs.addAll(loaded); sortAndTrim();
        } catch (Exception ex) { runs.clear(); }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        String s = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s;
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); } });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }
}