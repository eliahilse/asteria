package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, aligned highscore table. Times are kept in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_NAME_LENGTH = 40;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        return persist();
    }

    public synchronized List<String> getPlayersNames() {
        return Collections.unmodifiableList(new ArrayList<String>(names));
    }

    public synchronized List<Integer> getPlayersScores() {
        return Collections.unmodifiableList(new ArrayList<Integer>(scores));
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return Collections.unmodifiableList(new ArrayList<Integer>(times));
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    /** Records the first (human) player after the level has applied its final score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int x, int y, int width) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(x, y, width, 360, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(x, y, width, 360, 18, 18);
        g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", x + 24, y + 34);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < names.size() && i < 10; i++) {
            int row = y + 65 + i * 27;
            g.drawString(String.valueOf(i + 1), x + 25, row);
            g.drawString(names.get(i), x + 65, row);
            g.drawString(String.valueOf(scores.get(i)), x + width - 145, row);
            g.drawString(formatTime(times.get(i).intValue()), x + width - 75, row);
        }
        if (names.isEmpty()) g.drawString("No runs recorded", x + 25, y + 70);
        g.drawString("Press H or Escape to return", x + 24, y + 340);
    }

    public static String formatTime(int millis) {
        int seconds = Math.max(0, millis) / 1000;
        return String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        String result = value.replace('\n', ' ').replace('\r', ' ').trim();
        if (result.length() == 0) result = "Player";
        return result.length() > MAX_NAME_LENGTH ? result.substring(0, MAX_NAME_LENGTH) : result;
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try {
                    names.add(cleanName(new String(Base64.getDecoder().decode(p[0]), StandardCharsets.UTF_8)));
                    scores.add(Integer.valueOf(p[1]));
                    times.add(Integer.valueOf(Math.max(0, Integer.parseInt(p[2]))));
                } catch (RuntimeException ignored) { }
            }
            sort();
        } catch (IOException ignored) { }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) {
                lines.add(Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)) + "\t" + scores.get(i) + "\t" + times.get(i));
            }
            Files.write(store, lines, StandardCharsets.UTF_8);
            return true;
        } catch (IOException ex) { return false; }
    }
}