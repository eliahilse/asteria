package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Small renderer shared by the menu's highscore page. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore table, int width) {
        List<String> n = table.getPlayersNames(); List<Integer> s = table.getPlayersScores(); List<Integer> t = table.getSurvivalTimes();
        g.setColor(Color.WHITE); g.fillRect(20, 20, width - 40, 300);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 40, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < n.size() && i < 10; i++) {
            int seconds = t.get(i) / 1000; String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + n.get(i), 45, 85 + i * 22);
            g.drawString(String.valueOf(s.get(i)), width - 180, 85 + i * 22);
            g.drawString(time, width - 95, 85 + i * 22);
        }
        if (n.isEmpty()) g.drawString("No runs recorded", 45, 90);
        g.drawString("Press H or Escape to return", 45, 290);
    }
}