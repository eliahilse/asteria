package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import java.util.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore h, int width, int height) {
        g.setColor(new Color(255,255,255,240)); g.fillRoundRect(25,20,width-50,height-40,18,18);
        g.setColor(Color.BLACK); g.drawRoundRect(25,20,width-50,height-40,18,18);
        g.setFont(new Font("Dialog", Font.BOLD, 24)); g.drawString("HIGHSCORES", width/2-75, 58);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        java.util.List<String> n=h.getPlayersNames(); java.util.List<Integer> s=h.getPlayersScores(); java.util.List<Integer> t=h.getSurvivalTimes();
        for (int i=0;i<n.size() && i<12;i++) { int y=90+i*28; int sec=Math.max(0,t.get(i))/1000; g.drawString((i+1)+".  "+n.get(i),45,y); g.drawString(String.valueOf(s.get(i)),310,y); g.drawString(String.format("%02d:%02d",sec/60,sec%60),400,y); }
        g.drawString("H / ESC: back",45,height-20);
    }
}