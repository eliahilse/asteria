package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent local highscore table. Survival times are stored in milliseconds. */
public class ApoMarioHighscore {
    private final Path store;
    private final List<String> playersNames = new ArrayList<String>();
    private final List<Integer> playersScores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 24) name = name.substring(0, 24);
        playersNames.add(name);
        playersScores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(playersNames)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(playersScores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(survivalTimes)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < playersNames.size(); i++) {
                lines.add(playersScores.get(i) + "\t" + survivalTimes.get(i) + "\t" + Base64.getEncoder().encodeToString(playersNames.get(i).getBytes(StandardCharsets.UTF_8)));
            }
            Files.write(store, lines, StandardCharsets.UTF_8);
        } catch (IOException ignored) { }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getPlayer();
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(width / 8, height / 10, width * 3 / 4, height * 4 / 5, 20, 20);
        g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", width / 2 - 75, height / 10 + 38);
        g.setFont(ApoMarioConstants.FONT_MENU);
        int y = height / 10 + 78;
        int shown = Math.min(12, playersNames.size());
        if (shown == 0) g.drawString("No runs recorded yet", width / 2 - 75, y);
        for (int i = 0; i < shown; i++) {
            String time = formatTime(survivalTimes.get(i).intValue());
            g.drawString((i + 1) + ".", width / 5, y);
            g.drawString(playersNames.get(i), width / 5 + 35, y);
            g.drawString(String.valueOf(playersScores.get(i)), width / 2 + 25, y);
            g.drawString(time, width * 2 / 3, y);
            y += 25;
        }
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        g.drawString("H: close", width / 2 - 28, height - height / 10 - 8);
    }

    public static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", Integer.valueOf(seconds / 60), Integer.valueOf(seconds % 60));
    }

    private void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", 3);
                if (p.length != 3) continue;
                playersScores.add(Integer.valueOf(p[0]));
                survivalTimes.add(Integer.valueOf(p[1]));
                playersNames.add(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
            }
            sort();
        } catch (Exception ex) {
            playersNames.clear(); playersScores.clear(); survivalTimes.clear();
        }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < playersScores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return Integer.compare(playersScores.get(b.intValue()), playersScores.get(a.intValue()));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(playersNames.get(i)); s.add(playersScores.get(i)); t.add(survivalTimes.get(i)); }
        playersNames.clear(); playersNames.addAll(n); playersScores.clear(); playersScores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
}