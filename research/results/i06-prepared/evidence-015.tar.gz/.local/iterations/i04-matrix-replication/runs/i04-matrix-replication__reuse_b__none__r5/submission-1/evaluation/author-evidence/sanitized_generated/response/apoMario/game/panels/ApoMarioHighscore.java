package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Persistent local highscore table. Survival times are stored in milliseconds. */
public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int i = names.size() - 1;
            names.remove(i);
            scores.remove(i);
            survivalTimes.remove(i);
        }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(store));
            try {
                out.writeInt(VERSION);
                out.writeInt(names.size());
                for (int i = 0; i < names.size(); i++) {
                    out.writeUTF(names.get(i));
                    out.writeInt(scores.get(i).intValue());
                    out.writeInt(survivalTimes.get(i).intValue());
                }
            } finally { out.close(); }
        } catch (IOException ex) {
            // A highscore must never prevent the game from running.
        }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            try {
                if (in.readInt() != VERSION) return;
                int count = Math.min(MAX_ENTRIES, Math.max(0, in.readInt()));
                for (int i = 0; i < count; i++) {
                    names.add(in.readUTF());
                    scores.add(Integer.valueOf(in.readInt()));
                    survivalTimes.add(Integer.valueOf(Math.max(0, in.readInt())));
                }
                sort();
            } finally { in.close(); }
        } catch (IOException ex) {
            names.clear(); scores.clear(); survivalTimes.clear();
        }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                int result = scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
                return result != 0 ? result : a.compareTo(b);
            }
        });
        List<String> n = new ArrayList<String>();
        List<Integer> s = new ArrayList<Integer>();
        List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }
}