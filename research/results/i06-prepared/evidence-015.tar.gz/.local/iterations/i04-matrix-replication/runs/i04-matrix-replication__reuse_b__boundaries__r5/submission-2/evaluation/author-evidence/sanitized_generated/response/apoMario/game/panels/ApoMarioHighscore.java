package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Local, file-backed highscore board. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x4D485343;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 1000;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024L * 1024L;

    private static final class Run {
        String name; int score; int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final ArrayList<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > MAX_NAME) name = name.substring(0, MAX_NAME);
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(name, score, survivalTime));
        sort();
        if (runs.size() > MAX_RECORDS) runs.subList(MAX_RECORDS, runs.size()).clear();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Run r : runs) result.add(r.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Run r : runs) result.add(r.time);
        return Collections.unmodifiableList(result);
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed;
        try { elapsed = level.getPassedTime(); } catch (RuntimeException ex) { elapsed = 0; }
        storeRun(player.getPoints(), elapsed, name);
    }

    public void persistAcrossRuns() {
        if (store == null) return;
        Path absolute = store.toAbsolutePath();
        Path parent = absolute.getParent();
        Path temporary = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
        try {
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            synchronized (this) {
                out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
                for (Run r : runs) { out.writeUTF(r.name); out.writeInt(r.score); out.writeInt(r.time); }
            }
            out.close();
            try { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, absolute, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    private synchronized void sort() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score > b.score ? -1 : 1); }
        });
    }
    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int magic = in.readInt(), version = in.readInt(), count = in.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
            ArrayList<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                String name = in.readUTF(); int score = in.readInt(); int time = in.readInt();
                if (name.length() == 0 || name.length() > MAX_NAME || time < 0) { in.close(); return; }
                loaded.add(new Run(name, score, time));
            }
            in.close();
            synchronized (this) { runs.clear(); runs.addAll(loaded); sort(); }
        } catch (IOException ex) { /* malformed stores are ignored atomically */ }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int y = 95;
        for (int i = 0; i < runs.size() && i < 15; i++) {
            Run r = runs.get(i);
            int seconds = r.time / 1000;
            String time = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString(String.format("%2d  %-18s %7d  %s", i + 1, r.name, r.score, time), 35, y);
            y += 25;
        }
        if (runs.isEmpty()) g.drawString("No runs recorded", width / 2 - 70, y);
        g.drawString("Press Escape or H to return", 35, height - 25);
    }
}