package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.List;

/** Rendering helper for the menu highscore page. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
    public static void render(Graphics2D g, ApoMarioHighscore board, int width) {
        g.setColor(new Color(255,255,255,235)); g.fillRect(0, 0, width, 1000);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("HIGHSCORES", 30, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> n = board.getPlayersNames();
        List<Integer> s = board.getPlayersScores();
        List<Integer> t = board.getSurvivalTimes();
        for (int i=0; i<n.size() && i<20; i++) {
            int sec = t.get(i) / 1000; String time = String.format("%02d:%02d", sec / 60, sec % 60);
            g.drawString((i+1)+". "+n.get(i), 45, 80+i*25); g.drawString(String.valueOf(s.get(i)), 300, 80+i*25); g.drawString(time, 400, 80+i*25);
        }
        g.drawString("ESC / H: back", 30, 570);
    }
}