package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, numerically ranked run results. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 64;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private boolean runEndRecorded;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name == null || survivalTime < 0) {
            return false;
        }
        runs.add(new Run(score, survivalTime, name));
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) {
                return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1);
            }
        });
        while (runs.size() > MAX_ENTRIES) {
            runs.remove(runs.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the first terminal result of this live level, using its final score and elapsed time. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || this.runEndRecorded || level.getPlayers() == null || level.getPlayers().isEmpty()) {
            return;
        }
        this.runEndRecorded = true;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = "Player";
        }
        int elapsed = level.getPassedTime();
        if (elapsed < 0) {
            elapsed = 0;
        }
        storeRun(player.getPoints(), elapsed, name);
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (Run run : runs) {
                    writer.write(Integer.toString(run.score)); writer.write('\t');
                    writer.write(Integer.toString(run.time)); writer.write('\t');
                    writer.write(run.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " "));
                    writer.newLine();
                }
            } finally { writer.close(); }
            try { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) {
            // A read-only or unavailable store must not stop the game.
        }
    }

    /** Starts a new run while retaining all previously persisted scores. */
    public synchronized void beginRun() {
        this.runEndRecorded = false;
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while ((line = reader.readLine()) != null && runs.size() < MAX_ENTRIES) {
                    String[] fields = line.split("\\t", 3);
                    if (fields.length != 3) continue;
                    try {
                        int score = Integer.parseInt(fields[0]);
                        int time = Integer.parseInt(fields[1]);
                        String name = cleanName(fields[2]);
                        if (name != null && time >= 0) runs.add(new Run(score, time, name));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { reader.close(); }
            Collections.sort(runs, new Comparator<Run>() {
                public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
            });
        } catch (IOException ex) { /* missing or malformed stores are treated as empty */ }
    }

    private static String cleanName(String value) {
        if (value == null) return null;
        String name = value.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ').trim();
        if (name.length() == 0) return null;
        return name.length() > MAX_NAME_LENGTH ? name.substring(0, MAX_NAME_LENGTH) : name;
    }

    private static final class Run {
        final int score, time; final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
}