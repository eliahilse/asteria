package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Persistent, local highscore table for ApoMario. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int MAX_ENTRIES = 100;

    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = playerName == null ? "Player" : playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > 32) name = name.substring(0, 32);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            survivalTimes.remove(survivalTimes.size() - 1);
        }
        persistAcrossRuns();
        return true;
    }

    /** Records the first human/player slot when a live run finishes. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized List<String> getPlayersNames() {
        return new ArrayList<String>(names);
    }

    public synchronized List<Integer> getPlayersScores() {
        return new ArrayList<Integer>(scores);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        return new ArrayList<Integer>(survivalTimes);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(store)));
            out.writeInt(MAGIC);
            out.writeInt(names.size());
            for (int i = 0; i < names.size(); i++) {
                out.writeUTF(names.get(i));
                out.writeInt(scores.get(i).intValue());
                out.writeInt(survivalTimes.get(i).intValue());
            }
            out.close();
        } catch (IOException ex) {
            // A read-only home must not stop the game.
        }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_ENTRIES * 10) { in.close(); return; }
            for (int i = 0; i < count; i++) {
                names.add(in.readUTF());
                scores.add(Integer.valueOf(in.readInt()));
                survivalTimes.add(Integer.valueOf(Math.max(0, in.readInt())));
            }
            in.close();
            sort();
            while (names.size() > MAX_ENTRIES) {
                names.remove(names.size() - 1); scores.remove(scores.size() - 1); survivalTimes.remove(survivalTimes.size() - 1);
            }
        } catch (IOException | RuntimeException ex) {
            names.clear(); scores.clear(); survivalTimes.clear();
        }
    }

    private void sort() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
            }
        });
        ArrayList<String> n = new ArrayList<String>();
        ArrayList<Integer> s = new ArrayList<Integer>();
        ArrayList<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); scores.clear(); survivalTimes.clear(); names.addAll(n); scores.addAll(s); survivalTimes.addAll(t);
    }
}