package apoMario.game.panels;

import apoMario.entity.ApoMarioPlayer;
import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;

/** A small, local and durable high-score table. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_BYTES = 80;
    private static final long MAX_FILE_BYTES = 1024 * 1024;

    private static final class Run {
        final int score;
        final int time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        if (store == null) throw new IllegalArgumentException("store");
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (survivalTime < 0) survivalTime = 0;
        runs.add(new Run(score, survivalTime, name));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the final, already-scored human player in the supplied level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        try {
            apoMario.entity.ApoMarioPlayer player = level.getPlayers().get(0);
            String name = player.getTeamName();
            if (name == null || name.trim().length() == 0) name = "Player";
            storeRun(player.getPoints(), level.getPassedTime(), name);
        } catch (RuntimeException ignored) {
            // A partially constructed editor/replay level is not a completed run.
        }
    }

    public synchronized void persistAcrossRuns() {
        Path parent = store.toAbsolutePath().getParent();
        Path temporary = null;
        try {
            if (parent != null) Files.createDirectories(parent);
            temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(temporary));
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(runs.size());
            for (Run run : runs) {
                byte[] bytes = run.name.getBytes(StandardCharsets.UTF_8);
                out.writeInt(run.score);
                out.writeInt(run.time);
                out.writeInt(bytes.length);
                out.write(bytes);
            }
            out.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    private String cleanName(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_BYTES; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127) result.append(c);
        }
        String name = result.toString().trim();
        while (name.getBytes(StandardCharsets.UTF_8).length > MAX_NAME_BYTES) name = name.substring(0, name.length() - 1);
        return name;
    }

    private synchronized void load() {
        runs.clear();
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_BYTES) return;
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                int score = in.readInt();
                int time = in.readInt();
                int length = in.readInt();
                if (length < 0 || length > MAX_NAME_BYTES) { in.close(); return; }
                byte[] bytes = new byte[length];
                in.readFully(bytes);
                String name = cleanName(new String(bytes, StandardCharsets.UTF_8));
                if (name.length() == 0 || time < 0) { in.close(); return; }
                loaded.add(new Run(score, time, name));
            }
            in.close();
            runs.addAll(loaded);
            sortAndTrim();
        } catch (IOException | RuntimeException ignored) {
            runs.clear();
        }
    }

    private void sortAndTrim() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { return a.score == b.score ? 0 : (a.score < b.score ? 1 : -1); }
        });
        while (runs.size() > MAX_RECORDS) runs.remove(runs.size() - 1);
    }

    /** Renders the board; conversion to mm:ss intentionally happens only here. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 28));
        g.drawString("HIGHSCORES", width / 2 - 90, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 18));
        for (int i = 0; i < runs.size() && i < 15; i++) {
            Run r = runs.get(i); int y = 95 + i * 27;
            g.drawString(String.valueOf(i + 1), 45, y);
            g.drawString(r.name, 90, y);
            g.drawString(String.valueOf(r.score), width - 190, y);
            long seconds = ((long) r.time) / 1000L;
            long minutes = seconds / 60L;
            g.drawString(String.format("%02d:%02d", minutes, seconds % 60L), width - 95, y);
        }
        g.drawString("ESC: back", 20, height - 20);
    }
}