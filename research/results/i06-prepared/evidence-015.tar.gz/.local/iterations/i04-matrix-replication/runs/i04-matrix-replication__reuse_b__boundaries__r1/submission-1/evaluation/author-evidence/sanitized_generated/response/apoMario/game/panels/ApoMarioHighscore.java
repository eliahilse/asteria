package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local and deliberately bounded high-score table. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 40;
    private static final long MAX_FILE = 1024 * 1024;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || playerName == null) return false;
        String name = playerName.trim();
        if (name.length() == 0) name = "Player";
        if (name.length() > MAX_NAME) name = name.substring(0, MAX_NAME);
        entries.add(new Entry(score, survivalTime, name));
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return a.score == b.score ? a.name.compareToIgnoreCase(b.name) : (a.score < b.score ? 1 : -1); }
        });
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { List<String> r = new ArrayList<String>(); for (Entry e : entries) r.add(e.name); return r; }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.score); return r; }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.time); return r; }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try { for (Entry e : entries) { w.write(Integer.toString(e.score)); w.write('\t'); w.write(Integer.toString(e.time)); w.write('\t'); w.write(e.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " ").replace("\r", " ")); w.newLine(); } } finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed save must not stop the game. */ }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        if (p != null) storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), p.getTeamName());
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            List<Entry> loaded = new ArrayList<Entry>(); String line;
            try { while ((line = r.readLine()) != null && loaded.size() < MAX_RECORDS) { String[] p = line.split("\\t", 3); if (p.length != 3) continue; int s = Integer.parseInt(p[0]); int t = Integer.parseInt(p[1]); if (s >= 0 && t >= 0 && p[2].length() > 0 && p[2].length() <= MAX_NAME) loaded.add(new Entry(s, t, p[2])); } } finally { r.close(); }
            entries.clear(); entries.addAll(loaded);
            Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score == b.score ? a.name.compareToIgnoreCase(b.name) : (a.score < b.score ? 1 : -1); } });
        } catch (Exception ex) { entries.clear(); }
    }
}