package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local and deliberately network-free highscore table. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            int i = names.size() - 1;
            names.remove(i); scores.remove(i); survivalTimes.remove(i);
        }
        return persist();
    }

    public synchronized void persistAcrossRuns() {
        persist();
    }

    private synchronized boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Properties p = new Properties();
            p.setProperty("count", String.valueOf(names.size()));
            for (int i = 0; i < names.size(); i++) {
                p.setProperty("name." + i, names.get(i));
                p.setProperty("score." + i, String.valueOf(scores.get(i)));
                p.setProperty("time." + i, String.valueOf(survivalTimes.get(i)));
            }
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            java.io.OutputStream out = Files.newOutputStream(tmp);
            try { p.store(out, "ApoMario highscores"); } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (Exception ex) { return false; }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            Properties p = new Properties();
            java.io.InputStream in = Files.newInputStream(store);
            try { p.load(in); } finally { in.close(); }
            int count = Integer.parseInt(p.getProperty("count", "0"));
            for (int i = 0; i < count && i < MAX_ENTRIES; i++) {
                String n = p.getProperty("name." + i);
                int s = Integer.parseInt(p.getProperty("score." + i));
                int t = Integer.parseInt(p.getProperty("time." + i));
                if (n != null) { names.add(cleanName(n)); scores.add(s); survivalTimes.add(Math.max(0, t)); }
            }
            sort();
        } catch (Exception ex) { names.clear(); scores.clear(); survivalTimes.clear(); }
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < names.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b).compareTo(scores.get(a));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(survivalTimes.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); survivalTimes.clear(); survivalTimes.addAll(t);
    }

    private static String cleanName(String value) {
        if (value == null) return "Player";
        String s = value.replaceAll("[\\r\\n\\t]", " ").trim();
        if (s.length() == 0) s = "Player";
        return s.length() > 32 ? s.substring(0, 32) : s;
    }

    /** Records the first (human) player after ApoMarioLevel has applied its final bonus. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("Highscores", 30, 40);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < names.size() && i < 15; i++) {
            int y = 75 + i * 25;
            g.drawString((i + 1) + ". " + names.get(i), 35, y);
            g.drawString(String.valueOf(scores.get(i)), width / 2, y);
            g.drawString(formatTime(survivalTimes.get(i)), width - 100, y);
        }
        g.drawString("ESC / H: back", 30, height - 20);
    }

    public static String formatTime(int millis) {
        long seconds = Math.max(0, millis) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}