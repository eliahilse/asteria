package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Dedicated menu view for the local highscore table. */
public class ApoMarioHighscoreView {
    private final ApoMarioPanel panel;
    private final ApoMarioHighscore highscore;
    public ApoMarioHighscoreView(ApoMarioPanel panel, ApoMarioHighscore highscore) { this.panel = panel; this.highscore = highscore; }
    public void render(Graphics2D g) {
        g.setColor(new Color(245, 245, 255)); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 26));
        g.drawString("HIGHSCORES", ApoMarioConstants.GAME_WIDTH / 2 - 90, 45);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        List<String> n = highscore.getPlayersNames(); List<Integer> s = highscore.getPlayersScores(); List<Integer> t = highscore.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 15; i++) {
            int y = 80 + i * 25; int sec = t.get(i) / 1000; String time = String.format("%02d:%02d", sec / 60, sec % 60);
            g.drawString(String.valueOf(i + 1), 50, y); g.drawString(n.get(i), 100, y); g.drawString(String.valueOf(s.get(i)), 330, y); g.drawString(time, 440, y);
        }
        g.drawString("ESC / H: back", 20, ApoMarioConstants.GAME_HEIGHT - 20);
    }
    public void keyReleased(int key) { if (key == KeyEvent.VK_ESCAPE || key == KeyEvent.VK_H) panel.setMenu(); }
}