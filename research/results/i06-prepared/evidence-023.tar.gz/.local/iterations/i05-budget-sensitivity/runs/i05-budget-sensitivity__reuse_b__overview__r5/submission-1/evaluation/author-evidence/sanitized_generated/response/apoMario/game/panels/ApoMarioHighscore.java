package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** Local, deterministic highscore table. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        names.add(name);
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        while (names.size() > MAX_ENTRIES) {
            names.remove(names.size() - 1);
            scores.remove(scores.size() - 1);
            times.remove(times.size() - 1);
        }
        return write();
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() { write(); }

    /** Records the final, post-analysis score of the primary player exactly once per call. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer selected = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible() && p.getPoints() > selected.getPoints()) selected = p;
        }
        String name = selected.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(selected.getPoints(), level.getPassedTime(), name);
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        String s = value.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ').trim();
        if (s.length() == 0) return "Player";
        return s.length() > 32 ? s.substring(0, 32) : s;
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (Integer i : order) { n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            for (String line : Files.readAllLines(store, StandardCharsets.UTF_8)) {
                String[] p = line.split("\\t", -1);
                if (p.length != 3) continue;
                try { scores.add(Integer.valueOf(p[0])); times.add(Integer.valueOf(p[1])); names.add(cleanName(new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8))); }
                catch (Exception ignored) { }
            }
            sort();
        } catch (IOException ignored) { names.clear(); scores.clear(); times.clear(); }
    }

    private boolean write() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            List<String> lines = new ArrayList<String>();
            for (int i = 0; i < names.size(); i++) lines.add(scores.get(i) + "\t" + times.get(i) + "\t" + Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            return true;
        } catch (Exception ex) { return false; }
    }
}