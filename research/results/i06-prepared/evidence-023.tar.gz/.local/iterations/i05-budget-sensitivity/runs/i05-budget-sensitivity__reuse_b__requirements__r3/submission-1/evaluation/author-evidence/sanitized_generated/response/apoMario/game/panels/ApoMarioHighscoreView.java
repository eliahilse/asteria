package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

/** Small named view type for integrations that want a dedicated menu view. */
public class ApoMarioHighscoreView extends ApoMarioHighscore {
    public ApoMarioHighscoreView(java.nio.file.Path store) { super(store); }
}