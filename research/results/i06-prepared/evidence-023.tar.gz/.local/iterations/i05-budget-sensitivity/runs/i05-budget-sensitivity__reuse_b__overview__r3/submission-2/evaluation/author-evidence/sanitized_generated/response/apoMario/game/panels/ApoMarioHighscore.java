package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> survivalTimes = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        names.add(cleanName(playerName));
        scores.add(Integer.valueOf(score));
        survivalTimes.add(Integer.valueOf(Math.max(0, survivalTime)));
        sort();
        return persist();
    }

    public synchronized List<String> getPlayersNames() { return new ArrayList<String>(names); }
    public synchronized List<Integer> getPlayersScores() { return new ArrayList<Integer>(scores); }
    public synchronized List<Integer> getSurvivalTimes() { return new ArrayList<Integer>(survivalTimes); }
    public synchronized void persistAcrossRuns() { persist(); }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        String result = value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
        if (result.length() == 0) result = "Player";
        return result.length() > MAX_NAME ? result.substring(0, MAX_NAME) : result;
    }

    private void sort() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() {
            public int compare(Integer first, Integer second) {
                return scores.get(second.intValue()).compareTo(scores.get(first.intValue()));
            }
        });
        List<String> sortedNames = new ArrayList<String>();
        List<Integer> sortedScores = new ArrayList<Integer>();
        List<Integer> sortedTimes = new ArrayList<Integer>();
        for (Integer index : order) {
            sortedNames.add(names.get(index.intValue()));
            sortedScores.add(scores.get(index.intValue()));
            sortedTimes.add(survivalTimes.get(index.intValue()));
        }
        names.clear(); names.addAll(sortedNames);
        scores.clear(); scores.addAll(sortedScores);
        survivalTimes.clear(); survivalTimes.addAll(sortedTimes);
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try (BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("\\t", -1);
                if (fields.length != 3) continue;
                try {
                    scores.add(Integer.valueOf(fields[0]));
                    survivalTimes.add(Integer.valueOf(fields[1]));
                    names.add(cleanName(new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8)));
                } catch (RuntimeException ex) {
                    if (!scores.isEmpty()) scores.remove(scores.size() - 1);
                    if (!survivalTimes.isEmpty()) survivalTimes.remove(survivalTimes.size() - 1);
                }
            }
            sort();
        } catch (IOException ex) {
            names.clear(); scores.clear(); survivalTimes.clear();
        }
    }

    private boolean persist() {
        if (store == null) return false;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                for (int i = 0; i < names.size(); i++) {
                    writer.write(scores.get(i) + "\t" + survivalTimes.get(i) + "\t" + Base64.getEncoder().encodeToString(names.get(i).getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            }
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255, 255, 255, 245));
        g.fillRoundRect(25, 20, width - 50, height - 40, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(25, 20, width - 50, height - 40, 18, 18);
        g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 45, 55);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        int limit = Math.min(names.size(), 12);
        for (int i = 0; i < limit; i++) {
            int y = 85 + i * 25;
            g.drawString((i + 1) + ".", 48, y);
            g.drawString(names.get(i), 85, y);
            g.drawString(String.valueOf(scores.get(i)), width - 190, y);
            g.drawString(formatTime(survivalTimes.get(i).intValue()), width - 105, y);
        }
        g.drawString("Press H or ESC to return", 45, height - 45);
    }

    private static String formatTime(int milliseconds) {
        int seconds = Math.max(0, milliseconds) / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }
}