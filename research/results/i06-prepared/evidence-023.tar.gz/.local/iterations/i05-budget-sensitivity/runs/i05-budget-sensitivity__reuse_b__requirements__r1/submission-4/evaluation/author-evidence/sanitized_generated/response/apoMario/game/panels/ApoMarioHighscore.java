package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504D48;
    private static final int VERSION = 1;
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 40;
    private static final long MAX_FILE_LENGTH = 1024L * 1024L;

    private static final class Entry {
        private final String name;
        private final int score;
        private final int time;
        private Entry(String name, int score, int time) {
            this.name = name;
            this.score = score;
            this.time = time;
        }
    }

    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private boolean visible;

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = validName(playerName);
        if (name == null || score < 0 || survivalTime < 0) {
            return false;
        }
        entries.add(new Entry(name, score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return Collections.unmodifiableList(result);
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.time);
        return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream output = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temporary)));
            output.writeInt(MAGIC);
            output.writeInt(VERSION);
            output.writeInt(entries.size());
            for (Entry entry : entries) {
                output.writeUTF(entry.name);
                output.writeInt(entry.score);
                output.writeInt(entry.time);
            }
            output.close();
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null || player.getAi() != null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int elapsed = level.getPassedTime();
        if (elapsed < 0) elapsed = 0;
        storeRun(Math.max(0, player.getPoints()), elapsed, name);
    }

    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_LENGTH) return;
            DataInputStream input = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (input.readInt() != MAGIC || input.readInt() != VERSION) {
                input.close();
                return;
            }
            int count = input.readInt();
            if (count < 0 || count > MAX_ENTRIES) {
                input.close();
                return;
            }
            for (int i = 0; i < count; i++) {
                String name = input.readUTF();
                int score = input.readInt();
                int time = input.readInt();
                name = validName(name);
                if (name != null && score >= 0 && time >= 0) entries.add(new Entry(name, score, time));
            }
            input.close();
            sortAndLimit();
        } catch (IOException ex) {
            entries.clear();
        } catch (RuntimeException ex) {
            entries.clear();
        }
    }

    private String validName(String value) {
        if (value == null) return null;
        String name = value.trim();
        if (name.length() == 0 || name.length() > MAX_NAME_LENGTH) return null;
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) return null;
        }
        return name;
    }

    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) {
                return second.score < first.score ? -1 : (second.score == first.score ? 0 : 1);
            }
        });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    public synchronized void setVisible(boolean visible) { this.visible = visible; }
    public synchronized boolean isVisible() { return visible; }

    public synchronized void render(Graphics2D graphics) {
        graphics.setColor(new Color(245, 245, 230));
        graphics.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        graphics.setColor(Color.BLACK);
        graphics.setFont(new Font("Dialog", Font.BOLD, 28));
        graphics.drawString("HIGHSCORES", 30, 45);
        graphics.setFont(new Font("Dialog", Font.PLAIN, 16));
        graphics.drawString("Name", 35, 80);
        graphics.drawString("Points", 300, 80);
        graphics.drawString("Time", 430, 80);
        for (int i = 0; i < entries.size() && i < 15; i++) {
            Entry entry = entries.get(i);
            int y = 110 + i * 25;
            graphics.drawString((i + 1) + ". " + entry.name, 20, y);
            graphics.drawString(String.valueOf(entry.score), 300, y);
            graphics.drawString(formatTime(entry.time), 430, y);
        }
        graphics.drawString("H or Escape: back", 30, ApoMarioConstants.GAME_HEIGHT - 20);
    }

    private String formatTime(int milliseconds) {
        long seconds = Math.max(0L, milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}