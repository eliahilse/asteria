package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 32;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim());
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                out.write("APO_MARIO_HIGHSCORE_1"); out.newLine();
                out.write(String.valueOf(names.size())); out.newLine();
                for (int i = 0; i < names.size(); i++) {
                    out.write(scores.get(i) + "\t" + times.get(i) + "\t" + names.get(i)); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* a full/unwritable board must not stop play */ }
    }

    /** Records the first human player after the level has finalized its score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        String name = p.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(Math.max(0, p.getPoints()), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(245, 245, 220)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("HIGHSCORES", 20, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        g.drawString("Name", 35, 65); g.drawString("Points", width - 190, 65); g.drawString("Time", width - 90, 65);
        for (int i = 0; i < names.size() && i < 20; i++) {
            int y = 92 + i * 22;
            g.drawString((i + 1) + ". " + names.get(i), 35, y);
            g.drawString(String.valueOf(scores.get(i)), width - 190, y);
            int seconds = times.get(i) / 1000;
            g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), width - 90, y);
        }
        g.drawString("ESC / H: back", 20, height - 15);
    }

    private boolean validName(String n) {
        if (n == null) return false;
        String s = n.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }
    private void sortAndLimit() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b) - scores.get(a); } });
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (int j = 0; j < order.size() && j < MAX_ENTRIES; j++) { int i = order.get(j); n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE_1".equals(in.readLine())) return;
                int count = Integer.parseInt(in.readLine());
                if (count < 0 || count > MAX_ENTRIES) return;
                for (int i = 0; i < count; i++) {
                    String line = in.readLine(); if (line == null) return;
                    String[] p = line.split("\\t", 3); if (p.length != 3) continue;
                    int s = Integer.parseInt(p[0]); int t = Integer.parseInt(p[1]);
                    if (s >= 0 && t >= 0 && validName(p[2])) { scores.add(s); times.add(t); names.add(p[2].trim()); }
                }
            } finally { in.close(); }
            sortAndLimit();
        } catch (Exception ex) { names.clear(); scores.clear(); times.clear(); }
    }
}