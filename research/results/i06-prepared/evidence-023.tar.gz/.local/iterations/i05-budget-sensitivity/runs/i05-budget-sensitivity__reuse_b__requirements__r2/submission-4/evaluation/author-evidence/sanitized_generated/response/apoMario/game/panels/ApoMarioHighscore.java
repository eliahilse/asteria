package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.Collections;
import java.util.IdentityHashMap;

import apoMario.level.ApoMarioLevel;

/** File-backed, bounded highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final List<String> names = new ArrayList<String>();
    private final List<Integer> scores = new ArrayList<Integer>();
    private final List<Integer> times = new ArrayList<Integer>();
    private final Set<ApoMarioLevel> recordedLevels = Collections.newSetFromMap(new IdentityHashMap<ApoMarioLevel, Boolean>());

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    /** Records the final human player's result from a completed level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || recordedLevels.contains(level)) return;
        if (level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        if (level.getPlayers().get(0) == null) return;
        String name = level.getPlayers().get(0).getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        int score = level.getPlayers().get(0).getPoints();
        int elapsed = level.getPassedTime();
        boolean stored = storeRun(score, elapsed, name);
        if (!stored && level.getPlayers().get(0).getAi() != null) {
            String aiName = level.getPlayers().get(0).getAi().getTeamName();
            if (validName(aiName)) stored = storeRun(score, elapsed, aiName);
        }
        if (stored) recordedLevels.add(level);
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim());
        scores.add(Integer.valueOf(score));
        times.add(Integer.valueOf(survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < scores.size(); i++) {
                    out.write(Integer.toString(scores.get(i).intValue())); out.write('\t');
                    out.write(Integer.toString(times.get(i).intValue())); out.write('\t');
                    out.write(names.get(i)); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* Persistence must not stop the game. */ }
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > 1024L * 1024L) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = in.readLine()) != null && count++ < MAX_ENTRIES) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3 || p[2].length() > MAX_NAME) continue;
                    try {
                        int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                        if (score >= 0 && time >= 0 && validName(p[2])) {
                            scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(time)); names.add(p[2].trim());
                        }
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ex) { names.clear(); scores.clear(); times.clear(); }
    }

    private void sortAndTrim() {
        List<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) {
            return scores.get(b.intValue()).compareTo(scores.get(a.intValue()));
        }});
        List<String> n = new ArrayList<String>(); List<Integer> s = new ArrayList<Integer>(); List<Integer> t = new ArrayList<Integer>();
        for (int i = 0; i < order.size() && i < MAX_ENTRIES; i++) { int x = order.get(i).intValue(); n.add(names.get(x)); s.add(scores.get(x)); t.add(times.get(x)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 24));
        g.drawString("Highscores", 30, 40);
        g.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int i = 0; i < scores.size() && i < 15; i++) {
            int y = 75 + i * 25;
            g.drawString(Integer.toString(i + 1), 35, y);
            g.drawString(names.get(i), 75, y);
            g.drawString(Integer.toString(scores.get(i)), 260, y);
            int sec = times.get(i).intValue() / 1000;
            g.drawString(String.format("%02d:%02d", sec / 60, sec % 60), 360, y);
        }
        if (scores.isEmpty()) g.drawString("No scores yet", 35, 75);
        g.drawString("Escape: back", 30, height - 20);
    }
}