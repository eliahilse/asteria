package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent local highscore and its small menu view. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int VERSION = 1;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (playerName == null || playerName.trim().length() == 0) {
            playerName = "Player";
        }
        entries.add(new Entry(score, Math.max(0, survivalTime), playerName.trim()));
        sort();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry e : entries) result.add(e.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry e : entries) result.add(e.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(store)));
            out.writeInt(VERSION);
            out.writeInt(entries.size());
            for (Entry e : entries) {
                out.writeInt(e.score);
                out.writeInt(e.time);
                out.writeUTF(e.name);
            }
            out.close();
        } catch (IOException ignored) {
            // A game must remain playable when the profile directory is read-only.
        }
    }

    /** Records the best participating player from the just-finished real level. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getPoints() > chosen.getPoints()) chosen = p;
        }
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) {
            name = chosen.getAi() == null ? "Player" : chosen.getAi().getTeamName();
        }
        storeRun(chosen.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(245, 245, 245, 235));
        g.fillRoundRect(20, 18, ApoMarioConstants.GAME_WIDTH - 40, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setColor(Color.BLACK);
        g.drawRoundRect(20, 18, ApoMarioConstants.GAME_WIDTH - 40, ApoMarioConstants.GAME_HEIGHT - 36, 18, 18);
        g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 25, 48);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        int y = 72;
        for (int i = 0; i < entries.size() && i < 8; i++) {
            Entry e = entries.get(i);
            g.drawString((i + 1) + ".", 34, y);
            g.drawString(e.name, 62, y);
            g.drawString(String.valueOf(e.score), 190, y);
            g.drawString(formatTime(e.time), 260, y);
            y += 20;
        }
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("ESC / H: back", 25, ApoMarioConstants.GAME_HEIGHT - 25);
    }

    private static String formatTime(int millis) {
        int seconds = Math.max(0, millis) / 1000;
        return String.format("%02d:%02d", seconds / 60, seconds % 60);
    }

    private synchronized void load() {
        if (store == null || !Files.exists(store)) return;
        try {
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int version = in.readInt();
            int count = in.readInt();
            if (version != VERSION || count < 0 || count > 10000) { in.close(); return; }
            entries.clear();
            for (int i = 0; i < count; i++) entries.add(new Entry(in.readInt(), in.readInt(), in.readUTF()));
            in.close();
            sort();
        } catch (IOException ignored) {
            entries.clear();
        }
    }

    private void sort() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); }
        });
    }

    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
}