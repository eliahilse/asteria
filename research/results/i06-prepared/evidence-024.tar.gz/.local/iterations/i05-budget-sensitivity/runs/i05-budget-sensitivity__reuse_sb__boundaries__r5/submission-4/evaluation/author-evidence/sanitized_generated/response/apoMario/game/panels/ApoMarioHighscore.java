package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.entity.ApoMarioPlayer;
import apoMario.game.ApoMarioPanel;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore extends ApoMarioModel {
    private static final int MAX_RECORDS = 1000;
    private static final int MAX_NAME_LENGTH = 64;
    private static final long MAX_FILE_SIZE = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private ApoMarioPanel panel;

    private static final class Entry {
        private final int score;
        private final int survivalTime;
        private final String name;
        private Entry(int score, int survivalTime, String name) {
            this.score = score;
            this.survivalTime = survivalTime;
            this.name = name;
        }
    }

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public ApoMarioHighscore(ApoMarioPanel panel, Path store) {
        super(panel);
        this.store = store;
        this.panel = panel;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        entries.add(new Entry(score, Math.max(0, survivalTime), name));
        sortEntries();
        if (entries.size() > MAX_RECORDS) entries.subList(MAX_RECORDS, entries.size()).clear();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Entry entry : entries) result.add(entry.name);
        return result;
    }

    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.score);
        return result;
    }

    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Entry entry : entries) result.add(entry.survivalTime);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path temporary = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8);
            try {
                for (Entry entry : entries) {
                    writer.write(Integer.toString(entry.score));
                    writer.write('\t');
                    writer.write(Integer.toString(entry.survivalTime));
                    writer.write('\t');
                    writer.write(Base64.getEncoder().encodeToString(entry.name.getBytes(StandardCharsets.UTF_8)));
                    writer.newLine();
                }
            } finally {
                writer.close();
            }
            try {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temporary, store, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            try { Files.deleteIfExists(temporary); } catch (IOException ignored) { }
        }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    private synchronized void load() {
        entries.clear();
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_SIZE) return;
            BufferedReader reader = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line;
                while (entries.size() < MAX_RECORDS && (line = reader.readLine()) != null) {
                    String[] fields = line.split("\\t", -1);
                    if (fields.length != 3) continue;
                    int score = Integer.parseInt(fields[0]);
                    int time = Integer.parseInt(fields[1]);
                    if (time < 0) continue;
                    String name = cleanName(new String(Base64.getDecoder().decode(fields[2]), StandardCharsets.UTF_8));
                    if (name.length() > 0) entries.add(new Entry(score, time, name));
                }
            } finally {
                reader.close();
            }
            sortEntries();
        } catch (Exception ex) {
            entries.clear();
        }
    }

    private String cleanName(String value) {
        if (value == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < value.length() && result.length() < MAX_NAME_LENGTH; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127 && c != '\t' && c != '\r' && c != '\n') result.append(c);
        }
        return result.toString().trim();
    }

    private void sortEntries() {
        Collections.sort(entries, new Comparator<Entry>() {
            public int compare(Entry first, Entry second) {
                int result = Integer.compare(second.score, first.score);
                return result != 0 ? result : first.name.compareTo(second.name);
            }
        });
    }

    public void init() { }
    public void keyButtonReleased(int button, char character) {
        if (button == KeyEvent.VK_ESCAPE || button == KeyEvent.VK_BACK_SPACE) {
            if (panel != null) panel.setMenu();
        }
    }
    public void mouseButtonFunction(String function) {
        if ("backHighscore".equals(function) && panel != null) panel.setMenu();
    }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }

    public synchronized void render(Graphics2D g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK);
        g.setFont(ApoMarioConstants.FONT_MENU);
        g.drawString("HIGHSCORES", 20, 30);
        int y = 60;
        for (int i = 0; i < entries.size() && i < 20; i++) {
            Entry entry = entries.get(i);
            g.drawString((i + 1) + ". " + entry.name, 20, y);
            g.drawString(Integer.toString(entry.score), 190, y);
            g.drawString(formatTime(entry.survivalTime), 250, y);
            y += 18;
        }
        g.drawString("ESC: back", 20, ApoMarioConstants.GAME_HEIGHT - 10);
    }

    private static String formatTime(int milliseconds) {
        long seconds = Math.max(0L, (long) milliseconds) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}