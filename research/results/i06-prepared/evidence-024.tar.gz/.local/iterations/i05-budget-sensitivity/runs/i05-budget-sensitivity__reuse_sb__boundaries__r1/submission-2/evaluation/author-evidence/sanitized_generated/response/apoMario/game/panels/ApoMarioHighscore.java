package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** A small, local and deliberately bounded high-score table. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();

    private static final class Entry {
        final String name; final int score; final int time;
        Entry(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < Integer.MIN_VALUE || survivalTime < 0) return false;
        String name = cleanName(playerName);
        entries.add(new Entry(name, score, survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return result;
    }

    /** Records the final, already-scored human run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) {
                    out.write(e.score + "\t" + e.time + "\t" + e.name.replace("\\", "\\\\").replace("\t", " ").replace("\n", " "));
                    out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed save must not break the game. */ }
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        String s = value.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ').trim();
        if (s.length() == 0) s = "Player";
        return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s;
    }
    private void sortAndTrim() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) {
            int c = b.score < a.score ? -1 : (b.score == a.score ? 0 : 1);
            return c != 0 ? c : a.name.compareTo(b.name);
        }});
        while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1);
    }
    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            List<Entry> loaded = new ArrayList<Entry>(); String line;
            try {
                while ((line = in.readLine()) != null) {
                    if (loaded.size() >= MAX_RECORDS) break;
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]); int time = Integer.parseInt(p[1]);
                        if (time >= 0) loaded.add(new Entry(cleanName(p[2]), score, time));
                    } catch (NumberFormatException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            entries.clear(); entries.addAll(loaded); sortAndTrim();
        } catch (IOException ex) { /* retain an empty safe table */ }
    }

    /** Lightweight renderer used by the menu's dedicated high-score mode. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20, 15, width - 40, height - 30, 18, 18);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 18));
        g.drawString("HIGHSCORES", width / 2 - 55, 42);
        g.setFont(new Font("Dialog", Font.PLAIN, 12));
        for (int i = 0; i < entries.size() && i < 10; i++) {
            Entry e = entries.get(i); int y = 65 + i * 16;
            int seconds = e.time / 1000; String t = String.format("%02d:%02d", seconds / 60, seconds % 60);
            g.drawString((i + 1) + ". " + e.name, 35, y); g.drawString(String.valueOf(e.score), width - 105, y); g.drawString(t, width - 55, y);
        }
        g.drawString("ESC / H: back", 35, height - 38);
    }
}