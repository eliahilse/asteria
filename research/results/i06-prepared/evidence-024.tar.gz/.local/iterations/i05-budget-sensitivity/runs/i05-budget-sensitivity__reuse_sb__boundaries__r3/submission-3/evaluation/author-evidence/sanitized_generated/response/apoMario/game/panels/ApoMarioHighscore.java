package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Graphics2D;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 80;
    private final Path store;
    private final ArrayList<Entry> entries = new ArrayList<Entry>();
    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = clean(playerName); if (name.length() == 0) name = "Player";
        entries.add(new Entry(score, Math.max(0, survivalTime), name)); sort(); persistAcrossRuns(); return true;
    }
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = null;
        for (ApoMarioPlayer candidate : level.getPlayers()) if (candidate != null && candidate.isBVisible()) { p = candidate; break; }
        if (p == null) p = level.getPlayers().get(0);
        storeRun(p.getPoints(), level.getPassedTime(), p.getTeamName());
    }
    public synchronized List<String> getPlayersNames() { ArrayList<String> r = new ArrayList<String>(); for (Entry e : entries) r.add(e.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores() { ArrayList<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes() { ArrayList<Integer> r = new ArrayList<Integer>(); for (Entry e : entries) r.add(e.time); return Collections.unmodifiableList(r); }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
        try {
            if (store.toAbsolutePath().getParent() != null) Files.createDirectories(store.toAbsolutePath().getParent());
            DataOutputStream out = new DataOutputStream(Files.newOutputStream(tmp)); out.writeInt(MAGIC); out.writeInt(entries.size());
            for (Entry e : entries) { out.writeInt(e.score); out.writeInt(e.time); out.writeUTF(e.name); } out.close();
            Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) { try { Files.deleteIfExists(tmp); } catch (IOException ignored) { } }
    }
    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > 1048576L) return;
            DataInputStream in = new DataInputStream(Files.newInputStream(store));
            if (in.readInt() != MAGIC) { in.close(); return; }
            int count = in.readInt(); if (count < 0 || count > MAX_RECORDS) { in.close(); return; }
            ArrayList<Entry> loaded = new ArrayList<Entry>();
            for (int i = 0; i < count; i++) { int score = in.readInt(), time = in.readInt(); String name = in.readUTF(); if (time < 0 || name.length() == 0 || name.length() > MAX_NAME) { in.close(); return; } loaded.add(new Entry(score, time, clean(name))); }
            in.close(); entries.addAll(loaded); sort();
        } catch (IOException ex) { entries.clear(); }
    }
    private String clean(String s) { if (s == null) return ""; s = s.trim().replace('\n', ' ').replace('\r', ' '); return s.length() > MAX_NAME ? s.substring(0, MAX_NAME) : s; }
    private void sort() { Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return a.score == b.score ? a.name.compareTo(b.name) : (a.score < b.score ? 1 : -1); } }); while (entries.size() > MAX_RECORDS) entries.remove(entries.size() - 1); }
    private String time(int millis) { long seconds = Math.max(0L, (long) millis) / 1000L; return String.format("%02d:%02d", seconds / 60L, seconds % 60L); }
    public synchronized void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, 320, 240); g.setColor(Color.BLACK); g.drawString("HIGHSCORES", 20, 25); g.drawString("NAME                 POINTS   TIME", 20, 48);
        for (int i = 0; i < entries.size() && i < 12; i++) { Entry e = entries.get(i); int y = 66 + i * 14; g.drawString((i + 1) + ". " + e.name, 20, y); g.drawString(String.valueOf(e.score), 190, y); g.drawString(time(e.time), 250, y); }
        g.drawString("ESC: back", 20, 230);
    }
}