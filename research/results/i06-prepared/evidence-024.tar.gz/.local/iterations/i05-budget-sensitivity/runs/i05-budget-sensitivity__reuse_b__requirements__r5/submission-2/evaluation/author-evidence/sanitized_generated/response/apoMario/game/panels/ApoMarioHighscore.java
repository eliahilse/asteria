package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Base64;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME_LENGTH = 32;
    private static final long MAX_FILE_BYTES = 128L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private static final class Entry {
        final int score, time; final String name;
        Entry(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        entries.add(new Entry(score, survivalTime, playerName.trim())); sortAndLimit(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { List<String> r=new ArrayList<String>(); for(Entry e:entries)r.add(e.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r=new ArrayList<Integer>(); for(Entry e:entries)r.add(e.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r=new ArrayList<Integer>(); for(Entry e:entries)r.add(e.time); return Collections.unmodifiableList(r); }
    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent=store.toAbsolutePath().getParent(); if(parent!=null)Files.createDirectories(parent);
            Path tmp=store.resolveSibling(store.getFileName().toString()+".tmp"); List<String> lines=new ArrayList<String>();
            for(Entry e:entries) lines.add(e.score+"\t"+e.time+"\t"+Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)));
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            try { Files.move(tmp,store,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); } catch(IOException x) { Files.move(tmp,store,StandardCopyOption.REPLACE_EXISTING); }
        } catch(IOException ignored) { }
    }
    public synchronized boolean recordRunEnd(ApoMarioLevel level) {
        if(level==null||level.getPlayers()==null||level.getPlayers().isEmpty())return false;
        ApoMarioPlayer p=level.getPlayers().get(0); if(p==null)return false;
        String n=p.getTeamName(); if(n==null||n.trim().length()==0)n="Player";
        return storeRun(Math.max(0,p.getPoints()),Math.max(0,level.getPassedTime()),n);
    }
    public synchronized void render(Graphics2D g,int x,int y,int width) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(x,y,width,360,18,18); g.setColor(Color.BLACK); g.drawRoundRect(x,y,width,360,18,18);
        g.setFont(new Font("Dialog",Font.BOLD,22)); g.drawString("HIGHSCORES",x+24,y+34); g.setFont(new Font("Dialog",Font.PLAIN,15));
        for(int i=0;i<entries.size()&&i<12;i++){Entry e=entries.get(i);int yy=y+62+i*24;g.drawString(String.valueOf(i+1),x+25,yy);g.drawString(e.name,x+60,yy);g.drawString(String.valueOf(e.score),x+width-130,yy);g.drawString(formatTime(e.time),x+width-70,yy);}
        if(entries.isEmpty())g.drawString("No runs recorded",x+60,y+75);
    }
    public static String formatTime(int milliseconds){long s=Math.max(0L,milliseconds)/1000L;return String.format("%02d:%02d",s/60L,s%60L);}
    private boolean validName(String n){if(n==null)return false;String s=n.trim();if(s.length()==0||s.length()>MAX_NAME_LENGTH)return false;for(int i=0;i<s.length();i++)if(Character.isISOControl(s.charAt(i)))return false;return true;}
    private void sortAndLimit(){Collections.sort(entries,new Comparator<Entry>(){public int compare(Entry a,Entry b){return b.score<a.score?-1:(b.score==a.score?0:1);}});while(entries.size()>MAX_ENTRIES)entries.remove(entries.size()-1);}
    private void load(){if(store==null)return;try{if(!Files.exists(store)||Files.size(store)>MAX_FILE_BYTES)return;for(String line:Files.readAllLines(store,StandardCharsets.UTF_8)){if(entries.size()>=MAX_ENTRIES)break;try{String[] p=line.split("\\t",-1);if(p.length!=3)continue;int s=Integer.parseInt(p[0]),t=Integer.parseInt(p[1]);String n=new String(Base64.getDecoder().decode(p[2]),StandardCharsets.UTF_8);if(s>=0&&t>=0&&validName(n))entries.add(new Entry(s,t,n.trim()));}catch(RuntimeException ignored){}}sortAndLimit();}catch(IOException ignored){}}
}