package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed, local highscore board. Times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAGIC = 0x41504853;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 1000;
    private static final int MAX_NAME_BYTES = 80;
    private static final long MAX_FILE_BYTES = 1024L * 1024L;

    private static final class Run {
        final int score, time;
        final String name;
        Run(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = cleanName(playerName);
        if (name.length() == 0) name = "Player";
        if (runs.size() >= MAX_RECORDS) {
            sortRuns();
            if (score < runs.get(runs.size() - 1).score) return false;
            runs.remove(runs.size() - 1);
        }
        runs.add(new Run(score, Math.max(0, survivalTime), name));
        sortRuns();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>();
        for (Run run : runs) result.add(run.name);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.score);
        return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>();
        for (Run run : runs) result.add(run.time);
        return Collections.unmodifiableList(result);
    }

    /** Records the authoritative first player's final score and elapsed time. */
    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(player.getPoints(), level.getPassedTime(), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)));
            out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
            for (Run run : runs) { out.writeUTF(run.name); out.writeInt(run.score); out.writeInt(run.time); }
            out.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* a failed save must not disrupt the game */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            if (Files.size(store) > MAX_FILE_BYTES) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            if (in.readInt() != MAGIC || in.readInt() != VERSION) { in.close(); return; }
            int count = in.readInt();
            if (count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i = 0; i < count; i++) {
                String name = in.readUTF();
                if (name.getBytes(StandardCharsets.UTF_8).length > MAX_NAME_BYTES) { in.close(); return; }
                loaded.add(new Run(in.readInt(), Math.max(0, in.readInt()), cleanName(name)));
            }
            in.close(); runs.clear(); runs.addAll(loaded); sortRuns();
        } catch (IOException | RuntimeException ex) { /* retain the safe current board */ }
    }

    private static String cleanName(String value) {
        if (value == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < 40; i++) {
            char c = value.charAt(i);
            if (c >= 32 && c != 127) b.append(c);
        }
        return b.toString().trim();
    }
    private void sortRuns() {
        Collections.sort(runs, new Comparator<Run>() {
            public int compare(Run a, Run b) { int c = Integer.compare(b.score, a.score); return c != 0 ? c : Integer.compare(a.time, b.time); }
        });
    }

    /** Lightweight renderer used by the menu's dedicated highscore mode. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(240, 248, 255)); g.fillRect(0, 0, width, height);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 20));
        g.drawString("Highscores", width / 2 - 55,  thirty(height));
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        for (int i = 0; i < runs.size() && i < 12; i++) {
            Run r = runs.get(i); int y = 55 + i * 18;
            g.drawString((i + 1) + ". " + r.name, 25, y);
            g.drawString(String.valueOf(r.score), width / 2, y);
            g.drawString(formatTime(r.time), width - 65, y);
        }
        g.drawString("ESC: back", 10, height - 10);
    }
    private static int thirty(int height) { return height < 35 ? height - 5 : 28; }
    public static String formatTime(int millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        return String.format("%02d:%02d", seconds / 60L, seconds % 60L);
    }
}