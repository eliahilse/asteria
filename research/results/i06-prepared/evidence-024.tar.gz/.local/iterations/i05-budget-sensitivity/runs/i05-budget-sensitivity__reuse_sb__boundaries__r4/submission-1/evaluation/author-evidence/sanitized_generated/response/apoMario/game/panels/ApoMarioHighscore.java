package apoMario.game.panels;

import apoMario.ApoMarioConstants;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioModelMenu;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;
import apoMario.game.ApoMarioPanel;

/** Local, bounded and failure-safe highscore board. Times are milliseconds. */
public class ApoMarioHighscore extends ApoMarioModelMenu {
    private static final int MAGIC = 0x41504d48;
    private static final int VERSION = 1;
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME_BYTES = 96;
    private static final long MAX_FILE_BYTES = 1024 * 1024;

    private static final class Run {
        String name; int score; int time;
        Run(String name, int score, int time) { this.name = name; this.score = score; this.time = time; }
    }

    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private boolean view;

    public ApoMarioHighscore(Path store) {
        super(null);
        this.store = store;
        load();
    }

    public ApoMarioHighscore(ApoMarioPanel game, Path store) {
        super(game);
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0) score = 0;
        if (survivalTime < 0) survivalTime = 0;
        String name = cleanName(playerName);
        runs.add(new Run(name, score, survivalTime));
        sort();
        if (runs.size() > MAX_RECORDS) runs.subList(MAX_RECORDS, runs.size()).clear();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Run r : runs) result.add(r.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Run r : runs) result.add(r.time); return Collections.unmodifiableList(result);
    }

    public void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)));
            synchronized (this) {
                out.writeInt(MAGIC); out.writeInt(VERSION); out.writeInt(runs.size());
                for (Run r : runs) { out.writeInt(r.score); out.writeInt(r.time); out.writeUTF(r.name); }
            }
            out.close();
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A failed save must not stop the game. */ }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) if (p != null && p.isBVisible()) { chosen = p; break; }
        if (chosen != null) storeRun(chosen.getPoints(), level.getPassedTime(), chosen.getTeamName());
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        if (s.length() == 0) s = "Player";
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        if (b.length > MAX_NAME_BYTES) { int end = s.length(); while (end > 0 && s.substring(0, end).getBytes(StandardCharsets.UTF_8).length > MAX_NAME_BYTES) end--; s = s.substring(0, end); }
        return s;
    }
    private synchronized void sort() { Collections.sort(runs, new Comparator<Run>() { public int compare(Run a, Run b) { int c = Integer.compare(b.score, a.score); return c != 0 ? c : Integer.compare(a.time, b.time); } }); }
    private void load() {
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE_BYTES) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(store)));
            int magic = in.readInt(), version = in.readInt(), count = in.readInt();
            if (magic != MAGIC || version != VERSION || count < 0 || count > MAX_RECORDS) { in.close(); return; }
            List<Run> loaded = new ArrayList<Run>();
            for (int i=0;i<count;i++) { int score=in.readInt(), time=in.readInt(); String name=in.readUTF(); if (score<0||time<0||name.getBytes(StandardCharsets.UTF_8).length>MAX_NAME_BYTES) { in.close(); return; } loaded.add(new Run(cleanName(name),score,time)); }
            in.close(); synchronized(this) { runs.clear(); runs.addAll(loaded); sort(); }
        } catch (IOException ex) { /* retain an empty valid board */ }
    }

    public void init() { view = true; }
    public void makeBackground() { }
    public void makeBackgroundAnimation() { }
    public void makeRunner() { }
    public void makeSearch() { }
    public void keyButtonReleased(int button, char character) { if (button == java.awt.event.KeyEvent.VK_ESCAPE && getGame() != null) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function) && getGame() != null) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0,0,apoMario.ApoMarioConstants.GAME_WIDTH,apoMario.ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(new Font("Dialog", Font.BOLD, 20)); g.drawString("HIGHSCORES", 90, 35);
        g.setFont(new Font("Dialog", Font.PLAIN, 14));
        List<String> n=getPlayersNames(); List<Integer> s=getPlayersScores(); List<Integer> t=getSurvivalTimes();
        for(int i=0;i<n.size();i++) { int y=65+i*16; long sec=t.get(i)/1000L; g.drawString((i+1)+". "+n.get(i),25,y); g.drawString(String.valueOf(s.get(i)),190,y); g.drawString(String.format("%02d:%02d",sec/60,sec%60),255,y); }
        g.drawString("ESC: back", 25, apoMario.ApoMarioConstants.GAME_HEIGHT-12);
    }
}