package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;
import apoMario.ApoMarioConstants;

/** File-backed highscore board. Times are retained in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 64;
    private static final long MAX_FILE = 1024L * 1024L;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    private final Map<ApoMarioLevel, Boolean> recordedRuns = new WeakHashMap<ApoMarioLevel, Boolean>();
    private boolean loaded;
    private static final class Entry {
        String name; int score; int time;
        Entry(String n, int s, int t) { name = n; score = s; time = t; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        entries.add(new Entry(playerName.trim(), score, survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    /** Records the player who actually finished the supplied live run. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || recordedRuns.containsKey(level)) return;
        if (level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer player = level.getPlayers().get(0);
        if (player == null) return;
        String name = player.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        if (storeRun(Math.max(0, player.getPoints()), Math.max(0, level.getPassedTime()), name)) {
            recordedRuns.put(level, Boolean.TRUE);
        }
    }

    public synchronized List<String> getPlayersNames() {
        List<String> result = new ArrayList<String>(); for (Entry e : entries) result.add(e.name); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.score); return Collections.unmodifiableList(result);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> result = new ArrayList<Integer>(); for (Entry e : entries) result.add(e.time); return Collections.unmodifiableList(result);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (Entry e : entries) out.write(e.score + "\t" + e.time + "\t" + Base64.getEncoder().encodeToString(e.name.getBytes(StandardCharsets.UTF_8)) + "\n");
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* persistence must not stop the game */ }
    }

    private synchronized void load() {
        if (loaded) return; loaded = true;
        if (store == null) return;
        try {
            if (!Files.exists(store) || Files.size(store) > MAX_FILE) return;
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while ((line = in.readLine()) != null && count++ < MAX_ENTRIES) {
                    String[] p = line.split("\\t", -1); if (p.length != 3 || p[2].length() > 512) continue;
                    try {
                        int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]);
                        String name = new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                        if (score >= 0 && time >= 0 && validName(name)) entries.add(new Entry(name.trim(), score, time));
                    } catch (RuntimeException ex) { /* ignore malformed records */ }
                }
            } finally { in.close(); }
            sortAndLimit();
        } catch (IOException ex) { entries.clear(); }
    }
    private boolean validName(String name) {
        if (name == null || name.trim().length() == 0 || name.trim().length() > MAX_NAME) return false;
        for (int i = 0; i < name.length(); i++) if (Character.isISOControl(name.charAt(i))) return false;
        return true;
    }
    private void sortAndLimit() {
        Collections.sort(entries, new Comparator<Entry>() { public int compare(Entry a, Entry b) { return b.score < a.score ? -1 : (b.score == a.score ? 0 : 1); } });
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
    }

    /** Renders the board; only this method converts milliseconds to mm:ss. */
    public synchronized void render(Graphics2D g) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(45, 35, ApoMarioConstants.GAME_WIDTH - 90, ApoMarioConstants.GAME_HEIGHT - 70, 20, 20);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_MENU); g.drawString("HIGHSCORES", 70, 80);
        g.setFont(ApoMarioConstants.FONT_STATISTICS);
        for (int i = 0; i < entries.size() && i < 15; i++) {
            Entry e = entries.get(i); int y = 115 + i * 24;
            g.drawString(String.valueOf(i + 1), 75, y); g.drawString(e.name, 120, y); g.drawString(String.valueOf(e.score), 360, y);
            int seconds = e.time / 1000; g.drawString(String.format("%02d:%02d", seconds / 60, seconds % 60), 500, y);
        }
        g.drawString("Press ESC to return", 70, ApoMarioConstants.GAME_HEIGHT - 50);
    }
}