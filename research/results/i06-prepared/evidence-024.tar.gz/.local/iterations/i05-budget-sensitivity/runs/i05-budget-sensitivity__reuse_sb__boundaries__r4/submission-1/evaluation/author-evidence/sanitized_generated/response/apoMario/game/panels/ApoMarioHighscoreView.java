package apoMario.game.panels;

import apoMario.game.ApoMarioPanel;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

/** Compatibility alias for callers that prefer a view-named highscore panel. */
public class ApoMarioHighscoreView extends ApoMarioHighscore {
    public ApoMarioHighscoreView(java.nio.file.Path store) { super(store); }
    public ApoMarioHighscoreView(apoMario.game.ApoMarioPanel game, java.nio.file.Path store) { super(game, store); }
}