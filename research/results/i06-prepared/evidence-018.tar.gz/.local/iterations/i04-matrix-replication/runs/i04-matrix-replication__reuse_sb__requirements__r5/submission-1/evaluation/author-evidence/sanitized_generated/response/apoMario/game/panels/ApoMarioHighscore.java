package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** File-backed, bounded high-score table. Times are retained in milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name = normalize(playerName);
        if (name == null || score < 0 || survivalTime < 0) return false;
        names.add(name); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(survivalTime));
        sort();
        while (names.size() > MAX_ENTRIES) { names.remove(names.size()-1); scores.remove(scores.size()-1); times.remove(times.size()-1); }
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    /** Records the first player after the level has finalized its terminal score. */
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p = level.getPlayers().get(0);
        String name = p.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (int i=0; i<names.size(); i++) {
                    w.write(Integer.toString(scores.get(i).intValue())); w.newLine();
                    w.write(Integer.toString(times.get(i).intValue())); w.newLine();
                    w.write(names.get(i)); w.newLine();
                }
            } finally { w.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* persistence must not stop the game */ }
    }

    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String score, time, name;
                while (names.size() < MAX_ENTRIES && (score=r.readLine()) != null && (time=r.readLine()) != null && (name=r.readLine()) != null) {
                    try {
                        int s=Integer.parseInt(score), t=Integer.parseInt(time); String n=normalize(name);
                        if (s >= 0 && t >= 0 && n != null) { scores.add(Integer.valueOf(s)); times.add(Integer.valueOf(t)); names.add(n); }
                    } catch (RuntimeException ignored) { }
                }
            } finally { r.close(); }
            sort();
        } catch (IOException ignored) { names.clear(); scores.clear(); times.clear(); }
    }
    private String normalize(String value) {
        if (value == null) return null;
        String n=value.trim();
        if (n.length()==0 || n.length()>MAX_NAME) return null;
        for (int i=0;i<n.length();i++) if (Character.isISOControl(n.charAt(i))) return null;
        return n;
    }
    private void sort() {
        ArrayList<Integer> order=new ArrayList<Integer>(); for(int i=0;i<scores.size();i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a,Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); }});
        ArrayList<String> n=new ArrayList<String>(); ArrayList<Integer>s=new ArrayList<Integer>(); ArrayList<Integer>t=new ArrayList<Integer>();
        for(Integer i:order){n.add(names.get(i));s.add(scores.get(i));t.add(times.get(i));} names.clear();names.addAll(n);scores.clear();scores.addAll(s);times.clear();times.addAll(t);
    }

    /** Small menu view, using mm:ss only at render time. */
    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(20,20,width-40,height-40,15,15);
        g.setColor(Color.BLACK); g.setFont(new Font(Font.SANS_SERIF,Font.BOLD,16));
        g.drawString("HIGHSCORES", width/2-55, 50);
        g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,12));
        for(int i=0;i<names.size() && i<12;i++) {
            int y=75+i*14; int ms=times.get(i).intValue()/1000; String tm=String.format("%02d:%02d",ms/60,ms%60);
            g.drawString((i+1)+". "+names.get(i),35,y); g.drawString(scores.get(i)+"",width-110,y); g.drawString(tm,width-65,y);
        }
        g.drawString("ESC: back",35,height-30);
    }
}