package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX = 100, MAX_NAME = 40;
    private final Path store;
    private final List<Entry> entries = new ArrayList<Entry>();
    public ApoMarioHighscore(Path store) { this.store = store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !valid(playerName)) return false;
        entries.add(new Entry(score, survivalTime, playerName.trim()));
        sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() { List<String> r=new ArrayList<String>(); for(Entry e:entries)r.add(e.name); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getPlayersScores() { List<Integer> r=new ArrayList<Integer>(); for(Entry e:entries)r.add(e.score); return Collections.unmodifiableList(r); }
    public synchronized List<Integer> getSurvivalTimes() { List<Integer> r=new ArrayList<Integer>(); for(Entry e:entries)r.add(e.time); return Collections.unmodifiableList(r); }
    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p=level.getPlayers().get(0); if(p==null)return;
        String n=p.getTeamName(); if(n==null||n.trim().length()==0)n="Player";
        storeRun(p.getPoints(), Math.max(0, level.getPassedTime()), n);
    }
    public synchronized void persistAcrossRuns() {
        if(store==null)return;
        try { Path parent=store.toAbsolutePath().getParent(); if(parent!=null)Files.createDirectories(parent); Path t=store.resolveSibling(store.getFileName()+".tmp");
            BufferedWriter w=Files.newBufferedWriter(t, StandardCharsets.UTF_8); try { for(Entry e:entries){w.write(e.score+"\t"+e.time+"\t"+e.name.replace('\t',' ').replace('\n',' ').replace('\r',' '));w.newLine();} } finally {w.close();}
            try {Files.move(t,store,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);} catch(AtomicMoveNotSupportedException e){Files.move(t,store,StandardCopyOption.REPLACE_EXISTING);}
        } catch(IOException e) { }
    }
    private boolean valid(String n){if(n==null)return false;String s=n.trim();if(s.length()==0||s.length()>MAX_NAME)return false;for(int i=0;i<s.length();i++)if(Character.isISOControl(s.charAt(i)))return false;return true;}
    private void load(){if(store==null||!Files.isRegularFile(store))return;try{BufferedReader r=Files.newBufferedReader(store,StandardCharsets.UTF_8);try{String l;int c=0;while(c<MAX&&(l=r.readLine())!=null){String[] p=l.split("\\t",3);if(p.length!=3)continue;try{int s=Integer.parseInt(p[0]),t=Integer.parseInt(p[1]);if(s>=0&&t>=0&&valid(p[2])){entries.add(new Entry(s,t,p[2]));c++;}}catch(NumberFormatException e){}}}finally{r.close();}sort();}catch(IOException e){entries.clear();}}
    private void sort(){Collections.sort(entries,new Comparator<Entry>(){public int compare(Entry a,Entry b){return a.score==b.score?0:(a.score>b.score?-1:1);}});while(entries.size()>MAX)entries.remove(entries.size()-1);}
    private static final class Entry{final int score,time;final String name;Entry(int s,int t,String n){score=s;time=t;name=n;}}
}