package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

/** File-backed, bounded highscore table. Times are always milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim()); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(survivalTime));
        sortAndTrim();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        Path absolute = store.toAbsolutePath();
        Path parent = absolute.getParent();
        Path temp = absolute.resolveSibling(absolute.getFileName().toString() + ".tmp");
        try {
            if (parent != null) Files.createDirectories(parent);
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(Integer.toString(scores.get(i))); out.write('\t');
                    out.write(Integer.toString(times.get(i))); out.write('\t');
                    out.write(names.get(i).replace("\\", "\\\\").replace("\t", " ")); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(temp, absolute, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { try { Files.deleteIfExists(temp); } catch (IOException ignored) { } }
    }

    public void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.isBReplay() || level.getPlayers() == null) return;
        ApoMarioPlayer chosen = null;
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.isBVisible() && (chosen == null || p.getPoints() > chosen.getPoints())) chosen = p;
        }
        if (chosen == null) return;
        String name = chosen.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Player";
        storeRun(chosen.getPoints(), Math.max(0, level.getPassedTime()), name);
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                String line; int count = 0;
                while (count++ < MAX_ENTRIES && (line = in.readLine()) != null) {
                    String[] p = line.split("\\t", 3);
                    if (p.length != 3) continue;
                    try { int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]);
                        String n = p[2].trim().replace("\\\\", "\\");
                        if (score >= 0 && time >= 0 && validName(n)) { names.add(n); scores.add(score); times.add(time); }
                    } catch (RuntimeException ignored) { }
                }
            } finally { in.close(); }
            sortAndTrim();
        } catch (IOException ignored) { names.clear(); scores.clear(); times.clear(); }
    }
    private void sortAndTrim() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(i);
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b) - scores.get(a); } });
        ArrayList<String> n = new ArrayList<String>(); ArrayList<Integer> s = new ArrayList<Integer>(); ArrayList<Integer> t = new ArrayList<Integer>();
        for (int j = 0; j < order.size() && j < MAX_ENTRIES; j++) { int i = order.get(j); n.add(names.get(i)); s.add(scores.get(i)); t.add(times.get(i)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }

    public synchronized void render(Graphics2D g, int width, int height) {
        g.setColor(java.awt.Color.WHITE); g.fillRect(0, 0, width, height);
        g.setColor(java.awt.Color.BLACK); g.drawString("HIGHSCORES", width / 2 - 45, 30);
        for (int i = 0; i < names.size() && i < 12; i++) {
            int y = 55 + i * 15;
            g.drawString((i + 1) + ". " + names.get(i), 25, y);
            g.drawString(Integer.toString(scores.get(i)), width / 2, y);
            g.drawString(formatTime(times.get(i)), width - 65, y);
        }
        g.drawString("ESC: back", 10, height - 10);
    }
    private String formatTime(int ms) { long seconds = ms / 1000L; return String.format("%02d:%02d", seconds / 60L, seconds % 60L); }
}