package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Local, bounded highscore store. Survival times are milliseconds. */
public final class ApoMarioHighscore {
    private static final int MAX_ENTRIES = 100;
    private static final int MAX_NAME = 40;
    private final Path store;
    private final ArrayList<String> names = new ArrayList<String>();
    private final ArrayList<Integer> scores = new ArrayList<Integer>();
    private final ArrayList<Integer> times = new ArrayList<Integer>();

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < 0 || survivalTime < 0 || !validName(playerName)) return false;
        names.add(playerName.trim()); scores.add(Integer.valueOf(score)); times.add(Integer.valueOf(survivalTime));
        sortAndLimit();
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() { return Collections.unmodifiableList(new ArrayList<String>(names)); }
    public synchronized List<Integer> getPlayersScores() { return Collections.unmodifiableList(new ArrayList<Integer>(scores)); }
    public synchronized List<Integer> getSurvivalTimes() { return Collections.unmodifiableList(new ArrayList<Integer>(times)); }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path temp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
            try {
                for (int i = 0; i < names.size(); i++) {
                    out.write(Integer.toString(scores.get(i))); out.write('\t');
                    out.write(Integer.toString(times.get(i))); out.write('\t');
                    out.write(names.get(i).replace("\\", "\\\\").replace("\t", " ")); out.newLine();
                }
            } finally { out.close(); }
            try { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(temp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* persistence must not stop the game */ }
    }

    public synchronized void recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer best = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) if (p != null && p.getPoints() > best.getPoints()) best = p;
        String name = best.getTeamName();
        if (name == null || name.trim().length() == 0) name = "Human";
        storeRun(Math.max(0, best.getPoints()), Math.max(0, level.getPassedTime()), name);
    }

    private boolean validName(String name) {
        if (name == null) return false;
        String s = name.trim();
        if (s.length() == 0 || s.length() > MAX_NAME) return false;
        for (int i = 0; i < s.length(); i++) if (Character.isISOControl(s.charAt(i))) return false;
        return true;
    }
    private void sortAndLimit() {
        ArrayList<Integer> order = new ArrayList<Integer>();
        for (int i = 0; i < scores.size(); i++) order.add(Integer.valueOf(i));
        Collections.sort(order, new Comparator<Integer>() { public int compare(Integer a, Integer b) { return scores.get(b.intValue()).compareTo(scores.get(a.intValue())); } });
        ArrayList<String> n = new ArrayList<String>(); ArrayList<Integer> s = new ArrayList<Integer>(); ArrayList<Integer> t = new ArrayList<Integer>();
        for (int i = 0; i < order.size() && i < MAX_ENTRIES; i++) { int x = order.get(i).intValue(); n.add(names.get(x)); s.add(scores.get(x)); t.add(times.get(x)); }
        names.clear(); names.addAll(n); scores.clear(); scores.addAll(s); times.clear(); times.addAll(t);
    }
    private void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader in = Files.newBufferedReader(store, StandardCharsets.UTF_8); String line; int count = 0;
            try { while ((line = in.readLine()) != null && count++ < 1000) { String[] p = line.split("\\t", 3); if (p.length != 3) continue; try { int s = Integer.parseInt(p[0]); int t = Integer.parseInt(p[1]); if (s >= 0 && t >= 0 && validName(p[2])) { names.add(p[2].trim()); scores.add(Integer.valueOf(s)); times.add(Integer.valueOf(t)); } } catch (RuntimeException ex) { } } } finally { in.close(); }
            sortAndLimit();
        } catch (IOException ex) { names.clear(); scores.clear(); times.clear(); }
    }
}