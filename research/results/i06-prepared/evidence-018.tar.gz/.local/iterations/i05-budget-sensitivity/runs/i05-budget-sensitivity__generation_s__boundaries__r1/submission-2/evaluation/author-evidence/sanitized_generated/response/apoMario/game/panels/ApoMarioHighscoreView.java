package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioModelMenu;
import java.util.*;

import java.awt.Color;
import java.awt.Graphics2D;
import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Dedicated menu view for the persistent highscore table. */
public class ApoMarioHighscoreView extends ApoMarioModelMenu {
    public ApoMarioHighscoreView(ApoMarioPanel game) { super(game); }
    public void init() { super.init(); }
    public void makeBackground() { setIBackground(null); }
    public void makeBackgroundAnimation() { }
    public void makeRunner() { }
    public void makeSearch() { }
    public void keyButtonReleased(int button, char character) { if (button == java.awt.event.KeyEvent.VK_ESCAPE) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function)) getGame().setMenu(); }
    public void excecuteFunction() { if ("backHighscore".equals(getExcecuteFunction())) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(Color.WHITE); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS); g.drawString("HIGHSCORES", 20, 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        ApoMarioHighscore h = getGame().getHighscore();
        java.util.List<String> n = h.getPlayersNames(); java.util.List<Integer> s = h.getPlayersScores(); java.util.List<Integer> t = h.getSurvivalTimes();
        for (int i = 0; i < n.size() && i < 12; i++) {
            int ms = t.get(i); long seconds = ms / 1000L; long minutes = seconds / 60L;
            String time = String.format(java.util.Locale.ROOT, "%d:%02d", Long.valueOf(minutes), Long.valueOf(seconds % 60L));
            g.drawString((i + 1) + ". " + n.get(i), 25, 70 + i * 18);
            g.drawString(String.valueOf(s.get(i)), 190, 70 + i * 18);
            g.drawString(time, 255, 70 + i * 18);
        }
        g.drawString("ESC: back", 20, ApoMarioConstants.GAME_HEIGHT - 15);
    }
}