package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.List;
import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

public class ApoMarioHighscoreView {
    private final ApoMarioPanel game;
    public ApoMarioHighscoreView(ApoMarioPanel game) { this.game=game; }
    public void render(Graphics2D g) {
        ApoMarioHighscore h=game.getHighscore(); List<String> n=h.getPlayersNames(); List<Integer> p=h.getPlayersScores(); List<Integer> t=h.getSurvivalTimes();
        int x=20,y=15,w=ApoMarioConstants.GAME_WIDTH-40,hgt=ApoMarioConstants.GAME_HEIGHT-30;
        g.setColor(new Color(255,255,255,235)); g.fillRoundRect(x,y,w,hgt,20,20); g.setColor(Color.BLACK); g.drawRoundRect(x,y,w,hgt,20,20);
        g.setFont(ApoMarioConstants.FONT_MENU); g.drawString("HIGHSCORES",x+20,y+28); g.setFont(ApoMarioConstants.FONT_STATISTICS);
        if(n.isEmpty()) { g.drawString("No runs recorded yet",x+25,y+65); return; }
        for(int i=0;i<n.size() && i<10;i++) { int sec=t.get(i)/1000; String tm=(sec/60)+":"+(sec%60<10?"0":"")+(sec%60); int yy=y+58+i*22; g.drawString((i+1)+". "+n.get(i),x+25,yy); g.drawString(Integer.toString(p.get(i)),x+w-150,yy); g.drawString(tm,x+w-75,yy); }
        g.setFont(ApoMarioConstants.FONT_FPS); g.drawString("Press H or Escape to return",x+25,y+hgt-12);
    }
}