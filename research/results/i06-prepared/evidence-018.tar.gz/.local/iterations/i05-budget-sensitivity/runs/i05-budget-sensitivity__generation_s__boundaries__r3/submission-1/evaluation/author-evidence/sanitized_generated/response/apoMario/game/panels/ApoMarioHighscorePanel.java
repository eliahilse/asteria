package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscorePanel;
import apoMario.game.panels.ApoMarioModel;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;
import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Dedicated menu view for the persistent high-score table. */
public class ApoMarioHighscorePanel extends ApoMarioModel {
    public ApoMarioHighscorePanel(ApoMarioPanel game) { super(game); }
    public void init() { }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE || button == KeyEvent.VK_H) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function)) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void render(Graphics2D g) {
        g.setColor(new Color(245, 245, 255)); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 20, 35);
        ApoMarioHighscore h = getGame().getHighscore();
        List<String> names = h.getPlayersNames(); List<Integer> scores = h.getPlayersScores(); List<Integer> times = h.getSurvivalTimes();
        g.setFont(ApoMarioConstants.FONT_MENU);
        for (int i = 0; i < names.size() && i < 12; i++) {
            int ms = times.get(i); long seconds = ms / 1000L;
            String time = (seconds / 60L) + ":" + String.format("%02d", seconds % 60L);
            g.drawString((i + 1) + ". " + names.get(i), 25, 65 + i * 14);
            g.drawString(Integer.toString(scores.get(i)), 190, 65 + i * 14);
            g.drawString(time, 250, 65 + i * 14);
        }
        g.setFont(ApoMarioConstants.FONT_MENU); g.drawString("Press H or Escape to return", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
}