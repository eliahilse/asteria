package apoMario.game.panels;

import apoMario.game.ApoMarioSearch;
import apoMario.game.panels.ApoMarioHighscore;
import apoMario.game.panels.ApoMarioHighscoreView;
import apoMario.game.panels.ApoMarioModelMenu;
import org.apogames.entity.ApoAnimation;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.List;

import apoMario.ApoMarioConstants;
import apoMario.game.ApoMarioPanel;

/** Dedicated menu view for the persistent highscore table. */
public class ApoMarioHighscoreView extends ApoMarioModelMenu {
    private final ApoMarioHighscore scores;
    public ApoMarioHighscoreView(ApoMarioPanel game, ApoMarioHighscore scores) { super(game); this.scores = scores; }
    public void init() { super.init(); }
    public void makeBackground() { setIBackground(null); }
    public void makeBackgroundAnimation() { setBackgroundAnimation(new java.util.ArrayList<org.apogames.entity.ApoAnimation>()); }
    public void makeRunner() { setRunner(null); }
    public void makeSearch() { setSearch(new apoMario.game.ApoMarioSearch()); }
    public void keyButtonReleased(int button, char character) { if (button == KeyEvent.VK_ESCAPE || button == KeyEvent.VK_H) getGame().setMenu(); }
    public void mouseButtonFunction(String function) { if ("backHighscore".equals(function)) getGame().setMenu(); }
    public void mouseButtonReleased(int x, int y) { }
    public boolean mouseMoved(int x, int y) { return false; }
    public boolean mouseDragged(int x, int y) { return false; }
    public boolean mousePressed(int x, int y, boolean bRight) { return false; }
    public void think(int delta) { }
    public void excecuteFunction() { }
    public void render(Graphics2D g) {
        g.setColor(new Color(245, 235, 190)); g.fillRect(0, 0, ApoMarioConstants.GAME_WIDTH, ApoMarioConstants.GAME_HEIGHT);
        g.setColor(Color.BLACK); g.setFont(ApoMarioConstants.FONT_CREDITS);
        g.drawString("HIGHSCORES", 20, 35);
        g.setFont(ApoMarioConstants.FONT_MENU);
        List<String> names = scores.getPlayersNames(); List<Integer> points = scores.getPlayersScores(); List<Integer> times = scores.getSurvivalTimes();
        int y = 65;
        for (int i = 0; i < names.size() && i < 15; i++) {
            int seconds = times.get(i) / 1000; String time = (seconds / 60) + ":" + (seconds % 60 < 10 ? "0" : "") + (seconds % 60);
            g.drawString((i + 1) + ". " + names.get(i), 25, y); g.drawString(Integer.toString(points.get(i)), 190, y); g.drawString(time, 255, y); y += 16;
        }
        g.drawString("H / ESC - back", 20, ApoMarioConstants.GAME_HEIGHT - 12);
    }
}