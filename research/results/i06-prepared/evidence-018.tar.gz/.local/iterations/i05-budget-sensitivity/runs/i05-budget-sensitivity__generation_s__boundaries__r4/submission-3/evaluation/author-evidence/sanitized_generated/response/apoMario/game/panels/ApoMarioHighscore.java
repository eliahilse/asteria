package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import apoMario.entity.ApoMarioPlayer;
import apoMario.level.ApoMarioLevel;

public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 48;
    private final Path store;
    private final List<Run> runs = new ArrayList<Run>();
    private static final class Run {
        String name; int score; int time;
        Run(String name, int score, int time) { this.name=name; this.score=score; this.time=time; }
    }
    public ApoMarioHighscore(Path store) { this.store=store; load(); }
    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        String name=clean(playerName); if (name.length()==0) name="Player";
        if (score<0) score=0; if (survivalTime<0) survivalTime=0;
        runs.add(new Run(name,score,survivalTime)); sort(); persistAcrossRuns(); return true;
    }
    public synchronized List<String> getPlayersNames() {
        List<String> r=new ArrayList<String>(); for(Run x:runs) r.add(x.name); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getPlayersScores() {
        List<Integer> r=new ArrayList<Integer>(); for(Run x:runs) r.add(x.score); return Collections.unmodifiableList(r);
    }
    public synchronized List<Integer> getSurvivalTimes() {
        List<Integer> r=new ArrayList<Integer>(); for(Run x:runs) r.add(x.time); return Collections.unmodifiableList(r);
    }
    public void recordRunEnd(ApoMarioLevel level) {
        if(level==null || level.getPlayers()==null || level.getPlayers().isEmpty()) return;
        ApoMarioPlayer p=level.getPlayers().get(0);
        String name=p.getTeamName(); if(name==null || name.trim().length()==0) name="Player";
        storeRun(p.getPoints(),level.getPassedTime(),name);
    }
    public synchronized void persistAcrossRuns() {
        if(store==null) return;
        try {
            Path parent=store.toAbsolutePath().getParent(); if(parent!=null) Files.createDirectories(parent);
            Path temp=store.resolveSibling(store.getFileName().toString()+".tmp");
            BufferedWriter w=Files.newBufferedWriter(temp,StandardCharsets.UTF_8);
            try { w.write("APOMARIO_HIGHSCORE_1"); w.newLine(); for(Run x:runs) { w.write(Integer.toString(x.score)); w.write('\t'); w.write(Integer.toString(x.time)); w.write('\t'); w.write(x.name); w.newLine(); } }
            finally { w.close(); }
            try { Files.move(temp,store,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); }
            catch(IOException e) { Files.move(temp,store,StandardCopyOption.REPLACE_EXISTING); }
        } catch(IOException ignored) { }
    }
    private synchronized void load() {
        if(store==null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r=Files.newBufferedReader(store,StandardCharsets.UTF_8);
            try {
                if(!"APOMARIO_HIGHSCORE_1".equals(r.readLine())) return;
                String line; int count=0;
                while(count<MAX_RECORDS && (line=r.readLine())!=null) {
                    String[] f=line.split("\\t",3); if(f.length!=3) continue;
                    try { int score=Integer.parseInt(f[0]); int time=Integer.parseInt(f[1]); if(score>=0 && time>=0 && f[2].length()>0 && f[2].length()<=MAX_NAME) { runs.add(new Run(clean(f[2]),score,time)); count++; } }
                    catch(NumberFormatException ignored) { }
                }
            } finally { r.close(); }
            sort();
        } catch(IOException ignored) { }
    }
    private void sort() {
        Collections.sort(runs,new Comparator<Run>() { public int compare(Run a,Run b) { return a.score==b.score?a.name.compareTo(b.name):(a.score<b.score?1:-1); } });
        while(runs.size()>MAX_RECORDS) runs.remove(runs.size()-1);
    }
    private static String clean(String s) {
        if(s==null) return ""; StringBuilder b=new StringBuilder();
        for(int i=0;i<s.length() && b.length()<MAX_NAME;i++) { char c=s.charAt(i); if(c>=32 && c!=127 && c!='\t' && c!='\r' && c!='\n') b.append(c); }
        return b.toString().trim();
    }
}