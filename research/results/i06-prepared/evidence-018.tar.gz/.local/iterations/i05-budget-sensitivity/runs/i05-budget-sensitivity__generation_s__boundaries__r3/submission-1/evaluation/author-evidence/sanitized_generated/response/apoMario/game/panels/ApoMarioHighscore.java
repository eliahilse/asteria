package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Base64;

import apoMario.level.ApoMarioLevel;
import apoMario.entity.ApoMarioPlayer;

/** Persistent, bounded high-score table. Survival times are milliseconds. */
public class ApoMarioHighscore {
    private static final int MAX_RECORDS = 100;
    private static final int MAX_NAME = 64;
    private final Path store;
    private final ArrayList<Record> records = new ArrayList<Record>();

    private static final class Record {
        final int score, time;
        final String name;
        Record(int score, int time, String name) { this.score = score; this.time = time; this.name = name; }
    }

    public ApoMarioHighscore(Path store) {
        this.store = store;
        load();
    }

    private String cleanName(String value) {
        if (value == null) return "Player";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < value.length() && b.length() < MAX_NAME; i++) {
            char c = value.charAt(i);
            if (!Character.isISOControl(c)) b.append(c);
        }
        String s = b.toString().trim();
        return s.length() == 0 ? "Player" : s;
    }

    public synchronized boolean storeRun(int score, int survivalTime, String playerName) {
        if (score < -100000000 || score > 1000000000 || survivalTime < 0) return false;
        records.add(new Record(score, survivalTime, cleanName(playerName)));
        Collections.sort(records, new Comparator<Record>() {
            public int compare(Record a, Record b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); }
        });
        while (records.size() > MAX_RECORDS) records.remove(records.size() - 1);
        persistAcrossRuns();
        return true;
    }

    public synchronized List<String> getPlayersNames() {
        ArrayList<String> result = new ArrayList<String>();
        for (Record r : records) result.add(r.name);
        return result;
    }
    public synchronized List<Integer> getPlayersScores() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.score);
        return result;
    }
    public synchronized List<Integer> getSurvivalTimes() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (Record r : records) result.add(r.time);
        return result;
    }

    public synchronized void persistAcrossRuns() {
        if (store == null) return;
        try {
            Path parent = store.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Path tmp = store.resolveSibling(store.getFileName().toString() + ".tmp");
            BufferedWriter w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8);
            try {
                w.write("APO_MARIO_HIGHSCORE_1\n");
                for (Record r : records) {
                    w.write(Integer.toString(r.score)); w.write('\t');
                    w.write(Integer.toString(r.time)); w.write('\t');
                    w.write(Base64.getEncoder().encodeToString(r.name.getBytes(StandardCharsets.UTF_8)));
                    w.write('\n');
                }
            } finally { w.close(); }
            try { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException ex) { Files.move(tmp, store, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { /* A read-only score file must not stop the game. */ }
    }

    private synchronized void load() {
        if (store == null || !Files.isRegularFile(store)) return;
        try {
            BufferedReader r = Files.newBufferedReader(store, StandardCharsets.UTF_8);
            try {
                if (!"APO_MARIO_HIGHSCORE_1".equals(r.readLine())) return;
                String line;
                while (records.size() < MAX_RECORDS && (line = r.readLine()) != null) {
                    if (line.length() > 256) continue;
                    String[] p = line.split("\\t", -1);
                    if (p.length != 3) continue;
                    try {
                        int score = Integer.parseInt(p[0]), time = Integer.parseInt(p[1]);
                        if (score < -100000000 || score > 1000000000 || time < 0) continue;
                        String name = new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8);
                        records.add(new Record(score, time, cleanName(name)));
                    } catch (RuntimeException ex) { /* ignore malformed persisted records */ }
                }
            } finally { r.close(); }
            Collections.sort(records, new Comparator<Record>() {
                public int compare(Record a, Record b) { return b.score == a.score ? 0 : (b.score < a.score ? -1 : 1); }
            });
        } catch (IOException ex) { /* missing or unreadable scores are an empty table */ }
    }

    /** Captures the authoritative player score and elapsed level time once the level is scored. */
    public boolean recordRunEnd(ApoMarioLevel level) {
        if (level == null || level.getPlayers() == null || level.getPlayers().isEmpty()) return false;
        ApoMarioPlayer chosen = level.getPlayers().get(0);
        for (ApoMarioPlayer p : level.getPlayers()) {
            if (p != null && p.getAi() == null) { chosen = p; break; }
        }
        if (chosen == null) return false;
        return storeRun(chosen.getPoints(), Math.max(0, level.getPassedTime()), chosen.getTeamName());
    }
}