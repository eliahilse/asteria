# Highscore context experiment

Results snapshot: 2026-09-07T23:58:11.531642+00:00.

Generation implements the feature from target ApoMario source. Reuse also receives the ApoIcarus donor implementation and reuse-prioritizing instructions.

The paper matrix crosses these two methods with None, S, F, B, S+F, S+B, F+B and S+F+B. Each cell has five independent code requests. None still includes the task and target source.

The follow-up evaluates the top two functional conditions per method against fresh no-security controls and three acquired security-context strategies. Security outcomes do not select conditions.

Read the cell counts before interpreting percentages. Full functionality means all 16 functional checks pass on one response. Test/check totals are correlated outcomes, not additional independent replicates. Wilson intervals below apply only to the full-functionality endpoint within a cell, following the [NIST formula](https://www.itl.nist.gov/div898/handbook/prc/section2/prc241.htm). They assume independent draws with stable success probability in that cell; requested sampling settings remain unverified.

## highscore-paper-luna-v2

**Complete**: 80/80 attempts recorded; 0 pending response or evaluation.

Model: gpt-5.6-luna; requested medium reasoning. 79 attempts lack an effective-settings attestation. No claim of verified sampling settings is made.

Manifest SHA-256: `3b83dd17ecb217d6268e11679c7f732094e067c4dac75d96f199261a63e708bf`.

| Condition | Game compiled | Fully functional | 95% Wilson interval | Unit passes / 7n | Invoked passes / 4n | Autonomous passes / 5n | Security passes / 11n |
| --- | --- | --- | --- | --- | --- | --- | --- |
| reuse_none | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 14/20 (70.0%) | 5/25 (20.0%) | 17/55 (30.9%) |
| reuse_s | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 17/20 (85.0%) | 5/25 (20.0%) | 19/55 (34.5%) |
| reuse_f | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 19/20 (95.0%) | 5/25 (20.0%) | 19/55 (34.5%) |
| reuse_b | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 20/20 (100.0%) | 5/25 (20.0%) | 20/55 (36.4%) |
| reuse_sb | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 20/20 (100.0%) | 5/25 (20.0%) | 20/55 (36.4%) |
| reuse_fb | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 20/20 (100.0%) | 5/25 (20.0%) | 23/55 (41.8%) |
| reuse_sf | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 19/20 (95.0%) | 5/25 (20.0%) | 18/55 (32.7%) |
| reuse_sfb | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 20/20 (100.0%) | 5/25 (20.0%) | 18/55 (32.7%) |
| generation_none | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 14/20 (70.0%) | 5/25 (20.0%) | 16/55 (29.1%) |
| generation_s | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 16/20 (80.0%) | 5/25 (20.0%) | 17/55 (30.9%) |
| generation_f | 3/5 (60.0%) | 0/5 (0.0%) | 0.0–43.4% | 21/35 (60.0%) | 7/20 (35.0%) | 3/25 (12.0%) | 11/55 (20.0%) |
| generation_b | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 16/20 (80.0%) | 5/25 (20.0%) | 18/55 (32.7%) |
| generation_sb | 4/5 (80.0%) | 0/5 (0.0%) | 0.0–43.4% | 28/35 (80.0%) | 14/20 (70.0%) | 4/25 (16.0%) | 17/55 (30.9%) |
| generation_fb | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 16/20 (80.0%) | 5/25 (20.0%) | 17/55 (30.9%) |
| generation_sf | 4/5 (80.0%) | 0/5 (0.0%) | 0.0–43.4% | 28/35 (80.0%) | 16/20 (80.0%) | 4/25 (16.0%) | 17/55 (30.9%) |
| generation_sfb | 5/5 (100.0%) | 0/5 (0.0%) | 0.0–43.4% | 35/35 (100.0%) | 18/20 (90.0%) | 5/25 (20.0%) | 15/55 (27.3%) |

### Functional selection

Rule: full functional successes / all attempts; functional checks passed / (16 × all attempts); compilations / all attempts; ascending original prompt ID.

Generation: generation_sfb → generation_s → generation_b → generation_fb → generation_none → generation_sf → generation_sb → generation_f.

Reuse: reuse_b → reuse_sb → reuse_fb → reuse_sfb → reuse_f → reuse_sf → reuse_s → reuse_none.

Selected: generation_sfb, generation_s, reuse_b, reuse_sb.

No baseline response passed all functional checks. Selection therefore uses the predeclared per-test tie-breaker; selected conditions are not demonstrated working implementations.

### Every test by condition

Counts preserve pass, fail and unresolved outcomes. Pass/tested conditions on execution; pass/attempt retains every recorded model attempt.

#### reuse_none

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 3 | 2 | 0 | 0 | 0 | 0 | 3/5 (60.0%) | 3/5 (60.0%) |
| invoked.recordsRealPlayerName | 1 | 4 | 0 | 0 | 0 | 0 | 1/5 (20.0%) | 1/5 (20.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 3 | 0 | 0 | 0 | 0 | 2/5 (40.0%) | 2/5 (40.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 1 | 0 | 4 | 0 | 0 | 0/1 (0.0%) | 0/5 (0.0%) |

#### reuse_s

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 2 | 3 | 0 | 0 | 0 | 0 | 2/5 (40.0%) | 2/5 (40.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 3 | 0 | 0 | 0 | 0 | 2/5 (40.0%) | 2/5 (40.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 1 | 4 | 0 | 0 | 0 | 0 | 1/5 (20.0%) | 1/5 (20.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 1 | 0 | 0 | 4 | 0 | 0 | 1/1 (100.0%) | 1/5 (20.0%) |

#### reuse_f

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealPlayerName | 4 | 1 | 0 | 0 | 0 | 0 | 4/5 (80.0%) | 4/5 (80.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 4 | 1 | 0 | 0 | 0 | 0 | 4/5 (80.0%) | 4/5 (80.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 3 | 0 | 2 | 0 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |

#### reuse_b

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 2 | 0 | 3 | 0 | 0 | 0/2 (0.0%) | 0/5 (0.0%) |

#### reuse_sb

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 3 | 2 | 0 | 0 | 0 | 0 | 3/5 (60.0%) | 3/5 (60.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 1 | 4 | 0 | 0 | 0 | 0 | 1/5 (20.0%) | 1/5 (20.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 1 | 1 | 0 | 3 | 0 | 0 | 1/2 (50.0%) | 1/5 (20.0%) |

#### reuse_fb

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 4 | 1 | 0 | 0 | 0 | 0 | 4/5 (80.0%) | 4/5 (80.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 2 | 3 | 0 | 0 | 0 | 0 | 2/5 (40.0%) | 2/5 (40.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 2 | 1 | 0 | 2 | 0 | 0 | 2/3 (66.7%) | 2/5 (40.0%) |

#### reuse_sf

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 4 | 1 | 0 | 0 | 0 | 0 | 4/5 (80.0%) | 4/5 (80.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 3 | 2 | 0 | 0 | 0 | 0 | 3/5 (60.0%) | 3/5 (60.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 1 | 0 | 4 | 0 | 0 | 0/1 (0.0%) | 0/5 (0.0%) |

#### reuse_sfb

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 3 | 2 | 0 | 0 | 0 | 0 | 3/5 (60.0%) | 3/5 (60.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 3 | 0 | 2 | 0 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |

#### generation_none

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 1 | 4 | 0 | 0 | 0 | 0 | 1/5 (20.0%) | 1/5 (20.0%) |
| invoked.recordsRealPlayerName | 3 | 2 | 0 | 0 | 0 | 0 | 3/5 (60.0%) | 3/5 (60.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 1 | 4 | 0 | 0 | 0 | 0 | 1/5 (20.0%) | 1/5 (20.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 1 | 0 | 4 | 0 | 0 | 0/1 (0.0%) | 0/5 (0.0%) |

#### generation_s

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 1 | 4 | 0 | 0 | 0 | 0 | 1/5 (20.0%) | 1/5 (20.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 3 | 0 | 0 | 0 | 0 | 2/5 (40.0%) | 2/5 (40.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 2 | 0 | 3 | 0 | 0 | 0/2 (0.0%) | 0/5 (0.0%) |

#### generation_f

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| unit.saveAddsEntry | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| unit.parallelListsAligned | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| unit.boardSortedDescendingByPoints | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| unit.entriesPersistAcrossSessions | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| unit.emptyPersistRobust | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| unit.rankingPreservedAfterReload | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| invoked.recordsRealScore | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| invoked.recordsRealSurvivalTime | 1 | 2 | 2 | 0 | 0 | 0 | 1/3 (33.3%) | 1/5 (20.0%) |
| invoked.recordsRealPlayerName | 0 | 3 | 2 | 0 | 0 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 3 | 2 | 0 | 0 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 3 | 2 | 0 | 0 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 3 | 0 | 2 | 0 | 0 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 3 | 2 | 0 | 0 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 3 | 2 | 0 | 0 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 3 | 0 | 1 | 0 | 1 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| security_v1.rejectsNegativeScore | 0 | 3 | 1 | 0 | 1 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 3 | 1 | 0 | 1 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 3 | 1 | 0 | 1 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 3 | 1 | 0 | 1 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 3 | 1 | 0 | 1 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 1 | 1 | 0 | 1 | 0 | 2/3 (66.7%) | 2/5 (40.0%) |
| security_v1.malformedStoreDoesNotCrash | 3 | 0 | 1 | 0 | 1 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| security_v1.oversizedPhysicalLine | 0 | 3 | 1 | 0 | 1 | 0 | 0/3 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 3 | 0 | 1 | 0 | 1 | 0 | 3/3 (100.0%) | 3/5 (60.0%) |
| security_v1.largePersistedRecordSet | 0 | 1 | 1 | 2 | 1 | 0 | 0/1 (0.0%) | 0/5 (0.0%) |

#### generation_b

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 1 | 4 | 0 | 0 | 0 | 0 | 1/5 (20.0%) | 1/5 (20.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 3 | 2 | 0 | 0 | 0 | 0 | 3/5 (60.0%) | 3/5 (60.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 1 | 0 | 4 | 0 | 0 | 0/1 (0.0%) | 0/5 (0.0%) |

#### generation_sb

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.saveAddsEntry | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.parallelListsAligned | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.boardSortedDescendingByPoints | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.entriesPersistAcrossSessions | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.emptyPersistRobust | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.rankingPreservedAfterReload | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| invoked.recordsRealScore | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| invoked.recordsRealSurvivalTime | 2 | 2 | 1 | 0 | 0 | 0 | 2/4 (50.0%) | 2/5 (40.0%) |
| invoked.recordsRealPlayerName | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 4 | 1 | 0 | 0 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 4 | 1 | 0 | 0 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 4 | 1 | 0 | 0 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 4 | 1 | 0 | 0 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 4 | 0 | 0 | 0 | 1 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| security_v1.rejectsNegativeScore | 0 | 4 | 0 | 0 | 1 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 4 | 0 | 0 | 1 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 4 | 0 | 0 | 1 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 4 | 0 | 0 | 1 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 4 | 0 | 0 | 1 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 2 | 0 | 0 | 1 | 0 | 2/4 (50.0%) | 2/5 (40.0%) |
| security_v1.malformedStoreDoesNotCrash | 4 | 0 | 0 | 0 | 1 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| security_v1.oversizedPhysicalLine | 1 | 3 | 0 | 0 | 1 | 0 | 1/4 (25.0%) | 1/5 (20.0%) |
| security_v1.nativeDeserializationCanary | 4 | 0 | 0 | 0 | 1 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| security_v1.largePersistedRecordSet | 2 | 1 | 0 | 1 | 1 | 0 | 2/3 (66.7%) | 2/5 (40.0%) |

#### generation_fb

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 1 | 4 | 0 | 0 | 0 | 0 | 1/5 (20.0%) | 1/5 (20.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 3 | 0 | 0 | 0 | 0 | 2/5 (40.0%) | 2/5 (40.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 2 | 0 | 3 | 0 | 0 | 0/2 (0.0%) | 0/5 (0.0%) |

#### generation_sf

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.saveAddsEntry | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.parallelListsAligned | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.boardSortedDescendingByPoints | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.entriesPersistAcrossSessions | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.emptyPersistRobust | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| unit.rankingPreservedAfterReload | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| invoked.recordsRealScore | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| invoked.recordsRealSurvivalTime | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| invoked.recordsRealPlayerName | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 4 | 1 | 0 | 0 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 4 | 1 | 0 | 0 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 4 | 0 | 1 | 0 | 0 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 4 | 1 | 0 | 0 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 4 | 1 | 0 | 0 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 4 | 0 | 0 | 0 | 1 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| security_v1.rejectsNegativeScore | 0 | 4 | 0 | 0 | 1 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 4 | 0 | 0 | 1 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 1 | 3 | 0 | 0 | 1 | 0 | 1/4 (25.0%) | 1/5 (20.0%) |
| security_v1.rejectsBlankName | 1 | 3 | 0 | 0 | 1 | 0 | 1/4 (25.0%) | 1/5 (20.0%) |
| security_v1.rejectsExcessiveName | 0 | 4 | 0 | 0 | 1 | 0 | 0/4 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 1 | 3 | 0 | 0 | 1 | 0 | 1/4 (25.0%) | 1/5 (20.0%) |
| security_v1.malformedStoreDoesNotCrash | 4 | 0 | 0 | 0 | 1 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| security_v1.oversizedPhysicalLine | 1 | 3 | 0 | 0 | 1 | 0 | 1/4 (25.0%) | 1/5 (20.0%) |
| security_v1.nativeDeserializationCanary | 4 | 0 | 0 | 0 | 1 | 0 | 4/4 (100.0%) | 4/5 (80.0%) |
| security_v1.largePersistedRecordSet | 1 | 1 | 0 | 2 | 1 | 0 | 1/2 (50.0%) | 1/5 (20.0%) |

#### generation_sfb

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.saveAddsEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.parallelListsAligned | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.boardSortedDescendingByPoints | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.entriesPersistAcrossSessions | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.emptyPersistRobust | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| unit.rankingPreservedAfterReload | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealScore | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordsRealSurvivalTime | 3 | 2 | 0 | 0 | 0 | 0 | 3/5 (60.0%) | 3/5 (60.0%) |
| invoked.recordsRealPlayerName | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.validRecordRoundTrip | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsNullName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsBlankName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.boundsRetainedEntries | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.malformedStoreDoesNotCrash | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 5 | 0 | 0 | 0 | 0 | 0/5 (0.0%) | 0/5 (0.0%) |
| security_v1.nativeDeserializationCanary | 5 | 0 | 0 | 0 | 0 | 0 | 5/5 (100.0%) | 5/5 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 0 | 0 | 5 | 0 | 0 | — (0 attempts) | 0/5 (0.0%) |

### Protocol differences and limits

- Four v1 transport-calibration attempts are excluded: universal newline conversion altered the submitted text relative to its frozen hash. V2 reads exact UTF-8 prompt bytes and starts 80 new attempts.
- Luna with requested medium reasoning replaces the original model/temperature.
- Original task text and output suffix retained. Attachment bytes are inlined with boundaries in original attachment order instead of using a provider Files API; UTF-8 replacement decoding is recorded.
- Five exploratory repetitions per cell, randomized dispatch order. Repetition IDs are blocks, not identical model seeds.
- Original author integration plus documented deterministic package/import repairs. Sixteen functional and eleven separate security checks.
- Requested settings and served model are recorded. Missing effective-settings attestations remain unverified and are disclosed in results.
- Selection uses functionality over all attempts. Security outcomes do not choose winners. Selected controls are rerun in the follow-up to limit selection bias.
- Security treatments also add repository-derived information and prompt length. This design does not isolate security wording from those effects.

## highscore-security-luna-v1

**INCOMPLETE / provisional**: 43/80 attempts recorded; 4 pending response or evaluation.

Model: gpt-5.6-luna; requested medium reasoning. 40 attempts lack an effective-settings attestation. No claim of verified sampling settings is made.

Manifest SHA-256: `a85193d919358fdd535b186319528f2b5550a662c15a909ec5fef9b527522074`.

| Condition | Game compiled | Fully functional | 95% Wilson interval | Unit passes / 7n | Invoked passes / 4n | Autonomous passes / 5n | Security passes / 11n |
| --- | --- | --- | --- | --- | --- | --- | --- |
| reuse_b__none | 2/3 (66.7%) | 0/3 (0.0%) | 0.0–56.1% | 14/21 (66.7%) | 8/12 (66.7%) | 2/15 (13.3%) | 6/33 (18.2%) |
| reuse_b__overview | 3/3 (100.0%) | 0/3 (0.0%) | 0.0–56.1% | 21/21 (100.0%) | 12/12 (100.0%) | 3/15 (20.0%) | 9/33 (27.3%) |
| reuse_b__task | 2/3 (66.7%) | 0/3 (0.0%) | 0.0–56.1% | 14/21 (66.7%) | 8/12 (66.7%) | 2/15 (13.3%) | 6/33 (18.2%) |
| reuse_b__flows | 1/3 (33.3%) | 0/3 (0.0%) | 0.0–56.1% | 7/21 (33.3%) | 4/12 (33.3%) | 1/15 (6.7%) | 3/33 (9.1%) |
| reuse_sb__none | 3/3 (100.0%) | 0/3 (0.0%) | 0.0–56.1% | 21/21 (100.0%) | 12/12 (100.0%) | 3/15 (20.0%) | 12/33 (36.4%) |
| reuse_sb__overview | 3/3 (100.0%) | 0/3 (0.0%) | 0.0–56.1% | 21/21 (100.0%) | 12/12 (100.0%) | 3/15 (20.0%) | 16/33 (48.5%) |
| reuse_sb__task | 3/3 (100.0%) | 0/3 (0.0%) | 0.0–56.1% | 21/21 (100.0%) | 12/12 (100.0%) | 3/15 (20.0%) | 9/33 (27.3%) |
| reuse_sb__flows | 1/2 (50.0%) | 0/2 (0.0%) | 0.0–65.8% | 7/14 (50.0%) | 4/8 (50.0%) | 1/10 (10.0%) | 3/22 (13.6%) |
| generation_s__none | 1/2 (50.0%) | 0/2 (0.0%) | 0.0–65.8% | 7/14 (50.0%) | 3/8 (37.5%) | 1/10 (10.0%) | 4/22 (18.2%) |
| generation_s__overview | 3/3 (100.0%) | 0/3 (0.0%) | 0.0–56.1% | 21/21 (100.0%) | 9/12 (75.0%) | 3/15 (20.0%) | 11/33 (33.3%) |
| generation_s__task | 2/3 (66.7%) | 0/3 (0.0%) | 0.0–56.1% | 14/21 (66.7%) | 7/12 (58.3%) | 2/15 (13.3%) | 8/33 (24.2%) |
| generation_s__flows | 3/3 (100.0%) | 0/3 (0.0%) | 0.0–56.1% | 21/21 (100.0%) | 11/12 (91.7%) | 3/15 (20.0%) | 11/33 (33.3%) |
| generation_sfb__none | 3/3 (100.0%) | 0/3 (0.0%) | 0.0–56.1% | 21/21 (100.0%) | 9/12 (75.0%) | 3/15 (20.0%) | 12/33 (36.4%) |
| generation_sfb__overview | 2/2 (100.0%) | 0/2 (0.0%) | 0.0–65.8% | 14/14 (100.0%) | 6/8 (75.0%) | 2/10 (20.0%) | 9/22 (40.9%) |
| generation_sfb__task | 2/2 (100.0%) | 0/2 (0.0%) | 0.0–65.8% | 14/14 (100.0%) | 6/8 (75.0%) | 2/10 (20.0%) | 11/22 (50.0%) |
| generation_sfb__flows | 2/2 (100.0%) | 0/2 (0.0%) | 0.0–65.8% | 14/14 (100.0%) | 7/8 (87.5%) | 2/10 (20.0%) | 9/22 (40.9%) |

### Frozen context acquisitions

| Method | Strategy | Acquisition | Items | Citations matched / total | Uncited items | Status |
| --- | --- | --- | --- | --- | --- | --- |
| Generation | overview | context-6385045f9b0a4575b2adea66ac4629ae | 5 | 6/6 | 2 | settings_unverified |
| Generation | task | context-df9645fbb62744e8a2e55498077010d7 | 7 | 4/4 | 3 | settings_unverified |
| Generation | flows | context-f7c2d4f6fb7947c2a4ad1e2a66ab8dbf | 6 | 9/9 | 2 | settings_unverified |
| Reuse | overview | context-4202ad3e6eca449988e2a178265fafa3 | 1 | 0/0 | 1 | settings_unverified |
| Reuse | task | context-1a20e46e432548c984a70143d5393966 | 1 | 1/1 | 0 | settings_unverified |
| Reuse | flows | context-2cc481b5321748dc9584419e5744b4ba | 4 | 3/3 | 2 | settings_unverified |

Each context is acquired once and reused across that method’s selected paper contexts and code repetitions. Citation matching checks exact inspected source text; it does not prove the security claim.

### Security differences from fresh controls

Treatment minus the matching follow-up control, in percentage points (pp). Responses are independent; matching repetition labels do not imply shared model seeds. These are descriptive differences without a multiplicity-adjusted significance claim.

#### generation_sfb

Functional checks:

| Test | Security case | Control pass / tested | Treatment pass / tested | Control pass / attempts | Treatment pass / attempts | Δ tested pp | Δ all attempts pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.saveAddsEntry | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.parallelListsAligned | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.boardSortedDescendingByPoints | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.entriesPersistAcrossSessions | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.emptyPersistRobust | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.rankingPreservedAfterReload | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealScore | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealSurvivalTime | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| invoked.recordsRealPlayerName | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordRunEndAddsExactlyOneEntry | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| autonomous.runEndRecordsScoreWithoutHelp | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| unit.emptyBoardInitially | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.saveAddsEntry | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.parallelListsAligned | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.boardSortedDescendingByPoints | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.entriesPersistAcrossSessions | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.emptyPersistRobust | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.rankingPreservedAfterReload | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealScore | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealSurvivalTime | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| invoked.recordsRealPlayerName | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordRunEndAddsExactlyOneEntry | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| autonomous.runEndRecordsScoreWithoutHelp | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| unit.emptyBoardInitially | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.saveAddsEntry | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.parallelListsAligned | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.boardSortedDescendingByPoints | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.entriesPersistAcrossSessions | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.emptyPersistRobust | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| unit.rankingPreservedAfterReload | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealScore | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealSurvivalTime | flows | 0/3 (0.0%) | 1/2 (50.0%) | 0/3 (0.0%) | 1/2 (50.0%) | +50.0 | +50.0 |
| invoked.recordsRealPlayerName | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| invoked.recordRunEndAddsExactlyOneEntry | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| autonomous.runEndRecordsScoreWithoutHelp | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |

Security checks:

| Test | Security case | Control pass / tested | Treatment pass / tested | Control pass / attempts | Treatment pass / attempts | Δ tested pp | Δ all attempts pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| security_v1.validRecordRoundTrip | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeScore | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | overview | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | overview | 2/3 (66.7%) | 1/2 (50.0%) | 2/3 (66.7%) | 1/2 (50.0%) | -16.7 | -16.7 |
| security_v1.malformedStoreDoesNotCrash | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.oversizedPhysicalLine | overview | 0/3 (0.0%) | 1/2 (50.0%) | 0/3 (0.0%) | 1/2 (50.0%) | +50.0 | +50.0 |
| security_v1.nativeDeserializationCanary | overview | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.largePersistedRecordSet | overview | 1/1 (100.0%) | 1/1 (100.0%) | 1/3 (33.3%) | 1/2 (50.0%) | +0.0 | +16.7 |
| security_v1.validRecordRoundTrip | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeScore | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | task | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | task | 2/3 (66.7%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/2 (100.0%) | +33.3 | +33.3 |
| security_v1.malformedStoreDoesNotCrash | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.oversizedPhysicalLine | task | 0/3 (0.0%) | 2/2 (100.0%) | 0/3 (0.0%) | 2/2 (100.0%) | +100.0 | +100.0 |
| security_v1.nativeDeserializationCanary | task | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.largePersistedRecordSet | task | 1/1 (100.0%) | 1/1 (100.0%) | 1/3 (33.3%) | 1/2 (50.0%) | +0.0 | +16.7 |
| security_v1.validRecordRoundTrip | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeScore | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | flows | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | flows | 2/3 (66.7%) | 1/2 (50.0%) | 2/3 (66.7%) | 1/2 (50.0%) | -16.7 | -16.7 |
| security_v1.malformedStoreDoesNotCrash | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.oversizedPhysicalLine | flows | 0/3 (0.0%) | 1/2 (50.0%) | 0/3 (0.0%) | 1/2 (50.0%) | +50.0 | +50.0 |
| security_v1.nativeDeserializationCanary | flows | 3/3 (100.0%) | 2/2 (100.0%) | 3/3 (100.0%) | 2/2 (100.0%) | +0.0 | +0.0 |
| security_v1.largePersistedRecordSet | flows | 1/1 (100.0%) | 1/1 (100.0%) | 1/3 (33.3%) | 1/2 (50.0%) | +0.0 | +16.7 |

#### generation_s

Functional checks:

| Test | Security case | Control pass / tested | Treatment pass / tested | Control pass / attempts | Treatment pass / attempts | Δ tested pp | Δ all attempts pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.saveAddsEntry | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.parallelListsAligned | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.boardSortedDescendingByPoints | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.entriesPersistAcrossSessions | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.emptyPersistRobust | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.rankingPreservedAfterReload | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| invoked.recordsRealScore | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| invoked.recordsRealSurvivalTime | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| invoked.recordsRealPlayerName | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| invoked.recordRunEndAddsExactlyOneEntry | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| autonomous.runEndRecordsScoreWithoutHelp | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| unit.emptyBoardInitially | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| unit.saveAddsEntry | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| unit.parallelListsAligned | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| unit.boardSortedDescendingByPoints | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| unit.entriesPersistAcrossSessions | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| unit.emptyPersistRobust | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| unit.rankingPreservedAfterReload | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| invoked.recordsRealScore | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| invoked.recordsRealSurvivalTime | task | 0/1 (0.0%) | 1/2 (50.0%) | 0/2 (0.0%) | 1/3 (33.3%) | +50.0 | +33.3 |
| invoked.recordsRealPlayerName | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| invoked.recordRunEndAddsExactlyOneEntry | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| autonomous.runEndRecordsScoreWithoutHelp | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| unit.emptyBoardInitially | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.saveAddsEntry | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.parallelListsAligned | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.boardSortedDescendingByPoints | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.entriesPersistAcrossSessions | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.emptyPersistRobust | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| unit.rankingPreservedAfterReload | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| invoked.recordsRealScore | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| invoked.recordsRealSurvivalTime | flows | 0/1 (0.0%) | 2/3 (66.7%) | 0/2 (0.0%) | 2/3 (66.7%) | +66.7 | +66.7 |
| invoked.recordsRealPlayerName | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| invoked.recordRunEndAddsExactlyOneEntry | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| autonomous.runEndRecordsScoreWithoutHelp | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |

Security checks:

| Test | Security case | Control pass / tested | Treatment pass / tested | Control pass / attempts | Treatment pass / attempts | Δ tested pp | Δ all attempts pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| security_v1.validRecordRoundTrip | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| security_v1.rejectsNegativeScore | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | overview | 1/1 (100.0%) | 2/3 (66.7%) | 1/2 (50.0%) | 2/3 (66.7%) | -33.3 | +16.7 |
| security_v1.malformedStoreDoesNotCrash | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| security_v1.oversizedPhysicalLine | overview | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.nativeDeserializationCanary | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| security_v1.largePersistedRecordSet | overview | — (0 attempts) | — (0 attempts) | 0/2 (0.0%) | 0/3 (0.0%) | — | +0.0 |
| security_v1.validRecordRoundTrip | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| security_v1.rejectsNegativeScore | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| security_v1.malformedStoreDoesNotCrash | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| security_v1.oversizedPhysicalLine | task | 0/1 (0.0%) | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.nativeDeserializationCanary | task | 1/1 (100.0%) | 2/2 (100.0%) | 1/2 (50.0%) | 2/3 (66.7%) | +0.0 | +16.7 |
| security_v1.largePersistedRecordSet | task | — (0 attempts) | — (0 attempts) | 0/2 (0.0%) | 0/3 (0.0%) | — | +0.0 |
| security_v1.validRecordRoundTrip | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| security_v1.rejectsNegativeScore | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | flows | 1/1 (100.0%) | 2/3 (66.7%) | 1/2 (50.0%) | 2/3 (66.7%) | -33.3 | +16.7 |
| security_v1.malformedStoreDoesNotCrash | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| security_v1.oversizedPhysicalLine | flows | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.nativeDeserializationCanary | flows | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | 3/3 (100.0%) | +0.0 | +50.0 |
| security_v1.largePersistedRecordSet | flows | — (0 attempts) | — (0 attempts) | 0/2 (0.0%) | 0/3 (0.0%) | — | +0.0 |

#### reuse_b

Functional checks:

| Test | Security case | Control pass / tested | Treatment pass / tested | Control pass / attempts | Treatment pass / attempts | Δ tested pp | Δ all attempts pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| unit.saveAddsEntry | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| unit.parallelListsAligned | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| unit.boardSortedDescendingByPoints | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| unit.entriesPersistAcrossSessions | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| unit.emptyPersistRobust | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| unit.rankingPreservedAfterReload | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| invoked.recordsRealScore | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| invoked.recordsRealSurvivalTime | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| invoked.recordsRealPlayerName | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| invoked.recordRunEndAddsExactlyOneEntry | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| autonomous.runEndRecordsScoreWithoutHelp | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| unit.emptyBoardInitially | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| unit.saveAddsEntry | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| unit.parallelListsAligned | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| unit.boardSortedDescendingByPoints | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| unit.entriesPersistAcrossSessions | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| unit.emptyPersistRobust | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| unit.rankingPreservedAfterReload | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| invoked.recordsRealScore | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| invoked.recordsRealSurvivalTime | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| invoked.recordsRealPlayerName | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| invoked.recordRunEndAddsExactlyOneEntry | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| autonomous.runEndRecordsScoreWithoutHelp | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| unit.emptyBoardInitially | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| unit.saveAddsEntry | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| unit.parallelListsAligned | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| unit.boardSortedDescendingByPoints | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| unit.entriesPersistAcrossSessions | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| unit.emptyPersistRobust | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| unit.rankingPreservedAfterReload | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| invoked.recordsRealScore | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| invoked.recordsRealSurvivalTime | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| invoked.recordsRealPlayerName | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| invoked.recordRunEndAddsExactlyOneEntry | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| autonomous.runEndRecordsScoreWithoutHelp | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |

Security checks:

| Test | Security case | Control pass / tested | Treatment pass / tested | Control pass / attempts | Treatment pass / attempts | Δ tested pp | Δ all attempts pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| security_v1.validRecordRoundTrip | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| security_v1.rejectsNegativeScore | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.malformedStoreDoesNotCrash | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| security_v1.oversizedPhysicalLine | overview | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.nativeDeserializationCanary | overview | 2/2 (100.0%) | 3/3 (100.0%) | 2/3 (66.7%) | 3/3 (100.0%) | +0.0 | +33.3 |
| security_v1.largePersistedRecordSet | overview | 0/1 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.validRecordRoundTrip | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeScore | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.malformedStoreDoesNotCrash | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| security_v1.oversizedPhysicalLine | task | 0/2 (0.0%) | 0/2 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.nativeDeserializationCanary | task | 2/2 (100.0%) | 2/2 (100.0%) | 2/3 (66.7%) | 2/3 (66.7%) | +0.0 | +0.0 |
| security_v1.largePersistedRecordSet | task | 0/1 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.validRecordRoundTrip | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| security_v1.rejectsNegativeScore | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.malformedStoreDoesNotCrash | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| security_v1.oversizedPhysicalLine | flows | 0/2 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.nativeDeserializationCanary | flows | 2/2 (100.0%) | 1/1 (100.0%) | 2/3 (66.7%) | 1/3 (33.3%) | +0.0 | -33.3 |
| security_v1.largePersistedRecordSet | flows | 0/1 (0.0%) | — (0 attempts) | 0/3 (0.0%) | 0/3 (0.0%) | — | +0.0 |

#### reuse_sb

Functional checks:

| Test | Security case | Control pass / tested | Treatment pass / tested | Control pass / attempts | Treatment pass / attempts | Δ tested pp | Δ all attempts pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.saveAddsEntry | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.parallelListsAligned | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.boardSortedDescendingByPoints | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.entriesPersistAcrossSessions | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.emptyPersistRobust | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.rankingPreservedAfterReload | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealScore | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealSurvivalTime | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealPlayerName | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| invoked.recordRunEndAddsExactlyOneEntry | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| autonomous.runEndRecordsScoreWithoutHelp | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| unit.emptyBoardInitially | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.saveAddsEntry | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.parallelListsAligned | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.boardSortedDescendingByPoints | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.entriesPersistAcrossSessions | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.emptyPersistRobust | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| unit.rankingPreservedAfterReload | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealScore | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealSurvivalTime | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| invoked.recordsRealPlayerName | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| invoked.recordRunEndAddsExactlyOneEntry | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| autonomous.runEndRecordsScoreWithoutHelp | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| unit.emptyBoardInitially | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| unit.saveAddsEntry | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| unit.parallelListsAligned | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| unit.boardSortedDescendingByPoints | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| unit.entriesPersistAcrossSessions | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| unit.emptyPersistRobust | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| unit.rankingPreservedAfterReload | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| invoked.recordsRealScore | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| invoked.recordsRealSurvivalTime | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| invoked.recordsRealPlayerName | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| invoked.recordRunEndAddsExactlyOneEntry | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| autonomous.runEndRecordsScoreWithoutHelp | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.recordedNameIsTheRealPlayersName | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.noPhantomEntriesWithoutRunEnd | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |

Security checks:

| Test | Security case | Control pass / tested | Treatment pass / tested | Control pass / attempts | Treatment pass / attempts | Δ tested pp | Δ all attempts pp |
| --- | --- | --- | --- | --- | --- | --- | --- |
| security_v1.validRecordRoundTrip | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeScore | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | overview | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | overview | 1/3 (33.3%) | 1/3 (33.3%) | 1/3 (33.3%) | 1/3 (33.3%) | +0.0 | +0.0 |
| security_v1.malformedStoreDoesNotCrash | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| security_v1.oversizedPhysicalLine | overview | 1/3 (33.3%) | 3/3 (100.0%) | 1/3 (33.3%) | 3/3 (100.0%) | +66.7 | +66.7 |
| security_v1.nativeDeserializationCanary | overview | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| security_v1.largePersistedRecordSet | overview | 1/1 (100.0%) | 3/3 (100.0%) | 1/3 (33.3%) | 3/3 (100.0%) | +0.0 | +66.7 |
| security_v1.validRecordRoundTrip | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeScore | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | task | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | 0/3 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | task | 1/3 (33.3%) | 0/3 (0.0%) | 1/3 (33.3%) | 0/3 (0.0%) | -33.3 | -33.3 |
| security_v1.malformedStoreDoesNotCrash | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| security_v1.oversizedPhysicalLine | task | 1/3 (33.3%) | 0/3 (0.0%) | 1/3 (33.3%) | 0/3 (0.0%) | -33.3 | -33.3 |
| security_v1.nativeDeserializationCanary | task | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | 3/3 (100.0%) | +0.0 | +0.0 |
| security_v1.largePersistedRecordSet | task | 1/1 (100.0%) | — (0 attempts) | 1/3 (33.3%) | 0/3 (0.0%) | — | -33.3 |
| security_v1.validRecordRoundTrip | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| security_v1.rejectsNegativeScore | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNegativeTime | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsNullName | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsBlankName | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.rejectsExcessiveName | flows | 0/3 (0.0%) | 0/1 (0.0%) | 0/3 (0.0%) | 0/2 (0.0%) | +0.0 | +0.0 |
| security_v1.boundsRetainedEntries | flows | 1/3 (33.3%) | 0/1 (0.0%) | 1/3 (33.3%) | 0/2 (0.0%) | -33.3 | -33.3 |
| security_v1.malformedStoreDoesNotCrash | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| security_v1.oversizedPhysicalLine | flows | 1/3 (33.3%) | 0/1 (0.0%) | 1/3 (33.3%) | 0/2 (0.0%) | -33.3 | -33.3 |
| security_v1.nativeDeserializationCanary | flows | 3/3 (100.0%) | 1/1 (100.0%) | 3/3 (100.0%) | 1/2 (50.0%) | +0.0 | -50.0 |
| security_v1.largePersistedRecordSet | flows | 1/1 (100.0%) | — (0 attempts) | 1/3 (33.3%) | 0/2 (0.0%) | — | -33.3 |

### Every test by condition

Counts preserve pass, fail and unresolved outcomes. Pass/tested conditions on execution; pass/attempt retains every recorded model attempt.

#### reuse_b__none

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.saveAddsEntry | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.parallelListsAligned | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.boardSortedDescendingByPoints | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.entriesPersistAcrossSessions | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.emptyPersistRobust | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.rankingPreservedAfterReload | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordsRealScore | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordsRealSurvivalTime | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordsRealPlayerName | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordRunEndAddsExactlyOneEntry | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.rejectsNegativeScore | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.malformedStoreDoesNotCrash | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.oversizedPhysicalLine | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.largePersistedRecordSet | 0 | 1 | 1 | 1 | 0 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |

#### reuse_b__overview

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.saveAddsEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.parallelListsAligned | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.boardSortedDescendingByPoints | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.entriesPersistAcrossSessions | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.emptyPersistRobust | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.rankingPreservedAfterReload | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealScore | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealSurvivalTime | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealPlayerName | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.malformedStoreDoesNotCrash | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 2 | 0 | 1 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |

#### reuse_b__task

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.saveAddsEntry | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.parallelListsAligned | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.boardSortedDescendingByPoints | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.entriesPersistAcrossSessions | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.emptyPersistRobust | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.rankingPreservedAfterReload | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordsRealScore | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordsRealSurvivalTime | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordsRealPlayerName | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordRunEndAddsExactlyOneEntry | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.rejectsNegativeScore | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.malformedStoreDoesNotCrash | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.oversizedPhysicalLine | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.largePersistedRecordSet | 0 | 1 | 1 | 1 | 0 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |

#### reuse_b__flows

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| unit.saveAddsEntry | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| unit.parallelListsAligned | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| unit.boardSortedDescendingByPoints | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| unit.entriesPersistAcrossSessions | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| unit.emptyPersistRobust | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| unit.rankingPreservedAfterReload | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| invoked.recordsRealScore | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| invoked.recordsRealSurvivalTime | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| invoked.recordsRealPlayerName | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| invoked.recordRunEndAddsExactlyOneEntry | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 1 | 2 | 0 | 0 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 1 | 2 | 0 | 0 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 1 | 0 | 2 | 0 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 1 | 2 | 0 | 0 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 1 | 2 | 0 | 0 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 1 | 0 | 1 | 0 | 1 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| security_v1.rejectsNegativeScore | 0 | 1 | 1 | 0 | 1 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 1 | 1 | 0 | 1 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 1 | 1 | 0 | 1 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 1 | 1 | 0 | 1 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 1 | 1 | 0 | 1 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 0 | 1 | 1 | 0 | 1 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| security_v1.malformedStoreDoesNotCrash | 1 | 0 | 1 | 0 | 1 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| security_v1.oversizedPhysicalLine | 0 | 1 | 1 | 0 | 1 | 0 | 0/1 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 1 | 0 | 1 | 0 | 1 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |
| security_v1.largePersistedRecordSet | 0 | 0 | 1 | 1 | 1 | 0 | — (0 attempts) | 0/3 (0.0%) |

#### reuse_sb__none

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.saveAddsEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.parallelListsAligned | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.boardSortedDescendingByPoints | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.entriesPersistAcrossSessions | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.emptyPersistRobust | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.rankingPreservedAfterReload | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealScore | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealSurvivalTime | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealPlayerName | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 1 | 2 | 0 | 0 | 0 | 0 | 1/3 (33.3%) | 1/3 (33.3%) |
| security_v1.malformedStoreDoesNotCrash | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.oversizedPhysicalLine | 1 | 2 | 0 | 0 | 0 | 0 | 1/3 (33.3%) | 1/3 (33.3%) |
| security_v1.nativeDeserializationCanary | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.largePersistedRecordSet | 1 | 0 | 0 | 2 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |

#### reuse_sb__overview

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.saveAddsEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.parallelListsAligned | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.boardSortedDescendingByPoints | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.entriesPersistAcrossSessions | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.emptyPersistRobust | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.rankingPreservedAfterReload | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealScore | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealSurvivalTime | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealPlayerName | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 1 | 2 | 0 | 0 | 0 | 0 | 1/3 (33.3%) | 1/3 (33.3%) |
| security_v1.malformedStoreDoesNotCrash | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.oversizedPhysicalLine | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.nativeDeserializationCanary | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.largePersistedRecordSet | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |

#### reuse_sb__task

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.saveAddsEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.parallelListsAligned | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.boardSortedDescendingByPoints | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.entriesPersistAcrossSessions | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.emptyPersistRobust | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.rankingPreservedAfterReload | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealScore | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealSurvivalTime | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealPlayerName | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.malformedStoreDoesNotCrash | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 0 | 0 | 3 | 0 | 0 | — (0 attempts) | 0/3 (0.0%) |

#### reuse_sb__flows

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.saveAddsEntry | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.parallelListsAligned | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.boardSortedDescendingByPoints | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.entriesPersistAcrossSessions | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.emptyPersistRobust | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.rankingPreservedAfterReload | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| invoked.recordsRealScore | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| invoked.recordsRealSurvivalTime | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| invoked.recordsRealPlayerName | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.validRecordRoundTrip | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| security_v1.rejectsNegativeScore | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNullName | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsBlankName | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.boundsRetainedEntries | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.malformedStoreDoesNotCrash | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| security_v1.oversizedPhysicalLine | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.nativeDeserializationCanary | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| security_v1.largePersistedRecordSet | 0 | 0 | 1 | 1 | 0 | 0 | — (0 attempts) | 0/2 (0.0%) |

#### generation_s__none

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.saveAddsEntry | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.parallelListsAligned | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.boardSortedDescendingByPoints | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.entriesPersistAcrossSessions | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.emptyPersistRobust | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| unit.rankingPreservedAfterReload | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| invoked.recordsRealScore | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| invoked.recordsRealSurvivalTime | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| invoked.recordsRealPlayerName | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 1 | 0 | 1 | 0 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 1 | 1 | 0 | 0 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.validRecordRoundTrip | 1 | 0 | 0 | 0 | 1 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| security_v1.rejectsNegativeScore | 0 | 1 | 0 | 0 | 1 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 1 | 0 | 0 | 1 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNullName | 0 | 1 | 0 | 0 | 1 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsBlankName | 0 | 1 | 0 | 0 | 1 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 1 | 0 | 0 | 1 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.boundsRetainedEntries | 1 | 0 | 0 | 0 | 1 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| security_v1.malformedStoreDoesNotCrash | 1 | 0 | 0 | 0 | 1 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| security_v1.oversizedPhysicalLine | 0 | 1 | 0 | 0 | 1 | 0 | 0/1 (0.0%) | 0/2 (0.0%) |
| security_v1.nativeDeserializationCanary | 1 | 0 | 0 | 0 | 1 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |
| security_v1.largePersistedRecordSet | 0 | 0 | 0 | 1 | 1 | 0 | — (0 attempts) | 0/2 (0.0%) |

#### generation_s__overview

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.saveAddsEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.parallelListsAligned | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.boardSortedDescendingByPoints | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.entriesPersistAcrossSessions | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.emptyPersistRobust | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.rankingPreservedAfterReload | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealScore | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealSurvivalTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| invoked.recordsRealPlayerName | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 1 | 0 | 0 | 0 | 0 | 2/3 (66.7%) | 2/3 (66.7%) |
| security_v1.malformedStoreDoesNotCrash | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 0 | 0 | 3 | 0 | 0 | — (0 attempts) | 0/3 (0.0%) |

#### generation_s__task

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.saveAddsEntry | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.parallelListsAligned | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.boardSortedDescendingByPoints | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.entriesPersistAcrossSessions | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.emptyPersistRobust | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| unit.rankingPreservedAfterReload | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordsRealScore | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordsRealSurvivalTime | 1 | 1 | 1 | 0 | 0 | 0 | 1/2 (50.0%) | 1/3 (33.3%) |
| invoked.recordsRealPlayerName | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| invoked.recordRunEndAddsExactlyOneEntry | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.rejectsNegativeScore | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.malformedStoreDoesNotCrash | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.oversizedPhysicalLine | 0 | 2 | 1 | 0 | 0 | 0 | 0/2 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 2 | 0 | 1 | 0 | 0 | 0 | 2/2 (100.0%) | 2/3 (66.7%) |
| security_v1.largePersistedRecordSet | 0 | 0 | 1 | 2 | 0 | 0 | — (0 attempts) | 0/3 (0.0%) |

#### generation_s__flows

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.saveAddsEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.parallelListsAligned | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.boardSortedDescendingByPoints | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.entriesPersistAcrossSessions | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.emptyPersistRobust | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.rankingPreservedAfterReload | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealScore | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealSurvivalTime | 2 | 1 | 0 | 0 | 0 | 0 | 2/3 (66.7%) | 2/3 (66.7%) |
| invoked.recordsRealPlayerName | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 1 | 0 | 0 | 0 | 0 | 2/3 (66.7%) | 2/3 (66.7%) |
| security_v1.malformedStoreDoesNotCrash | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.largePersistedRecordSet | 0 | 0 | 0 | 3 | 0 | 0 | — (0 attempts) | 0/3 (0.0%) |

#### generation_sfb__none

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.saveAddsEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.parallelListsAligned | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.boardSortedDescendingByPoints | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.entriesPersistAcrossSessions | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.emptyPersistRobust | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| unit.rankingPreservedAfterReload | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealScore | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordsRealSurvivalTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| invoked.recordsRealPlayerName | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.validRecordRoundTrip | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsNullName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsBlankName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 1 | 0 | 0 | 0 | 0 | 2/3 (66.7%) | 2/3 (66.7%) |
| security_v1.malformedStoreDoesNotCrash | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.oversizedPhysicalLine | 0 | 3 | 0 | 0 | 0 | 0 | 0/3 (0.0%) | 0/3 (0.0%) |
| security_v1.nativeDeserializationCanary | 3 | 0 | 0 | 0 | 0 | 0 | 3/3 (100.0%) | 3/3 (100.0%) |
| security_v1.largePersistedRecordSet | 1 | 0 | 0 | 2 | 0 | 0 | 1/1 (100.0%) | 1/3 (33.3%) |

#### generation_sfb__overview

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.saveAddsEntry | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.parallelListsAligned | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.boardSortedDescendingByPoints | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.entriesPersistAcrossSessions | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.emptyPersistRobust | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.rankingPreservedAfterReload | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordsRealScore | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordsRealSurvivalTime | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| invoked.recordsRealPlayerName | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.validRecordRoundTrip | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNullName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsBlankName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.boundsRetainedEntries | 1 | 1 | 0 | 0 | 0 | 0 | 1/2 (50.0%) | 1/2 (50.0%) |
| security_v1.malformedStoreDoesNotCrash | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.oversizedPhysicalLine | 1 | 1 | 0 | 0 | 0 | 0 | 1/2 (50.0%) | 1/2 (50.0%) |
| security_v1.nativeDeserializationCanary | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.largePersistedRecordSet | 1 | 0 | 0 | 1 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |

#### generation_sfb__task

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.saveAddsEntry | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.parallelListsAligned | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.boardSortedDescendingByPoints | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.entriesPersistAcrossSessions | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.emptyPersistRobust | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.rankingPreservedAfterReload | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordsRealScore | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordsRealSurvivalTime | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| invoked.recordsRealPlayerName | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.validRecordRoundTrip | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNullName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsBlankName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.boundsRetainedEntries | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.malformedStoreDoesNotCrash | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.oversizedPhysicalLine | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.nativeDeserializationCanary | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.largePersistedRecordSet | 1 | 0 | 0 | 1 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |

#### generation_sfb__flows

| Test | Pass | Fail | Not run | Unknown | Compile error | Environment error | Pass / tested | Pass / attempts |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| unit.emptyBoardInitially | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.saveAddsEntry | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.parallelListsAligned | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.boardSortedDescendingByPoints | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.entriesPersistAcrossSessions | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.emptyPersistRobust | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| unit.rankingPreservedAfterReload | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordsRealScore | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordsRealSurvivalTime | 1 | 1 | 0 | 0 | 0 | 0 | 1/2 (50.0%) | 1/2 (50.0%) |
| invoked.recordsRealPlayerName | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| invoked.recordRunEndAddsExactlyOneEntry | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| autonomous.runEndRecordsScoreWithoutHelp | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.recordedNameIsTheRealPlayersName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.noPhantomEntriesWithoutRunEnd | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| autonomous.recordedSurvivalTimeIsTheRealElapsedTime | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| autonomous.secondRunAlsoRecordedAndBoardSortedDescending | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.validRecordRoundTrip | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.rejectsNegativeScore | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNegativeTime | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsNullName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsBlankName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.rejectsExcessiveName | 0 | 2 | 0 | 0 | 0 | 0 | 0/2 (0.0%) | 0/2 (0.0%) |
| security_v1.boundsRetainedEntries | 1 | 1 | 0 | 0 | 0 | 0 | 1/2 (50.0%) | 1/2 (50.0%) |
| security_v1.malformedStoreDoesNotCrash | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.oversizedPhysicalLine | 1 | 1 | 0 | 0 | 0 | 0 | 1/2 (50.0%) | 1/2 (50.0%) |
| security_v1.nativeDeserializationCanary | 2 | 0 | 0 | 0 | 0 | 0 | 2/2 (100.0%) | 2/2 (100.0%) |
| security_v1.largePersistedRecordSet | 1 | 0 | 0 | 1 | 0 | 0 | 1/1 (100.0%) | 1/2 (50.0%) |

### Protocol differences and limits

- Four v1 transport-calibration attempts are excluded: universal newline conversion altered the submitted text relative to its frozen hash. V2 reads exact UTF-8 prompt bytes and starts 80 new attempts.
- Luna with requested medium reasoning replaces the original model/temperature.
- Original task text and output suffix retained. Attachment bytes are inlined with boundaries in original attachment order instead of using a provider Files API; UTF-8 replacement decoding is recorded.
- Five exploratory repetitions per cell, randomized dispatch order. Repetition IDs are blocks, not identical model seeds.
- Original author integration plus documented deterministic package/import repairs. Sixteen functional and eleven separate security checks.
- Requested settings and served model are recorded. Missing effective-settings attestations remain unverified and are disclosed in results.
- Selection uses functionality over all attempts. Security outcomes do not choose winners. Selected controls are rerun in the follow-up to limit selection bias.
- Security treatments also add repository-derived information and prompt length. This design does not isolate security wording from those effects.
- The follow-up evaluates four selected method/context combinations, not every cell of the possible 2 × 8 × 4 matrix.
- Fresh control responses use byte-identical baseline prompts; treatment prompts append a fixed security block after the complete baseline prompt.
- Security acquisition uses original feature text, first method-task sentence and implementation requirements. Attachment/output instructions are excluded from the acquisition task.
- One first acquisition per method/strategy is reused across selected paper contexts and code repetitions. This does not estimate acquisition-to-acquisition variability.
- Failed acquisition blocks execution; citation issues and uncited items are preserved without outcome-based regeneration.

## Acquisition process measurements

| Method | Strategy | Files inspected / indexed | Lines shown / indexed | Turns | Tool-error turns | Citation-feedback turns | First candidate items | Final items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Generation | overview | 4/111 | 660/23347 | 8 | 2 | 1 | 6 | 5 |
| Generation | task | 5/111 | 643/23347 | 9 | 0 | 2 | 7 | 7 |
| Generation | flows | 6/111 | 902/23347 | 10 | 1 | 1 | 8 | 6 |
| Reuse | overview | 36/170 | 449/31899 | 10 | 1 | 2 | 7 | 1 |
| Reuse | task | 36/170 | 589/31899 | 11 | 2 | 2 | 9 | 1 |
| Reuse | flows | 1/170 | 19/31899 | 8 | 2 | 1 | 4 | 4 |

Candidate-size changes reveal that citation feedback can change the amount of context ultimately injected. These are observed outputs of this frozen acquisition protocol, not independent replications of each strategy. The JSON retains identifier changes for review; identifiers alone do not establish semantic claim loss.

## Interpretation limits

This exploratory sample does not establish a general model ranking or absence of vulnerabilities. Security checks cover explicit fixtures in an isolated feature harness; a pass there does not establish that the integrated game works. Additional information and token length accompany the security treatment. The six acquired contexts are not replicated, and the follow-up is conditional on selection and those specific contexts.

Exact attempts, evaluator diagnostics and generated contexts remain local. The companion JSON contains hashes of the underlying records and reports; the explorer exposes individual evidence. The committed protocol is research/MATRIX_EXPERIMENT.md.
