package apoMario.game.panels;

import apoMario.game.panels.ApoMarioHighscoreView;

/** Marker view type for menu integrations that need a dedicated highscore view. */
public final class ApoMarioHighscoreView {
    private ApoMarioHighscoreView() { }
}